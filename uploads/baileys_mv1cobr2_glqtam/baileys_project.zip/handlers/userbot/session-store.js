const fs = require("fs");
const path = require("path");

const SESSION_DIR = path.join(__dirname, "..", "..", "database", "userbot_sessions");
if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true });

const ROLE_FILE = path.join(__dirname, "..", "..", "database", "userbot_roles.json");
if (!fs.existsSync(ROLE_FILE)) fs.writeFileSync(ROLE_FILE, "{}", "utf8");

const PENDING_FILE = path.join(__dirname, "..", "..", "database", "userbot_pending.json");
if (!fs.existsSync(PENDING_FILE)) fs.writeFileSync(PENDING_FILE, "{}", "utf8");

const MODE_FILE = path.join(__dirname, "..", "..", "database", "userbot_mode.json");
if (!fs.existsSync(MODE_FILE)) fs.writeFileSync(MODE_FILE, "{}", "utf8");

// ═══ SESSION ═══
function getSessionPath(userId) {
    return path.join(SESSION_DIR, `${userId}.json`);
}

function loadSession(userId) {
    const p = getSessionPath(userId);
    if (!fs.existsSync(p)) return null;
    try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return null; }
}

function saveSession(userId, data) {
    fs.writeFileSync(getSessionPath(userId), JSON.stringify(data, null, 2), "utf8");
}

function deleteSession(userId) {
    const p = getSessionPath(userId);
    if (fs.existsSync(p)) fs.unlinkSync(p);
}

function listSessions() {
    return fs.readdirSync(SESSION_DIR).filter(f => f.endsWith(".json")).map(f => f.replace(".json", ""));
}

// ═══ ROLE USERBOT ═══
function readRoles() {
    try { return JSON.parse(fs.readFileSync(ROLE_FILE, "utf8")); } catch { return {}; }
}

function writeRoles(data) {
    fs.writeFileSync(ROLE_FILE, JSON.stringify(data, null, 2), "utf8");
}

function getUserRole(userId) {
    const roles = readRoles();
    return roles[String(userId)] || null;
}

function setUserRole(userId, role, days = 0) {
    const roles = readRoles();
    roles[String(userId)] = {
        role,
        expiresAt: days > 0 ? Date.now() + days * 24 * 60 * 60 * 1000 : 0,
        createdAt: Date.now()
    };
    writeRoles(roles);
}

function removeUserRole(userId) {
    const roles = readRoles();
    delete roles[String(userId)];
    writeRoles(roles);
}

function checkExpiredRoles() {
    const roles = readRoles();
    const now = Date.now();
    let changed = false;
    for (const uid in roles) {
        if (roles[uid].expiresAt && now > roles[uid].expiresAt) {
            delete roles[uid];
            changed = true;
        }
    }
    if (changed) writeRoles(roles);
}

// ═══ MODE (self / public) ═══
function readModes() {
    try { return JSON.parse(fs.readFileSync(MODE_FILE, "utf8")); } catch { return {}; }
}

function writeModes(data) {
    fs.writeFileSync(MODE_FILE, JSON.stringify(data, null, 2), "utf8");
}

/**
 * Get mode userbot
 * @param {string} userId - ID userbot (Telegram user ID)
 * @returns {"self"|"public"}
 */
function getMode(userId) {
    const modes = readModes();
    const mode = modes[String(userId)];
    if (mode === "public" || mode === "self") return mode;
    return "self"; // default: self
}

/**
 * Set mode userbot
 * @param {string} userId
 * @param {"self"|"public"} mode
 */
function setMode(userId, mode) {
    if (!["self", "public"].includes(mode)) return false;
    const modes = readModes();
    modes[String(userId)] = mode;
    writeModes(modes);
    return true;
}

function isSelfMode(userId) {
    return getMode(userId) === "self";
}

function isPublicMode(userId) {
    return getMode(userId) === "public";
}

// ═══ PENDING LOGIN ═══
function readPending() {
    try { return JSON.parse(fs.readFileSync(PENDING_FILE, "utf8")); } catch { return {}; }
}

function writePending(data) {
    fs.writeFileSync(PENDING_FILE, JSON.stringify(data, null, 2), "utf8");
}

function getPending(userId) {
    const pending = readPending();
    return pending[String(userId)] || null;
}

function setPending(userId, data) {
    const pending = readPending();
    pending[String(userId)] = { ...data, updatedAt: Date.now() };
    writePending(pending);
}

function clearPending(userId) {
    const pending = readPending();
    delete pending[String(userId)];
    writePending(pending);
}

setInterval(checkExpiredRoles, 60 * 1000);

module.exports = {
    loadSession,
    saveSession,
    deleteSession,
    listSessions,
    getUserRole,
    setUserRole,
    removeUserRole,
    readRoles,
    writeRoles,
    getMode,
    setMode,
    isSelfMode,
    isPublicMode,
    readModes,
    writeModes,
    getPending,
    setPending,
    clearPending
};