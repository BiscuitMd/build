// ═══════════════════════════════════════════
// USERBOT LOGIN — Telegram MTProto (GramJS 2.26)
// v16 — FINAL: COMMAND MENU (modern iOS style)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const store = require("./session-store");

const API_ID = 37192283;
const API_HASH = "18e59914ed0b123b1120e4c9a516e43c";

const ACTIVE_CLIENTS = new Map();
const PENDING_LOGINS = new Map();

function cleanOtp(text) {
    return String(text || "").replace(/[\s\-_]/g, "").trim();
}

// ═══ ICON SET — iOS Style ═══
const ICON = {
    diamond: "◆",
    diamondOut: "◇",
    bullet: "▸",
    bulletOut: "▪",
    arrow: "→",
    arrowRight: "⇒",
    dot: "●",
    dotOut: "○",
    circle: "◉",
    square: "■",
    squareOut: "□",
    triangle: "▲",
    star: "✦",
    check: "✓",
    cross: "✕",
    line: "─",
    doubleLine: "═",
    cornerTL: "╭",
    cornerTR: "╮",
    cornerBL: "╰",
    cornerBR: "╯",
    pipe: "│",
    teeL: "├",
    teeR: "┤",
    title: "【",
    titleEnd: "】",
    angleL: "「",
    angleR: "」",
};

// ═══ CATEGORY ICON (tanpa emoji) ═══
const CATEGORY_ICON = {
    ai: "◈",
    download: "▣",
    fun: "✦",
    tools: "⚙",
    info: "◉",
    media: "▤",
    text: "▥",
    crypto: "◆",
    osint: "◎",
    admin: "▲",
    group: "▦",
    build: "▧",
    forward: "⇒",
    general: "▪",
    userbot: "●"
};

function getCategoryIcon(cat) {
    return CATEGORY_ICON[cat] || "▪";
}

// ═══ START LOGIN ═══
async function startLogin(bot, chatId, userId, phoneNumber, ctx) {
    try {
        const session = new StringSession("");
        const client = new TelegramClient(session, API_ID, API_HASH, {
            connectionRetries: 3,
            useWSS: false
        });

        await client.connect();

        let phoneCodeHash;
        let codeType = "app";
        try {
            const result = await client.invoke(
                new Api.auth.SendCode({
                    phoneNumber,
                    apiId: API_ID,
                    apiHash: API_HASH,
                    settings: new Api.CodeSettings({})
                })
            );
            phoneCodeHash = result.phoneCodeHash;

            if (result.type) {
                const typeName = result.type.className || "";
                if (typeName.includes("App")) codeType = "app";
                else if (typeName.includes("Sms")) codeType = "sms";
                else if (typeName.includes("Call")) codeType = "call";
                else if (typeName.includes("FlashCall")) codeType = "flash";
            }
        } catch (e) {
            console.log("[USERBOT] sendCode fail:", e.message);
            try { await client.disconnect(); } catch {}
            let errMsg = e.message || "Unknown error";
            if (errMsg.includes("PHONE_NUMBER_INVALID")) errMsg = "Nomor HP salah format";
            else if (errMsg.includes("PHONE_NUMBER_BANNED")) errMsg = "Nomor HP di-ban";
            else if (errMsg.includes("FLOOD_WAIT")) {
                const m = errMsg.match(/FLOOD_WAIT_(\d+)/);
                errMsg = m ? `Tunggu ${m[1]} detik` : "Flood wait";
            }
            return { ok: false, error: errMsg };
        }

        PENDING_LOGINS.set(String(userId), {
            client, phoneNumber, phoneCodeHash, step: "otp", createdAt: Date.now()
        });

        ctx.setState(String(userId), "userbot_await_otp", { phoneNumber });

        const codeTypeText = codeType === "app" ? "Telegram App" :
                             codeType === "sms" ? "SMS" :
                             codeType === "call" ? "Telepon" : "Telegram";

        await bot.sendMessage(chatId,
            `<b>${ICON.cornerTL}${ICON.line.repeat(20)}${ICON.cornerTR}</b>\n` +
            `<b>${ICON.pipe}  ${ICON.check} KODE OTP DIKIRIM  ${ICON.pipe}</b>\n` +
            `<b>${ICON.cornerBL}${ICON.line.repeat(20)}${ICON.cornerBR}</b>\n\n` +
            `${ICON.bullet} Nomor: <code>${phoneNumber}</code>\n` +
            `${ICON.bullet} Metode: <b>${codeTypeText}</b>\n\n` +
            `<b>${ICON.arrow} Cara kirim OTP:</b>\n` +
            `${ICON.bulletOut} Ketik <b>5 digit</b> OTP ke chat ini\n` +
            `${ICON.bulletOut} Bisa pake spasi: <code>1 2 3 4 5</code>\n` +
            `${ICON.bulletOut} Bisa tanpa spasi: <code>12345</code>`,
            { parse_mode: "HTML" });

        return { ok: true };
    } catch (e) {
        console.log("[USERBOT] startLogin exception:", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ VERIFY OTP ═══
async function verifyOtp(userId, otpCode, bot, chatId, ctx) {
    const uid = String(userId);
    const pending = PENDING_LOGINS.get(uid);
    if (!pending) return { ok: false, error: "Sesi login hilang." };

    try {
        const { client, phoneNumber, phoneCodeHash } = pending;
        const cleanCode = cleanOtp(otpCode);

        try {
            await client.invoke(
                new Api.auth.SignIn({ phoneNumber, phoneCodeHash, phoneCode: cleanCode })
            );
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("SESSION_PASSWORD_NEEDED")) {
                pending.step = "password";
                PENDING_LOGINS.set(uid, pending);
                ctx.setState(uid, "userbot_await_password", {});
                await bot.sendMessage(chatId,
                    `<b>${ICON.cornerTL}${ICON.line.repeat(20)}${ICON.cornerTR}</b>\n` +
                    `<b>${ICON.pipe}  ${ICON.dot} 2FA REQUIRED  ${ICON.pipe}</b>\n` +
                    `<b>${ICON.cornerBL}${ICON.line.repeat(20)}${ICON.cornerBR}</b>\n\n` +
                    `Kirim <b>password 2FA</b> lu ke chat ini.`,
                    { parse_mode: "HTML" });
                return { ok: false, needPassword: true };
            }
            if (msg.includes("PHONE_CODE_INVALID") || msg.includes("PHONE_CODE_EXPIRED")) {
                return { ok: false, error: msg.includes("EXPIRED") ? "Kode OTP expired." : "Kode OTP salah." };
            }
            throw e;
        }

        return await finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx);
    } catch (e) {
        console.log("[USERBOT] verifyOtp fail:", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ VERIFY 2FA ═══
async function verifyPassword(userId, password, bot, chatId, ctx) {
    const uid = String(userId);
    const pending = PENDING_LOGINS.get(uid);
    if (!pending) return { ok: false, error: "Sesi 2FA hilang." };

    if (pending.step !== "password") {
        try {
            const authorized = await pending.client.checkAuthorization();
            if (authorized) {
                return await finalizeLogin(userId, pending.client, pending.phoneNumber, bot, chatId, ctx);
            }
        } catch {}
        return { ok: false, error: "Sesi 2FA hilang." };
    }

    try {
        const { client, phoneNumber } = pending;
        const pwdInfo = await client.invoke(new Api.account.GetPassword());
        const { computeCheck } = require("telegram/Password");
        const pwdCheck = await computeCheck(pwdInfo, password);

        try {
            await client.invoke(new Api.auth.CheckPassword({ password: pwdCheck }));
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("PASSWORD_HASH_INVALID") || msg.includes("SRP_ID_INVALID")) {
                try {
                    const authorized = await client.checkAuthorization();
                    if (authorized) {
                        return await finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx);
                    }
                } catch {}
                return { ok: false, error: "Password 2FA salah." };
            }
            throw e;
        }

        return await finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx);
    } catch (e) {
        try {
            const authorized = await pending.client.checkAuthorization();
            if (authorized) {
                return await finalizeLogin(userId, pending.client, pending.phoneNumber, bot, chatId, ctx);
            }
        } catch {}
        return { ok: false, error: e.message };
    }
}

// ═══ FINALIZE ═══
async function finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx) {
    try {
        const uid = String(userId);
        const sessionString = client.session.save();

        store.saveSession(uid, { phone: phoneNumber, sessionString, connectedAt: Date.now() });

        ACTIVE_CLIENTS.set(uid, client);
        PENDING_LOGINS.delete(uid);
        store.clearPending(uid);
        ctx.clearState(uid);

        setupEventHandler(userId, client, bot);

        let userName = "-";
        try {
            const me = await client.getMe();
            userName = [me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "-";
        } catch {}

        const currentMode = store.getMode(uid);

        await bot.sendMessage(chatId,
            `<b>${ICON.cornerTL}${ICON.line.repeat(22)}${ICON.cornerTR}</b>\n` +
            `<b>${ICON.pipe}  ${ICON.check} USERBOT CONNECTED  ${ICON.pipe}</b>\n` +
            `<b>${ICON.cornerBL}${ICON.line.repeat(22)}${ICON.cornerBR}</b>\n\n` +
            `${ICON.bullet} Nama: <b>${userName}</b>\n` +
            `${ICON.bullet} Mode: <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `${ICON.bullet} Status: <b>ONLINE</b>\n\n` +
            `Ketik <code>.menu</code> buat mulai`,
            { parse_mode: "HTML" });

        return { ok: true };
    } catch (e) {
        console.log("[USERBOT] finalizeLogin fail:", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ SETUP EVENT HANDLER ═══
function setupEventHandler(userId, client, bot) {
    client.addEventHandler(async (msg) => {
        try {
            const text = msg.message?.message || msg.message?.text || "";
            if (!text) return;

            const senderId = msg.message?.senderId?.toString() || "";
            const isFromMe = !!msg.message?.out;
            const isFromSelf = String(senderId) === String(userId);

            const mode = store.getMode(userId);

const PUBLIC_CMDS = [
    "chess", "uno", "poker", "billiard", "pokemon",
    "ular", "puzzle", "botol", "mancing", "zombie",
    "claim", "gamecoin", "coin", "mycoin",
    "menu_game", "menugame", "game", "games"
];

const textLower = (msg.message?.message || msg.message?.text || "").toLowerCase();
const isPublicCmd = PUBLIC_CMDS.some(c => textLower.startsWith("." + c));

if (mode === "self") {
    if (!isFromSelf && !isFromMe && !isPublicCmd) return;
}

if (text.startsWith(".")) {
    const args = text.slice(1).trim().split(/\s+/);
    const cmd = args.shift().toLowerCase();
    await handleUserbotCommand(userId, client, msg, cmd, args, bot);
    return;
}

            if (!isFromMe) {
    try {
        const autofw = require("./modules/autofw");
        if (typeof autofw.handleForward === "function") {
            await autofw.handleForward(userId, client, msg);
        }
    } catch {}

    try {
        const autorespon = require("./modules/autorespon");
        if (typeof autorespon.handleIncoming === "function") {
            await autorespon.handleIncoming(userId, client, msg);
        }
    } catch (e) {
        console.log("[AUTORESPOON HOOK ERR]", e.message.slice(0, 100));
    }

    try {
        const afk = require("./modules/afk");
        if (typeof afk.handleIncoming === "function") {
            await afk.handleIncoming(userId, client, msg);
        }
    } catch (e) {
        console.log("[AFK HOOK ERR]", e.message.slice(0, 100));
    }
}
        } catch (e) {
            console.log("[USERBOT EVENT ERR]", e.message.slice(0, 100));
        }
    }, new NewMessage({}));

    console.log(`[USERBOT] ✅ Event handler aktif`);
}

// ═══════════════════════════════════════════
// HANDLE COMMAND
// ═══════════════════════════════════════════
async function handleUserbotCommand(userId, client, msg, cmd, args, bot) {
    const peerId = msg.message.peerId;
    const chatId = String(msg.message.chatId || "");

    console.log(`[UBOT CMD] .${cmd}`);

    try {
        // ═══════════════════════════════════
        // .menu — MENU UTAMA
        // ═══════════════════════════════════
        if (cmd === "menu") {
            const loader = require("./module-loader");
            const groups = loader.groupByCategory();
            const totalModules = loader.listModules().length;
            const totalCategories = Object.keys(groups).length;
            const currentMode = store.getMode(userId);

            let me = null;
            try { me = await client.getMe(); } catch {}
            const userName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "User") : "User";
            const userUsername = me?.username ? "@" + me.username : "-";

            const userRole = store.getUserRole(userId);
            const roleName = userRole ? userRole.role.toUpperCase() : "FREE";

            let expiredText = "UNLIMITED";
            if (userRole && userRole.expiresAt) {
                const days = Math.ceil((userRole.expiresAt - Date.now()) / 86400000);
                expiredText = days > 0 ? `${days} DAYS` : "EXPIRED";
            }

            const categories = Object.keys(groups).sort();

            let menuList = "";
            for (const cat of categories) {
                const icon = getCategoryIcon(cat);
                const count = groups[cat].length;
                const paddedCat = cat.padEnd(10, " ");
                menuList += `${ICON.bullet} <code>.menu_${cat}</code>\n`;
                menuList += `  ${icon} ${paddedCat} ${ICON.dotOut} ${count} cmd\n`;
            }

            const caption =
                `${ICON.cornerTL}${ICON.doubleLine.repeat(11)}${ICON.cornerTR}\n` +
                `${ICON.pipe}  ${ICON.star} USERBOT MENU ${ICON.star}  ${ICON.pipe}\n` +
                `${ICON.cornerBL}${ICON.doubleLine.repeat(11)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                `${ICON.pipe} ${ICON.diamond} ACCOUNT INFO\n` +
                `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                `${ICON.pipe} ${ICON.bullet} Username  ${ICON.arrow}  <code>${userUsername}</code>\n` +
                `${ICON.pipe} ${ICON.bullet} Name      ${ICON.arrow}  ${userName.slice(0, 20)}\n` +
                `${ICON.pipe} ${ICON.bullet} Mode      ${ICON.arrow}  <b>${currentMode.toUpperCase()}</b>\n` +
                `${ICON.pipe} ${ICON.bullet} Role      ${ICON.arrow}  <b>${roleName}</b>\n` +
                `${ICON.pipe} ${ICON.bullet} Expired   ${ICON.arrow}  ${expiredText}\n` +
                `${ICON.pipe} ${ICON.bullet} Modules   ${ICON.arrow}  <code>${totalModules}</code>\n` +
                `${ICON.pipe} ${ICON.bullet} Category  ${ICON.arrow}  <code>${totalCategories}</code>\n` +
                `${ICON.pipe} ${ICON.bullet} Status    ${ICON.arrow}  <b>ONLINE</b>\n` +
                `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                `${ICON.pipe} ${ICON.square} CATEGORIES\n` +
                `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                menuList +
                `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.arrow} <b>Usage:</b>\n` +
                `${ICON.bulletOut} Ketik <code>.menu_[kategori]</code>\n` +
                `${ICON.bulletOut} Contoh: <code>.menu_ai</code>`;

            const path = require("path");
            let cfg = {};
            try { cfg = require(path.join(__dirname, "..", "..", "config.js")); } catch {}
            const fotoUrl = cfg?.FOTO?.MENU || "https://files.catbox.moe/3hj0vu.png";

            try {
                await client.sendFile(peerId, {
                    file: fotoUrl,
                    caption: caption,
                    parseMode: "html"
                });
                console.log("[UBOT MENU] ✅ sent");
            } catch (e) {
                await client.sendMessage(peerId, {
                    message: caption,
                    parseMode: "html"
                });
                console.log("[UBOT MENU] ✅ sent (text)");
            }
            return;
        }

        // ═══════════════════════════════════
        // .menu_[kategori] — MENU KATEGORI
        // ═══════════════════════════════════
        if (cmd.startsWith("menu_")) {
            const category = cmd.slice(5);
            const loader = require("./module-loader");
            const groups = loader.groupByCategory();
            const modules = groups[category];

            if (!modules) {
                return client.sendMessage(peerId, {
                    message:
                        `${ICON.cross} Kategori <code>${category}</code> gaada\n\n` +
                        `Ketik <code>.menu</code> buat liat semua kategori`,
                    parseMode: "html"
                });
            }

            const icon = getCategoryIcon(category);

            let cmdList = "";
            for (const m of modules) {
                const paddedCmd = (m.command + " ").padEnd(14, " ");
                const desc = (m.description || "-").slice(0, 30);
                cmdList += `${ICON.bullet} <code>.${paddedCmd}</code>\n`;
                cmdList += `  ${ICON.bulletOut} ${desc}\n`;
            }

            const caption =
                `${ICON.cornerTL}${ICON.doubleLine.repeat(11)}${ICON.cornerTR}\n` +
                `${ICON.pipe}  ${icon} ${category.toUpperCase()} ${icon}  ${ICON.pipe}\n` +
                `${ICON.cornerBL}${ICON.doubleLine.repeat(11)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                `${ICON.pipe} ${ICON.diamond} INFO\n` +
                `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                `${ICON.pipe} ${ICON.bullet} Total    ${ICON.arrow}  <code>${modules.length}</code> commands\n` +
                `${ICON.pipe} ${ICON.bullet} Category ${ICON.arrow}  <code>${category}</code>\n` +
                `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                `${ICON.pipe} ${ICON.square} COMMANDS\n` +
                `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                cmdList +
                `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.arrow} <b>Usage:</b>\n` +
                `${ICON.bulletOut} Ketik command tanpa tanda <code>.</code>\n` +
                `${ICON.bulletOut} Contoh: <code>.${modules[0]?.command || "ping"}</code>\n` +
                `${ICON.bulletOut} Balik menu: <code>.menu</code>`;

            try {
                await client.sendMessage(peerId, {
                    message: caption,
                    parseMode: "html"
                });
                console.log(`[UBOT MENU] ✅ category: ${category}`);
            } catch (e) {
                console.log(`[UBOT MENU] category fail:`, e.message.slice(0, 100));
            }
            return;
        }

        // ═══════════════════════════════════
        // .help — BANTUAN
        // ═══════════════════════════════════
        if (cmd === "help" || cmd === "h") {
            const loader = require("./module-loader");
            const totalModules = loader.listModules().length;

            const caption =
                `${ICON.cornerTL}${ICON.doubleLine.repeat(11)}${ICON.cornerTR}\n` +
                `${ICON.pipe}  ${ICON.star} HELP MENU ${ICON.star}  ${ICON.pipe}\n` +
                `${ICON.cornerBL}${ICON.doubleLine.repeat(11)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                `${ICON.pipe} ${ICON.diamond} BASIC COMMANDS\n` +
                `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.menu</code>       ${ICON.arrow}  Menu utama\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.help</code>       ${ICON.arrow}  Bantuan\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.ping</code>       ${ICON.arrow}  Test bot\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.id</code>         ${ICON.arrow}  Info chat\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.mode self</code>  ${ICON.arrow}  Private mode\n` +
                `${ICON.pipe} ${ICON.bullet} <code>.mode public</code>${ICON.arrow}  Public mode\n` +
                `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n` +
                `\n` +
                `${ICON.arrow} Total <code>${totalModules}</code> commands available\n` +
                `${ICON.bulletOut} Ketik <code>.menu</code> buat liat semua`;

            await client.sendMessage(peerId, { message: caption, parseMode: "html" });
            return;
        }

        // ═══════════════════════════════════
        // .mode
        // ═══════════════════════════════════
        if (cmd === "mode") {
            const senderId = msg.message?.senderId?.toString() || "";
            const isFromMe = !!msg.message?.out;
            const isFromSelf = String(senderId) === String(userId);

            if (!isFromSelf && !isFromMe) {
                return client.sendMessage(peerId, {
                    message: `${ICON.cross} Cuma owner userbot yang bisa ganti mode`
                });
            }

            const newMode = args[0]?.toLowerCase();
            const currentMode = store.getMode(userId);

            if (!newMode) {
                return client.sendMessage(peerId, {
                    message:
                        `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                        `${ICON.pipe} ${ICON.diamond} USERBOT MODE\n` +
                        `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                        `${ICON.pipe} ${ICON.bullet} Current  ${ICON.arrow}  <b>${currentMode.toUpperCase()}</b>\n` +
                        `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}\n\n` +
                        `${ICON.arrow} <b>Usage:</b>\n` +
                        `${ICON.bulletOut} <code>.mode self</code>\n` +
                        `${ICON.bulletOut} <code>.mode public</code>`,
                    parseMode: "html"
                });
            }

            if (!["self", "public"].includes(newMode)) {
                return client.sendMessage(peerId, {
                    message: `${ICON.cross} Mode invalid\n\n${ICON.bulletOut} <code>self</code>\n${ICON.bulletOut} <code>public</code>`,
                    parseMode: "html"
                });
            }

            if (currentMode === newMode) {
                return client.sendMessage(peerId, {
                    message: `${ICON.square} Mode udah <b>${newMode.toUpperCase()}</b>`,
                    parseMode: "html"
                });
            }

            store.setMode(userId, newMode);
            await client.sendMessage(peerId, {
                message:
                    `${ICON.check} Mode: <b>${currentMode.toUpperCase()}</b> ${ICON.arrowRight} <b>${newMode.toUpperCase()}</b>\n\n` +
                    (newMode === "self" ? `${ICON.dot} Private mode: cuma lu` : `${ICON.dot} Public mode: semua orang`),
                parseMode: "html"
            });
            return;
        }

        // ═══════════════════════════════════
        // .ping
        // ═══════════════════════════════════
        if (cmd === "ping") {
            const start = Date.now();
            const sent = await client.sendMessage(peerId, { message: "▸ Pinging..." });
            const latency = Date.now() - start;
            try {
                await client.editMessage(peerId, {
                    message: sent.id,
                    text: `${ICON.check} Pong! <code>${latency}ms</code>`,
                    parseMode: "html"
                });
            } catch {
                await client.sendMessage(peerId, { message: `${ICON.check} Pong! <code>${latency}ms</code>`, parseMode: "html" });
            }
            return;
        }

        // ═══════════════════════════════════
        // .id
        // ═══════════════════════════════════
        if (cmd === "id") {
            const senderId = msg.message?.senderId?.toString() || "";
            await client.sendMessage(peerId, {
                message:
                    `${ICON.cornerTL}${ICON.line.repeat(18)}${ICON.cornerTR}\n` +
                    `${ICON.pipe} ${ICON.diamond} CHAT INFO\n` +
                    `${ICON.teeL}${ICON.line.repeat(18)}\n` +
                    `${ICON.pipe} ${ICON.bullet} Chat ID    ${ICON.arrow}  <code>${chatId}</code>\n` +
                    `${ICON.pipe} ${ICON.bullet} Sender ID  ${ICON.arrow}  <code>${senderId}</code>\n` +
                    `${ICON.cornerBL}${ICON.line.repeat(18)}${ICON.cornerBR}`,
                parseMode: "html"
            });
            return;
        }

        // ═══════════════════════════════════
        // Auto-load module
        // ═══════════════════════════════════
        const loader = require("./module-loader");
        const handled = await loader.execute(userId, client, msg, cmd, args, bot);
        if (handled) return;

        await client.sendMessage(peerId, {
            message:
                `${ICON.cross} Command <code>.${cmd}</code> gaada\n\n` +
                `Ketik <code>.menu</code> buat liat semua command`,
            parseMode: "html"
        });
    } catch (e) {
        console.log("[USERBOT CMD ERR]", e.message);
    }
}

// ═══ RESTORE ═══
async function restoreAllSessions(bot) {
    const userIds = store.listSessions();
    console.log(`[USERBOT] restore ${userIds.length} sesi...`);

    for (const userId of userIds) {
        try {
            const sessionData = store.loadSession(userId);
            if (!sessionData?.sessionString) continue;

            const session = new StringSession(sessionData.sessionString);
            const client = new TelegramClient(session, API_ID, API_HASH, {
                connectionRetries: 3,
                useWSS: false
            });

            await client.connect();
            ACTIVE_CLIENTS.set(String(userId), client);
            setupEventHandler(userId, client, bot);
            console.log(`[USERBOT] ✅ restored ${userId}`);
        } catch (e) {
            console.log(`[USERBOT] restore ${userId} fail:`, e.message);
        }
    }
}

function getClient(userId) {
    return ACTIVE_CLIENTS.get(String(userId));
}

async function stopClient(userId) {
    const client = ACTIVE_CLIENTS.get(String(userId));
    if (client) {
        try { await client.disconnect(); } catch {}
        ACTIVE_CLIENTS.delete(String(userId));
    }
    store.deleteSession(userId);

    // ⚡ Cleanup build keep-alive
    try {
        const build = require("./modules/build");
        if (build && typeof build.cleanup === "function") {
            build.cleanup(userId);
        }
    } catch {}
}

function cancelLogin(userId) {
    const pending = PENDING_LOGINS.get(String(userId));
    if (pending) {
        try { pending.client.disconnect(); } catch {}
        PENDING_LOGINS.delete(String(userId));
    }
    store.clearPending(userId);
}

module.exports = {
    startLogin, verifyOtp, verifyPassword,
    restoreAllSessions, getClient, stopClient, cancelLogin,
    API_ID, API_HASH
};

console.log("[USERBOT LOGIN] module loaded (v16 — modern iOS)");