// ═══════════════════════════════════════════
// MENU CALLBACK — Handler klik button menu userbot
// v1 — Edit message, bukan kirim baru
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const path = require("path");
const router = require(path.join(__dirname, "..", "..", "modules", "router.js"));
const cfg = require(path.join(__dirname, "..", "..", "config.js"));
const loader = require("./module-loader");

// ═══ OPEN MENU MODULE ═══
router.registerCallback("ubot_menu_open", async (bot, q, data, user, ctx) => {
    try {
        const category = data.split(":")[1] || "general";
        await showCategoryMenu(bot, q, category, ctx);
    } catch (e) {
        console.log("[UBOT MENU OPEN ERR]", e.message);
    }
});

// ═══ SHOW CATEGORY MENU (edit existing message) ═══
async function showCategoryMenu(bot, q, category, ctx) {
    const groups = loader.groupByCategory();
    const categories = Object.keys(groups).sort();

    const modules = groups[category] || [];
    const emoji = loader.getCategoryEmoji(category);

    const caption =
        `<b>𖡛 USERBOT MENU</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ Kategori: <b>${emoji} ${category.toUpperCase()}</b>\n` +
        `▸ Total module: <code>${modules.length}</code>\n` +
        `▸ Total kategori: <code>${categories.length}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>Command:</b>\n` +
        (modules.slice(0, 15).map(m => `▸ <code>.${m.command}</code> — ${m.description || "-"}`).join("\n") || "<i>(kosong)</i>") +
        (modules.length > 15 ? `\n▸ <i>...dan ${modules.length - 15} module lain</i>` : "");

    // Button: category navigation
    const kb = [];

    // Row 1: tombol kategori (max 5)
    const catRow1 = [];
    for (let i = 0; i < Math.min(5, categories.length); i++) {
        const c = categories[i];
        catRow1.push({
            text: `${loader.getCategoryEmoji(c)} ${c}`,
            callback_data: `ubot_menu_open:${c}`,
            style: c === category ? "success" : "primary"
        });
    }
    if (catRow1.length > 0) kb.push(catRow1);

    // Row 2: kategori berikutnya
    if (categories.length > 5) {
        const catRow2 = [];
        for (let i = 5; i < Math.min(10, categories.length); i++) {
            const c = categories[i];
            catRow2.push({
                text: `${loader.getCategoryEmoji(c)} ${c}`,
                callback_data: `ubot_menu_open:${c}`,
                style: c === category ? "success" : "primary"
            });
        }
        if (catRow2.length > 0) kb.push(catRow2);
    }

    // Row 3: category berikutnya (kalau ada)
    if (categories.length > 10) {
        const catRow3 = [];
        for (let i = 10; i < Math.min(15, categories.length); i++) {
            const c = categories[i];
            catRow3.push({
                text: `${loader.getCategoryEmoji(c)} ${c}`,
                callback_data: `ubot_menu_open:${c}`,
                style: c === category ? "success" : "primary"
            });
        }
        if (catRow3.length > 0) kb.push(catRow3);
    }

    kb.push([
        { text: "🔄 Refresh", callback_data: `ubot_menu_open:${category}`, style: "primary" },
        { text: "✕ Tutup", callback_data: "ubot_menu_close", style: "danger" }
    ]);

    // Edit existing message (kalau bisa), kalau ga bisa kirim baru
    try {
        await bot.editMessageText(caption, {
            chat_id: q.message.chat.id,
            message_id: q.message.message_id,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return;

        // Kalau pesan sebelumnya foto, edit caption
        if (msg.includes("there is no text in the message to edit")) {
            try {
                await bot.editMessageCaption(caption, {
                    chat_id: q.message.chat.id,
                    message_id: q.message.message_id,
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
                return;
            } catch {}
        }

        // Fallback: kirim baru
        try {
            await bot.sendMessage(q.message.chat.id, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
        } catch (e2) {
            console.log("[UBOT MENU SEND ERR]", e2.message);
        }
    }
}

// ═══ CLOSE MENU ═══
router.registerCallback("ubot_menu_close", async (bot, q, data, user, ctx) => {
    try {
        await bot.answerCallbackQuery(q.id, { text: "✓ Ditutup", show_alert: false });
        await bot.deleteMessage(q.message.chat.id, q.message.message_id).catch(() => {});
    } catch (e) { console.log("[UBOT MENU CLOSE ERR]", e.message); }
});

module.exports = { showCategoryMenu };
console.log("[UBOT MENU CB] module loaded");