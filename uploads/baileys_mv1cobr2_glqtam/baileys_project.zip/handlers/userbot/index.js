const path = require("path");
const router = require(path.join(__dirname, "..", "..", "modules", "router.js"));
const cfg = require(path.join(__dirname, "..", "..", "config.js"));
const store = require("./session-store");
const login = require("./login");

// ═══ ICON ═══
const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
};

// ═══ ROLE PRICES ═══
const ROLE_PRICES = {
    permanent: 3000,
    reseller: 6000,
    admin: 9000,
    owner: 12000
};

const ROLE_BENEFIT = {
    permanent: "Akses ubot permanen selamanya",
    reseller: "Akses ubot + add permanen only",
    admin: "Akses ubot + add permanen sampai reseller",
    owner: "Akses ubot + add permanen sampai admin"
};

// ═══════════════════════════════════════════
// MENU UTAMA
// ═══════════════════════════════════════════
router.registerCallback("menu_userbot", async (bot, q, data, user, ctx) => {
    try {
        const userRole = store.getUserRole(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const activeClient = login.getClient(user.id);
        const currentMode = store.getMode(user.id);

        const statusIcon = activeClient ? I.check : (sessionExists ? I.clock : I.cross);
        const statusText = activeClient ? "Online" : (sessionExists ? "Session ada, offline" : "Belum login");

        const caption =
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} USERBOT — TELEGRAM  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} STATUS\n` +
            `${I.teeL}${I.line.repeat(22)}\n` +
            `${I.pipe} ${I.bullet} Status   ${I.arrow}  <b>${statusIcon} ${statusText}</b>\n` +
            `${I.pipe} ${I.bullet} Mode     ${I.arrow}  <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `${I.pipe} ${I.bullet} Role     ${I.arrow}  <b>${userRole ? userRole.role.toUpperCase() : "TIDAK ADA"}</b>\n` +
            `${I.pipe} ${I.bullet} Expired  ${I.arrow}  ${userRole && userRole.expiresAt ? Math.ceil((userRole.expiresAt - Date.now()) / 86400000) + " hari" : "∞"}\n` +
            `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
            `${I.pipe} ${I.diamond} FITUR\n` +
            `${I.teeL}${I.line.repeat(22)}\n` +
            `${I.pipe} ${I.bulletOut} 200+ module\n` +
            `${I.pipe} ${I.bulletOut} Auto forward\n` +
            `${I.pipe} ${I.bulletOut} Build APK via GitHub\n` +
            `${I.pipe} ${I.bulletOut} Clone profile\n` +
            `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}`;

        const kb = [];
        if (!userRole) {
            kb.push([{ text: `${I.bullet} Beli Role Ubot`, callback_data: "userbot_buy", style: "success" }]);
        } else if (!activeClient) {
            kb.push([{ text: `${I.bullet} Login Telegram`, callback_data: "userbot_login", style: "success" }]);
        } else {
            kb.push([
                { text: `${I.bullet} Manage Session`, callback_data: "userbot_manage", style: "primary" }
            ]);
        }
        kb.push([{ text: `${I.cross} Kembali`, callback_data: "menu_back", style: "danger" }]);

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) { console.log("[USERBOT MENU ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BELI ROLE — Menu pilih role
// ═══════════════════════════════════════════
router.registerCallback("userbot_buy", async (bot, q, data, user, ctx) => {
    try {
        const rows = [];
        for (const [role, price] of Object.entries(ROLE_PRICES)) {
            rows.push([{
                text: `${I.bullet} ${role.toUpperCase()} — Rp${price.toLocaleString("id-ID")}`,
                callback_data: `userbot_buy_pick:${role}`,
                style: "success"
            }]);
        }
        rows.push([{ text: `${I.cross} Batal`, callback_data: "userbot_main", style: "danger" }]);

        await bot.sendMessage(q.message.chat.id,
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.star} BELI ROLE USERBOT  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.arrow} Pilih role yang mau lu beli:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[USERBOT BUY ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BELI ROLE — Kirim QRIS
// ═══════════════════════════════════════════
router.registerCallback("userbot_buy_pick", async (bot, q, data, user, ctx) => {
    try {
        const role = data.split(":")[1];
        const price = ROLE_PRICES[role];
        const benefit = ROLE_BENEFIT[role];

        ctx.setState(String(user.id), "userbot_await_bukti", { role, price });

        const caption =
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} PEMBAYARAN  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} ORDER\n` +
            `${I.teeL}${I.line.repeat(22)}\n` +
            `${I.pipe} ${I.bullet} Role     ${I.arrow}  <b>${role.toUpperCase()}</b>\n` +
            `${I.pipe} ${I.bullet} Harga    ${I.arrow}  <b>Rp${price.toLocaleString("id-ID")}</b>\n` +
            `${I.pipe} ${I.bullet} Benefit  ${I.arrow}  ${benefit}\n` +
            `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
            `${I.star} <b>Scan QRIS di bawah</b>\n` +
            `${I.bulletOut} <i>Setelah transfer, kirim foto bukti ke chat ini</i>`;

        const kb = { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "userbot_main", style: "danger" }]] };

        let sent = false;
        try {
            await bot.sendPhoto(q.message.chat.id, cfg.FOTO.QRIS, {
                caption, parse_mode: "HTML", reply_markup: kb
            });
            sent = true;
        } catch (e) {
            console.log("[USERBOT BUY PICK] sendPhoto fail:", e.message.slice(0, 100));
        }

        if (!sent) {
            try {
                await bot.sendMessage(q.message.chat.id,
                    caption + `\n\n${I.arrow} <a href="${cfg.FOTO.QRIS}">Link QRIS</a>`,
                    { parse_mode: "HTML", reply_markup: kb });
                sent = true;
            } catch (e) {}
        }

        if (!sent) {
            await bot.sendMessage(q.message.chat.id, `QRIS: ${cfg.FOTO.QRIS}`, { reply_markup: kb }).catch(() => {});
        }
    } catch (e) { console.log("[USERBOT BUY PICK ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA BUKTI TRANSFER
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_bukti", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id, `${I.cross} Kirim foto bukti transfer.`, { parse_mode: "HTML" });
        }

        const photo = msg.photo[msg.photo.length - 1];
        const { role, price } = state;

        ctx.clearState(String(msg.from.id));

        // ⚡ KIRIM NOTIF KE CHANNEL — Status PENDING
        try {
            const notifGen = require("./modules/notif-generator");
            let photoUrl = null;

            try {
                const photos = await bot.getUserProfilePhotos(msg.from.id, { limit: 1 });
                if (photos.total_count > 0 && photos.photos[0].length > 0) {
                    const fileId = photos.photos[0][0].file_id;
                    photoUrl = await bot.getFileLink(fileId);
                }
            } catch (e) {}

            await notifGen.sendBuyRoleNotif(bot, cfg, {
                roleName: role.toUpperCase(),
                price: `Rp${price.toLocaleString("id-ID")}`,
                status: "pending",
                username: msg.from.username ? `@${msg.from.username}` : "-",
                fullName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(" ") || "User",
                userPhotoUrl: photoUrl,
                userId: msg.from.id,
                timestamp: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
            });
        } catch (e) {
            console.log("[USERBOT BUKTI] notif fail:", e.message);
        }

        // Pesan ke user
        await bot.sendMessage(msg.chat.id,
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.check} BUKTI DITERIMA  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.bulletOut} Role: <b>${role.toUpperCase()}</b>\n` +
            `${I.bulletOut} Status: <i>Menunggu acc admin...</i>\n\n` +
            `<i>Bakal di-acc dalam 1x24 jam</i>`,
            { parse_mode: "HTML" });

        // Forward bukti ke owner
        try {
            await bot.sendPhoto(cfg.OWNER_ID, photo.file_id, {
                caption:
                    `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                    `${I.pipe}  ${I.square} BUKTI TRANSFER  ${I.pipe}\n` +
                    `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                    `${I.bullet} User ID   ${I.arrow}  <code>${msg.from.id}</code>\n` +
                    `${I.bullet} Nama      ${I.arrow}  ${msg.from.first_name || "-"}\n` +
                    `${I.bullet} Username  ${I.arrow}  ${msg.from.username ? "@" + msg.from.username : "-"}\n` +
                    `${I.bullet} Role      ${I.arrow}  <b>${role.toUpperCase()}</b>\n` +
                    `${I.bullet} Harga     ${I.arrow}  <b>Rp${price.toLocaleString("id-ID")}</b>\n\n` +
                    `${I.arrow} <b>Ketik:</b>\n` +
                    `<code>/accubot ${msg.from.id} ${role}</code>`,
                parse_mode: "HTML"
            });
        } catch (e) {
            console.log("[USERBOT FORWARD BUKTI ERR]", e.message);
        }
    } catch (e) { console.log("[USERBOT BUKTI ERR]", e.message); }
});

// ═══════════════════════════════════════════
// LOGIN — Minta nomor
// ═══════════════════════════════════════════
router.registerCallback("userbot_login", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(String(user.id), "userbot_await_phone", {});
        await bot.sendMessage(q.message.chat.id,
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.circle} LOGIN USERBOT  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.arrow} <b>Kirim nomor Telegram lu:</b>\n\n` +
            `${I.bulletOut} Format: <code>+6281234567890</code>\n` +
            `${I.bulletOut} Kode negara pake tanda +\n\n` +
            `<i>Bot bakal kirim kode OTP ke akun Telegram lu.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "userbot_cancel_login", style: "danger" }]] } });
    } catch (e) { console.log("[USERBOT LOGIN ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA NOMOR → KIRIM OTP
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_phone", async (bot, msg, state, ctx) => {
    try {
        const phone = (msg.text || "").trim();
        if (!phone.match(/^\+\d{8,15}$/)) {
            return bot.sendMessage(msg.chat.id,
                `${I.cross} Format nomor salah.\n\nGunakan: <code>+6281234567890</code>`,
                { parse_mode: "HTML" });
        }

        ctx.clearState(String(msg.from.id));

        const loading = await bot.sendMessage(msg.chat.id,
            `${I.circle} Kirim OTP ke ${phone}...\n\n<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        const result = await login.startLogin(bot, msg.chat.id, msg.from.id, phone, ctx);

        if (!result.ok) {
            await bot.editMessageText(
                `${I.cross} Gagal kirim OTP:\n<code>${String(result.error).slice(0, 200)}</code>`,
                { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        } else {
            try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}
        }
    } catch (e) { console.log("[USERBOT PHONE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA OTP
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_otp", async (bot, msg, state, ctx) => {
    try {
        const otp = (msg.text || "").trim().replace(/\s/g, "");
        if (!otp.match(/^\d{4,6}$/)) {
            return bot.sendMessage(msg.chat.id, `${I.cross} Kode OTP harus 4-6 digit angka.`, { parse_mode: "HTML" });
        }

        ctx.clearState(String(msg.from.id));

        const loading = await bot.sendMessage(msg.chat.id, `${I.circle} Verifikasi OTP...`, { parse_mode: "HTML" });
        const result = await login.verifyOtp(msg.from.id, otp, bot, msg.chat.id, ctx);
        try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

        if (!result.ok && !result.needPassword) {
            await bot.sendMessage(msg.chat.id,
                `${I.cross} Verifikasi gagal:\n<code>${String(result.error).slice(0, 200)}</code>\n\n` +
                `<i>Ketik /menu → Userbot → Login buat ulang.</i>`,
                { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[USERBOT OTP ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA 2FA PASSWORD
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_password", async (bot, msg, state, ctx) => {
    try {
        const password = (msg.text || "").trim();
        if (!password) return;

        ctx.clearState(String(msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}

        const loading = await bot.sendMessage(msg.chat.id, `${I.circle} Verifikasi 2FA...`, { parse_mode: "HTML" });
        const result = await login.verifyPassword(msg.from.id, password, bot, msg.chat.id, ctx);
        try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

        if (!result.ok) {
            await bot.sendMessage(msg.chat.id,
                `${I.cross} 2FA salah:\n<code>${String(result.error).slice(0, 200)}</code>\n\n` +
                `<i>Ketik /menu → Userbot → Login buat ulang.</i>`,
                { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[USERBOT PWD ERR]", e.message); }
});

router.registerCallback("userbot_cancel_login", async (bot, q, data, user, ctx) => {
    try {
        login.cancelLogin(user.id);
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `${I.cross} Login dibatalkan.`, { parse_mode: "HTML" });
    } catch (e) { console.log("[USERBOT CANCEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// MANAGE SESSION
// ═══════════════════════════════════════════
router.registerCallback("userbot_manage", async (bot, q, data, user, ctx) => {
    try {
        const activeClient = login.getClient(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const currentMode = store.getMode(user.id);

        await bot.sendMessage(q.message.chat.id,
            `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} MANAGE SESSION\n` +
            `${I.teeL}${I.line.repeat(22)}\n` +
            `${I.pipe} ${I.bullet} Status   ${I.arrow}  ${activeClient ? "Online" : "Offline"}\n` +
            `${I.pipe} ${I.bullet} Session  ${I.arrow}  ${sessionExists ? "Ada" : "Gaada"}\n` +
            `${I.pipe} ${I.bullet} Mode     ${I.arrow}  <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: `${I.bullet} Logout Userbot`, callback_data: "userbot_logout", style: "danger" }],
                        [{ text: `${I.cross} Kembali`, callback_data: "userbot_main", style: "danger" }]
                    ]
                }
            });
    } catch (e) { console.log("[USERBOT MANAGE ERR]", e.message); }
});

router.registerCallback("userbot_logout", async (bot, q, data, user, ctx) => {
    try {
        await login.stopClient(user.id);
        store.deleteSession(user.id);
        await bot.sendMessage(q.message.chat.id,
            `${I.check} USERBOT LOGOUT\n\n<i>Session lu udah dihapus.</i>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[USERBOT LOGOUT ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BACK KE MENU USERBOT
// ═══════════════════════════════════════════
router.registerCallback("userbot_main", async (bot, q, data, user, ctx) => {
    try {
        const userRole = store.getUserRole(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const activeClient = login.getClient(user.id);
        const currentMode = store.getMode(user.id);

        const statusIcon = activeClient ? I.check : (sessionExists ? I.clock : I.cross);
        const statusText = activeClient ? "Online" : (sessionExists ? "Session ada, offline" : "Belum login");

        const caption =
            `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} USERBOT — TELEGRAM  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} STATUS\n` +
            `${I.teeL}${I.line.repeat(22)}\n` +
            `${I.pipe} ${I.bullet} Status   ${I.arrow}  <b>${statusIcon} ${statusText}</b>\n` +
            `${I.pipe} ${I.bullet} Mode     ${I.arrow}  <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `${I.pipe} ${I.bullet} Role     ${I.arrow}  <b>${userRole ? userRole.role.toUpperCase() : "TIDAK ADA"}</b>\n` +
            `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}`;

        const kb = [];
        if (!userRole) {
            kb.push([{ text: `${I.bullet} Beli Role Ubot`, callback_data: "userbot_buy", style: "success" }]);
        } else if (!activeClient) {
            kb.push([{ text: `${I.bullet} Login Telegram`, callback_data: "userbot_login", style: "success" }]);
        } else {
            kb.push([{ text: `${I.bullet} Manage Session`, callback_data: "userbot_manage", style: "primary" }]);
        }
        kb.push([{ text: `${I.cross} Kembali`, callback_data: "menu_back", style: "danger" }]);

        try {
            await bot.editMessageText(caption, {
                chat_id: q.message.chat.id,
                message_id: q.message.message_id,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
        } catch (e) {
            if (e.message.includes("message is not modified")) return;
            await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }
    } catch (e) { console.log("[USERBOT MAIN ERR]", e.message); }
});

module.exports = { ROLE_PRICES, ROLE_BENEFIT };
console.log("[USERBOT] module loaded (v7 — notif generator + flow lengkap)");