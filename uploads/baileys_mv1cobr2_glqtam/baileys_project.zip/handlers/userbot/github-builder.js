// ═══════════════════════════════════════════
// GITHUB BUILDER — Standalone untuk Userbot
// v5 — FIX path config (naik 2 folder ke root)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const axios = require("axios");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

// ⚡ FIX: naik 2 folder (handlers/userbot/ → handlers/ → root) baru ambil config.js
const ROOT = path.join(__dirname, "..", "..");
const cfg = require(path.join(ROOT, "config.js"));

const GH = cfg.GITHUB || {};
const API = "https://api.github.com";

const TMP_DIR = path.join(ROOT, cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

const JOBS_FILE = path.join(ROOT, "database", "buildjobs.json");
if (!fs.existsSync(JOBS_FILE)) fs.writeFileSync(JOBS_FILE, "{}", "utf8");

// ═══ HELPERS ═══
function readJobs() {
    try { return JSON.parse(fs.readFileSync(JOBS_FILE, "utf8")); } catch { return {}; }
}
function writeJobs(d) {
    fs.writeFileSync(JOBS_FILE, JSON.stringify(d, null, 2), "utf8");
}

function newJobId(prefix = "job") {
    return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(3).toString("hex")}`;
}

function ghHeaders(extra = {}) {
    return {
        Authorization: `token ${GH.TOKEN}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "SpartaX-Bot",
        ...extra
    };
}

function validateConfig() {
    if (!GH.TOKEN || GH.TOKEN.startsWith("ISI_")) throw new Error("GITHUB.TOKEN belum di-set");
    if (!GH.USERNAME || GH.USERNAME.startsWith("ISI_")) throw new Error("GITHUB.USERNAME belum di-set");
    if (!GH.REPO || GH.REPO.startsWith("ISI_")) throw new Error("GITHUB.REPO belum di-set");
}

// ═══ PUT FILE ═══
async function putFile(repoPath, contentBase64, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${repoPath}`;

    console.log("[UBOT GH putFile] path:", repoPath, "size(b64):", contentBase64.length);

    let sha = null;
    try {
        const cur = await axios.get(url, {
            headers: ghHeaders(),
            params: { ref: b },
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (cur.status === 200 && cur.data && cur.data.sha) sha = cur.data.sha;
    } catch (e) {}

    const body = {
        message: message || `upload ${repoPath}`,
        content: contentBase64,
        branch: b
    };
    if (sha) body.sha = sha;

    const res = await axios.put(url, body, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });

    console.log("[UBOT GH putFile] uploaded, status:", res.status);
    return res.data;
}

// ═══ UPLOAD FILE (BLOBS) ═══
async function uploadFile(repoPath, buffer, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";

    const blobRes = await axios.post(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/blobs`, {
        content: buffer.toString("base64"),
        encoding: "base64"
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });

    const refRes = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/ref/heads/${b}`, {
        headers: ghHeaders(), timeout: 30000
    });
    const parentSha = refRes.data.object.sha;

    const commitRes = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/commits/${parentSha}`, {
        headers: ghHeaders(), timeout: 30000
    });
    const baseTreeSha = commitRes.data.tree.sha;

    const treeRes = await axios.post(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/trees`, {
        base_tree: baseTreeSha,
        tree: [{ path: repoPath, mode: "100644", type: "blob", sha: blobRes.data.sha }]
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }), timeout: 60000
    });

    const newCommitRes = await axios.post(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/commits`, {
        message: message || `upload ${repoPath}`,
        tree: treeRes.data.sha,
        parents: [parentSha]
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }), timeout: 60000
    });

    await axios.patch(`${API}/repos/${GH.USERNAME}/${GH.REPO}/git/refs/heads/${b}`, {
        sha: newCommitRes.data.sha
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }), timeout: 60000
    });

    return newCommitRes.data;
}

// ═══ DELETE FILE ═══
async function deleteFile(repoPath, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${repoPath}`;

    let sha;
    try {
        const cur = await axios.get(url, {
            headers: ghHeaders(), params: { ref: b }, timeout: 30000, validateStatus: s => s < 500
        });
        if (cur.status !== 200 || !cur.data || !cur.data.sha) return null;
        sha = cur.data.sha;
    } catch { return null; }

    const res = await axios.delete(url, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        data: { message: message || `delete ${repoPath}`, sha, branch: b },
        timeout: 60000
    });
    return res.data;
}

// ═══ LIST FILES ═══
async function listFiles(folderPath, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${folderPath ? folderPath : ""}`;
    try {
        const res = await axios.get(url, {
            headers: ghHeaders(), params: { ref: b }, timeout: 30000
        });
        return res.data;
    } catch { return []; }
}

// ═══ TRIGGER WORKFLOW ═══
async function triggerWorkflow(workflowFile, inputs = {}, ref = null) {
    validateConfig();
    const r = ref || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/workflows/${workflowFile}/dispatches`;

    console.log("[UBOT GH triggerWorkflow]", workflowFile, "| inputs:", JSON.stringify(inputs).slice(0, 200));

    try {
        const res = await axios.post(url, { ref: r, inputs }, {
            headers: ghHeaders({ "Content-Type": "application/json" }),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 204) {
            console.log("[UBOT GH triggerWorkflow] ✅ triggered");
            return { ok: true };
        }
        return { ok: false, error: `HTTP ${res.status}: ${JSON.stringify(res.data).slice(0, 200)}` };
    } catch (e) {
        const msg = e.response?.data?.message || e.message;
        const details = e.response?.data?.errors ? JSON.stringify(e.response.data.errors) : "";
        console.log("[UBOT GH triggerWorkflow] ❌ fail:", msg, details);
        return { ok: false, error: `${msg} ${details}`.trim() };
    }
}

// ═══ GET LATEST RUN ═══
async function getLatestRun(workflowFile, afterTimestamp = 0) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/workflows/${workflowFile}/runs`;
    try {
        const res = await axios.get(url, {
            headers: ghHeaders(), params: { per_page: 10 }, timeout: 30000
        });
        const runs = res.data.workflow_runs || [];
        for (const r of runs) {
            const created = new Date(r.created_at).getTime();
            if (created >= afterTimestamp - 10000) {
                console.log("[UBOT GH getLatestRun] found:", r.id);
                return r;
            }
        }
        return null;
    } catch (e) {
        console.log("[UBOT GH getLatestRun] err:", e.message);
        return null;
    }
}

// ═══ GET RUN STATUS ═══
async function getRunStatus(runId) {
    validateConfig();
    try {
        const res = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}`, {
            headers: ghHeaders(), timeout: 30000
        });
        return res.data;
    } catch { return null; }
}

// ═══ GET RUN JOBS ═══
async function getRunJobs(runId) {
    validateConfig();
    try {
        const res = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/jobs`, {
            headers: ghHeaders(), timeout: 30000
        });
        return res.data.jobs || [];
    } catch { return []; }
}

// ═══ GET RUN ARTIFACTS ═══
async function getRunArtifacts(runId) {
    validateConfig();
    try {
        const res = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/artifacts`, {
            headers: ghHeaders(), timeout: 30000
        });
        const arts = res.data.artifacts || [];
        console.log("[UBOT GH getRunArtifacts]", arts.map(a => a.name));
        return arts;
    } catch { return []; }
}

async function getRunArtifactsByName(runId, keywords = ["apk", "aab", "appbundle"]) {
    const arts = await getRunArtifacts(runId);
    const kws = keywords.map(k => k.toLowerCase());
    return arts.filter(a => kws.some(k => String(a.name || "").toLowerCase().includes(k)));
}

// ═══ DOWNLOAD ARTIFACT ═══
async function downloadArtifact(artifactId, destPath = null, returnBuffer = false) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/artifacts/${artifactId}/zip`;
    const res = await axios.get(url, {
        headers: ghHeaders(),
        responseType: "arraybuffer",
        maxRedirects: 10,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });
    const buf = Buffer.from(res.data);
    console.log("[UBOT GH downloadArtifact] size:", buf.length);

    if (returnBuffer) return buf;
    if (destPath) {
        fs.writeFileSync(destPath, buf);
        return destPath;
    }
    return buf;
}

// ═══ GET RAW FILE ═══
async function getRawFile(repoPath, ref = null) {
    validateConfig();
    const r = ref || GH.BRANCH || "main";
    const url = `https://raw.githubusercontent.com/${GH.USERNAME}/${GH.REPO}/${r}/${repoPath}`;
    try {
        const res = await axios.get(url, { responseType: "text", timeout: 15000 });
        return res.data;
    } catch { return null; }
}

// ═══ GET RUN LOGS ═══
async function getRunLogs(runId) {
    validateConfig();
    try {
        const res = await axios.get(`${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/logs`, {
            headers: ghHeaders(),
            responseType: "arraybuffer",
            maxRedirects: 10,
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            timeout: 120000
        });
        return Buffer.from(res.data);
    } catch (e) {
        console.log("[UBOT GH getRunLogs] err:", e.message);
        return null;
    }
}

// ═══ POLL RUN UNTIL DONE ═══
async function pollRunUntilDone(runId, onProgress, maxWaitMs = null) {
    const maxWait = maxWaitMs || cfg.BUILD_MAX_WAIT_MS || 1800000;
    const interval = cfg.BUILD_POLL_INTERVAL || 15000;
    const start = Date.now();

    while (Date.now() - start < maxWait) {
        const run = await getRunStatus(runId);
        if (run) {
            if (typeof onProgress === "function") {
                onProgress({ status: run.status, conclusion: run.conclusion, run });
            }
            if (run.status === "completed") {
                return { status: run.status, conclusion: run.conclusion, run };
            }
        }
        await new Promise(r => setTimeout(r, interval));
    }
    return { status: "timeout", conclusion: null, run: null };
}

// ═══ NOTIF (dummy, biar kompatibel) ═══
async function generateBuildNotifImage() { return null; }

async function sendBuildNotif(bot, { title, caption = "" }) {
    if (!cfg.BUILD_LOG_CHANNEL || cfg.BUILD_LOG_CHANNEL === "-1001234567890") return;
    try {
        await bot.sendMessage(cfg.BUILD_LOG_CHANNEL, caption || `<b>▸ ${title}</b>`, { parse_mode: "HTML" });
    } catch {}
}

// ═══ EXPORT ═══
module.exports = {
    API,
    TMP_DIR,
    readJobs,
    writeJobs,
    newJobId,
    validateConfig,
    putFile,
    uploadFile,
    deleteFile,
    listFiles,
    triggerWorkflow,
    getLatestRun,
    getRunStatus,
    getRunJobs,
    getRunArtifacts,
    getRunArtifactsByName,
    downloadArtifact,
    getRawFile,
    getRunLogs,
    pollRunUntilDone,
    generateBuildNotifImage,
    sendBuildNotif
};

console.log("[UBOT GH BUILDER] ✅ standalone loaded from handlers/userbot/");