const { exec } = require("child_process");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const host = args[0];

    if (!host) return client.sendMessage(chatId, { message: "▸ .pinghost [host/ip]" });

    const safe = host.replace(/[^a-zA-Z0-9.\-:]/g, "");

    return new Promise((resolve) => {
        exec("ping -c 4 -W 2 " + safe, { timeout: 15000 }, async (err, stdout) => {
            if (err && !stdout) {
                await client.sendMessage(chatId, { message: "✕ Host ga reachable: " + safe });
                return resolve();
            }

            const lines = stdout.split("\n").filter(l => l.trim());
            const stats = lines.find(l => l.includes("packet loss") || l.includes("rtt"));
            const times = lines.filter(l => l.includes("time="));

            let timeList = "";
            times.forEach((t, i) => {
                const m = t.match(/time=([\d.]+)/);
                if (m) timeList += "│ " + (i + 1) + ". " + m[1] + " ms\n";
            });
            if (!timeList) timeList = "│ (gaada response)\n";

            const text =
                "╭───────────────────╮\n" +
                "│   ◉  PINGHOST      │\n" +
                "╰───────────────────╯\n\n" +
                "├───────────────────\n" +
                "│ ▪ Host  → " + safe + "\n" +
                "│ ▪ Stats → " + (stats ? stats.trim().slice(0, 60) : "-") + "\n" +
                "├───────────────────\n" +
                timeList +
                "╰───────────────────";

            await client.sendMessage(chatId, { message: text });
            resolve();
        });
    });
}

module.exports = {
    command: "pinghost",
    handler,
    description: "Ping host/ip",
    category: "monitor"
};