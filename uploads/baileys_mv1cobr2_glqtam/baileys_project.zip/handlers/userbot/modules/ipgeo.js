const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const ip = args[0] || "";
    const loading = await client.sendMessage(chatId, { message: `🌍 Lookup IP...` });

    try {
        const r = await axios.get(`http://ip-api.com/json/${ip}?fields=66846719`, { timeout: 15000 });
        const d = r.data;
        if (d.status !== "success") throw new Error(d.message);

        const text =
            `🌍 IP GEOLOCATION\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ IP: ${d.query}\n` +
            `▸ Country: ${d.country} (${d.countryCode})\n` +
            `▸ Region: ${d.regionName} (${d.region})\n` +
            `▸ City: ${d.city}\n` +
            `▸ Zip: ${d.zip || "-"}\n` +
            `▸ Lat/Lon: ${d.lat}, ${d.lon}\n` +
            `▸ Timezone: ${d.timezone}\n` +
            `▸ ISP: ${d.isp}\n` +
            `▸ Org: ${d.org || "-"}\n` +
            `▸ AS: ${d.as || "-"}\n` +
            `▸ Mobile: ${d.mobile ? "✅" : "❌"}\n` +
            `▸ Proxy/VPN: ${d.proxy ? "⚠️ IYA" : "✅ Bukan"}\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "ipgeo", handler, description: "IP geolocation detail", category: "osint" };