const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://dog.ceo/api/breeds/image/random", { timeout: 15000 });
        const url = r.data?.message;
        if (!url) throw new Error("No image");
        const img = await axios.get(url, { responseType: "arraybuffer", timeout: 20000 });
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: "🐶 Woof!",
            forceDocument: false
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "dog", handler, description: "Random dog pic", category: "fun" };