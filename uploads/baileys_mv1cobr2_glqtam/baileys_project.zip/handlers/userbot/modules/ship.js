async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let name1 = args[0] || "Kamu";
    let name2 = args[1] || "Dia";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) name2 = msgs[0].sender?.firstName || msgs[0].senderId || name2;
    }

    const percent = Math.floor(Math.random() * 101);
    let emoji = "💔";
    if (percent > 80) emoji = "💖💖💖";
    else if (percent > 60) emoji = "💖💖";
    else if (percent > 40) emoji = "💖";
    else if (percent > 20) emoji = "💛";

    await client.sendMessage(chatId, {
        message: `💕 SHIP\n\n${name1} + ${name2}\n\n▸ Love: ${emoji} ${percent}%`
    });
}

module.exports = { command: "ship", handler, description: "Ship 2 nama", category: "fun" };