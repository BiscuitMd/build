const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ").trim();
    if (!prompt) return client.sendMessage(chatId, { message: "📖 .llama [pertanyaan]" });
    const loading = await client.sendMessage(chatId, { message: "🦙 Llama mikir..." });
    try {
        const r = await axios.post("https://text.pollinations.ai/openai", {
            model: "llama",
            messages: [{ role: "user", content: prompt }],
            temperature: 0.7, private: true
        }, { timeout: 60000 });
        const text = r.data?.choices?.[0]?.message?.content || "AI ga jawab.";
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "llama", handler, description: "Chat dengan Llama", category: "ai" };