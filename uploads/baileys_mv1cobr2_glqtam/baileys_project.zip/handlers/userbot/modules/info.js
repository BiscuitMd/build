async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = replyTo ? null : msg.message.senderId;

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    }

    if (!targetId) return client.sendMessage(chatId, { message: "❌ Reply user / gaada target" });

    try {
        const users = await client.invoke(new (require("telegram").Api.users.GetFullUser)({
            id: targetId
        }));
        const u = users.users?.[0] || {};
        await client.sendMessage(chatId, {
            message: `👤 INFO USER\n\n▸ ID: ${u.id}\n▸ Nama: ${[u.firstName, u.lastName].filter(Boolean).join(" ") || "-"}\n▸ Username: ${u.username ? "@" + u.username : "-"}\n▸ Bio: ${users.fullUser?.about || "-"}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "info", handler, description: "Info user", category: "info" };