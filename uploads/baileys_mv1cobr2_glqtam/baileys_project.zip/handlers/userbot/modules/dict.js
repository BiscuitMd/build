const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const word = args[0];
    if (!word) return client.sendMessage(chatId, { message: "📖 .dict [english-word]" });
    try {
        const r = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`, { timeout: 15000 });
        const d = r.data?.[0];
        if (!d) throw new Error("Kata ga ditemukan");
        const meanings = d.meanings.slice(0, 2).map(m => `▸ (${m.partOfSpeech}) ${m.definitions[0]?.definition}`).join("\n");
        await client.sendMessage(chatId, {
            message: `📖 ${d.word}\n\n${meanings}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "dict", handler, description: "Kamus English", category: "tools" };