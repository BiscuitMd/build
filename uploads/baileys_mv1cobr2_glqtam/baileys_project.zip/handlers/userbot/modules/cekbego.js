const ROASTS = {
    bego: [
        "Otak lu tuh kayak kertas kosong, ga ada isinya 🗿",
        "Lu tuh bego tapi sok pinter, kombinasi paling menyedihkan 😹",
        "Kalo bego itu pake gelar, lu udah doktor.",
        "IQ lu tuh kayak suhu kulkas, rendah banget 🥶",
        "Ngomong sama lu tuh kayak ngomong sama dinding, sama-sama kosong.",
        "Bego lu tuh udah level internasional, ga ada obat.",
        "Lu tuh kayak wifi lemah, sinyalnya ilang tiap 5 detik.",
        "Kalo otak itu duit, lu tuh bangkrut parah."
    ],
    tolol: [
        "Tolol lu tuh udah masuk rekor MURI 🏆",
        "Lu tuh tolol tapi PD, itu yang bikin kasian.",
        "Ngomong sama lu tuh bikin otak aku nge-lag 🐌",
        "Tolol aja lu, pake mikir dikit kek.",
        "Lu tuh tolol karena emang tolol, bukan karena salah paham.",
        "Kalo tolol bisa ditularkeun, lu udah jadi wabah nasional.",
        "Tolol lu tuh kaya film horor, ngeri banget 😱",
        "Mikir tuh gratis, sayangnya lu pelit pake otak."
    ],
    idiot: [
        "Idiot lu tuh ga ada obat, udah kronis.",
        "Kalo idiot itu olahraga, lu udah juara dunia 🥇",
        "Idiot aja lu, pake ribet.",
        "Ngomong sama lu tuh buang-buang kuota.",
        "Idiot lu tuh bikin aku pengen restart hidup.",
        "Lu tuh idiot dengan gelar master, cum laude lagi 🎓",
        "Idiot tapi yakin, itu bahaya.",
        "Otak lu tuh cuma pajangan, ga pernah dipake."
    ],
    jomok: [
        "Jomok lu tuh udah level bencong legend 👑",
        "Muka lu tuh kayak tempe kemarin.",
        "Jomok lu tuh bikin cermin pecah sendiri 🪞",
        "Kalo jomok itu prestasi, lu udah S3.",
        "Jomok aja lu, ga usah sok ganteng.",
        "Muka lu tuh kayak hasil edit Photoshop yang gagal 🎨",
        "Jomok lu tuh bikin orang mual, serius.",
        "Cermin aja mingkem liat muka lu."
    ],
    cantik: [
        "Cantik? Cantik lampu lu 💡",
        "Cantik konoha? Emang lu Hinata? 🤣",
        "Cantiknya cuma di hati, di muka mah jomok.",
        "Cantik bohongan lu masih keliatan.",
        "Cantik aja lu, tapi boong.",
        "Cantik lu tuh kayak fatamorgana, ilusi optik.",
        "Cantik kata mama lu doang kali 🤷",
        "Cantiknya cuma ada di IG, aslinya zonk."
    ],
    ganteng: [
        "Ganteng? Ganteng apa? Ganteng gerobak? 🛻",
        "Ganteng lu tuh kayak hasil edit mie instan.",
        "Ganteng konoha? Lu Sasuke? Mimpi kali 🤣",
        "Gantengnya cuma di cermin, di foto biasa aja.",
        "Ganteng lu tuh kayak wajah babi yang dipakein kacamata 🐷",
        "Ganteng aja lu, tapi boong.",
        "Ganteng kata nenek lu doang kali 👵",
        "Cermin aja nyerah liat lu."
    ],
    pintar: [
        "Pintar? Pintar apa? Pintar ngibul? 🗿",
        "Pintar lu tuh kayak AI versi bug.",
        "Pintar kata guru SD lu doang kali.",
        "Pintar aja lu, tapi boong.",
        "Pintar lu tuh cuma di pelajaran tidur.",
        "Pintar lu tuh level Google tapi offline.",
        "Pintar otak lu tuh sekelas kalkulator rusak.",
        "Pintar? Baca buku aja lu males."
    ]
};

function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const target = args.slice(1).join(" ") || "lu";

    const map = {
        bego: "bego",
        tolol: "tolol",
        idiot: "idiot",
        jomok: "jomok",
        cantik: "cantik",
        ganteng: "ganteng",
        pintar: "pintar"
    };

    if (!cmd || !map[cmd]) {
        const text =
            "╭───────────────────╮\n" +
            "│   ◇  CEK KEPRIBADIAN│\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ COMMANDS\n" +
            "├───────────────────\n" +
            "│ ▪ .cekbego [target]\n" +
            "│ ▪ .cektolol [target]\n" +
            "│ ▪ .cekidiot [target]\n" +
            "│ ▪ .cekjomok [target]\n" +
            "│ ▪ .cekcantik [target]\n" +
            "│ ▪ .cekganteng [target]\n" +
            "│ ▪ .cekpintar [target]\n" +
            "╰───────────────────\n\n" +
            "▸ Contoh: .cekbego arkan";

        return client.sendMessage(chatId, { message: text });
    }

    const roast = pick(ROASTS[map[cmd]]);

    const text =
        "◆ CEK " + cmd.toUpperCase() + "\n\n" +
        "├─────────────────\n" +
        "│ Target → " + target + "\n" +
        "├─────────────────\n" +
        "│ " + roast + "\n" +
        "╰─────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "cekbego",
    handler,
    description: "Roast kasar (bego/tolol/idiot/jomok/cantik/ganteng/pintar)",
    category: "tools",
    commands: ["cektolol", "cekidiot", "cekjomok", "cekcantik", "cekganteng", "cekpintar"]
};