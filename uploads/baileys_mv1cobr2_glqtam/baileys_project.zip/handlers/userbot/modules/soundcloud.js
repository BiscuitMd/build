const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args.join(" ").trim();
    if (!url || !url.includes("soundcloud")) return client.sendMessage(chatId, { message: "📖 .soundcloud [url]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Download SoundCloud..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/d/soundcloud?url=${encodeURIComponent(url)}`, { timeout: 40000 });
        const dl = r.data?.data?.download || r.data?.data?.url;
        if (!dl) throw new Error("No URL");
        const audio = await axios.get(dl, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(audio.data), caption: "🎧 SoundCloud", forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "soundcloud", handler, description: "Download SoundCloud", category: "download" };