const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ").trim();
    if (!prompt) return client.sendMessage(chatId, { message: "📖 .imgflux [prompt]" });
    const loading = await client.sendMessage(chatId, { message: "🎨 Flux generate..." });
    try {
        const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1280&height=1280&model=flux&nologo=true&seed=${Date.now()}`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 120000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(r.data), caption: `🎨 Flux: ${prompt.slice(0, 200)}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "imgflux", handler, description: "Generate image pake Flux", category: "ai" };