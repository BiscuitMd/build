const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const start = Date.now();
        await axios.head("https://www.google.com", { timeout: 5000 });
        const ms = Date.now() - start;
        await client.sendMessage(chatId, { message: `🏓 Ping Google: ${ms}ms` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "speed", handler, description: "Test kecepatan internet", category: "tools" };