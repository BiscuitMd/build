const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ").trim();
    if (!query) return client.sendMessage(chatId, { message: "📖 .ytmp3 [judul/url]" });

    const loading = await client.sendMessage(chatId, { message: "⏳ Mencari audio..." });

    try {
        const searchUrl = query.startsWith("http")
            ? query
            : `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;

        const r = await axios.get(`https://api.siputzx.my.id/api/d/ytplaymp3?query=${encodeURIComponent(query)}`, { timeout: 40000 });
        const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.download;
        if (!url) throw new Error("No download URL");

        const audioRes = await axios.get(url, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        const buf = Buffer.from(audioRes.data);
        if (buf.length < 50000) throw new Error("File terlalu kecil");

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: buf,
            caption: `🎵 ${query}\n▸ Size: ${(buf.length / 1024 / 1024).toFixed(2)} MB`,
            forceDocument: false,
            attributes: [
                new (require("telegram").Api.DocumentAttributeAudio)({
                    title: query,
                    performer: "YouTube",
                    duration: 0
                })
            ]
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ Gagal: ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "ytmp3", handler, description: "Download MP3 dari YouTube", category: "download" };