const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args.join(" ").trim();
    if (!url || !url.includes("facebook")) return client.sendMessage(chatId, { message: "📖 .facebook [url]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Download FB..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/d/facebook?url=${encodeURIComponent(url)}`, { timeout: 40000 });
        const dl = r.data?.data?.hd || r.data?.data?.sd || r.data?.data?.url;
        if (!dl) throw new Error("No URL");
        const v = await axios.get(dl, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(v.data), caption: "📘 Facebook", forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "facebook", handler, description: "Download FB", category: "download" };