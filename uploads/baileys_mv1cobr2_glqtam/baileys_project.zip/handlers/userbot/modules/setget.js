const fs = require("fs");
const path = require("path");

const DB_FILE = path.join(__dirname, "..", "..", "..", "database", "userbot_notes.json");
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "{}", "utf8");

function read() {
    try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); } catch { return {}; }
}
function write(d) { fs.writeFileSync(DB_FILE, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const key = args[1];
    const value = args.slice(2).join(" ");

    const notes = read();
    notes[userId] = notes[userId] || {};

    if (cmd === "set") {
        if (!key || !value) return client.sendMessage(chatId, { message: "📖 .note set [key] [value]" });
        notes[userId][key] = value;
        write(notes);
        return client.sendMessage(chatId, { message: `✅ Saved: ${key}` });
    }

    if (cmd === "get") {
        if (!key) return client.sendMessage(chatId, { message: "📖 .note get [key]" });
        const val = notes[userId][key];
        return client.sendMessage(chatId, { message: val ? `📝 ${key}: ${val}` : `❌ ${key} gaada` });
    }

    if (cmd === "del") {
        if (!key) return client.sendMessage(chatId, { message: "📖 .note del [key]" });
        delete notes[userId][key];
        write(notes);
        return client.sendMessage(chatId, { message: `✅ Deleted: ${key}` });
    }

    if (cmd === "list") {
        const keys = Object.keys(notes[userId]);
        return client.sendMessage(chatId, {
            message: keys.length > 0 ? `📋 Notes:\n${keys.map(k => `▸ ${k}`).join("\n")}` : "📋 (kosong)"
        });
    }

    return client.sendMessage(chatId, {
        message: "📖 Command .note:\n▸ .note set [key] [value]\n▸ .note get [key]\n▸ .note del [key]\n▸ .note list"
    });
}

module.exports = { command: "note", handler, description: "Simpen catatan", category: "tools" };