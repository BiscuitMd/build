const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .headers [url]" });

    const loading = await client.sendMessage(chatId, { message: `📋 Get headers...` });

    try {
        const r = await axios.get(url, { timeout: 15000, validateStatus: () => true });
        const headers = Object.entries(r.headers).slice(0, 20).map(([k, v]) => `▸ ${k}: ${String(v).slice(0, 100)}`).join("\n");
        const text = `📋 HEADERS ${url}\n\n▸ Status: ${r.status}\n\n${headers}`;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "headers", handler, description: "Get HTTP headers", category: "osint" };