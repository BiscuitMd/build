const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .ocr" });
    const loading = await client.sendMessage(chatId, { message: "🔍 Baca text dari gambar..." });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        // Fallback OCR sederhana — kirim ke API
        const FormData = require("form-data");
        const fd = new FormData();
        fd.append("file", buf, { filename: "image.jpg" });
        const r = await axios.post("https://api.ocr.space/parse/image", fd, {
            headers: { ...fd.getHeaders(), apikey: "helloworld" },
            timeout: 30000
        });
        const text = r.data?.ParsedResults?.[0]?.ParsedText || "Ga ada text yang kebaca";
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: `🔍 OCR Result:\n\n${text.slice(0, 4000)}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "ocr", handler, description: "Baca text dari gambar", category: "tools" };