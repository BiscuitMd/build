const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const ip = args[0] || "";
    try {
        const r = await axios.get(`http://ip-api.com/json/${ip}`, { timeout: 15000 });
        const d = r.data;
        if (d.status !== "success") throw new Error(d.message);
        await client.sendMessage(chatId, {
            message:
                `🌍 IP INFO\n\n` +
                `▸ IP: ${d.query}\n` +
                `▸ Country: ${d.country} (${d.countryCode})\n` +
                `▸ Region: ${d.regionName}\n` +
                `▸ City: ${d.city}\n` +
                `▸ ISP: ${d.isp}\n` +
                `▸ Timezone: ${d.timezone}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "ipinfo", handler, description: "Info IP address", category: "tools" };