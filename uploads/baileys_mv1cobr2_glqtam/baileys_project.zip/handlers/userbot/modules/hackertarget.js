const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const target = args[0];
    if (!target) return client.sendMessage(chatId, { message: "📖 .hackertarget [domain/ip]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Hackertarget lookup...` });

    try {
        const endpoints = ["nmap", "whois", "dnsrecon", "geoip"];
        const ep = endpoints[Math.floor(Math.random() * endpoints.length)];
        const r = await axios.get(`https://api.hackertarget.com/${ep}/?q=${target}`, { timeout: 30000 });
        const text = `🔍 HACKERTARGET [${ep}]\n▸ Target: ${target}\n\n${String(r.data).slice(0, 4000)}`;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "hackertarget", handler, description: "Hackertarget API lookup", category: "osint" };