const LINES = [
    "Kamu itu kayak kopi — pait tapi bikin nagih.",
    "Kamu itu kayak wifi — ga keliatan tapi bikin kangen.",
    "Kamu itu kayak matahari — bikin buta tapi hangat.",
    "Kalo kamu jadi soal, gua bakal belajar tiap hari.",
    "Kamu itu kayak alarm — ganggu tapi berguna.",
    "Kamu itu kayak motor — bikin jantung deg-degan.",
    "Kalo cinta itu dosa, gua udah di neraka.",
    "Kamu itu kayak bintang — jauh tapi bersinar.",
    "Kamu itu kayak hujan — bikin kedinginan tapi damai.",
    "Chat gua kayak SMS promo — ga pernah lu bales."
];

async function handler(userId, client, msg, args) {
    const l = LINES[Math.floor(Math.random() * LINES.length)];
    await client.sendMessage(msg.message.chatId, { message: `💘 ${l}` });
}

module.exports = { command: "pickupline", handler, description: "Pickup line random", category: "fun" };