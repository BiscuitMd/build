const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/simple/price?ids=dogecoin&vs_currencies=usd,idr&include_24hr_change=true", { timeout: 15000 });
        const d = r.data.dogecoin;
        await client.sendMessage(chatId, {
            message: `🐕 DOGECOIN (DOGE)\n\n▸ USD: $${d.usd?.toFixed(6)}\n▸ IDR: Rp${d.idr?.toFixed(2)}\n▸ 24h: ${d.usd_24h_change?.toFixed(2)}%`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "doge", handler, description: "Harga Dogecoin", category: "crypto" };