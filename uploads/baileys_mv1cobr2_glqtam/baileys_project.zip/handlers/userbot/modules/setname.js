async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const name = args.join(" ").trim();
    if (!name) return client.sendMessage(chatId, { message: "📖 .setname [nama grup]" });
    try {
        await client.invoke(new (require("telegram").Api.channels.EditTitle)({
            channel: chatId,
            title: name
        }));
        await client.sendMessage(chatId, { message: `✅ Nama grup diubah jadi: ${name}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "setname", handler, description: "Ubah nama grup", category: "admin" };