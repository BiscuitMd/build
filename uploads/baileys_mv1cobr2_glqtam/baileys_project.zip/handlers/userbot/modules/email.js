const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const email = args[0];
    if (!email || !email.includes("@")) return client.sendMessage(chatId, { message: "📖 .email [email]" });

    const [user, domain] = email.split("@");
    const loading = await client.sendMessage(chatId, { message: `📧 Check email...` });

    try {
        const result = { email, valid: false, disposable: false, mx: false, gravatar: false };

        // 1. Format check
        result.valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

        // 2. Disposable check
        const disposableCheck = await axios.get(`https://disposable.debounce.io/?email=${encodeURIComponent(email)}`, { timeout: 10000, validateStatus: () => true }).catch(() => null);
        if (disposableCheck?.data?.disposable === "true") result.disposable = true;

        // 3. MX record check
        try {
            const dns = require("dns").promises;
            const mx = await dns.resolveMx(domain).catch(() => []);
            result.mx = mx.length > 0;
        } catch {}

        // 4. Gravatar check
        try {
            const crypto = require("crypto");
            const hash = crypto.createHash("md5").update(email.toLowerCase().trim()).digest("hex");
            const grav = await axios.head(`https://www.gravatar.com/avatar/${hash}?d=404`, { timeout: 8000, validateStatus: () => true });
            result.gravatar = grav.status === 200;
        } catch {}

        const text =
            `📧 EMAIL LOOKUP\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Email: ${email}\n` +
            `▸ User: ${user}\n` +
            `▸ Domain: ${domain}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Valid format: ${result.valid ? "✅" : "❌"}\n` +
            `▸ MX record: ${result.mx ? "✅" : "❌"}\n` +
            `▸ Disposable: ${result.disposable ? "⚠️ IYA" : "✅ Bukan"}\n` +
            `▸ Gravatar: ${result.gravatar ? "✅ Ada" : "❌ Gaada"}\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "email", handler, description: "Email lookup + validasi", category: "osint" };