// ═══════════════════════════════════════════
// UNCLONE — Balikin profile userbot ke semula
// v2 — Restore PP + nama + bio dari backup
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const fs = require("fs");
const path = require("path");
const { Api } = require("telegram");

const BACKUP_FILE = path.join(__dirname, "..", "..", "..", "database", "userbot_clone_backup.json");
if (!fs.existsSync(BACKUP_FILE)) fs.writeFileSync(BACKUP_FILE, "{}", "utf8");

function readBackup() {
    try { return JSON.parse(fs.readFileSync(BACKUP_FILE, "utf8")); } catch { return {}; }
}

function writeBackup(data) {
    fs.writeFileSync(BACKUP_FILE, JSON.stringify(data, null, 2), "utf8");
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const uid = String(userId);

    const backup = readBackup();
    const data = backup[uid];

    if (!data) {
        return client.sendMessage(chatId, {
            message:
                `❌ <b>Belum ada backup profile</b>\n\n` +
                `<i>Ketik <code>.clone</code> dulu (reply pesan user)\n` +
                `buat backup + clone.</i>`,
            parseMode: "html"
        });
    }

    const loading = await client.sendMessage(chatId, { message: "🔄 Restore profile..." });

    try {
        // 1. Restore nama + bio
        try {
            await client.invoke(new Api.account.UpdateProfile({
                firstName: data.firstName || "User",
                lastName: data.lastName || "",
                about: data.about || ""
            }));
            console.log(`[UNCLONE] ✅ name+bio restored`);
        } catch (e) {
            console.log("[UNCLONE] name restore fail:", e.message.slice(0, 100));
        }

        // 2. Hapus semua foto profile, terus upload backup
        let photoRestored = false;

        // Hapus foto yang ada dulu
        try {
            const me = await client.getMe();
            if (me.photo) {
                const photos = await client.invoke(new Api.photos.GetUserPhotos({
                    userId: me.id,
                    offset: 0,
                    maxId: 0,
                    limit: 100
                }));
                if (photos.photos && photos.photos.length > 0) {
                    const photoIds = photos.photos.map(p => p.id).filter(Boolean);
                    if (photoIds.length > 0) {
                        await client.invoke(new Api.photos.DeletePhotos({
                            id: photoIds.map(id => new Api.InputPhoto({
                                id,
                                accessHash: 0,
                                fileReference: Buffer.alloc(0)
                            }))
                        })).catch(() => {});
                    }
                }
            }
        } catch (e) {
            console.log("[UNCLONE] delete photos skip:", e.message.slice(0, 80));
        }

        // Upload backup photo kalau ada
        if (data.photoFile && fs.existsSync(data.photoFile)) {
            try {
                const buf = fs.readFileSync(data.photoFile);
                const uploadedFile = await client.uploadFile({
                    file: buf,
                    workers: 1
                });
                await client.invoke(new Api.photos.UploadProfilePhoto({
                    file: uploadedFile
                }));
                photoRestored = true;
                console.log(`[UNCLONE] ✅ photo restored`);
            } catch (e) {
                console.log("[UNCLONE] photo restore fail:", e.message.slice(0, 100));
            }
        }

        // 3. Kirim hasil
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}

        await client.sendMessage(chatId, {
            message:
                `✅ <b>UNCLONE BERHASIL</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Nama: <b>${data.firstName || "User"} ${data.lastName || ""}</b>\n` +
                `▸ Bio: <i>${(data.about || "-").slice(0, 50)}</i>\n` +
                `▸ Photo: ${photoRestored ? "✅ Restored" : (data.photoFile ? "❌ Gagal" : "❌ Gaada backup")}\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Profile userbot udah balik ke semula.</i>`,
            parseMode: "html"
        });
    } catch (e) {
        console.log("[UNCLONE ERR]", e.message);
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, {
            message: `❌ Unclone gagal: <code>${e.message.slice(0, 150)}</code>`,
            parseMode: "html"
        });
    }
}

module.exports = {
    command: "unclone",
    handler,
    description: "Balikin profile userbot ke semula",
    category: "userbot"
};