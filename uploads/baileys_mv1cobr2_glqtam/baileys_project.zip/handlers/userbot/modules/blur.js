const sharp = require("sharp");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .blur" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const blurred = await sharp(buf).blur(10).jpeg({ quality: 90 }).toBuffer();
        await client.sendFile(chatId, { file: blurred, caption: "🌫️ Blurred", forceDocument: false });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "blur", handler, description: "Blur gambar", category: "media" };