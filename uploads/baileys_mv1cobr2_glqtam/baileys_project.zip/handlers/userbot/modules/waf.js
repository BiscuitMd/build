const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .waf [url]" });

    const loading = await client.sendMessage(chatId, { message: `🛡️ Detect WAF...` });

    try {
        const r = await axios.get(url, {
            timeout: 15000,
            headers: { "User-Agent": "Mozilla/5.0" },
            validateStatus: () => true
        });

        const headers = r.headers || {};
        const wafSignatures = {
            "cloudflare": /cloudflare/i,
            "akamai": /akamai/i,
            "aws": /awselb|cloudfront/i,
            "sucuri": /sucuri/i,
            "incapsula": /incap/i,
            "f5": /big-ip|f5/i,
            "fastly": /fastly/i,
            "nginx": /nginx/i,
            "apache": /apache/i
        };

        const detected = [];
        for (const [name, regex] of Object.entries(wafSignatures)) {
            if (regex.test(headers.server || "") || regex.test(headers["x-powered-by"] || "")) detected.push(name);
        }

        const text =
            `🛡️ WAF DETECTION\n\n` +
            `▸ URL: ${url}\n` +
            `▸ Status: ${r.status}\n` +
            `▸ Server: ${headers.server || "-"}\n` +
            `▸ Powered by: ${headers["x-powered-by"] || "-"}\n` +
            `▸ Detected WAF: ${detected.length > 0 ? detected.join(", ") : "Ga kedetek"}`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "waf", handler, description: "Detect WAF website", category: "osint" };