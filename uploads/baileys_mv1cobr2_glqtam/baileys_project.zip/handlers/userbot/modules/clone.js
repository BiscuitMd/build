// ═══════════════════════════════════════════
// CLONE — Clone profile dari user (foto + nama + bio)
// v2 — Fix ambil foto + nama + bio dari reply
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const fs = require("fs");
const path = require("path");
const { Api } = require("telegram");

const BACKUP_FILE = path.join(__dirname, "..", "..", "..", "database", "userbot_clone_backup.json");
if (!fs.existsSync(BACKUP_FILE)) fs.writeFileSync(BACKUP_FILE, "{}", "utf8");

function readBackup() {
    try { return JSON.parse(fs.readFileSync(BACKUP_FILE, "utf8")); } catch { return {}; }
}

function writeBackup(data) {
    fs.writeFileSync(BACKUP_FILE, JSON.stringify(data, null, 2), "utf8");
}

// ═══ HANDLE .clone ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;

    if (!replyTo) {
        return client.sendMessage(chatId, {
            message:
                `📖 <b>CARA PAKAI .clone</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `1. Reply pesan user yang mau di-clone\n` +
                `2. Ketik <code>.clone</code>\n` +
                `3. Bot bakal ganti PP + nama + bio\n` +
                `   jadi punya target\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Buat balikin: <code>.unclone</code></i>`,
            parseMode: "html"
        });
    }

    const loading = await client.sendMessage(chatId, { message: "🔍 Clone profile..." });

    try {
        // 1. Ambil pesan target
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const targetMsg = msgs[0];
        if (!targetMsg) throw new Error("Ga bisa ambil pesan target");

        const targetId = targetMsg.senderId;
        if (!targetId) throw new Error("Target ga jelas");

        // 2. Ambil info user target
        let targetUser;
        try {
            targetUser = await client.getEntity(targetId);
        } catch (e) {
            throw new Error(`Ga bisa ambil info target: ${e.message.slice(0, 80)}`);
        }

        if (!targetUser) throw new Error("Info target kosong");

        const targetFirstName = targetUser.firstName || "User";
        const targetLastName = targetUser.lastName || "";
        const targetUsername = targetUser.username || "";

        console.log(`[CLONE] target: ${targetId} | name: ${targetFirstName} ${targetLastName}`);

        // 3. Ambil bio (about) target
        let targetAbout = "";
        try {
            const fullUser = await client.invoke(new Api.users.GetFullUser({ id: targetId }));
            targetAbout = fullUser.fullUser?.about || "";
        } catch (e) {
            console.log("[CLONE] get bio fail:", e.message.slice(0, 80));
        }

        // 4. Simpen backup profile userbot (kalau belum ada)
        const me = await client.getMe();
        const backup = readBackup();
        const uid = String(userId);

        if (!backup[uid]) {
            console.log(`[CLONE] backup profile userbot...`);

            let myAbout = "";
            try {
                const myFull = await client.invoke(new Api.users.GetFullUser({ id: me.id }));
                myAbout = myFull.fullUser?.about || "";
            } catch {}

            const backupEntry = {
                firstName: me.firstName || "",
                lastName: me.lastName || "",
                about: myAbout,
                hasPhoto: !!me.photo,
                photoFile: null,
                clonedAt: null,
                createdAt: Date.now()
            };

            // Download PP lama ke file
            if (me.photo) {
                try {
                    const photoPath = path.join(__dirname, "..", "..", "..", "database", `ubot_backup_${uid}.jpg`);
                    const buf = await client.downloadProfilePhoto(me.id);
                    if (buf && buf.length > 0) {
                        fs.writeFileSync(photoPath, buf);
                        backupEntry.photoFile = photoPath;
                        console.log(`[CLONE] ✅ backup PP saved (${buf.length} bytes)`);
                    }
                } catch (e) {
                    console.log("[CLONE] backup PP fail:", e.message.slice(0, 80));
                }
            }

            backup[uid] = backupEntry;
            writeBackup(backup);
        } else {
            console.log(`[CLONE] backup udah ada, skip`);
        }

        // 5. Ambil PP target
        let targetPhotoBuf = null;
        try {
            if (targetUser.photo) {
                targetPhotoBuf = await client.downloadProfilePhoto(targetId);
                if (targetPhotoBuf && targetPhotoBuf.length > 0) {
                    console.log(`[CLONE] target PP downloaded (${targetPhotoBuf.length} bytes)`);
                } else {
                    targetPhotoBuf = null;
                }
            }
        } catch (e) {
            console.log("[CLONE] download target PP fail:", e.message.slice(0, 80));
        }

        // 6. Update nama + bio userbot
        const newFirstName = targetFirstName.slice(0, 64);
        const newLastName = targetLastName.slice(0, 64);
        const newAbout = targetAbout.slice(0, 70);

        try {
            await client.invoke(new Api.account.UpdateProfile({
                firstName: newFirstName,
                lastName: newLastName,
                about: newAbout
            }));
            console.log(`[CLONE] ✅ name+bio updated`);
        } catch (e) {
            console.log("[CLONE] update name fail:", e.message.slice(0, 100));
            // Tetep lanjut kalau gagal
        }

        // 7. Update PP userbot
        let photoUpdated = false;
        if (targetPhotoBuf) {
            try {
                const uploadedFile = await client.uploadFile({
                    file: targetPhotoBuf,
                    workers: 1
                });
                await client.invoke(new Api.photos.UploadProfilePhoto({
                    file: uploadedFile
                }));
                photoUpdated = true;
                console.log(`[CLONE] ✅ photo updated`);
            } catch (e) {
                console.log("[CLONE] update photo fail:", e.message.slice(0, 100));
            }
        }

        // 8. Update backup info
        backup[uid].clonedAt = Date.now();
        backup[uid].clonedFrom = {
            id: String(targetId),
            firstName: newFirstName,
            lastName: newLastName,
            about: newAbout,
            username: targetUsername
        };
        writeBackup(backup);

        // 9. Kirim hasil
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}

        await client.sendMessage(chatId, {
            message:
                `✅ <b>CLONE BERHASIL</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Nama: <b>${newFirstName} ${newLastName}</b>\n` +
                `▸ Username: ${targetUsername ? "@" + targetUsername : "-"}\n` +
                `▸ Bio: <i>${newAbout.slice(0, 50) || "-"}</i>\n` +
                `▸ Photo: ${photoUpdated ? "✅ Updated" : (targetUser.photo ? "❌ Gagal" : "❌ Target gaada PP")}\n` +
                `▸ Cloned from: <code>${targetId}</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Ketik <code>.unclone</code> buat balikin profile.</i>`,
            parseMode: "html"
        });
    } catch (e) {
        console.log("[CLONE ERR]", e.message);
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, {
            message: `❌ Clone gagal: <code>${e.message.slice(0, 150)}</code>`,
            parseMode: "html"
        });
    }
}

module.exports = {
    command: "clone",
    handler,
    description: "Clone profile userbot dari user (reply)",
    category: "userbot"
};