const core = require("./gamecore");

function renderGame(room) {
    let svg = "";
    svg += `<rect x="100" y="180" width="600" height="400" rx="20" fill="rgba(0,0,0,0.5)" stroke="#fbbf24" stroke-width="3"/>`;

    for (let i = 0; i < 5; i++) {
        const bx = 200 + i * 100;
        const alive = !room.state.bottles[i].broken;
        const color = alive ? "#22c55e" : "#ef4444";
        svg += `<rect x="${bx}" y="380" width="40" height="120" rx="10" fill="${color}" stroke="#000" stroke-width="3"/>`;
        svg += `<rect x="${bx + 10}" y="360" width="20" height="30" fill="#666" stroke="#000" stroke-width="2"/>`;
        svg += `<text x="${bx + 20}" y="450" font-family="Arial" font-size="16" font-weight="900" fill="#fff" text-anchor="middle">${i + 1}</text>`;
    }

    svg += `<circle cx="400" cy="250" r="25" fill="#fbbf24" stroke="#000" stroke-width="3"/>`;
    svg += `<text x="400" y="257" font-family="Arial" font-size="20" text-anchor="middle">🏀</text>`;

    svg += `<text x="400" y="550" font-family="Arial Black" font-size="22" fill="#fbbf24" text-anchor="middle">SCORE: ${room.state.scores[0]} - ${room.state.scores[1]}</text>`;

    return svg;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderGame(room), "🍾 TEMBAK BOTOL 🎯", "orange");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const room = core.createRoom("botol", userId, myName, null, {
            state: { bottles: Array(5).fill(0).map(() => ({ broken: false })), scores: [0, 0] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "🍾 <b>TEMBAK BOTOL</b> 🎯\n\n│ 🆔 <code>" + room.id + "</code>\n│ <code>.botol join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .botol join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        await sendGame(client, chatId, r.room,
            "🍾 <b>START!</b>\n\n│ 🎯 Turn: " + r.room.players[0].name + "\n│ 📖 <code>.botol shoot [1-5]</code>"
        );
        return;
    }

    if (cmd === "shoot") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "botol" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const idx = parseInt(args[1]) - 1;
        if (isNaN(idx) || idx < 0 || idx >= 5) return client.sendMessage(chatId, { message: "▸ .botol shoot [1-5]" });

        const bottle = room.state.bottles[idx];
        let eventText;

        if (bottle.broken) {
            eventText = "❌ Botol " + (idx + 1) + " udah pecah";
        } else {
            const hit = Math.random() < 0.6;
            if (hit) {
                bottle.broken = true;
                room.state.scores[room.turn % 2]++;
                eventText = "✅ Pecah! Botol " + (idx + 1);
            } else {
                eventText = "❌ Meleset di botol " + (idx + 1);
            }
        }

        const allBroken = room.state.bottles.every(b => b.broken);
        if (allBroken) {
            const winner = room.state.scores[0] > room.state.scores[1] ? room.players[0] : room.players[1];
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🏆 " + winner.name + " menang!");
            return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
        }

        room.turn++;
        core.saveRoom(room);

        await sendGame(client, chatId, room,
            "🍾 <b>TEMBAK BOTOL</b>\n\n│ " + currentPlayer.name + "\n│ " + eventText + "\n│ Next: " + room.players[room.turn % 2].name
        );
        return;
    }

    return client.sendMessage(chatId, {
        message: "🍾 <b>TEMBAK BOTOL</b>\n\n├─────────────────\n│ ▪ .botol start\n│ ▪ .botol join [KODE]\n│ ▪ .botol shoot [1-5]\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "botol",
    handler,
    description: "Tembak botol PVP",
    category: "game"
};