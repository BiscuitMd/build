const FLAGS = { indonesia:"🇮🇩", malaysia:"🇲🇾", singapore:"🇸🇬", japan:"🇯🇵", korea:"🇰🇷", china:"🇨🇳", usa:"🇺🇸", uk:"🇬🇧", france:"🇫🇷", germany:"🇩🇪", italy:"🇮🇹", spain:"🇪🇸", brazil:"🇧🇷", india:"🇮🇳", russia:"🇷🇺", australia:"🇦🇺", canada:"🇨🇦", mexico:"🇲🇽", thailand:"🇹🇭", vietnam:"🇻🇳" };

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const country = args.join(" ").toLowerCase();
    if (!country) {
        const list = Object.entries(FLAGS).map(([k,v]) => `${v} ${k}`).join("\n");
        return client.sendMessage(chatId, { message: `📖 .flag [negara]\n\nAvailable:\n${list}` });
    }
    const flag = FLAGS[country];
    if (!flag) return client.sendMessage(chatId, { message: `❌ Negara ga ada di database` });
    await client.sendMessage(chatId, { message: `${flag} ${country.charAt(0).toUpperCase() + country.slice(1)}` });
}

module.exports = { command: "flag", handler, description: "Emoji bendera negara", category: "text" };