const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_bots.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

const BOT_ENGINES = {
    node: { name: "Node.js (Telegraf)" },
    python: { name: "Python (pyTelegramBotAPI)" },
    gramjs: { name: "GramJS (Telegram Client)" }
};

const BOT_TEMPLATES = {
    echo: "Echo Bot — balas pesan sama",
    menu: "Menu Bot — inline keyboard",
    forward: "Forward Bot — auto forward",
    admin: "Admin Bot — command admin",
    ai: "AI Bot — integrasi API AI"
};

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }
function genToken() { return Math.random().toString(36).slice(2, 12) + Date.now().toString(36).slice(-6); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || [];

    if (cmd === "new" || !cmd) {
        const name = args[1];
        const engine = (args[2] || "node").toLowerCase();
        const template = (args[3] || "echo").toLowerCase();

        if (!name) {
            let engList = Object.entries(BOT_ENGINES).map(([k, v]) => "│ ▪ " + k.padEnd(8) + " → " + v.name).join("\n");
            let tplList = Object.entries(BOT_TEMPLATES).map(([k, v]) => "│ ▪ " + k.padEnd(9) + " → " + v).join("\n");

            const text =
                "╭───────────────────╮\n" +
                "│   ✦  CREATE BOT    │\n" +
                "╰───────────────────╯\n\n" +
                "├───────────────────\n" +
                "│ ◆ USAGE\n" +
                "├───────────────────\n" +
                "│ ▪ .createbot new [nama] [engine] [template]\n" +
                "├───────────────────\n" +
                "│ ◆ ENGINES\n" +
                "├───────────────────\n" +
                engList + "\n" +
                "├───────────────────\n" +
                "│ ◆ TEMPLATES\n" +
                "├───────────────────\n" +
                tplList + "\n" +
                "├───────────────────\n" +
                "│ ◆ EXAMPLE\n" +
                "├───────────────────\n" +
                "│ ▪ .createbot new mybot node echo\n" +
                "╰───────────────────";

            return client.sendMessage(chatId, { message: text });
        }

        if (!BOT_ENGINES[engine]) return client.sendMessage(chatId, { message: "✕ Engine invalid: " + engine });
        if (!BOT_TEMPLATES[template]) return client.sendMessage(chatId, { message: "✕ Template invalid: " + template });

        const token = genToken();
        const bot = {
            id: token, name, engine, template, token,
            status: "stopped",
            createdAt: Date.now(),
            stats: { messages: 0, commands: 0 }
        };

        db[userId].push(bot);
        write(db);

        const text =
            "✓ BOT CREATED\n\n" +
            "├───────────────────\n" +
            "│ ▪ Name      → " + name + "\n" +
            "│ ▪ Engine    → " + BOT_ENGINES[engine].name + "\n" +
            "│ ▪ Template  → " + template + "\n" +
            "│ ▪ Token     → <code>" + token + "</code>\n" +
            "├───────────────────\n" +
            "│ ◆ NEXT STEPS\n" +
            "├───────────────────\n" +
            "│ ▪ .createbot start " + name + "\n" +
            "│ ▪ .botpanel config " + name + "\n" +
            "│ ▪ .createbot file " + name + "\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text, parseMode: "html" });
    }

    if (cmd === "list") {
        const bots = db[userId];
        if (!bots.length) return client.sendMessage(chatId, { message: "▸ Belum ada bot\n\nPakai: .createbot new [nama]" });

        let list = "";
        bots.forEach((b, i) => {
            const icon = b.status === "running" ? "●" : "○";
            list += "│ " + (i + 1) + ". " + icon + " " + b.name.padEnd(12) + " [" + b.engine + "/" + b.template + "]\n";
        });

        const text =
            "╭───────────────────╮\n" +
            "│   ◆  MY BOTS       │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ Total: " + bots.length + "\n" +
            "├───────────────────\n" +
            list +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "start" || cmd === "stop") {
        const name = args[1];
        const bot = db[userId].find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        if (cmd === "start") {
            if (bot.status === "running") return client.sendMessage(chatId, { message: "▪ Bot udah running" });
            bot.status = "running";
            bot.startedAt = Date.now();
            write(db);
            return client.sendMessage(chatId, { message: "✓ Bot started: " + name });
        } else {
            if (bot.status === "stopped") return client.sendMessage(chatId, { message: "▪ Bot udah stopped" });
            bot.status = "stopped";
            write(db);
            return client.sendMessage(chatId, { message: "✓ Bot stopped: " + name });
        }
    }

    if (cmd === "del") {
        const name = args[1];
        const idx = db[userId].findIndex(b => b.name === name);
        if (idx === -1) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });
        db[userId].splice(idx, 1);
        write(db);
        return client.sendMessage(chatId, { message: "✓ Bot dihapus: " + name });
    }

    if (cmd === "info") {
        const name = args[1];
        const bot = db[userId].find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const created = new Date(bot.createdAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
        const uptime = bot.startedAt ? Math.floor((Date.now() - bot.startedAt) / 60000) + " menit" : "-";

        const text =
            "╭───────────────────╮\n" +
            "│   ●  BOT INFO      │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ Name      → " + bot.name + "\n" +
            "│ ▪ Engine    → " + bot.engine + "\n" +
            "│ ▪ Template  → " + bot.template + "\n" +
            "│ ▪ Status    → " + bot.status.toUpperCase() + "\n" +
            "│ ▪ Token     → <code>" + bot.token + "</code>\n" +
            "│ ▪ Created   → " + created + "\n" +
            "│ ▪ Uptime    → " + uptime + "\n" +
            "│ ▪ Messages  → " + (bot.stats?.messages || 0) + "\n" +
            "│ ▪ Commands  → " + (bot.stats?.commands || 0) + "\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text, parseMode: "html" });
    }

    if (cmd === "file") {
        const name = args[1];
        const bot = db[userId].find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const code = generateBotCode(bot);

        const text =
            "◆ " + bot.name + " — " + bot.engine + "/" + bot.template + "\n\n" +
            "<pre>" + code.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</pre>";

        return client.sendMessage(chatId, { message: text, parseMode: "html" });
    }

    if (cmd === "token") {
        const name = args[1];
        const bot = db[userId].find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        return client.sendMessage(chatId, {
            message: "◆ TOKEN — " + name + "\n\n<code>" + bot.token + "</code>",
            parseMode: "html"
        });
    }

    if (cmd === "regen") {
        const name = args[1];
        const bot = db[userId].find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        bot.token = genToken();
        write(db);

        return client.sendMessage(chatId, {
            message: "✓ Token regenerated\n\n<code>" + bot.token + "</code>",
            parseMode: "html"
        });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ✦  CREATE BOT    │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .createbot new [nama] [engine] [template]\n" +
        "│ ▪ .createbot list\n" +
        "│ ▪ .createbot info [nama]\n" +
        "│ ▪ .createbot start [nama]\n" +
        "│ ▪ .createbot stop [nama]\n" +
        "│ ▪ .createbot file [nama]\n" +
        "│ ▪ .createbot token [nama]\n" +
        "│ ▪ .createbot regen [nama]\n" +
        "│ ▪ .createbot del [nama]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

function generateBotCode(bot) {
    const { engine, template, token, name } = bot;
    if (engine === "node") return nodeTemplate(template, token, name);
    if (engine === "python") return pythonTemplate(template, token, name);
    if (engine === "gramjs") return gramjsTemplate(template, token, name);
    return "";
}

function nodeTemplate(template, token, name) {
    const header = `const { Telegraf } = require("telegraf");\nconst bot = new Telegraf("${token}");\n\n`;
    const footer = `\nbot.launch().then(() => console.log("${name} running..."));\nprocess.once("SIGINT", () => bot.stop("SIGINT"));\nprocess.once("SIGTERM", () => bot.stop("SIGTERM"));\n`;
    if (template === "echo") return header + `bot.on("text", ctx => ctx.reply(ctx.message.text));` + footer;
    if (template === "menu") return header + `bot.start(ctx => ctx.reply("Menu:", {\n  reply_markup: { inline_keyboard: [\n    [{ text: "Info", callback_data: "info" }]\n  ]}\n}));\n\nbot.action("info", ctx => ctx.answerCbQuery("Bot by SpartaX"));` + footer;
    if (template === "forward") return header + `const TARGET = "CHANNEL_ID";\n\nbot.on("text", async ctx => {\n  await ctx.telegram.sendMessage(TARGET, ctx.message.text);\n});` + footer;
    if (template === "admin") return header + `const ADMINS = [123456789];\n\nbot.command("ban", ctx => {\n  if (!ADMINS.includes(ctx.from.id)) return;\n  ctx.reply("User banned");\n});` + footer;
    if (template === "ai") return header + `bot.on("text", async ctx => {\n  const res = await fetch("https://api.example.com/ai", {\n    method: "POST",\n    body: JSON.stringify({ prompt: ctx.message.text })\n  });\n  const data = await res.json();\n  ctx.reply(data.result || "No response");\n});` + footer;
    return header + `bot.start(ctx => ctx.reply("Hello"));` + footer;
}

function pythonTemplate(template, token, name) {
    const header = `import telebot\n\nbot = telebot.TeleBot("${token}")\n\n`;
    const footer = `\nif __name__ == "__main__":\n    print("${name} running...")\n    bot.infinity_polling()\n`;
    if (template === "echo") return header + `@bot.message_handler(func=lambda m: True)\ndef echo(message):\n    bot.reply_to(message, message.text)` + footer;
    if (template === "menu") return header + `from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton\n\n@bot.message_handler(commands=["start"])\ndef start(message):\n    kb = InlineKeyboardMarkup()\n    kb.add(InlineKeyboardButton("Info", callback_data="info"))\n    bot.send_message(message.chat.id, "Menu:", reply_markup=kb)` + footer;
    if (template === "forward") return header + `TARGET = -1001234567890\n\n@bot.message_handler(func=lambda m: True)\ndef fwd(message):\n    bot.send_message(TARGET, message.text)` + footer;
    if (template === "admin") return header + `ADMINS = [123456789]\n\n@bot.message_handler(commands=["ban"])\ndef ban(message):\n    if message.from_user.id not in ADMINS:\n        return\n    bot.reply_to(message, "User banned")` + footer;
    if (template === "ai") return header + `import requests\n\n@bot.message_handler(func=lambda m: True)\ndef ai(message):\n    r = requests.post("https://api.example.com/ai", json={"prompt": message.text})\n    bot.reply_to(message, r.json().get("result", "No response"))` + footer;
    return header + `@bot.message_handler(func=lambda m: True)\ndef hello(message):\n    bot.reply_to(message, "Hello")` + footer;
}

function gramjsTemplate(template, token, name) {
    const header = `const { TelegramClient } = require("telegram");\nconst { StringSession } = require("telegram/sessions");\nconst { NewMessage } = require("telegram/events");\n\nconst apiId = 0;\nconst apiHash = "YOUR_API_HASH";\nconst session = new StringSession("${token}");\n\n(async () => {\n  const client = new TelegramClient(session, apiId, apiHash, { connectionRetries: 5 });\n  await client.start({ botAuthToken: "${token}" });\n\n`;
    const footer = `\n  console.log("${name} running...");\n})();\n`;
    if (template === "echo") return header + `  client.addEventHandler(async (event) => {\n    const msg = event.message;\n    if (msg.out) return;\n    await client.sendMessage(msg.chatId, { message: msg.message });\n  }, new NewMessage({}));` + footer;
    if (template === "menu") return header + `  client.addEventHandler(async (event) => {\n    const msg = event.message;\n    if (msg.message === "/start") {\n      await client.sendMessage(msg.chatId, { message: "Menu\\n/start\\n/help" });\n    }\n  }, new NewMessage({}));` + footer;
    if (template === "forward") return header + `  const TARGET = "channel_username";\n  client.addEventHandler(async (event) => {\n    const msg = event.message;\n    if (msg.out) return;\n    await client.sendMessage(TARGET, { message: msg.message });\n  }, new NewMessage({}));` + footer;
    if (template === "admin") return header + `  const ADMINS = [123456789];\n  client.addEventHandler(async (event) => {\n    const msg = event.message;\n    if (msg.message === "/ban" && ADMINS.includes(Number(msg.senderId))) {\n      await client.sendMessage(msg.chatId, { message: "User banned" });\n    }\n  }, new NewMessage({}));` + footer;
    if (template === "ai") return header + `  client.addEventHandler(async (event) => {\n    const msg = event.message;\n    if (msg.out) return;\n    const res = await fetch("https://api.example.com/ai", {\n      method: "POST",\n      body: JSON.stringify({ prompt: msg.message })\n    });\n    const data = await res.json();\n    await client.sendMessage(msg.chatId, { message: data.result });\n  }, new NewMessage({}));` + footer;
    return header + `  console.log("hello");` + footer;
}

module.exports = {
    command: "createbot",
    handler,
    description: "Create bot multi-engine",
    category: "bot",
    commands: ["cb", "newbot"]
};