const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ").trim();
    if (!prompt) return client.sendMessage(chatId, { message: "📖 .ai [pertanyaan]" });

    const loading = await client.sendMessage(chatId, { message: "🤖 AI mikir..." });

    try {
        const r = await axios.post("https://text.pollinations.ai/openai", {
            model: "openai",
            messages: [
                { role: "system", content: "Kamu AI asisten ramah. Jawab singkat padat jelas." },
                { role: "user", content: prompt }
            ],
            temperature: 0.7,
            private: true
        }, { timeout: 60000 });

        const text = r.data?.choices?.[0]?.message?.content || "AI ga bisa jawab.";
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ Error: ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "ai", handler, description: "AI chat via Pollinations", category: "ai" };