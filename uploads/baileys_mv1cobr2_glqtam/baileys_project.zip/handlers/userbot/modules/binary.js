async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mode = args[0]?.toLowerCase();
    const text = args.slice(1).join(" ");
    if (!mode || !text) return client.sendMessage(chatId, { message: "📖 .binary [encode/decode] [text]" });

    if (mode === "encode") {
        const out = text.split("").map(c => c.charCodeAt(0).toString(2).padStart(8, "0")).join(" ");
        return client.sendMessage(chatId, { message: out });
    }
    if (mode === "decode") {
        try {
            const out = text.split(" ").map(b => String.fromCharCode(parseInt(b, 2))).join("");
            return client.sendMessage(chatId, { message: out });
        } catch {
            return client.sendMessage(chatId, { message: "❌ Invalid binary" });
        }
    }
    await client.sendMessage(chatId, { message: "❌ Mode harus encode/decode" });
}

module.exports = { command: "binary", handler, description: "Encode/decode binary", category: "text" };