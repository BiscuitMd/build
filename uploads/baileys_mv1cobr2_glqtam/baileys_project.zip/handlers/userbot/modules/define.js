const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const term = args.join(" ");
    if (!term) return client.sendMessage(chatId, { message: "📖 .define [kata]" });
    try {
        const r = await axios.get(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(term)}`, { timeout: 15000 });
        const d = r.data?.list?.[0];
        if (!d) throw new Error("Kata ga ditemukan");
        await client.sendMessage(chatId, {
            message: `📚 ${d.word}\n\n▸ Definisi: ${d.definition.slice(0, 1000)}\n\n▸ Contoh: ${(d.example || "-").slice(0, 500)}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "define", handler, description: "Kamus Urban Dictionary", category: "tools" };