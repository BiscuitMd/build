const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://dogapi.dog/api/v2/facts", { timeout: 15000 });
        const fact = r.data?.data?.[0]?.attributes?.body || "No fact";
        await client.sendMessage(chatId, { message: `🐶 DOG FACT:\n\n${fact}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "dogfact", handler, description: "Dog fact random", category: "fun" };