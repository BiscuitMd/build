async function handler(userId, client, msg, args) {
    const sides = Math.min(parseInt(args[0]) || 6, 1000);
    const result = Math.floor(Math.random() * sides) + 1;
    const emoji = ["⚀","⚁","⚂","⚃","⚄","⚅"][Math.min(result - 1, 5)] || "🎲";
    await client.sendMessage(msg.message.chatId, {
        message: `${emoji} Dadu ${sides} sisi\n\n▸ Hasil: *${result}*`,
        parseMode: "markdown"
    });
}

module.exports = { command: "dice", handler, description: "Lempar dadu", category: "fun" };