async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .owo [text]" });
    const owo = text
        .replace(/r/g, "w").replace(/R/g, "W")
        .replace(/l/g, "w").replace(/L/g, "W")
        .replace(/no/g, "nyo").replace(/No/g, "Nyo")
        .replace(/!+/g, "! ^w^");
    await client.sendMessage(chatId, { message: owo + " owo" });
}

module.exports = { command: "owo", handler, description: "OwO text", category: "fun" };