const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ") || "anime girl kawaii";
    const loading = await client.sendMessage(chatId, { message: "🌸 Anime generate..." });
    try {
        const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt + ", anime style, kawaii, detailed")}?width=1024&height=1024&nologo=true&model=flux&seed=${Date.now()}`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 90000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(r.data), caption: `🌸 ${prompt}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "anime", handler, description: "Generate anime image", category: "ai" };