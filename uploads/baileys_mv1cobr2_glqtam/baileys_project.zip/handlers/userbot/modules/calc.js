async function handler(userId, client, msg, args) {
    const expr = args.join(" ").replace(/[^0-9+\-*/().%\s]/g, "");
    if (!expr) return client.sendMessage(msg.message.chatId, { message: "📖 .calc 2+2*3" });
    try {
        const result = Function(`"use strict"; return (${expr})`)();
        await client.sendMessage(msg.message.chatId, { message: `🧮 ${expr} = ${result}` });
    } catch (e) {
        await client.sendMessage(msg.message.chatId, { message: `❌ Invalid expression` });
    }
}

module.exports = { command: "calc", handler, description: "Kalkulator", category: "tools" };