const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "🔥 Trending crypto..." });
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/search/trending", { timeout: 15000 });
        const list = r.data?.coins || [];
        let text = `🔥 TRENDING CRYPTO\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        list.forEach((c, i) => {
            const item = c.item;
            text += `${i + 1}. ${item.name} (${item.symbol})\n▸ Rank: #${item.market_cap_rank || "-"}\n▸ Score: ${item.score}\n\n`;
        });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "trendingcrypto", handler, description: "Trending crypto", category: "crypto" };