const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ").trim();
    if (!text) return client.sendMessage(chatId, { message: "📖 .qr [text/url]" });

    try {
        const url = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(text)}`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 20000 });
        const buf = Buffer.from(r.data);
        await client.sendFile(chatId, {
            file: buf,
            caption: `📱 QR: ${text.slice(0, 100)}`,
            forceDocument: false
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "qr", handler, description: "Generate QR code", category: "tools" };