const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url || !url.includes("t.me/addstickers")) return client.sendMessage(chatId, { message: "📖 .stickertelegram [t.me/addstickers/xxx]" });
    const loading = await client.sendMessage(chatId, { message: "🎴 Ambil stiker pack..." });
    try {
        const { Api } = require("telegram");
        const nameMatch = url.match(/addstickers\/(.+)/);
        if (!nameMatch) throw new Error("Format URL salah");
        const setName = nameMatch[1];
        const stickerSet = await client.invoke(new Api.messages.GetStickerSet({
            stickerset: new Api.InputStickerSetShortName({ shortName: setName }),
            hash: 0
        }));
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message: `✅ Sticker pack: ${stickerSet.set?.title || setName}\n▸ Total: ${stickerSet.documents?.length || 0} stiker`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "stickertelegram", handler, description: "Info sticker pack", category: "media" };