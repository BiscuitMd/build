const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const [btc, eth] = await Promise.all([
            axios.get("https://blockchain.info/q/getblockcount", { timeout: 15000, responseType: "text" }).then(r => r.data).catch(() => "-"),
            axios.get("https://api.blockcypher.com/v1/eth/main", { timeout: 15000 }).then(r => r.data.height).catch(() => "-")
        ]);
        await client.sendMessage(chatId, {
            message:
                `📦 BLOCK COUNT\n\n` +
                `▸ BTC: ${btc}\n` +
                `▸ ETH: ${eth}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "blockcount", handler, description: "Block count BTC/ETH", category: "crypto" };