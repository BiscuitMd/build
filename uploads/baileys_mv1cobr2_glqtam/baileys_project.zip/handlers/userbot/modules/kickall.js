async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const confirm = args[0] === "yes";
    if (!confirm) {
        return client.sendMessage(chatId, { message: "⚠️ .kickall yes — kick semua member (KECUALI admin)\n\n<i>Bisa bikin lu di-ban Telegram!</i>", parseMode: "html" });
    }
    try {
        const participants = await client.getParticipants(chatId);
        let kicked = 0;
        for (const p of participants) {
            if (p.id.toString() === userId) continue;
            try {
                await client.kickParticipant(chatId, p.id);
                kicked++;
                await new Promise(r => setTimeout(r, 800));
            } catch {}
        }
        await client.sendMessage(chatId, { message: `✅ Kick ${kicked} member` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "kickall", handler, description: "Kick semua member (hati-hati)", category: "admin" };