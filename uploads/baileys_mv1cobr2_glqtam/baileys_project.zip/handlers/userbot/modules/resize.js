const sharp = require("sharp");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    const size = parseInt(args[0]) || 512;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .resize [size]" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const resized = await sharp(buf).resize(size, size, { fit: "inside" }).jpeg({ quality: 90 }).toBuffer();
        await client.sendFile(chatId, { file: resized, caption: `📐 Resized ke ${size}x${size}`, forceDocument: false });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "resize", handler, description: "Resize gambar", category: "media" };