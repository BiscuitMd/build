async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const memUsage = process.memoryUsage();
    const uptime = process.uptime();

    const text =
        `📊 STATS\n\n` +
        `▸ Uptime: ${Math.floor(uptime / 60)}m ${Math.floor(uptime % 60)}s\n` +
        `▸ RAM: ${(memUsage.rss / 1024 / 1024).toFixed(2)} MB\n` +
        `▸ Heap: ${(memUsage.heapUsed / 1024 / 1024).toFixed(2)} MB\n` +
        `▸ Node: ${process.version}\n` +
        `▸ Platform: ${process.platform}`;

    await client.sendMessage(chatId, { message: text });
}

module.exports = { command: "stats", handler, description: "Bot stats", category: "info" };