async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];

    if (!url) return client.sendMessage(chatId, { message: "▸ .uptime [url]\n\n▸ Contoh: .uptime https://google.com" });

    try {
        const start = Date.now();
        const res = await fetch(url, {
            method: "HEAD",
            signal: AbortSignal.timeout(10000),
            headers: { "User-Agent": "SpartaX-Monitor" }
        });
        const latency = Date.now() - start;

        const text =
            "╭───────────────────╮\n" +
            "│   ◉  UPTIME        │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ URL      → " + url.slice(0, 40) + "\n" +
            "│ ▪ Status   → " + (res.ok ? "● UP" : "○ DOWN") + "\n" +
            "│ ▪ Code     → " + res.status + "\n" +
            "│ ▪ Latency  → " + latency + "ms\n" +
            "│ ▪ Server   → " + (res.headers.get("server") || "-") + "\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    } catch (e) {
        return client.sendMessage(chatId, { message: "✕ DOWN: " + e.message });
    }
}

module.exports = {
    command: "uptime",
    handler,
    description: "Cek uptime/status website",
    category: "monitor"
};