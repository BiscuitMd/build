async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mac = args[0];
    if (!mac) return client.sendMessage(chatId, { message: "📖 .mac [MAC address]" });

    try {
        const r = await axios.get(`https://api.macvendors.com/${encodeURIComponent(mac)}`, { timeout: 15000, validateStatus: () => true });
        if (r.status === 200) {
            await client.sendMessage(chatId, { message: `🔍 MAC VENDOR: ${mac}\n\n▸ Vendor: ${r.data}` });
        } else {
            await client.sendMessage(chatId, { message: `❌ Vendor ga ditemukan (HTTP ${r.status})` });
        }
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

const axios = require("axios");
module.exports = { command: "mac", handler, description: "Lookup MAC address vendor", category: "osint" };