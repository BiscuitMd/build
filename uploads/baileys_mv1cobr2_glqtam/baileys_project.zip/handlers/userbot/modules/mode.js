// ═══════════════════════════════════════════
// MODE — Self / Public mode userbot
// v1 — Switch mode biar cuma owner atau semua orang
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const store = require("../session-store");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const senderId = msg.message?.senderId?.toString() || "";
    const isFromSelf = String(senderId) === String(userId);

    const currentMode = store.getMode(userId);
    const newMode = args[0]?.toLowerCase();

    // Tanpa argumen → tampilkan status
    if (!newMode) {
        return client.sendMessage(chatId, {
            message:
                `🔒 <b>MODE USERBOT</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Current: <b>${currentMode === "self" ? "🔒 SELF" : "🌐 PUBLIC"}</b>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>Penjelasan:</b>\n` +
                `▸ <b>SELF</b> — cuma owner (lu) yang bisa pake command\n` +
                `▸ <b>PUBLIC</b> — semua orang bisa pake command\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>Cara ganti:</b>\n` +
                `▸ <code>.mode self</code>\n` +
                `▸ <code>.mode public</code>`,
            parseMode: "html"
        });
    }

    // Cek mode valid
    if (!["self", "public"].includes(newMode)) {
        return client.sendMessage(chatId, {
            message: `❌ Mode ga valid. Pilih: <code>self</code> atau <code>public</code>`,
            parseMode: "html"
        });
    }

    // Cuma owner yang bisa ganti mode
    if (!isFromSelf) {
        return client.sendMessage(chatId, {
            message: `❌ Cuma owner userbot yang bisa ganti mode`
        });
    }

    // Mode sama, skip
    if (currentMode === newMode) {
        return client.sendMessage(chatId, {
            message: `⚠️ Mode udah <b>${newMode.toUpperCase()}</b>`,
            parseMode: "html"
        });
    }

    // Ganti mode
    const ok = store.setMode(userId, newMode);
    if (!ok) {
        return client.sendMessage(chatId, {
            message: `❌ Gagal ganti mode. Coba lagi.`
        });
    }

    await client.sendMessage(chatId, {
        message:
            `✅ <b>MODE DIUBAH</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Old: <b>${currentMode.toUpperCase()}</b>\n` +
            `▸ New: <b>${newMode.toUpperCase()}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            (newMode === "self"
                ? `🔒 <b>Self Mode Aktif</b>\n▸ Cuma lu yang bisa pake command .xxx\n▸ Pesan dari orang lain diabaikan`
                : `🌐 <b>Public Mode Aktif</b>\n▸ Semua orang bisa pake command .xxx\n▸ Gunakan dengan bijak!`),
        parseMode: "html"
    });
}

module.exports = {
    command: "mode",
    handler,
    description: "Ganti mode self/public userbot",
    category: "userbot"
};