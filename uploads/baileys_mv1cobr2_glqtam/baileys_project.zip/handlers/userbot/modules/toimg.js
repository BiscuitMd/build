async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply stiker + .toimg" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        await client.sendFile(chatId, { file: buf, forceDocument: false, caption: "🖼️ Stiker → Gambar" });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "toimg", handler, description: "Convert stiker ke gambar", category: "media" };