const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const symbol = args[0]?.toUpperCase();
    if (!symbol) return client.sendMessage(chatId, { message: "📖 .stock [symbol]\nContoh: .stock AAPL" });
    try {
        const r = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`, { timeout: 15000 });
        const meta = r.data?.chart?.result?.[0]?.meta;
        if (!meta) throw new Error("Stock ga ditemukan");
        await client.sendMessage(chatId, {
            message:
                `📈 ${meta.symbol}\n\n` +
                `▸ Harga: ${meta.regularMarketPrice} ${meta.currency}\n` +
                `▸ Prev close: ${meta.chartPreviousClose}\n` +
                `▸ Exchange: ${meta.exchangeName}\n` +
                `▸ Timezone: ${meta.exchangeTimezoneName}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "stock", handler, description: "Harga saham", category: "info" };