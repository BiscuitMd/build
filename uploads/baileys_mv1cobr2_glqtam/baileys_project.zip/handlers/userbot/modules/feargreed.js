const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.alternative.me/fng/?limit=1", { timeout: 15000 });
        const d = r.data?.data?.[0];
        if (!d) throw new Error("No data");
        const val = parseInt(d.value);
        const bar = "█".repeat(Math.round(val / 5)) + "░".repeat(20 - Math.round(val / 5));
        await client.sendMessage(chatId, {
            message:
                `😱 FEAR & GREED INDEX\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Value: ${d.value}/100\n` +
                `▸ Label: ${d.value_classification}\n` +
                `\n${bar}\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Updated: ${new Date(d.timestamp * 1000).toLocaleString("id-ID")}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "feargreed", handler, description: "Fear & Greed Index crypto", category: "crypto" };