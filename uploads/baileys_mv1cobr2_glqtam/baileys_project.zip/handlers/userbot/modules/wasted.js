async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let target = args.join(" ") || "dia";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) target = msgs[0].sender?.firstName || "dia";
    }

    await client.sendMessage(chatId, {
        message: `☠️ *WASTED*\n\n▸ ${target} udah tumbang~`
    });
}

module.exports = { command: "wasted", handler, description: "Wasted meme", category: "fun" };