async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ").trim();
    if (!text) return client.sendMessage(chatId, { message: "📖 .broadcast [text]" });

    try {
        const dialogs = await client.getDialogs({ limit: 50 });
        let sent = 0, failed = 0;
        for (const d of dialogs) {
            try {
                await client.sendMessage(d.id, { message: text });
                sent++;
                await new Promise(r => setTimeout(r, 1000));
            } catch { failed++; }
        }
        await client.sendMessage(chatId, { message: `✅ Broadcast selesai\n▸ Sent: ${sent}\n▸ Failed: ${failed}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "broadcast", handler, description: "Broadcast ke semua chat", category: "admin" };