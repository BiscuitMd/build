const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const input = args.join(" ");
    if (!input) return client.sendMessage(chatId, { message: "📖 .translate [text] atau .translate en|Hello" });

    let to = "id", text = input;
    const m = input.match(/^(\w{2})\|(.+)$/s);
    if (m) { to = m[1]; text = m[2].trim(); }

    try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${to}`, { timeout: 15000 });
        const result = r.data?.responseData?.translatedText;
        if (!result) throw new Error("Translate gagal");
        await client.sendMessage(chatId, { message: `🌐 [${to}] ${result}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "translate", handler, description: "Translate text", category: "tools" };