const core = require("./gamecore");

const COLORS = ["red", "blue", "green", "yellow"];
const NUMBERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

const COLOR_HEX = {
    red: "#ef4444",
    blue: "#3b82f6",
    green: "#22c55e",
    yellow: "#eab308",
    wild: "#1f2937"
};

function makeDeck() {
    const deck = [];
    for (const c of COLORS) {
        for (const n of NUMBERS) {
            deck.push({ color: c, value: String(n) });
            deck.push({ color: c, value: String(n) });
        }
        deck.push({ color: c, value: "Skip" });
        deck.push({ color: c, value: "+2" });
    }
    for (let i = 0; i < 4; i++) {
        deck.push({ color: "wild", value: "Wild" });
        deck.push({ color: "wild", value: "+4" });
    }
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function renderCard(card, x, y, scale = 1) {
    const w = 60 * scale;
    const h = 90 * scale;
    const color = COLOR_HEX[card.color] || "#1f2937";
    const textColor = card.color === "yellow" ? "#000" : "#fff";

    let content = "";
    content += `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="${color}" stroke="#000" stroke-width="2"/>`;

    if (card.color === "wild") {
        for (let i = 0; i < 4; i++) {
            const cx = x + w / 2 + Math.cos(i * Math.PI / 2 + Math.PI / 4) * w / 4;
            const cy = y + h / 2 + Math.sin(i * Math.PI / 2 + Math.PI / 4) * h / 4;
            content += `<circle cx="${cx}" cy="${cy}" r="${w / 5}" fill="${COLOR_HEX[COLORS[i]]}"/>`;
        }
    }

    content += `<text x="${x + w / 2}" y="${y + h / 2 + 6}" font-family="Arial Black" font-size="${16 * scale}" font-weight="900" fill="${textColor}" text-anchor="middle">${core.escapeXml(card.value)}</text>`;

    return content;
}

async function sendGame(client, chatId, room, caption = "") {
    const s = room.state;
    let svg = "";

    svg += `<text x="400" y="200" font-family="Arial Black" font-size="22" fill="#fbbf24" text-anchor="middle">DISCARD PILE</text>`;
    svg += renderCard(s.discard[s.discard.length - 1], 370, 220, 1.5);

    svg += `<text x="400" y="420" font-family="Arial Black" font-size="22" fill="#22c55e" text-anchor="middle">YOUR HAND (${s.hands[room.turn % 2].length})</text>`;

    const hand = s.hands[room.turn % 2];
    const startX = 400 - (hand.length * 65) / 2;
    hand.forEach((card, i) => {
        svg += renderCard(card, startX + i * 65, 440, 1);
    });

    svg += `<text x="400" y="580" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">Current Color: ${s.currentColor.toUpperCase()}</text>`;

    svg += `<text x="400" y="620" font-family="Arial" font-size="18" fill="#fbbf24" text-anchor="middle">Turn: ${room.players[room.turn % 2].name}</text>`;

    const buf = await core.renderSVG(core.buildLegoFrame(svg, "🃏 UNO 🃏", "red"));
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";
    const myUsername = me?.username || null;

    if (cmd === "start") {
        const deck = makeDeck();
        const hands = [[], []];
        for (let i = 0; i < 7; i++) {
            hands[0].push(deck.pop());
            hands[1].push(deck.pop());
        }

        let first = deck.pop();
        while (first.color === "wild") {
            deck.unshift(first);
            first = deck.pop();
        }

        const room = core.createRoom("uno", userId, myName, myUsername, {
            state: { deck, hands, discard: [first], currentColor: first.color },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        const caption =
            "🃏 <b>UNO ROOM</b> 🃏\n\n" +
            "├─────────────────\n" +
            "│ 🆔 Room   → <code>" + room.id + "</code>\n" +
            "│ 👤 Host   → " + myName + "\n" +
            "│ 👥 Player → 1/2\n" +
            "├─────────────────\n" +
            "│ <code>.uno join " + room.id + "</code>\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .uno join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, myUsername);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        const caption =
            "🃏 <b>UNO START!</b> 🃏\n\n" +
            "├─────────────────\n" +
            "│ 👤 P1 → " + r.room.players[0].name + "\n" +
            "│ 👤 P2 → " + r.room.players[1].name + "\n" +
            "├─────────────────\n" +
            "│ 🎯 Turn → " + r.room.players[0].name + "\n" +
            "│ 📖 Main: <code>.uno play [index]</code>\n" +
            "│ 📖 Ambil: <code>.uno draw</code>\n" +
            "╰─────────────────";

        await sendGame(client, chatId, r.room, caption);
        return;
    }

    const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "uno" && r.status === "playing");
    if (!room) return client.sendMessage(chatId, { message: "✕ Lu ga di game UNO aktif. Ketik .uno start / .uno join [KODE]" });

    const currentPlayer = room.players[room.turn % 2];
    if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

    const myIdx = room.turn % 2;
    const otherIdx = 1 - myIdx;

    if (cmd === "draw") {
        if (room.state.deck.length === 0) {
            return client.sendMessage(chatId, { message: "✕ Deck kosong" });
        }
        const card = room.state.deck.pop();
        room.state.hands[myIdx].push(card);
        room.turn++;
        core.saveRoom(room);

        const caption = "🃏 " + currentPlayer.name + " ambil kartu → " + card.color + " " + card.value + "\n🎯 Turn: " + room.players[room.turn % 2].name;
        await sendGame(client, chatId, room, caption);
        return;
    }

    if (cmd === "play") {
        const idx = parseInt(args[1]);
        const hand = room.state.hands[myIdx];
        if (isNaN(idx) || idx < 1 || idx > hand.length) return client.sendMessage(chatId, { message: "✕ Index invalid (1-" + hand.length + ")" });

        const card = hand[idx - 1];
        const top = room.state.discard[room.state.discard.length - 1];

        const matchColor = card.color === room.state.currentColor;
        const matchValue = card.value === top.value;
        const isWild = card.color === "wild";

        if (!matchColor && !matchValue && !isWild) {
            return client.sendMessage(chatId, { message: "✕ Kartu ga match! Top: " + room.state.currentColor + " " + top.value });
        }

        hand.splice(idx - 1, 1);
        room.state.discard.push(card);
        if (card.color !== "wild") room.state.currentColor = card.color;

        if (card.value === "Skip") {
            room.turn += 2;
        } else if (card.value === "+2") {
            for (let i = 0; i < 2; i++) room.state.hands[otherIdx].push(room.state.deck.pop());
            room.turn += 2;
        } else if (card.value === "+4") {
            for (let i = 0; i < 4; i++) room.state.hands[otherIdx].push(room.state.deck.pop());
            room.turn += 2;
        } else {
            room.turn++;
        }

        if (hand.length === 0) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🃏 UNO! " + currentPlayer.name + " menang!");
            return core.checkWinAndReward(room, currentPlayer.id, currentPlayer.name, client, chatId);
        }

        core.saveRoom(room);

        const caption =
            "🃏 <b>UNO</b>\n\n" +
            "├─────────────────\n" +
            "│ Play    → " + card.color + " " + card.value + "\n" +
            "│ Sisa    → " + hand.length + " kartu\n" +
            "│ Next    → " + room.players[room.turn % 2].name + "\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "🃏 <b>UNO</b> 🃏\n\n" +
            "├─────────────────\n" +
            "│ ▪ .uno start\n" +
            "│ ▪ .uno join [KODE]\n" +
            "│ ▪ .uno play [index]\n" +
            "│ ▪ .uno draw\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "uno",
    handler,
    description: "UNO card game PVP",
    category: "game"
};