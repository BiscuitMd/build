async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    if (cmd === "js") {
        const code = args.slice(1).join(" ");
        if (!code) return client.sendMessage(chatId, { message: "▸ .obfuscate js [kode]" });

        const hexed = code.split("").map(c => "\\x" + c.charCodeAt(0).toString(16).padStart(2, "0")).join("");
        const out = "eval(\"" + hexed + "\")";

        return client.sendMessage(chatId, {
            message: "◆ JS OBFUSCATED\n\n<code>" + out + "</code>",
            parseMode: "html"
        });
    }

    if (cmd === "php") {
        const code = args.slice(1).join(" ");
        if (!code) return client.sendMessage(chatId, { message: "▸ .obfuscate php [kode]" });

        const b64 = Buffer.from(code).toString("base64");
        const out = "<?php eval(base64_decode('" + b64 + "')); ?>";

        return client.sendMessage(chatId, {
            message: "◆ PHP OBFUSCATED\n\n<code>" + out.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</code>",
            parseMode: "html"
        });
    }

    if (cmd === "b64loop") {
        const code = args.slice(1).join(" ");
        if (!code) return client.sendMessage(chatId, { message: "▸ .obfuscate b64loop [kode]" });

        let out = code;
        for (let i = 0; i < 5; i++) out = Buffer.from(out).toString("base64");

        return client.sendMessage(chatId, {
            message: "◆ 5x B64 ENCODED\n\n<code>" + out + "</code>",
            parseMode: "html"
        });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚿  OBFUSCATE     │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .obfuscate js [code]\n" +
        "│ ▪ .obfuscate php [code]\n" +
        "│ ▪ .obfuscate b64loop [code]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "obfuscate",
    handler,
    description: "Obfuscate JS/PHP code",
    category: "security"
};