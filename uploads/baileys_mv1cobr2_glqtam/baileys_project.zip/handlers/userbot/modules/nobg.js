const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .nobg" });
    const loading = await client.sendMessage(chatId, { message: "🎨 Remove BG..." });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const b64 = buf.toString("base64");
        const r = await axios.post("https://api.siputzx.my.id/api/ai/removebg", { image: b64 }, { timeout: 60000 }).catch(() => null);
        if (!r || !r.data?.data?.url) throw new Error("API ga support / limit");
        const img = await axios.get(r.data.data.url, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(img.data), caption: "🎨 No BG", forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "nobg", handler, description: "Hapus background foto (alt API)", category: "media" };