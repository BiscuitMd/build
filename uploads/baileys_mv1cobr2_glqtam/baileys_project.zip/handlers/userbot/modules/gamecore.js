const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DB_DIR = path.join(__dirname, "..", "..", "..", "database");
const ROOMS_FILE = path.join(DB_DIR, "game_rooms.json");
const COIN_FILE = path.join(DB_DIR, "game_coins.json");
const CLAIM_FILE = path.join(DB_DIR, "game_claims.json");

if (!fs.existsSync(ROOMS_FILE)) fs.writeFileSync(ROOMS_FILE, "{}", "utf8");
if (!fs.existsSync(COIN_FILE)) fs.writeFileSync(COIN_FILE, "{}", "utf8");
if (!fs.existsSync(CLAIM_FILE)) fs.writeFileSync(CLAIM_FILE, "{}", "utf8");

function readJSON(f) { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return {}; } }
function writeJSON(f, d) { fs.writeFileSync(f, JSON.stringify(d, null, 2), "utf8"); }

const ROOMS = readJSON(ROOMS_FILE);
const COINS = readJSON(COIN_FILE);
const CLAIMS = readJSON(CLAIM_FILE);

function saveRooms() { writeJSON(ROOMS_FILE, ROOMS); }
function saveCoins() { writeJSON(COIN_FILE, COINS); }
function saveClaims() { writeJSON(CLAIM_FILE, CLAIMS); }

function genRoomId() {
    return crypto.randomBytes(4).toString("hex").toUpperCase();
}

function createRoom(gameType, hostId, hostName, hostUsername, extra = {}) {
    const id = genRoomId();
    const room = {
        id,
        gameType,
        host: { id: hostId, name: hostName, username: hostUsername },
        players: [{ id: hostId, name: hostName, username: hostUsername, joinedAt: Date.now() }],
        state: extra.state || {},
        turn: 0,
        status: "waiting",
        maxPlayers: extra.maxPlayers || 2,
        createdAt: Date.now(),
        chatId: extra.chatId,
        lastMove: null,
        moveHistory: []
    };
    ROOMS[id] = room;
    saveRooms();
    return room;
}

function getRoom(id) { return ROOMS[id] || null; }
function saveRoom(room) { ROOMS[room.id] = room; saveRooms(); }
function deleteRoom(id) { delete ROOMS[id]; saveRooms(); }

function joinRoom(id, userId, userName, userUsername) {
    const room = ROOMS[id];
    if (!room) return { ok: false, error: "Room gaada" };
    if (room.status === "playing") return { ok: false, error: "Game udah mulai" };
    if (room.players.length >= room.maxPlayers) return { ok: false, error: "Room penuh" };
    if (room.players.find(p => p.id === userId)) return { ok: true, room, already: true };

    room.players.push({ id: userId, name: userName, username: userUsername, joinedAt: Date.now() });
    if (room.players.length >= room.maxPlayers) room.status = "playing";
    saveRoom(room);
    return { ok: true, room };
}

function addCoin(userId, amount = 1) {
    COINS[userId] = (COINS[userId] || 0) + amount;
    saveCoins();
    return COINS[userId];
}

function getCoin(userId) { return COINS[userId] || 0; }

function subtractCoin(userId, amount) {
    COINS[userId] = Math.max(0, (COINS[userId] || 0) - amount);
    saveCoins();
    return COINS[userId];
}

function getClaimStatus(userId) {
    const c = CLAIMS[userId];
    if (!c) return { claimed: false, expiresAt: 0, active: false };
    const active = c.expiresAt > Date.now();
    return { claimed: true, expiresAt: c.expiresAt, active, claimedAt: c.claimedAt };
}

function setClaim(userId, days) {
    CLAIMS[userId] = {
        claimedAt: Date.now(),
        expiresAt: Date.now() + days * 86400000,
        days
    };
    saveClaims();
}

async function renderSVG(svg, width = 800, height = 800) {
    try {
        const sharp = require("sharp");
        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch {
        return Buffer.from(svg);
    }
}

function escapeXml(s) {
    return String(s).replace(/[<>&'"]/g, c => ({
        "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
    }[c]));
}

async function sendGameImage(client, chatId, svgBuffer, caption, buttons = null) {
    try {
        const { CustomFile } = require("telegram/client/uploads");
        const file = new CustomFile("game.png", svgBuffer.length, "", svgBuffer);

        const opts = {
            file,
            caption,
            parseMode: "html"
        };

        if (buttons) {
            const { Api } = require("telegram");
            opts.buttons = buttons;
        }

        await client.sendFile(chatId, opts);
    } catch (e) {
        await client.sendMessage(chatId, { message: caption + "\n\n✕ Image fail: " + e.message, parseMode: "html" });
    }
}

function buildLegoFrame(content, title, theme = "blue") {
    const themes = {
        blue: { bg: "#1e40af", accent: "#3b82f6", light: "#93c5fd" },
        red: { bg: "#991b1b", accent: "#ef4444", light: "#fca5a5" },
        green: { bg: "#166534", accent: "#22c55e", light: "#86efac" },
        yellow: { bg: "#a16207", accent: "#eab308", light: "#fde047" },
        purple: { bg: "#6b21a8", accent: "#a855f7", light: "#d8b4fe" },
        orange: { bg: "#c2410c", accent: "#f97316", light: "#fdba74" }
    };
    const t = themes[theme] || themes.blue;

    return (
        `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">` +
        `<defs>` +
        `<pattern id="lego" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">` +
        `<rect width="40" height="40" fill="${t.bg}"/>` +
        `<circle cx="20" cy="20" r="10" fill="${t.accent}" opacity="0.15"/>` +
        `</pattern>` +
        `<linearGradient id="header" x1="0%" y1="0%" x2="100%" y2="0%">` +
        `<stop offset="0%" stop-color="${t.accent}"/>` +
        `<stop offset="100%" stop-color="${t.light}"/>` +
        `</linearGradient>` +
        `</defs>` +
        `<rect width="800" height="800" fill="url(#lego)"/>` +
        `<rect x="20" y="20" width="760" height="80" rx="15" fill="url(#header)" stroke="#000" stroke-width="3"/>` +
        `<text x="400" y="72" font-family="Arial Black,sans-serif" font-size="36" font-weight="900" fill="#fff" text-anchor="middle" letter-spacing="2">${escapeXml(title)}</text>` +
        `<rect x="20" y="120" width="760" height="660" rx="20" fill="rgba(0,0,0,0.85)" stroke="${t.accent}" stroke-width="4"/>` +
        content +
        `</svg>`
    );
}

async function checkWinAndReward(room, winnerId, winnerName, client, chatId) {
    addCoin(winnerId, 1);
    const totalCoins = getCoin(winnerId);

    await client.sendMessage(chatId, {
        message:
            "🏆 <b>WINNER!</b> 🏆\n\n" +
            "├─────────────────\n" +
            "│ 🥇 Pemenang  → " + winnerName + "\n" +
            "│ 💰 Reward    → +1 coin\n" +
            "│ 📊 Total     → " + totalCoins + " coin\n" +
            "├─────────────────\n" +
            "│ " + (totalCoins >= 20
                ? "✨ Ketik .claim buat claim userbot gratis 7 hari!"
                : "🎯 Butuh " + (20 - totalCoins) + " coin lagi buat claim") + "\n" +
            "╰─────────────────",
        parseMode: "html"
    });

    room.status = "finished";
    saveRoom(room);
}

module.exports = {
    ROOMS, COINS, CLAIMS,
    createRoom, getRoom, saveRoom, deleteRoom, joinRoom,
    addCoin, getCoin, subtractCoin,
    getClaimStatus, setClaim,
    renderSVG, escapeXml, sendGameImage, buildLegoFrame,
    checkWinAndReward,
    saveRooms, saveCoins, saveClaims
};