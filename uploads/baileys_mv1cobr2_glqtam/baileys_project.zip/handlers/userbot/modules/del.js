async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply pesan + .del" });

    try {
        await client.deleteMessages(chatId, [replyTo], { revoke: true });
        await client.deleteMessages(chatId, [msg.message.id], { revoke: true }).catch(() => {});
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "del", handler, description: "Hapus pesan", category: "group" };