const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://catfact.ninja/fact", { timeout: 15000 });
        await client.sendMessage(chatId, { message: `🐱 CAT FACT:\n\n${r.data.fact}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "catfact", handler, description: "Cat fact random", category: "fun" };