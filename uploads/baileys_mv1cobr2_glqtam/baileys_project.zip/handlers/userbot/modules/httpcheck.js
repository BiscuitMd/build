async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];

    if (!url) return client.sendMessage(chatId, { message: "▸ .httpcheck [url]" });

    try {
        const start = Date.now();
        const res = await fetch(url, {
            signal: AbortSignal.timeout(15000),
            headers: { "User-Agent": "SpartaX-Monitor" },
            redirect: "follow"
        });
        const elapsed = Date.now() - start;

        const headers = {};
        res.headers.forEach((v, k) => { headers[k] = v; });

        let headerList = "";
        Object.entries(headers).slice(0, 15).forEach(([k, v]) => {
            headerList += "│ " + k + ": " + String(v).slice(0, 35) + "\n";
        });

        const text =
            "╭───────────────────╮\n" +
            "│   ◉  HTTPCHECK     │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ URL       → " + url.slice(0, 40) + "\n" +
            "│ ▪ Status    → " + res.status + " " + res.statusText + "\n" +
            "│ ▪ Latency   → " + elapsed + "ms\n" +
            "│ ▪ Redirect  → " + (res.redirected ? "YES" : "NO") + "\n" +
            "├───────────────────\n" +
            "│ ◆ HEADERS\n" +
            "├───────────────────\n" +
            headerList +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    } catch (e) {
        return client.sendMessage(chatId, { message: "✕ Error: " + e.message });
    }
}

module.exports = {
    command: "httpcheck",
    handler,
    description: "Check HTTP response & headers",
    category: "monitor"
};