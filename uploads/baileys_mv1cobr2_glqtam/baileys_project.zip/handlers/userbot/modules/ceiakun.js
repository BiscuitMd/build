const { Api } = require("telegram");

const ID_TIMELINE = [
    { id: 100000, date: "2013-08-01", label: "Awal Telegram" },
    { id: 500000, date: "2014-01-01", label: "2014" },
    { id: 1000000, date: "2014-06-01", label: "2014 pertengahan" },
    { id: 5000000, date: "2015-01-01", label: "2015" },
    { id: 10000000, date: "2015-06-01", label: "2015 pertengahan" },
    { id: 20000000, date: "2016-01-01", label: "2016" },
    { id: 40000000, date: "2017-01-01", label: "2017" },
    { id: 80000000, date: "2018-01-01", label: "2018" },
    { id: 150000000, date: "2019-01-01", label: "2019" },
    { id: 250000000, date: "2020-01-01", label: "2020" },
    { id: 400000000, date: "2021-01-01", label: "2021" },
    { id: 550000000, date: "2022-01-01", label: "2022" },
    { id: 700000000, date: "2023-01-01", label: "2023" },
    { id: 800000000, date: "2024-01-01", label: "2024" },
    { id: 900000000, date: "2025-01-01", label: "2025" }
];

function estimateDate(userId) {
    const id = Number(userId);
    if (isNaN(id)) return { date: "-", era: "-", confidence: "unknown" };

    for (let i = 0; i < ID_TIMELINE.length - 1; i++) {
        const curr = ID_TIMELINE[i];
        const next = ID_TIMELINE[i + 1];
        if (id >= curr.id && id < next.id) {
            const ratio = (id - curr.id) / (next.id - curr.id);
            const startTime = new Date(curr.date).getTime();
            const endTime = new Date(next.date).getTime();
            const estTime = startTime + ratio * (endTime - startTime);
            const estDate = new Date(estTime);

            return {
                date: estDate.toISOString().slice(0, 10),
                era: curr.label + " - " + next.label,
                confidence: "estimasi dari ID"
            };
        }
    }

    if (id >= ID_TIMELINE[ID_TIMELINE.length - 1].id) {
        return { date: "2025+", era: "2025 atau lebih baru", confidence: "estimasi" };
    }

    return { date: "sebelum 2013", era: "pre-2013", confidence: "unknown" };
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const target = args[0] || msg.message.replyTo?.senderId?.toString();

    if (!target) {
        return client.sendMessage(chatId, {
            message:
                "╭───────────────────╮\n" +
                "│   ◇  CEK AKUN TG   │\n" +
                "╰───────────────────╯\n\n" +
                "├───────────────────\n" +
                "│ ▪ .ceiakun [@user/ID]\n" +
                "│ ▪ Atau reply pesan target\n" +
                "╰───────────────────\n\n" +
                "▸ Contoh: .ceiakun @durov\n" +
                "▸ Atau reply ke pesan target terus ketik .ceiakun"
        });
    }

    try {
        const entity = await client.getEntity(target);
        const full = await client.invoke(new Api.users.GetFullUser({ id: entity.id }));

        const u = full.users[0];
        const fu = full.fullUser;

        const name = [u.firstName, u.lastName].filter(Boolean).join(" ") || "-";
        const username = u.username ? "@" + u.username : "-";
        const est = estimateDate(entity.id);

        let photoCount = 0;
        try {
            const photos = await client.invoke(new Api.photos.GetUserPhotos({
                userId: entity.id, offset: 0, maxId: 0, limit: 100
            }));
            photoCount = photos.photos?.length || 0;
        } catch {}

        const statusClass = u.status?.className || "Unknown";
        let statusText = "Unknown";
        if (statusClass === "UserStatusOnline") statusText = "● ONLINE";
        else if (statusClass === "UserStatusOffline") statusText = "○ OFFLINE (" + new Date(u.status.wasOnline * 1000).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + ")";
        else if (statusClass === "UserStatusRecently") statusText = "○ RECENTLY";
        else if (statusClass === "UserStatusLastWeek") statusText = "○ LAST WEEK";
        else if (statusClass === "UserStatusLastMonth") statusText = "○ LAST MONTH";

        const accountAgeDays = Math.floor((Date.now() - new Date(est.date).getTime()) / 86400000);
        const accountAgeYears = (accountAgeDays / 365).toFixed(1);

        const text =
            "╭───────────────────╮\n" +
            "│   ◇  CEK AKUN TG   │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ PROFILE\n" +
            "├───────────────────\n" +
            "│ ▪ Name       → " + name + "\n" +
            "│ ▪ Username   → " + username + "\n" +
            "│ ▪ ID         → <code>" + entity.id + "</code>\n" +
            "│ ▪ Bio        → " + (fu.about || "-").slice(0, 40) + "\n" +
            "│ ▪ Phone      → " + (u.phone || "hidden") + "\n" +
            "├───────────────────\n" +
            "│ ◆ ESTIMASI AKUN DIBUAT\n" +
            "├───────────────────\n" +
            "│ ▪ Tanggal    → " + est.date + "\n" +
            "│ ▪ Era        → " + est.era + "\n" +
            "│ ▪ Umur Akun  → ~" + accountAgeYears + " tahun (" + accountAgeDays + " hari)\n" +
            "│ ▪ Metode     → " + est.confidence + "\n" +
            "├───────────────────\n" +
            "│ ◆ METADATA\n" +
            "├───────────────────\n" +
            "│ ▪ Photos     → " + photoCount + "\n" +
            "│ ▪ Common     → " + (fu.commonChatsCount || 0) + " chats\n" +
            "│ ▪ Status     → " + statusText + "\n" +
            "│ ▪ Premium    → " + (u.premium ? "✓ YES" : "✕ NO") + "\n" +
            "│ ▪ Verified   → " + (u.verified ? "✓ YES" : "✕ NO") + "\n" +
            "│ ▪ Scam       → " + (u.scam ? "⚠️ YES" : "✓ NO") + "\n" +
            "│ ▪ Fake       → " + (u.fake ? "⚠️ YES" : "✓ NO") + "\n" +
            "│ ▪ Bot        → " + (u.bot ? "YES" : "NO") + "\n" +
            "╰───────────────────\n\n" +
            "▸ Note: Tanggal dibuat itu <b>estimasi</b> dari ID Telegram karena Telegram ga expose data resmi.";

        return client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        return client.sendMessage(chatId, { message: "✕ Error: " + e.message });
    }
}

module.exports = {
    command: "ceiakun",
    handler,
    description: "Cek estimasi tanggal pembuatan akun Telegram",
    category: "tools",
    commands: ["akuninfo", "accountage", "umurakun"]
};