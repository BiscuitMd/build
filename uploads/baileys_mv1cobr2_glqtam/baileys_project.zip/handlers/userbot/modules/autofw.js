// ═══════════════════════════════════════════
// AUTOFW — Auto Forward dengan sistem PUTARAN
// v4 — Putaran + .addbl + .delbl + .listbl
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const fs = require("fs");
const path = require("path");

const FW_FILE = path.join(__dirname, "..", "..", "..", "database", "userbot_autofw.json");
if (!fs.existsSync(FW_FILE)) fs.writeFileSync(FW_FILE, "{}", "utf8");

// Runtime state
const RUNNING_JOBS = new Map();

const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
};

function readFw() {
    try { return JSON.parse(fs.readFileSync(FW_FILE, "utf8")); } catch { return {}; }
}

function writeFw(data) {
    fs.writeFileSync(FW_FILE, JSON.stringify(data, null, 2), "utf8");
}

function defaultConfig() {
    return {
        enabled: false,
        mode: "both",              // "user" | "group" | "channel" | "both"
        intervalMs: 60000,         // jeda ANTAR PUTARAN
        blacklist: [],             // [ { id, name, addedAt } ]
        lastRun: 0,
        totalSent: 0,
        totalFailed: 0,
        totalRounds: 0
    };
}

function getConfig(userId) {
    const fw = readFw();
    const uid = String(userId);
    if (!fw[uid]) {
        fw[uid] = defaultConfig();
        writeFw(fw);
    }
    const cfg = fw[uid];
    if (!cfg.mode) cfg.mode = "both";
    if (!cfg.intervalMs) cfg.intervalMs = 60000;
    if (!cfg.blacklist) cfg.blacklist = [];
    return cfg;
}

function setConfig(userId, patch) {
    const fw = readFw();
    const uid = String(userId);
    fw[uid] = { ...(fw[uid] || defaultConfig()), ...patch };
    writeFw(fw);
    return fw[uid];
}

// ═══ PARSE INTERVAL ═══
function parseIntervalInput(input) {
    if (!input) return null;
    const m = String(input).toLowerCase().trim();
    let match = m.match(/^(\d+)\s*(ms|s|m|h)$/);
    if (match) {
        const num = parseInt(match[1]);
        const unit = match[2];
        if (unit === "ms") return num;
        if (unit === "s") return num * 1000;
        if (unit === "m") return num * 60 * 1000;
        if (unit === "h") return num * 60 * 60 * 1000;
    }
    match = m.match(/^(\d+)$/);
    if (match) return parseInt(match[1]) * 1000;
    return null;
}

function formatInterval(ms) {
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)} detik`;
    return `${(ms / 60000).toFixed(1)} menit`;
}

// ═══════════════════════════════════════════
// HANDLE COMMAND .autofw
// ═══════════════════════════════════════════
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const uid = String(userId);
    const cfg = getConfig(userId);
    const text = msg.message?.message || msg.message?.text || "";
    const cmd = text.slice(1).trim().split(/\s+/)[0].toLowerCase();

    // ═══════════════════════════════════
    // .addbl — Add group ke blacklist (HARUS DI GROUP)
    // ═══════════════════════════════════
    if (cmd === "addbl") {
        // Cek chat type — harus group
        const isGroup = msg.message?.peerId?.className === "PeerChannel" ||
                       msg.message?.peerId?.className === "PeerChat";

        if (!isGroup) {
            return client.sendMessage(chatId, {
                message:
                    `${I.cross} <b>Harus di GROUP</b>\n\n` +
                    `${I.bulletOut} Command <code>.addbl</code> cuma bisa dipake di dalam group\n` +
                    `${I.bulletOut} Group yang lu kirim command ini bakal di-blacklist`,
                parseMode: "html"
            });
        }

        // Dapetin info group
        let groupName = "Unknown Group";
        let groupId = String(chatId);

        try {
            const entity = await client.getEntity(chatId);
            groupName = entity.title || entity.username || "Unknown Group";
            groupId = String(entity.id);

            // Handle channel ID format
            if (entity.className === "Channel" || entity.className === "Chat") {
                const rawId = entity.id?.toString() || "";
                if (rawId && !rawId.startsWith("-100")) {
                    // Konversi ke format -100xxx
                    groupId = "-100" + rawId.replace("-100", "").replace("-", "");
                } else {
                    groupId = rawId || String(chatId);
                }
            }
        } catch (e) {
            console.log("[AUTOFW addbl] getEntity fail:", e.message);
        }

        const fw = readFw();
        const userCfg = fw[uid] || defaultConfig();
        if (!userCfg.blacklist) userCfg.blacklist = [];

        // Cek udah ada?
        const existing = userCfg.blacklist.find(b => String(b.id) === String(groupId));
        if (existing) {
            return client.sendMessage(chatId, {
                message:
                    `${I.squareOut} <b>Group udah di blacklist</b>\n\n` +
                    `${I.bulletOut} Nama: <b>${existing.name}</b>\n` +
                    `${I.bulletOut} ID: <code>${existing.id}</code>`,
                parseMode: "html"
            });
        }

        // Add ke blacklist
        userCfg.blacklist.push({
            id: String(groupId),
            name: groupName,
            addedAt: Date.now()
        });

        fw[uid] = userCfg;
        writeFw(fw);

        await client.sendMessage(chatId, {
            message:
                `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                `${I.pipe}  ${I.check} SUCCESS ADDBL  ${I.pipe}\n` +
                `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} GROUP INFO\n` +
                `${I.teeL}${I.line.repeat(22)}\n` +
                `${I.pipe} ${I.bullet} Nama  ${I.arrow}  <b>${groupName.slice(0, 30)}</b>\n` +
                `${I.pipe} ${I.bullet} ID    ${I.arrow}  <code>${groupId}</code>\n` +
                `${I.pipe} ${I.bullet} Total ${I.arrow}  <code>${userCfg.blacklist.length}</code> groups\n` +
                `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                `${I.arrow} <i>Group ini gaakan dikirim pesan autofw</i>`,
            parseMode: "html"
        });
        return;
    }

    // ═══════════════════════════════════
    // .delbl — Hapus dari blacklist (DI GROUP)
    // ═══════════════════════════════════
    if (cmd === "delbl") {
        const isGroup = msg.message?.peerId?.className === "PeerChannel" ||
                       msg.message?.peerId?.className === "PeerChat";

        if (!isGroup) {
            return client.sendMessage(chatId, {
                message: `${I.cross} Command <code>.delbl</code> cuma bisa di group`,
                parseMode: "html"
            });
        }

        let groupId = String(chatId);
        try {
            const entity = await client.getEntity(chatId);
            groupId = String(entity.id);
        } catch {}

        const fw = readFw();
        const userCfg = fw[uid] || defaultConfig();
        const before = (userCfg.blacklist || []).length;
        userCfg.blacklist = (userCfg.blacklist || []).filter(b => String(b.id) !== String(groupId));

        if (before === userCfg.blacklist.length) {
            return client.sendMessage(chatId, {
                message: `${I.squareOut} Group ini gaada di blacklist`,
                parseMode: "html"
            });
        }

        fw[uid] = userCfg;
        writeFw(fw);

        await client.sendMessage(chatId, {
            message:
                `${I.check} <b>Group dihapus dari blacklist</b>\n\n` +
                `${I.bulletOut} ID: <code>${groupId}</code>\n` +
                `${I.bulletOut} Total: <code>${userCfg.blacklist.length}</code> groups`,
            parseMode: "html"
        });
        return;
    }

    // ═══════════════════════════════════
    // .listbl — List blacklist
    // ═══════════════════════════════════
    if (cmd === "listbl") {
        const fw = readFw();
        const userCfg = fw[uid] || defaultConfig();
        const bl = userCfg.blacklist || [];

        if (bl.length === 0) {
            return client.sendMessage(chatId, {
                message: `${I.squareOut} Blacklist kosong`,
                parseMode: "html"
            });
        }

        let list = "";
        bl.forEach((b, i) => {
            list += `${i + 1}. <b>${String(b.name || "Unknown").slice(0, 30)}</b>\n`;
            list += `   ${I.bulletOut} <code>${b.id}</code>\n`;
        });

        return client.sendMessage(chatId, {
            message:
                `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                `${I.pipe}  ${I.square} BLACKLIST ${I.square}  ${I.pipe}\n` +
                `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                `${list}\n` +
                `${I.bulletOut} Total: <code>${bl.length}</code> groups`,
            parseMode: "html"
        });
    }

    // ═══════════════════════════════════
    // .autofw — Menu utama
    // ═══════════════════════════════════
    if (cmd === "autofw") {
        const sub = args[0]?.toLowerCase();
        const val = args[1];
        const rest = args.slice(1).join(" ");

        if (!sub) {
            const statusText = cfg.enabled ? "ON" : "OFF";
            const modeText = cfg.mode === "both" ? "User + Group + Channel" :
                            cfg.mode === "user" ? "Cuma User DM" :
                            cfg.mode === "group" ? "Cuma Group" :
                            cfg.mode === "channel" ? "Cuma Channel" : cfg.mode;

            return client.sendMessage(chatId, {
                message:
                    `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                    `${I.pipe}  ${I.square} AUTOFW COMMANDS  ${I.pipe}\n` +
                    `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                    `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.circle} STATUS\n` +
                    `${I.teeL}${I.line.repeat(22)}\n` +
                    `${I.pipe} ${I.bullet} Status     ${I.arrow}  <b>${statusText}</b>\n` +
                    `${I.pipe} ${I.bullet} Mode       ${I.arrow}  <b>${modeText}</b>\n` +
                    `${I.pipe} ${I.bullet} Jeda       ${I.arrow}  <b>${formatInterval(cfg.intervalMs)}</b>\n` +
                    `${I.pipe} ${I.bullet} Blacklist  ${I.arrow}  <code>${(cfg.blacklist || []).length}</code>\n` +
                    `${I.pipe} ${I.bullet} Sent       ${I.arrow}  <code>${cfg.totalSent || 0}</code>\n` +
                    `${I.pipe} ${I.bullet} Putaran    ${I.arrow}  <code>${cfg.totalRounds || 0}</code>\n` +
                    `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                    `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.diamond} COMMANDS\n` +
                    `${I.teeL}${I.line.repeat(22)}\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw on</code>       Aktifin\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw off</code>      Matiin\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw stop</code>     Force stop\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw mode user</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw mode group</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw mode channel</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw mode both</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw jeda 30s</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw jeda 5m</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw send [text]</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.addbl</code>           Bl group ini\n` +
                    `${I.pipe} ${I.bullet} <code>.delbl</code>           Unbl group ini\n` +
                    `${I.pipe} ${I.bullet} <code>.listbl</code>          Liat blacklist\n` +
                    `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}`,
                parseMode: "html"
            });
        }

        // ─── ON ───
        if (sub === "on") {
            const newCfg = setConfig(userId, { enabled: true });
            return client.sendMessage(chatId, {
                message:
                    `${I.check} <b>AUTOFW ON</b>\n\n` +
                    `${I.bulletOut} Mode: ${newCfg.mode}\n` +
                    `${I.bulletOut} Jeda: ${formatInterval(newCfg.intervalMs)}\n\n` +
                    `${I.arrow} Kirim <code>.autofw send [text]</code> buat mulai`,
                parseMode: "html"
            });
        }

        // ─── OFF ───
        if (sub === "off") {
            setConfig(userId, { enabled: false });
            const job = RUNNING_JOBS.get(uid);
            if (job) {
                job.stopped = true;
                RUNNING_JOBS.delete(uid);
            }
            return client.sendMessage(chatId, {
                message: `${I.cross} <b>AUTOFW OFF</b>\n\n<i>Running forward dihentikan.</i>`,
                parseMode: "html"
            });
        }

        // ─── STOP ───
        if (sub === "stop") {
            const job = RUNNING_JOBS.get(uid);
            if (job) {
                job.stopped = true;
                RUNNING_JOBS.delete(uid);
                return client.sendMessage(chatId, {
                    message: `${I.squareOut} <b>STOPPED</b>`,
                    parseMode: "html"
                });
            }
            return client.sendMessage(chatId, { message: `${I.squareOut} Gaada proses running` });
        }

        // ─── MODE ───
        if (sub === "mode") {
            if (!["user", "group", "channel", "both"].includes(val)) {
                return client.sendMessage(chatId, {
                    message: `${I.cross} Mode: <code>user</code> | <code>group</code> | <code>channel</code> | <code>both</code>`,
                    parseMode: "html"
                });
            }
            setConfig(userId, { mode: val });
            return client.sendMessage(chatId, { message: `${I.check} Mode: <b>${val.toUpperCase()}</b>`, parseMode: "html" });
        }

        // ─── JEDA ───
        if (sub === "jeda" || sub === "interval") {
            const ms = parseIntervalInput(val);
            if (!ms) {
                return client.sendMessage(chatId, {
                    message:
                        `${I.cross} Format jeda salah\n\n` +
                        `${I.bulletOut} <code>.autofw jeda 30s</code>\n` +
                        `${I.bulletOut} <code>.autofw jeda 5m</code>\n` +
                        `${I.bulletOut} <code>.autofw jeda 1h</code>`,
                    parseMode: "html"
                });
            }
            if (ms < 5000) return client.sendMessage(chatId, { message: `${I.cross} Jeda minimal 5 detik` });
            if (ms > 24 * 60 * 60 * 1000) return client.sendMessage(chatId, { message: `${I.cross} Jeda max 24 jam` });

            setConfig(userId, { intervalMs: ms });
            return client.sendMessage(chatId, { message: `${I.check} Jeda: <b>${formatInterval(ms)}</b>`, parseMode: "html" });
        }

        // ─── SEND ───
        if (sub === "send") {
            const sendText = rest;
            if (!sendText) return client.sendMessage(chatId, { message: `${I.bullet} <code>.autofw send [text]</code>`, parseMode: "html" });

            const c = getConfig(userId);
            if (!c.enabled) return client.sendMessage(chatId, { message: `${I.cross} Autofw OFF. Ketik <code>.autofw on</code> dulu` });
            if (RUNNING_JOBS.has(uid)) return client.sendMessage(chatId, { message: `${I.squareOut} Masih ada proses running` });

            await client.sendMessage(chatId, {
                message:
                    `${I.circle} <b>MULAI FORWARD</b>\n\n` +
                    `${I.bulletOut} Mode: ${c.mode}\n` +
                    `${I.bulletOut} Jeda antar putaran: ${formatInterval(c.intervalMs)}\n` +
                    `${I.bulletOut} Text: <i>${sendText.slice(0, 100)}</i>\n\n` +
                    `${I.arrow} Ketik <code>.autofw off</code> buat stop`,
                parseMode: "html"
            });

            runForward(userId, client, sendText).catch(e => console.log("[AUTOFW BG ERR]", e.message));
            return;
        }

        return client.sendMessage(chatId, { message: `${I.cross} Command ga dikenal` });
    }
}

// ═══════════════════════════════════════════
// RUN FORWARD — SISTEM PUTARAN
// ═══════════════════════════════════════════
async function runForward(userId, client, text) {
    const uid = String(userId);
    const job = { stopped: false, startedAt: Date.now() };
    RUNNING_JOBS.set(uid, job);

    const cfg = getConfig(userId);
    const intervalMs = cfg.intervalMs || 60000;
    const blacklistIds = (cfg.blacklist || []).map(b => String(b.id).toLowerCase());

    let totalSent = 0;
    let totalFailed = 0;
    let totalRounds = 0;
    let stopped = false;

    function shouldStop() {
        const j = RUNNING_JOBS.get(uid);
        const cfgNow = getConfig(userId);
        if (!j || j.stopped || !cfgNow.enabled) return true;
        return false;
    }

    // ═══════════════════════════════════
    // KUMPULIN SEMUA TARGET DULU
    // ═══════════════════════════════════
    console.log(`[AUTOFW] scanning targets...`);

    const targets = {
        users: [],
        groups: [],
        channels: []
    };

    try {
        const dialogs = await client.getDialogs({ limit: 500 });

        for (const d of dialogs) {
            const id = String(d.id || d.entity?.id || "");
            if (!id) continue;
            if (blacklistIds.includes(id.toLowerCase())) {
                console.log(`[AUTOFW] skip blacklist: ${id}`);
                continue;
            }

            // Filter user
            if (d.isUser && !d.entity?.bot && !d.entity?.self) {
                targets.users.push({ id: d.id, name: d.title || d.name || "User" });
            }
            // Filter group
            else if (d.isGroup) {
                targets.groups.push({ id: d.id, name: d.title || "Group" });
            }
            // Filter channel
            else if (d.isChannel && !d.isGroup) {
                targets.channels.push({ id: d.id, name: d.title || "Channel" });
            }
        }
    } catch (e) {
        console.log("[AUTOFW] getDialogs err:", e.message);
    }

    console.log(`[AUTOFW] targets: users=${targets.users.length} groups=${targets.groups.length} channels=${targets.channels.length}`);

    // ═══════════════════════════════════
    // FILTER SESUAI MODE
    // ═══════════════════════════════════
    const sendList = [];
    if (cfg.mode === "user" || cfg.mode === "both") {
        for (const t of targets.users) sendList.push({ ...t, type: "user" });
    }
    if (cfg.mode === "group" || cfg.mode === "both") {
        for (const t of targets.groups) sendList.push({ ...t, type: "group" });
    }
    if (cfg.mode === "channel" || cfg.mode === "both") {
        for (const t of targets.channels) sendList.push({ ...t, type: "channel" });
    }

    if (sendList.length === 0) {
        RUNNING_JOBS.delete(uid);
        try {
            await client.sendMessage("me", {
                message: `${I.cross} Gaada target buat dikirim`
            });
        } catch {}
        return;
    }

    console.log(`[AUTOFW] total targets: ${sendList.length}`);

    // ═══════════════════════════════════
    // PUTARAN LOOP — SEND KE SEMUA TARGET
    // ═══════════════════════════════════
    try {
        // ═══ PUTARAN: kirim ke SEMUA target tanpa jeda ═══
        totalRounds++;

        for (let i = 0; i < sendList.length; i++) {
            if (shouldStop()) {
                console.log(`[AUTOFW] ✕ stopped`);
                stopped = true;
                break;
            }

            const target = sendList[i];

            try {
                await client.sendMessage(target.id, { message: text });
                totalSent++;
                console.log(`[AUTOFW] ✓ [${i + 1}/${sendList.length}] ${target.type} ${target.name}`);
            } catch (e) {
                totalFailed++;
                console.log(`[AUTOFW] ✕ [${i + 1}/${sendList.length}] ${target.type} ${target.name}: ${e.message.slice(0, 60)}`);
            }
        }

        console.log(`[AUTOFW] ✓ PUTARAN SELESAI — sent=${totalSent} failed=${totalFailed}`);
    } finally {
        RUNNING_JOBS.delete(uid);

        const cfgNow = getConfig(userId);
        setConfig(userId, {
            totalSent: (cfgNow.totalSent || 0) + totalSent,
            totalFailed: (cfgNow.totalFailed || 0) + totalFailed,
            totalRounds: (cfgNow.totalRounds || 0) + totalRounds,
            lastRun: Date.now()
        });

        try {
            await client.sendMessage("me", {
                message:
                    `${stopped ? I.squareOut + " AUTOFW STOPPED" : I.check + " AUTOFW SELESAI"}\n\n` +
                    `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.circle} RESULT\n` +
                    `${I.teeL}${I.line.repeat(20)}\n` +
                    `${I.pipe} ${I.bullet} Sent       ${I.arrow}  <code>${totalSent}</code>\n` +
                    `${I.pipe} ${I.bullet} Failed     ${I.arrow}  <code>${totalFailed}</code>\n` +
                    `${I.pipe} ${I.bullet} Total      ${I.arrow}  <code>${sendList.length}</code>\n` +
                    `${I.pipe} ${I.bullet} Putaran    ${I.arrow}  <code>${totalRounds}</code>\n` +
                    `${I.pipe} ${I.bullet} Mode       ${I.arrow}  <b>${cfg.mode}</b>\n` +
                    `${I.pipe} ${I.bullet} Durasi     ${I.arrow}  ${((Date.now() - job.startedAt) / 1000).toFixed(1)}s\n` +
                    `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`
            });
        } catch {}
    }
}

// ═══ FORWARD PESAN MASUK (opsional) ═══
async function handleForward(userId, client, msg) {
    const cfg = getConfig(userId);
    if (!cfg.enabled) return;
    if (cfg.mode === "user") return;

    const chatId = String(msg.message.chatId);
    const blacklistIds = (cfg.blacklist || []).map(b => String(b.id).toLowerCase());
    if (blacklistIds.includes(chatId.toLowerCase())) return;
}

module.exports = {
    command: "autofw",
    handler,
    handleForward,
    runForward,
    getConfig,
    setConfig,
    commands: ["autofw", "addbl", "delbl", "listbl"],
    description: "Auto forward dengan putaran + blacklist",
    category: "forward"
};

console.log("[AUTOFW] module loaded (v4 — putaran + addbl)");