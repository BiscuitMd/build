const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const category = args[0] || "Any";
    try {
        const r = await axios.get(`https://v2.jokeapi.dev/joke/${category}?blacklistFlags=nsfw,religious,political,racist,sexist,explicit`, { timeout: 15000 });
        const d = r.data;
        let text = "";
        if (d.type === "single") text = d.joke;
        else text = `${d.setup}\n\n${d.delivery}`;
        await client.sendMessage(chatId, { message: `😂 JOKE\n\n${text}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "jokeapi", handler, description: "Joke random dari JokeAPI", category: "fun" };