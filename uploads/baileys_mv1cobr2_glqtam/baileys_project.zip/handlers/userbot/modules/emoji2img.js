const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const emoji = args[0];
    if (!emoji) return client.sendMessage(chatId, { message: "📖 .emoji2img 😀" });
    try {
        const url = `https://emojicdn.elk.sh/${encodeURIComponent(emoji)}?style=apple`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
        await client.sendFile(chatId, { file: Buffer.from(r.data), forceDocument: false });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "emoji2img", handler, description: "Emoji jadi gambar HD", category: "media" };