const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const domain = args[0];
    if (!domain) return client.sendMessage(chatId, { message: "📖 .whois [domain]" });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/tools/whois?domain=${encodeURIComponent(domain)}`, { timeout: 20000 });
        const d = r.data?.data;
        const text =
            `🔍 WHOIS ${domain}\n\n` +
            `▸ Registrar: ${d?.registrar || "-"}\n` +
            `▸ Created: ${d?.creationDate || "-"}\n` +
            `▸ Expiry: ${d?.expirationDate || "-"}\n` +
            `▸ Nameservers: ${(d?.nameservers || []).join(", ") || "-"}`;
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "whois", handler, description: "WHOIS domain lookup", category: "tools" };