const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const [amount, from, to] = args;
    if (!amount || !from || !to) {
        return client.sendMessage(chatId, { message: "📖 .converter [amount] [from] [to]\nContoh: .converter 1 btc idr\n\nCoins: btc, eth, bnb, sol, xrp, doge, ada, ton, dll\nFiat: usd, idr, eur, jpy, dll" });
    }

    const loading = await client.sendMessage(chatId, { message: `💱 Convert...` });
    try {
        const coinMap = { btc: "bitcoin", eth: "ethereum", bnb: "binancecoin", sol: "solana", xrp: "ripple", doge: "dogecoin", ada: "cardano", ton: "the-open-network", dot: "polkadot", matic: "matic-network", avax: "avalanche-2", link: "chainlink" };

        const fromId = coinMap[from.toLowerCase()] || from.toLowerCase();
        const toLower = to.toLowerCase();

        const r = await axios.get(`https://api.coingecko.com/api/v3/simple/price?ids=${fromId}&vs_currencies=${toLower}`, { timeout: 15000 });
        const rate = r.data?.[fromId]?.[toLower];
        if (!rate) throw new Error("Kurs ga ditemukan");

        const result = (parseFloat(amount) * rate).toLocaleString("id-ID");
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: `💱 ${amount} ${from.toUpperCase()} = ${result} ${to.toUpperCase()}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "converter", handler, description: "Convert crypto ke fiat / crypto", category: "crypto" };