const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ") || "cat";
    const loading = await client.sendMessage(chatId, { message: "🎬 Cari GIF..." });
    try {
        const r = await axios.get(`https://api.giphy.com/v1/gifs/search?api_key=dc6zaTOxFJmzC&q=${encodeURIComponent(query)}&limit=20`, { timeout: 15000 });
        const list = r.data?.data || [];
        if (list.length === 0) throw new Error("No gif");
        const pick = list[Math.floor(Math.random() * list.length)];
        const gifUrl = pick.images?.original?.url;
        const gif = await axios.get(gifUrl, { responseType: "arraybuffer", timeout: 30000, maxContentLength: 20 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(gif.data), caption: `🎬 ${query}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "gif", handler, description: "Cari GIF dari Giphy", category: "media" };