const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const username = args[0];
    if (!username) return client.sendMessage(chatId, { message: "📖 .github [username]" });
    try {
        const r = await axios.get(`https://api.github.com/users/${username}`, { headers: { "User-Agent": "SpartaX-Bot" }, timeout: 15000 });
        const d = r.data;
        await client.sendMessage(chatId, {
            message:
                `🐙 GITHUB: ${d.login}\n\n` +
                `▸ Nama: ${d.name || "-"}\n` +
                `▸ Bio: ${d.bio || "-"}\n` +
                `▸ Repos: ${d.public_repos}\n` +
                `▸ Followers: ${d.followers}\n` +
                `▸ Following: ${d.following}\n` +
                `▸ Location: ${d.location || "-"}\n` +
                `▸ Blog: ${d.blog || "-"}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "github", handler, description: "Info user GitHub", category: "info" };