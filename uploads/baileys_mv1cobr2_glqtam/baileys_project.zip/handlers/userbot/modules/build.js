const path = require("path");
const fs = require("fs");
const axios = require("axios");
const AdmZip = require("adm-zip");

// ⚡ LIMIT ZIP
const MAX_ZIP_SIZE = 70 * 1024 * 1024;

// ⚡ ICON SET
const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
    triangle: "▲", triangleDown: "▼", triangleRight: "►",
};

// ⚡ ROOT
const ROOT = path.join(__dirname, "..", "..", "..");
const cfg = require(path.join(ROOT, "config.js"));

// ⚡ GITHUB BUILDER
const GH_PATH = path.join(__dirname, "..", "github-builder.js");

let gh;
try {
    gh = require(GH_PATH);
    console.log("[UBOT BUILD] ✅ github-builder loaded");
} catch (e) {
    console.log("[UBOT BUILD] ❌ gagal load github-builder:", e.message);
    gh = {
        putFile: async () => { throw new Error("github-builder gaada"); },
        uploadFile: async () => { throw new Error("github-builder gaada"); },
        deleteFile: async () => null,
        triggerWorkflow: async () => ({ ok: false, error: "github-builder gaada" }),
        getLatestRun: async () => null,
        getRunStatus: async () => null,
        getRunArtifacts: async () => [],
        downloadArtifact: async () => { throw new Error("github-builder gaada"); },
        getRunLogs: async () => null,
        newJobId: (prefix = "job") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
    };
}

const TMP_DIR = path.join(ROOT, "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ STATE ═══
const PENDING_ZIPS = new Map();
const ACTIVE_BUILDS = new Map();
const KEEP_ALIVE_INTERVALS = new Map();

// ═══════════════════════════════════════════
// KEEP ALIVE
// ═══════════════════════════════════════════
function startKeepAlive(userId, client) {
    stopKeepAlive(userId);
    const intervalId = setInterval(async () => {
        try {
            if (client && typeof client.getMe === "function") {
                await client.getMe();
            }
        } catch (e) {
            if (e.message && (
                e.message.includes("disconnect") ||
                e.message.includes("ECONNRESET") ||
                e.message.includes("Not connected")
            )) {
                try { await client.connect(); } catch {}
            }
        }
    }, 30000);
    KEEP_ALIVE_INTERVALS.set(String(userId), intervalId);
}

function stopKeepAlive(userId) {
    const id = KEEP_ALIVE_INTERVALS.get(String(userId));
    if (id) {
        clearInterval(id);
        KEEP_ALIVE_INTERVALS.delete(String(userId));
    }
}

// ═══ SAFE SEND ═══
async function safeSend(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try {
            return await client.sendMessage(peer, options);
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try {
                    await client.connect();
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                } catch {}
            }
            if (attempt === retry) throw e;
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

async function safeEdit(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try {
            return await client.editMessage(peer, options);
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("message is not modified")) return null;
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try { await client.connect(); await new Promise(r => setTimeout(r, 2000)); continue; } catch {}
            }
            if (attempt === retry) {
                try {
                    return await client.sendMessage(peer, { message: options.text || options.message, parseMode: options.parseMode });
                } catch { return null; }
            }
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

async function safeDelete(client, peer, msgIds, retry = 2) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try { return await client.deleteMessages(peer, msgIds, { revoke: true }); }
        catch (e) { if (attempt === retry) return null; await new Promise(r => setTimeout(r, 1000)); }
    }
}

async function safeSendFile(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try { return await client.sendFile(peer, options); }
        catch (e) {
            const msg = e.message || "";
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try { await client.connect(); await new Promise(r => setTimeout(r, 2000)); continue; } catch {}
            }
            if (attempt === retry) throw e;
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

// ═══ HELPERS ═══
function tmpFile(ext = "zip") {
    return path.join(TMP_DIR, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);
}

function isZipBuffer(buf) {
    return buf.length > 4 && buf[0] === 0x50 && buf[1] === 0x4b;
}

function detectProjectType(zipPath) {
    try {
        const zip = new AdmZip(zipPath);
        const entries = zip.getEntries();
        let hasPubspec = false;
        let hasBuildGradle = false;
        for (const entry of entries) {
            const name = entry.entryName.toLowerCase();
            if (name.endsWith("pubspec.yaml")) hasPubspec = true;
            if (name.endsWith("build.gradle") || name.endsWith("build.gradle.kts")) hasBuildGradle = true;
        }
        if (hasPubspec) return "flutter";
        if (hasBuildGradle) return "native";
        return "unknown";
    } catch { return "error"; }
}

async function downloadFromMessage(client, msg) {
    const buf = await client.downloadMedia(msg);
    if (!buf) throw new Error("Gagal download media");
    return Buffer.from(buf);
}

async function uploadZip(jobId, zipPath) {
    const repoPath = `uploads/${jobId}/project.zip`;
    const buf = fs.readFileSync(zipPath);
    const sizeMB = (buf.length / 1024 / 1024).toFixed(2);

    console.log(`[UBOT BUILD] upload ${sizeMB} MB`);

    if (buf.length < 90 * 1024 * 1024) {
        try {
            if (typeof gh.putFile === "function") {
                await gh.putFile(repoPath, buf.toString("base64"), `[${jobId}] ubot build`);
                return { ok: true, path: repoPath, method: "putFile" };
            }
        } catch (e) { console.log("[UBOT BUILD] putFile fail:", e.message.slice(0, 100)); }
    }

    try {
        if (typeof gh.uploadFile === "function") {
            await gh.uploadFile(repoPath, buf, `[${jobId}] ubot build`);
            return { ok: true, path: repoPath, method: "uploadFile" };
        }
    } catch (e) { console.log("[UBOT BUILD] uploadFile fail:", e.message.slice(0, 100)); }

    return { ok: false, error: "Upload gagal" };
}

async function cleanupGitHub(repoPath) {
    try {
        if (typeof gh.deleteFile === "function") {
            await gh.deleteFile(repoPath, `cleanup ${repoPath}`);
        }
    } catch {}
}

function buildProgressBar(pct) {
    const total = 12;
    const filled = Math.round((pct / 100) * total);
    return "▰".repeat(filled) + "▱".repeat(total - filled);
}

function shortJobId(jobId) {
    if (!jobId) return "-";
    const parts = String(jobId).split("_");
    if (parts.length >= 2) return parts[0] + "_" + parts[1];
    return jobId.slice(0, 16);
}

// ═══════════════════════════════════════════
// BUILD MENU (6 command)
// ═══════════════════════════════════════════
function buildMenuText() {
    return (
        `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
        `${I.pipe}  ${I.square} BUILD SYSTEM  ${I.pipe}\n` +
        `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +

        `${I.cornerTL}${I.line.repeat(24)}${I.cornerTR}\n` +
        `${I.pipe} ${I.diamond} FLUTTER\n` +
        `${I.teeL}${I.line.repeat(24)}\n` +
        `${I.pipe} ${I.bullet} <code>.build_flutter_release</code>\n` +
        `${I.pipe}   ${I.bulletOut} Flutter APK Release\n` +
        `${I.pipe} ${I.bullet} <code>.build_flutter_debug</code>\n` +
        `${I.pipe}   ${I.bulletOut} Flutter APK Debug\n` +
        `${I.cornerBL}${I.line.repeat(24)}${I.cornerBR}\n\n` +

        `${I.cornerTL}${I.line.repeat(24)}${I.cornerTR}\n` +
        `${I.pipe} ${I.diamond} NATIVE ANDROID\n` +
        `${I.teeL}${I.line.repeat(24)}\n` +
        `${I.pipe} ${I.bullet} <code>.build_native_release</code>\n` +
        `${I.pipe}   ${I.bulletOut} Native APK Release\n` +
        `${I.pipe} ${I.bullet} <code>.build_native_debug</code>\n` +
        `${I.pipe}   ${I.bulletOut} Native APK Debug\n` +
        `${I.cornerBL}${I.line.repeat(24)}${I.cornerBR}\n\n` +

        `${I.cornerTL}${I.line.repeat(24)}${I.cornerTR}\n` +
        `${I.pipe} ${I.diamond} WEB TO APP\n` +
        `${I.teeL}${I.line.repeat(24)}\n` +
        `${I.pipe} ${I.bullet} <code>.build_web_to_app_release</code>\n` +
        `${I.pipe}   ${I.bulletOut} Web to APK Release\n` +
        `${I.pipe} ${I.bullet} <code>.build_web_to_app_debug</code>\n` +
        `${I.pipe}   ${I.bulletOut} Web to APK Debug\n` +
        `${I.cornerBL}${I.line.repeat(24)}${I.cornerBR}\n\n` +

        `${I.cornerTL}${I.line.repeat(24)}${I.cornerTR}\n` +
        `${I.pipe} ${I.diamond} INFO\n` +
        `${I.teeL}${I.line.repeat(24)}\n` +
        `${I.pipe} ${I.bullet} Max zip  ${I.arrow}  <b>70 MB</b>\n` +
        `${I.pipe} ${I.bullet} Format   ${I.arrow}  .apk / .aab\n` +
        `${I.cornerBL}${I.line.repeat(24)}${I.cornerBR}\n\n` +

        `${I.arrow} <b>Cara pakai:</b>\n` +
        `${I.bulletOut} Reply file <code>.zip</code> base project\n` +
        `${I.bulletOut} Ketik command di atas`
    );
}

// ═══════════════════════════════════════════
// HANDLER UTAMA
// ═══════════════════════════════════════════
async function handler(userId, client, msg, args) {
    const peerId = msg.message.peerId;
    const text = msg.message?.message || msg.message?.text || "";
    const cmd = text.slice(1).trim().split(/\s+/)[0].toLowerCase();

    // ═══ Parse command (6 jenis) ═══
    let buildType = null;   // "pubspec" | "native" | "web2app"
    let buildMode = null;   // "release" | "debug"

    // ═══ NATIVE ═══
    if (cmd === "build_native_release") { buildType = "native"; buildMode = "release"; }
    else if (cmd === "build_native_debug") { buildType = "native"; buildMode = "debug"; }

    // ═══ FLUTTER ═══
    else if (cmd === "build_flutter_release") { buildType = "pubspec"; buildMode = "release"; }
    else if (cmd === "build_flutter_debug") { buildType = "pubspec"; buildMode = "debug"; }

    // ═══ WEB TO APP ═══
    else if (cmd === "build_web_to_app_release" || cmd === "build_wep_to_app_release") { buildType = "web2app"; buildMode = "release"; }
    else if (cmd === "build_web_to_app_debug" || cmd === "build_wep_to_app_debug") { buildType = "web2app"; buildMode = "debug"; }

    // ═══ MENU ═══
    else if (cmd === "build") {
        return safeSend(client, peerId, {
            message: buildMenuText(),
            parseMode: "html"
        });
    } else {
        return;
    }

    console.log(`[UBOT BUILD] cmd: ${cmd} | type: ${buildType} | mode: ${buildMode}`);

    // ═══ Cek build aktif ═══
    const activeBuild = ACTIVE_BUILDS.get(String(userId));
    if (activeBuild) {
        return safeSend(client, peerId, {
            message:
                `${I.cross} <b>Lu masih punya build aktif</b>\n\n` +
                `${I.bulletOut} Job: <code>${shortJobId(activeBuild.jobId)}</code>\n` +
                `${I.bulletOut} Status: ${activeBuild.status}\n` +
                `${I.bulletOut} Waktu: ${((Date.now() - activeBuild.startTime) / 1000).toFixed(0)}s\n\n` +
                `<i>Tunggu build sebelumnya selesai</i>`,
            parseMode: "html"
        });
    }

    // ═══ Cek reply ═══
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) {
        return safeSend(client, peerId, {
            message:
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.cross} REPLY FILE .ZIP\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
                `${I.arrow} <b>Langkah:</b>\n` +
                `${I.bulletOut} Kirim file <code>.zip</code> base project\n` +
                `${I.bulletOut} Reply file itu\n` +
                `${I.bulletOut} Ketik <code>.${cmd}</code>\n\n` +
                `${I.bulletOut} Max size: <b>70 MB</b>`,
            parseMode: "html"
        });
    }

    const msgs = await client.getMessages(msg.message.chatId, { ids: [replyTo] });
    const target = msgs[0];
    if (!target || !target.media || !target.document) {
        return safeSend(client, peerId, {
            message: `${I.cross} Yang di-reply harus file <b>.zip</b>`,
            parseMode: "html"
        });
    }

    const fileName = target.document.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.toLowerCase().endsWith(".zip")) {
        return safeSend(client, peerId, {
            message: `${I.cross} File harus <b>.zip</b>`,
            parseMode: "html"
        });
    }

    const fileSize = Number(target.document.size) || 0;
    if (fileSize > MAX_ZIP_SIZE) {
        return safeSend(client, peerId, {
            message:
                `${I.cross} <b>File terlalu besar!</b>\n\n` +
                `${I.bulletOut} Size: ${(fileSize / 1024 / 1024).toFixed(2)} MB\n` +
                `${I.bulletOut} Max: <b>70 MB</b>`,
            parseMode: "html"
        });
    }

    // ═══ START KEEP ALIVE ═══
    startKeepAlive(userId, client);

    // ═══ Loading ═══
    const loading = await safeSend(client, peerId, {
        message:
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} DOWNLOADING\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} File  ${I.arrow}  <code>${fileName.slice(0, 30)}</code>\n` +
            `${I.pipe} ${I.bullet} Size  ${I.arrow}  ${(fileSize / 1024 / 1024).toFixed(2)} MB\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
        parseMode: "html"
    });

    try {
        const buf = await downloadFromMessage(client, target);

        if (!isZipBuffer(buf)) {
            stopKeepAlive(userId);
            try { await safeDelete(client, peerId, [loading.id]); } catch {}
            return safeSend(client, peerId, { message: `${I.cross} File bukan zip valid`, parseMode: "html" });
        }

        const zipPath = tmpFile("zip");
        fs.writeFileSync(zipPath, buf);

        const detectedType = detectProjectType(zipPath);
        const sizeMB = (buf.length / 1024 / 1024).toFixed(2);

        try { await safeDelete(client, peerId, [loading.id]); } catch {}

        const jobId = gh.newJobId("ubotbuild");
        console.log(`[UBOT BUILD] job: ${jobId} | size: ${sizeMB} MB`);

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "uploading" });

        const progressMsg = await safeSend(client, peerId, {
            message:
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} UPLOADING\n` +
                `${I.teeL}${I.line.repeat(20)}\n` +
                `${I.pipe} ${I.bullet} File    ${I.arrow}  <code>${fileName.slice(0, 24)}</code>\n` +
                `${I.pipe} ${I.bullet} Size    ${I.arrow}  ${sizeMB} MB\n` +
                `${I.pipe} ${I.bullet} Type    ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                `${I.pipe} ${I.bullet} Mode    ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                `${I.pipe} ${I.bullet} Job     ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            parseMode: "html"
        });

        const upload = await uploadZip(jobId, zipPath);
        if (!upload.ok) {
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message: `${I.cross} Upload gagal\n\n${I.bulletOut} ${upload.error}`,
                parseMode: "html"
            });
        }

        console.log(`[UBOT BUILD] uploaded via ${upload.method}`);

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "triggering" });

        try {
            await safeEdit(client, peerId, {
                message: progressMsg.id,
                text:
                    `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.circle} TRIGGERING\n` +
                    `${I.teeL}${I.line.repeat(20)}\n` +
                    `${I.pipe} ${I.bullet} Job  ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                    `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
                parseMode: "html"
            });
        } catch {}

        // ═══ Pilih workflow (3 jenis) ═══
        let workflow, inputs;
        if (buildType === "pubspec") {
            // Flutter
            workflow = cfg.GITHUB.WORKFLOW_FLUTTER || "flutter-build.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_type: "apk",
                build_mode: buildMode,
                split_per_abi: "false",
                flutter_version: "auto"
            };
        } else if (buildType === "web2app") {
            // Web to App
            workflow = cfg.GITHUB.WORKFLOW_WEB2APP || "web-to-app.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_mode: buildMode
            };
        } else {
            // Native Android
            workflow = cfg.GITHUB.WORKFLOW_NATIVE || "native-build.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_task: buildMode === "debug" ? "assembleDebug" : "assembleRelease",
                build_flavor: "",
                java_version: "17"
            };
        }

        let trigger;
        try {
            trigger = await gh.triggerWorkflow(workflow, inputs);
        } catch (e) {
            try { await cleanupGitHub(upload.path); } catch {}
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message: `${I.cross} Trigger gagal\n\n${I.bulletOut} ${e.message.slice(0, 150)}`,
                parseMode: "html"
            });
        }

        if (!trigger?.ok) {
            try { await cleanupGitHub(upload.path); } catch {}
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message: `${I.cross} Trigger gagal\n\n${I.bulletOut} ${(trigger?.error || "unknown").slice(0, 150)}`,
                parseMode: "html"
            });
        }

        try { fs.unlinkSync(zipPath); } catch {}

        const triggerTime = Date.now();
        let run = null;
        for (let i = 0; i < 12; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await gh.getLatestRun(workflow, triggerTime); } catch {}
            if (run) break;
        }

        if (!run) {
            try { await cleanupGitHub(upload.path); } catch {}
            try {
                await safeEdit(client, peerId, {
                    message: progressMsg.id,
                    text: `${I.cross} GitHub ga response\n\n${I.bulletOut} Job: <code>${shortJobId(jobId)}</code>`,
                    parseMode: "html"
                });
            } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return;
        }

        const runId = run.id;
        console.log(`[UBOT BUILD] run id: ${runId}`);

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "building" });

        const startTime = Date.now();
        const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;
        const pollInterval = cfg.BUILD_POLL_INTERVAL || 20000;
        let lastEditAt = 0;

        while (Date.now() - startTime < maxWait) {
            let status = null;
            try { status = await gh.getRunStatus(runId); } catch {}

            if (!status) { await new Promise(r => setTimeout(r, pollInterval)); continue; }

            const jobStatus = status.status;
            const conclusion = status.conclusion;
            const elapsed = Date.now() - startTime;

            if (Date.now() - lastEditAt > 18000) {
                lastEditAt = Date.now();
                const pct = Math.min(Math.floor((elapsed / 900000) * 100), 95);
                const bar = buildProgressBar(pct);
                const statusLabel = jobStatus === "in_progress" ? "BUILDING" : jobStatus === "queued" ? "QUEUED" : jobStatus.toUpperCase();

                try {
                    await safeEdit(client, peerId, {
                        message: progressMsg.id,
                        text:
                            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                            `${I.pipe} ${I.circle} ${statusLabel}\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} ${I.bullet} Type    ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Mode    ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Job     ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                            `${I.pipe} ${I.bullet} Waktu   ${I.arrow}  ${(elapsed / 1000).toFixed(0)}s\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} <code>${bar}</code> ${pct}%\n` +
                            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
                        parseMode: "html"
                    });
                } catch {}
            }

            if (jobStatus === "completed") {
                try { await cleanupGitHub(upload.path); } catch {}

                if (conclusion === "success") {
                    let artifacts = [];
                    try { artifacts = await gh.getRunArtifacts(runId); } catch {}

                    const apkArtifacts = artifacts.filter(a =>
                        a.name.includes("apk") || a.name.includes("appbundle") ||
                        a.name.includes("release") || a.name.includes("app")
                    );

                    const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);
                    try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}

                    await safeSend(client, peerId, {
                        message:
                            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                            `${I.pipe} ${I.check} BUILD SUCCESS\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} ${I.bullet} Type       ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Mode       ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Artifacts  ${I.arrow}  <code>${apkArtifacts.length}</code>\n` +
                            `${I.pipe} ${I.bullet} Waktu      ${I.arrow}  ${elapsedSec}s\n` +
                            `${I.pipe} ${I.bullet} Job        ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
                            `${I.circle} <b>Mengirim file APK/AAB...</b>`,
                        parseMode: "html"
                    });

                    for (const art of apkArtifacts.slice(0, 5)) {
                        try {
                            const dest = tmpFile("zip");
                            await gh.downloadArtifact(art.id, dest);
                            const zip = new AdmZip(dest);
                            const entries = zip.getEntries().filter(e =>
                                e.entryName.endsWith(".apk") || e.entryName.endsWith(".aab")
                            );

                            for (const entry of entries.slice(0, 3)) {
                                const fileBuf = entry.getData();
                                const ext = entry.entryName.endsWith(".apk") ? "apk" : "aab";
                                const outPath = tmpFile(ext);
                                fs.writeFileSync(outPath, fileBuf);

                                const fname = entry.entryName.split("/").pop();

                                try {
                                    await safeSendFile(client, peerId, {
                                        file: outPath,
                                        caption:
                                            `${I.cornerTL}${I.line.repeat(18)}${I.cornerTR}\n` +
                                            `${I.pipe} ${I.star} BUILD ARTIFACT\n` +
                                            `${I.teeL}${I.line.repeat(18)}\n` +
                                            `${I.pipe} ${I.bullet} File  ${I.arrow}  <code>${fname}</code>\n` +
                                            `${I.pipe} ${I.bullet} Size  ${I.arrow}  ${(fileBuf.length / 1024 / 1024).toFixed(2)} MB\n` +
                                            `${I.pipe} ${I.bullet} Job   ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                                            `${I.cornerBL}${I.line.repeat(18)}${I.cornerBR}`,
                                        forceDocument: false
                                    });
                                } catch (e) {
                                    console.log("[UBOT BUILD] sendFile fail:", e.message.slice(0, 100));
                                }

                                try { fs.unlinkSync(outPath); } catch {}
                            }

                            try { fs.unlinkSync(dest); } catch {}
                        } catch (e) {
                            console.log("[UBOT BUILD] artifact fail:", e.message.slice(0, 100));
                        }
                    }

                    await safeSend(client, peerId, { message: `${I.check} <b>Build selesai</b>` });
                } else {
                    const actionsUrl = `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`;
                    try {
                        await safeEdit(client, peerId, {
                            message: progressMsg.id,
                            text:
                                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                                `${I.pipe} ${I.cross} BUILD FAILED\n` +
                                `${I.teeL}${I.line.repeat(20)}\n` +
                                `${I.pipe} ${I.bullet} Type        ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                                `${I.pipe} ${I.bullet} Mode        ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                                `${I.pipe} ${I.bullet} Conclusion  ${I.arrow}  <code>${conclusion}</code>\n` +
                                `${I.pipe} ${I.bullet} Job         ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                                `${I.teeL}${I.line.repeat(20)}\n` +
                                `${I.pipe} ${I.arrow} ${actionsUrl}\n` +
                                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
                            parseMode: "html"
                        });
                    } catch {}
                }

                ACTIVE_BUILDS.delete(String(userId));
                stopKeepAlive(userId);
                return;
            }

            await new Promise(r => setTimeout(r, pollInterval));
        }

        try { await cleanupGitHub(upload.path); } catch {}
        try {
            await safeEdit(client, peerId, {
                message: progressMsg.id,
                text: `${I.cross} Build timeout (>60 menit)\n\n${I.bulletOut} Job: <code>${shortJobId(jobId)}</code>`,
                parseMode: "html"
            });
        } catch {}
        ACTIVE_BUILDS.delete(String(userId));
        stopKeepAlive(userId);
    } catch (e) {
        console.log("[UBOT BUILD] ERR:", e.message);
        console.log(e.stack);
        ACTIVE_BUILDS.delete(String(userId));
        stopKeepAlive(userId);
        try {
            await safeSend(client, peerId, {
                message: `${I.cross} Error: ${e.message.slice(0, 200)}`,
                parseMode: "html"
            });
        } catch {}
    }
}

module.exports = {
    command: "build_flutter_release",
    handler,
    commands: [
        // Native
        "build_native_release",
        "build_native_debug",
        // Flutter
        "build_flutter_release",
        "build_flutter_debug",
        // Web to App
        "build_web_to_app_release",
        "build_web_to_app_debug",
        "build_wep_to_app_release",
        "build_wep_to_app_debug",
        // Menu
        "build"
    ],
    description: "Build APK via GitHub (6 command)",
    category: "build",
    cleanup: (userId) => {
        stopKeepAlive(userId);
        ACTIVE_BUILDS.delete(String(userId));
    }
};

console.log("[UBOT BUILD] module loaded (v9 — 6 commands)");