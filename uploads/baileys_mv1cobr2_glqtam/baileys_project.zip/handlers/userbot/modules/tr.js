const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const input = args.join(" ").trim();
    if (!input) return client.sendMessage(chatId, { message: "📖 .tr en|Hello world" });

    let to = "id", text = input;
    const m = input.match(/^(\w{2})\|(.+)$/s);
    if (m) { to = m[1]; text = m[2].trim(); }

    try {
        const r = await axios.get(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${to}`, { timeout: 15000 });
        const result = r.data?.responseData?.translatedText;
        if (!result) throw new Error("Translate gagal");
        await client.sendMessage(chatId, { message: `🌐 ${result}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "tr", handler, description: "Translate text", category: "text" };