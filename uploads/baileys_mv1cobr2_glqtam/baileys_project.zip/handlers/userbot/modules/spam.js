async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const [count, ...rest] = args;
    const n = Math.min(parseInt(count) || 5, 10);
    const text = rest.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .spam [jumlah] [text]" });

    for (let i = 0; i < n; i++) {
        await client.sendMessage(chatId, { message: text });
        await new Promise(r => setTimeout(r, 1000));
    }
}

module.exports = { command: "spam", handler, description: "Spam text (max 10x)", category: "fun" };