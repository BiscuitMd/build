const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "⏳ BTC halving countdown..." });
    try {
        const r = await axios.get("https://blockchain.info/q/getblockcount", { timeout: 15000, responseType: "text" });
        const currentBlock = parseInt(r.data);
        const nextHalving = Math.ceil((currentBlock + 1) / 210000) * 210000;
        const blocksLeft = nextHalving - currentBlock;
        const minutesLeft = blocksLeft * 10;
        const daysLeft = Math.floor(minutesLeft / 1440);

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message:
                `₿ BTC HALVING COUNTDOWN\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Current Block: ${currentBlock.toLocaleString("id-ID")}\n` +
                `▸ Next Halving Block: ${nextHalving.toLocaleString("id-ID")}\n` +
                `▸ Blocks Left: ${blocksLeft.toLocaleString("id-ID")}\n` +
                `▸ Est. Days: ~${daysLeft} hari\n` +
                `━━━━━━━━━━━━━━━━━━━━`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "halving", handler, description: "BTC halving countdown", category: "crypto" };