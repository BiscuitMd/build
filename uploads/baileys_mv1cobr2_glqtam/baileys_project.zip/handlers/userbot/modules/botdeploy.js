async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    if (cmd === "heroku") {
        const name = args[1];
        if (!name) return client.sendMessage(chatId, { message: "▸ .botdeploy heroku [nama-bot]" });

        const text =
            "◆ DEPLOY — HEROKU\n\n" +
            "├─────────────────\n" +
            "│ ◆ LANGKAH\n" +
            "├─────────────────\n" +
            "│ 1. Install Heroku CLI\n" +
            "│ 2. heroku login\n" +
            "│ 3. heroku create " + name + "\n" +
            "│ 4. git push heroku main\n" +
            "├─────────────────\n" +
            "│ ◆ ENV SETUP\n" +
            "├─────────────────\n" +
            "│ ▪ heroku config:set BOT_TOKEN=xxx\n" +
            "│ ▪ heroku config:set API_ID=xxx\n" +
            "│ ▪ heroku config:set API_HASH=xxx\n" +
            "├─────────────────\n" +
            "│ ◆ SCALE\n" +
            "├─────────────────\n" +
            "│ ▪ heroku ps:scale worker=1\n" +
            "╰─────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "railway") {
        const text =
            "◆ DEPLOY — RAILWAY\n\n" +
            "├─────────────────\n" +
            "│ ◆ LANGKAH\n" +
            "├─────────────────\n" +
            "│ 1. Buka railway.app\n" +
            "│ 2. New Project → Deploy from GitHub\n" +
            "│ 3. Pilih repo bot lu\n" +
            "│ 4. Tambah environment variables\n" +
            "├─────────────────\n" +
            "│ ◆ ENV SETUP\n" +
            "├─────────────────\n" +
            "│ ▪ BOT_TOKEN=xxx\n" +
            "│ ▪ API_ID=xxx\n" +
            "│ ▪ API_HASH=xxx\n" +
            "╰─────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "vps") {
        const text =
            "◆ DEPLOY — VPS\n\n" +
            "├─────────────────\n" +
            "│ ◆ LANGKAH\n" +
            "├─────────────────\n" +
            "│ 1. ssh root@ip-vps\n" +
            "│ 2. apt update && apt install nodejs npm -y\n" +
            "│ 3. npm install\n" +
            "│ 4. npm install -g pm2\n" +
            "│ 5. pm2 start index.js --name bot\n" +
            "│ 6. pm2 save && pm2 startup\n" +
            "╰─────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "docker") {
        const text =
            "◆ DEPLOY — DOCKER\n\n" +
            "├─────────────────\n" +
            "│ ◆ LANGKAH\n" +
            "├─────────────────\n" +
            "│ 1. docker build -t mybot .\n" +
            "│ 2. docker run -d --name mybot --restart unless-stopped mybot\n" +
            "│ 3. docker logs -f mybot\n" +
            "├─────────────────\n" +
            "│ ◆ DOCKERFILE\n" +
            "├─────────────────\n" +
            "│ FROM node:20-alpine\n" +
            "│ WORKDIR /app\n" +
            "│ COPY . .\n" +
            "│ RUN npm install\n" +
            '│ CMD ["node", "index.js"]\n' +
            "╰─────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⇒  DEPLOY        │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ OPTIONS\n" +
        "├───────────────────\n" +
        "│ ▪ .botdeploy heroku [nama]\n" +
        "│ ▪ .botdeploy railway\n" +
        "│ ▪ .botdeploy vps\n" +
        "│ ▪ .botdeploy docker\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "botdeploy",
    handler,
    description: "Panduan deploy bot",
    category: "bot"
};