const core = require("./gamecore");

async function handler(userId, client, msg, args, bot) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const target = args[1] || userId;

    if (cmd === "top") {
        const entries = Object.entries(core.COINS).sort((a, b) => b[1] - a[1]).slice(0, 10);
        if (!entries.length) return client.sendMessage(chatId, { message: "▸ Belum ada yang punya coin" });

        let list = "";
        const medals = ["🥇", "🥈", "🥉"];
        entries.forEach(([uid, c], i) => {
            const m = medals[i] || (i + 1) + ".";
            list += "│ " + m + " " + uid.slice(-8) + " → " + c + " coin\n";
        });

        return client.sendMessage(chatId, {
            message:
                "🏆 LEADERBOARD\n\n" +
                "├─────────────────\n" +
                list +
                "╰─────────────────"
        });
    }

    if (cmd === "claim") {
        const coins = core.getCoin(userId);
        const claimStatus = core.getClaimStatus(userId);

        if (claimStatus.active) {
            const sisa = Math.ceil((claimStatus.expiresAt - Date.now()) / 86400000);
            return client.sendMessage(chatId, {
                message: "▸ Lu udah punya claim aktif\n\n│ Sisa: " + sisa + " hari"
            });
        }

        if (coins < 20) {
            return client.sendMessage(chatId, {
                message:
                    "✕ Coin kurang\n\n" +
                    "├─────────────────\n" +
                    "│ Punya  → " + coins + " coin\n" +
                    "│ Butuh  → 20 coin\n" +
                    "│ Kurang → " + (20 - coins) + " coin\n" +
                    "╰─────────────────\n\n" +
                    "▸ Main game buat dapet coin: .menu_game"
            });
        }

        core.subtractCoin(userId, 20);
        core.setClaim(userId, 7);

        try {
            const store = require("../session-store");
            if (typeof store.setUserRole === "function") {
                store.setUserRole(userId, "permanent", 7);
            }
        } catch (e) {
            console.log("[CLAIM] setUserRole fail:", e.message);
        }

        return client.sendMessage(chatId, {
            message:
                "🎉 CLAIM BERHASIL!\n\n" +
                "├─────────────────\n" +
                "│ ✅ Userbot gratis 7 hari\n" +
                "│ 💰 Coin dipotong 20\n" +
                "│ 💵 Sisa → " + core.getCoin(userId) + " coin\n" +
                "│ ⏰ Expired → " + new Date(Date.now() + 7 * 86400000).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + "\n" +
                "╰─────────────────\n\n" +
                "▸ Userbot lu bakal aktif 7 hari kedepan"
        });
    }

    if (cmd === "balance" || !cmd) {
        const coins = core.getCoin(userId);
        const claim = core.getClaimStatus(userId);

        let status = "Belum claim";
        let expiry = "-";
        if (claim.active) {
            const sisa = Math.ceil((claim.expiresAt - Date.now()) / 86400000);
            status = "Aktif";
            expiry = sisa + " hari lagi";
        }

        const text =
            "💰 COIN STATUS\n\n" +
            "├─────────────────\n" +
            "│ Coin      → " + coins + "\n" +
            "│ Progress  → " + Math.min(coins, 20) + "/20\n" +
            "│ Bar       → " + "█".repeat(Math.floor(Math.min(coins, 20) / 2)) + "░".repeat(10 - Math.floor(Math.min(coins, 20) / 2)) + "\n" +
            "├─────────────────\n" +
            "│ Claim     → " + status + "\n" +
            "│ Expired   → " + expiry + "\n" +
            "├─────────────────\n" +
            "│ ▪ .claim → tukar 20 coin\n" +
            "│ ▪ .gamecoin top → leaderboard\n" +
            "╰─────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    return client.sendMessage(chatId, { message: "▸ .gamecoin balance/claim/top" });
}

module.exports = {
    command: "gamecoin",
    handler,
    description: "Coin & claim system",
    category: "game",
    commands: ["coin", "claim", "mycoin"]
};