const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args.join(" ").trim();
    if (!url || !url.includes("tiktok")) {
        return client.sendMessage(chatId, { message: "📖 .tiktok [url]" });
    }
    const loading = await client.sendMessage(chatId, { message: "⏳ Download TikTok..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/d/tiktok?url=${encodeURIComponent(url)}`, { timeout: 40000 });
        const d = r.data?.data;
        const dlUrl = d?.video || d?.download || d?.play;
        if (!dlUrl) throw new Error("No video URL");
        const v = await axios.get(dlUrl, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(v.data),
            caption: `🎵 ${d?.title?.slice(0, 100) || "TikTok"}`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "tiktok", handler, description: "Download TikTok", category: "download" };