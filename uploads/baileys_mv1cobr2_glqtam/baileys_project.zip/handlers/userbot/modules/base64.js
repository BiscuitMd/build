async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mode = args[0]?.toLowerCase();
    const text = args.slice(1).join(" ");
    if (!mode || !text) {
        return client.sendMessage(chatId, { message: "📖 .base64 [encode/decode] [text]" });
    }
    try {
        if (mode === "encode") {
            const result = Buffer.from(text, "utf8").toString("base64");
            await client.sendMessage(chatId, { message: `🔐 Encoded:\n\`${result}\`` });
        } else if (mode === "decode") {
            const result = Buffer.from(text, "base64").toString("utf8");
            await client.sendMessage(chatId, { message: `🔓 Decoded:\n${result}` });
        } else {
            await client.sendMessage(chatId, { message: "❌ Mode harus encode/decode" });
        }
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "base64", handler, description: "Encode/decode base64", category: "tools" };