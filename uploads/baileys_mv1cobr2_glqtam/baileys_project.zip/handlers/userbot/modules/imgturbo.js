const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ").trim();
    if (!prompt) return client.sendMessage(chatId, { message: "📖 .imgturbo [prompt]" });
    const loading = await client.sendMessage(chatId, { message: "⚡ Turbo generate..." });
    try {
        const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=turbo&nologo=true&seed=${Date.now()}`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(r.data), caption: `⚡ Turbo: ${prompt.slice(0, 200)}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "imgturbo", handler, description: "Generate image pake Turbo", category: "ai" };