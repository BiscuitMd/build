const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args[0];
    if (!query) return client.sendMessage(chatId, { message: "📖 .shodan [ip/query]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Shodan search...` });

    try {
        const text =
            `🔍 SHODAN SEARCH\n\n` +
            `▸ Query: ${query}\n\n` +
            `⚠️ Butuh API key Shodan.\n\n` +
            `▸ Register gratis: https://account.shodan.io/\n` +
            `▸ Manual check: https://www.shodan.io/search?query=${encodeURIComponent(query)}\n\n` +
            `<i>Free tier bisa 1 request/hari.</i>`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "shodan", handler, description: "Shodan search info", category: "osint" };