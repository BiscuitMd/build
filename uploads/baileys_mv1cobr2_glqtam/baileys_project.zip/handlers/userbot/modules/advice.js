const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.adviceslip.com/advice", { timeout: 15000 });
        const advice = r.data?.slip?.advice || "Gaada advice.";
        await client.sendMessage(chatId, { message: `💡 ADVICE:\n\n${advice}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "advice", handler, description: "Random advice", category: "fun" };