const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_bots.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const name = args[1];
    const db = read();
    const bots = db[userId] || [];

    if (cmd === "config") {
        const bot = bots.find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const key = args[2];
        const val = args.slice(3).join(" ");

        if (!key) {
            bot.config = bot.config || {};
            const cfgList = Object.entries(bot.config).map(([k, v]) => "│ ▪ " + k.padEnd(12) + " → " + v).join("\n");

            const text =
                "╭───────────────────╮\n" +
                "│   ⚙  BOT CONFIG    │\n" +
                "╰───────────────────╯\n\n" +
                "├───────────────────\n" +
                "│ ▪ Bot: " + bot.name + "\n" +
                "├───────────────────\n" +
                (cfgList || "│ ▪ (kosong)") + "\n" +
                "├───────────────────\n" +
                "│ ◆ USAGE\n" +
                "├───────────────────\n" +
                "│ ▪ .botpanel config " + bot.name + " [key] [val]\n" +
                "│ ▪ .botpanel config " + bot.name + " del [key]\n" +
                "╰───────────────────";

            return client.sendMessage(chatId, { message: text });
        }

        bot.config = bot.config || {};

        if (key === "del") {
            delete bot.config[val];
            write(db);
            return client.sendMessage(chatId, { message: "✓ Config " + val + " dihapus" });
        }

        bot.config[key] = val;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Config " + key + " = " + val });
    }

    if (cmd === "stats") {
        const bot = bots.find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const text =
            "╭───────────────────╮\n" +
            "│   ■  BOT STATS     │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ Name     → " + bot.name + "\n" +
            "│ ▪ Messages → " + (bot.stats?.messages || 0) + "\n" +
            "│ ▪ Commands → " + (bot.stats?.commands || 0) + "\n" +
            "│ ▪ Status   → " + bot.status.toUpperCase() + "\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "reset") {
        const bot = bots.find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        bot.stats = { messages: 0, commands: 0 };
        write(db);

        return client.sendMessage(chatId, { message: "✓ Stats direset: " + name });
    }

    if (cmd === "clone") {
        const bot = bots.find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const newName = args[2];
        if (!newName) return client.sendMessage(chatId, { message: "▸ .botpanel clone [nama] [nama-baru]" });

        const clone = {
            ...JSON.parse(JSON.stringify(bot)),
            id: Math.random().toString(36).slice(2),
            name: newName,
            token: Math.random().toString(36).slice(2, 12) + Date.now().toString(36).slice(-6),
            status: "stopped",
            createdAt: Date.now()
        };

        bots.push(clone);
        write(db);

        return client.sendMessage(chatId, { message: "✓ Bot cloned: " + name + " → " + newName });
    }

    if (cmd === "export") {
        const bot = bots.find(b => b.name === name);
        if (!bot) return client.sendMessage(chatId, { message: "✕ Bot gaada: " + name });

        const json = JSON.stringify(bot, null, 2);
        const b64 = Buffer.from(json).toString("base64");

        return client.sendMessage(chatId, {
            message: "◆ EXPORT — " + name + "\n\n<code>" + b64 + "</code>",
            parseMode: "html"
        });
    }

    if (cmd === "import") {
        const b64 = args[1];
        if (!b64) return client.sendMessage(chatId, { message: "▸ .botpanel import [base64]" });

        try {
            const bot = JSON.parse(Buffer.from(b64, "base64").toString("utf8"));
            if (!bot.name || !bot.token) throw new Error("invalid");

            bots.push(bot);
            write(db);

            return client.sendMessage(chatId, { message: "✓ Bot imported: " + bot.name });
        } catch (e) {
            return client.sendMessage(chatId, { message: "✕ Import gagal: " + e.message });
        }
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚙  BOT PANEL     │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .botpanel config [bot] [key] [val]\n" +
        "│ ▪ .botpanel stats [bot]\n" +
        "│ ▪ .botpanel reset [bot]\n" +
        "│ ▪ .botpanel clone [bot] [nama-baru]\n" +
        "│ ▪ .botpanel export [bot]\n" +
        "│ ▪ .botpanel import [base64]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "botpanel",
    handler,
    description: "Manage config & lifecycle bot",
    category: "bot",
    commands: ["bp", "managebot"]
};