async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ").trim();
    if (!text) return client.sendMessage(chatId, { message: "📖 .say [text]" });
    await client.deleteMessages(chatId, [msg.message.id], { revoke: true }).catch(() => {});
    await client.sendMessage(chatId, { message: text });
}

module.exports = { command: "say", handler, description: "Bot ngomong (delete pesan lu)", category: "fun" };