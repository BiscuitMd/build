const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_antilink.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");
function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mode = args[0]?.toLowerCase();
    if (!mode || !["on", "off"].includes(mode)) {
        return client.sendMessage(chatId, { message: "📖 .antilink on/off" });
    }
    const db = read();
    db[chatId] = { enabled: mode === "on" };
    write(db);
    await client.sendMessage(chatId, { message: `🔗 Antilink: ${mode.toUpperCase()}` });
}

module.exports = { command: "antilink", handler, description: "Anti link group", category: "group" };