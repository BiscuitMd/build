const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const coin = args[0]?.toLowerCase();
    if (!coin) return client.sendMessage(chatId, { message: "📖 .cryptoprice [coingecko-id]\nContoh: .cryptoprice bitcoin" });

    const loading = await client.sendMessage(chatId, { message: `💰 Ambil harga ${coin}...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin}?localization=false&tickers=false&community_data=false&developer_data=false`, { timeout: 20000 });
        const d = r.data;
        const md = d.market_data;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message:
                `${d.symbol?.toUpperCase()} ${d.name}\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ USD: $${md.current_price.usd?.toLocaleString("id-ID")}\n` +
                `▸ IDR: Rp${md.current_price.idr?.toLocaleString("id-ID")}\n` +
                `▸ 24h: ${md.price_change_percentage_24h?.toFixed(2)}%\n` +
                `▸ 7d: ${md.price_change_percentage_7d?.toFixed(2)}%\n` +
                `▸ Market Cap: $${(md.market_cap.usd / 1e9).toFixed(2)}B\n` +
                `▸ Volume 24h: $${(md.total_volume.usd / 1e9).toFixed(2)}B\n` +
                `▸ ATH: $${md.ath.usd?.toLocaleString("id-ID")}\n` +
                `▸ Rank: #${d.market_cap_rank}\n` +
                `━━━━━━━━━━━━━━━━━━━━`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "cryptoprice", handler, description: "Harga crypto detail", category: "crypto" };