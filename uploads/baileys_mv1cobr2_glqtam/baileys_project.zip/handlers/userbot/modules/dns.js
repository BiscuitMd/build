const dns = require("dns").promises;

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const domain = args[0];
    if (!domain) return client.sendMessage(chatId, { message: "📖 .dns [domain]" });
    try {
        const a = await dns.resolve4(domain).catch(() => []);
        const mx = await dns.resolveMx(domain).catch(() => []);
        const txt = await dns.resolveTxt(domain).catch(() => []);
        const ns = await dns.resolveNs(domain).catch(() => []);

        let text = `🌐 DNS ${domain}\n`;
        if (a.length) text += `\n▸ A: ${a.join(", ")}`;
        if (mx.length) text += `\n▸ MX: ${mx.map(m => `${m.priority} ${m.exchange}`).join(", ")}`;
        if (txt.length) text += `\n▸ TXT: ${txt.map(t => t.join("")).join(" | ").slice(0, 200)}`;
        if (ns.length) text += `\n▸ NS: ${ns.join(", ")}`;

        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "dns", handler, description: "Cek DNS record domain", category: "tools" };