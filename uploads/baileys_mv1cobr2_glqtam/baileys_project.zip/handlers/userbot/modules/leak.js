const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args[0];
    if (!query) return client.sendMessage(chatId, { message: "📖 .leak [email/username]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Check data leak...` });

    try {
        // Pake API publik terbatas
        const text =
            `🔍 DATA LEAK CHECK\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Query: ${query}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `⚠️ <b>Check manual di link berikut:</b>\n` +
            `▸ https://haveibeenpwned.com/unifiedsearch/${encodeURIComponent(query)}\n` +
            `▸ https://leakcheck.io\n` +
            `▸ https://dehashed.com\n\n` +
            `<i>API HIBP pake API key berbayar. Check manual.</i>`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "leak", handler, description: "Check data leak", category: "osint" };