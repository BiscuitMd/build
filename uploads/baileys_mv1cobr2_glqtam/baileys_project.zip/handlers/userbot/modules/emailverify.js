const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const email = args[0];
    if (!email || !email.includes("@")) return client.sendMessage(chatId, { message: "📖 .emailverify [email]" });

    const loading = await client.sendMessage(chatId, { message: `📧 Verify email...` });

    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/tools/emailvalidate?email=${encodeURIComponent(email)}`, { timeout: 20000 }).catch(() => null);
        const d = r?.data?.data;

        let text = `📧 EMAIL VERIFY\n\n▸ Email: ${email}\n`;
        if (d) {
            text += `▸ Valid: ${d.valid ? "✅" : "❌"}\n`;
            text += `▸ Disposable: ${d.disposable ? "⚠️" : "✅"}\n`;
            text += `▸ MX: ${d.mx ? "✅" : "❌"}\n`;
            text += `▸ SMTP: ${d.smtp ? "✅" : "❌"}\n`;
        } else {
            text += `▸ Format: ${/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "✅" : "❌"}\n`;
            text += `\n<i>API ga response, cuma cek format.</i>`;
        }

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "emailverify", handler, description: "Verify email valid", category: "osint" };