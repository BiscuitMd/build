const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url || !url.startsWith("http")) return client.sendMessage(chatId, { message: "📖 .shorturl [url]" });
    try {
        const r = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`, { timeout: 15000 });
        await client.sendMessage(chatId, { message: `🔗 ${r.data}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "shorturl", handler, description: "Pendekin URL", category: "tools" };