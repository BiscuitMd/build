const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const ip = args[0];
    if (!ip) return client.sendMessage(chatId, { message: "📖 .trackip [ip]" });

    const loading = await client.sendMessage(chatId, { message: `📍 Track IP...` });

    try {
        const [geo, rdns] = await Promise.all([
            axios.get(`http://ip-api.com/json/${ip}?fields=66846719`, { timeout: 15000 }).then(r => r.data).catch(() => null),
            axios.get(`https://api.hackertarget.com/reverseiplookup/?q=${ip}`, { timeout: 15000 }).then(r => String(r.data)).catch(() => "")
        ]);

        let text = `📍 TRACK IP\n\n▸ IP: ${ip}\n`;
        if (geo && geo.status === "success") {
            text += `▸ Country: ${geo.country} (${geo.countryCode})\n`;
            text += `▸ Region: ${geo.regionName}\n`;
            text += `▸ City: ${geo.city}\n`;
            text += `▸ ISP: ${geo.isp}\n`;
            text += `▸ Org: ${geo.org}\n`;
            text += `▸ AS: ${geo.as}\n`;
            text += `▸ Lat/Lon: ${geo.lat}, ${geo.lon}\n`;
            text += `▸ Maps: https://www.google.com/maps?q=${geo.lat},${geo.lon}\n`;
            text += `▸ Proxy: ${geo.proxy ? "⚠️" : "✅"}\n`;
        }
        if (rdns && rdns.length > 0 && rdns.length < 500) {
            text += `\n▸ Reverse DNS:\n${rdns.slice(0, 800)}`;
        }

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "trackip", handler, description: "Track IP + reverse DNS", category: "osint" };