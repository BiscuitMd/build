const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const me = await client.getMe();
        const text =
            `👤 WHOAMI (userbot)\n\n` +
            `▸ ID: ${me.id}\n` +
            `▸ Nama: ${[me.firstName, me.lastName].filter(Boolean).join(" ")}\n` +
            `▸ Username: ${me.username ? "@" + me.username : "-"}\n` +
            `▸ Phone: ${me.phone || "-"}\n` +
            `▸ Premium: ${me.premium ? "✅" : "❌"}\n` +
            `▸ Verified: ${me.verified ? "✅" : "❌"}`;
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "whoami", handler, description: "Info akun userbot", category: "osint" };