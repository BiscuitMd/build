async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const start = Date.now();
    const sent = await client.sendMessage(chatId, { message: "🏓 Pinging..." });
    const latency = Date.now() - start;
    try {
        await client.editMessage(chatId, {
            message: sent.id,
            text: `🏓 Pong!\n▸ Latency: ${latency}ms`
        });
    } catch {
        await client.sendMessage(chatId, { message: `🏓 Pong! ${latency}ms` });
    }
}

module.exports = { command: "ping", handler, description: "Test latency", category: "info" };