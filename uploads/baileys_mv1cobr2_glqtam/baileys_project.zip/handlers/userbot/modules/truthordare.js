async function handler(userId, client, msg, args) {
    const result = Math.random() < 0.5 ? "TRUTH 🎯" : "DARE 🎯";
    await client.sendMessage(msg.message.chatId, {
        message: `🎲 Spin hasilnya:\n\n▸ ${result}\n\n<i>Ketik .truth atau .dare buat mulai</i>`,
        parseMode: "html"
    });
}

module.exports = { command: "tod", handler, description: "Spin Truth or Dare", category: "fun" };