const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_goodbye.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");
function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    const db = read();
    db[chatId] = db[chatId] || {};

    if (!text) {
        const cur = db[chatId].goodbyeText || "(default)";
        return client.sendMessage(chatId, { message: `📖 Goodbye text sekarang: ${cur}\n\nKetik: .goodbye [text]` });
    }
    db[chatId].goodbyeText = text;
    write(db);
    await client.sendMessage(chatId, { message: `✅ Goodbye text diset:\n${text}` });
}

module.exports = { command: "goodbye", handler, description: "Set goodbye message", category: "group" };