const crypto = require("crypto");

async function handler(userId, client, msg, args) {
    const len = Math.min(parseInt(args[0]) || 16, 64);
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*";
    let pwd = "";
    const bytes = crypto.randomBytes(len);
    for (let i = 0; i < len; i++) pwd += chars[bytes[i] % chars.length];
    await client.sendMessage(msg.message.chatId, { message: `🔐 Password (${len}):\n\`${pwd}\`` });
}

module.exports = { command: "password", handler, description: "Generate password random", category: "tools" };