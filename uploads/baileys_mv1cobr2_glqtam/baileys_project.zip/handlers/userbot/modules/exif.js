// ═══════════════════════════════════════════
// EXIF — Baca metadata foto
// v2 — Graceful fallback kalau exifr ga keinstall
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

let exifr = null;
try {
    exifr = require("exifr");
} catch (e) {
    console.log("[EXIF MODULE] exifr ga keinstall, fitur exif disabled");
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;

    // Kalau exifr gaada, kasih info + skip
    if (!exifr) {
        return client.sendMessage(chatId, {
            message:
                `⚠️ Fitur EXIF ga tersedia\n\n` +
                `<i>Module exifr ga keinstall di server.\n` +
                `Install dulu: <code>npm install exifr</code></i>`,
            parseMode: "html"
        });
    }

    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) {
        return client.sendMessage(chatId, { message: "📖 Reply foto + .exif" });
    }

    const loading = await client.sendMessage(chatId, { message: "📷 Baca EXIF..." });

    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");

        const parsed = await exifr.parse(buf).catch(() => null);
        if (!parsed) throw new Error("Gaada metadata EXIF");

        const text =
            `📷 EXIF DATA\n\n` +
            `▸ Make: ${parsed.Make || "-"}\n` +
            `▸ Model: ${parsed.Model || "-"}\n` +
            `▸ Software: ${parsed.Software || "-"}\n` +
            `▸ Date: ${parsed.DateTimeOriginal || "-"}\n` +
            `▸ GPS: ${parsed.latitude && parsed.longitude ? `${parsed.latitude}, ${parsed.longitude}` : "-"}\n` +
            `▸ ISO: ${parsed.ISO || "-"}\n` +
            `▸ FNumber: ${parsed.FNumber || "-"}\n` +
            `▸ Exposure: ${parsed.ExposureTime || "-"}`;

        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = {
    command: "exif",
    handler,
    description: "Baca EXIF foto",
    category: "osint"
};