const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const [coin, date] = args;
    if (!coin || !date) return client.sendMessage(chatId, { message: "📖 .historical [coin] [DD-MM-YYYY]\nContoh: .historical bitcoin 01-01-2024" });

    const loading = await client.sendMessage(chatId, { message: `📅 Historical ${coin}...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin}/history?date=${date}`, { timeout: 20000 });
        const d = r.data;
        if (!d.market_data) throw new Error("Gaada data tanggal itu");
        const md = d.market_data;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message:
                `📅 ${d.name || coin} — ${date}\n\n` +
                `▸ USD: $${md.current_price?.usd?.toLocaleString("id-ID")}\n` +
                `▸ IDR: Rp${md.current_price?.idr?.toLocaleString("id-ID")}\n` +
                `▸ Market Cap: $${(md.market_cap?.usd / 1e9).toFixed(2)}B`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "historical", handler, description: "Harga crypto di tanggal tertentu", category: "crypto" };