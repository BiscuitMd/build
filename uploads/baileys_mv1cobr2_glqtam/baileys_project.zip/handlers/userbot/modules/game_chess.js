const core = require("./gamecore");

const PIECES = {
    "♔": "K", "♕": "Q", "♖": "R", "♗": "B", "♘": "N", "♙": "P",
    "♚": "k", "♛": "q", "♜": "r", "♝": "b", "♞": "n", "♟": "p"
};

function initBoard() {
    return [
        ["r", "n", "b", "q", "k", "b", "n", "r"],
        ["p", "p", "p", "p", "p", "p", "p", "p"],
        ["", "", "", "", "", "", "", ""],
        ["", "", "", "", "", "", "", ""],
        ["", "", "", "", "", "", "", ""],
        ["", "", "", "", "", "", "", ""],
        ["P", "P", "P", "P", "P", "P", "P", "P"],
        ["R", "N", "B", "Q", "K", "B", "N", "R"]
    ];
}

const UNICODE = {
    "K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘", "P": "♙",
    "k": "♚", "q": "♛", "r": "♜", "b": "♝", "n": "♞", "p": "♟"
};

const FILES = "abcdefgh";

function renderBoard(board, highlight = []) {
    let cells = "";
    const size = 70;
    const offset = 80;

    for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
            const light = (r + c) % 2 === 0;
            const x = offset + c * size;
            const y = offset + r * size;
            const isHL = highlight.some(h => h[0] === r && h[1] === c);
            const fill = isHL ? "#fbbf24" : (light ? "#f0d9b5" : "#b58863");

            cells += `<rect x="${x}" y="${y}" width="${size}" height="${size}" fill="${fill}" stroke="#000" stroke-width="1"/>`;

            const piece = board[r][c];
            if (piece && UNICODE[piece]) {
                cells += `<text x="${x + size / 2}" y="${y + size / 2 + 18}" font-family="Arial" font-size="52" fill="${piece === piece.toUpperCase() ? "#fff" : "#000"}" text-anchor="middle" dominant-baseline="middle">${UNICODE[piece]}</text>`;
            }
        }
    }

    for (let i = 0; i < 8; i++) {
        cells += `<text x="${offset + i * size + size / 2}" y="${offset + 8 * size + 20}" font-family="Arial" font-size="14" fill="#fbbf24" text-anchor="middle">${FILES[i]}</text>`;
        cells += `<text x="${offset - 25}" y="${offset + i * size + size / 2 + 5}" font-family="Arial" font-size="14" fill="#fbbf24" text-anchor="middle">${8 - i}</text>`;
    }

    return cells;
}

async function sendBoard(client, chatId, room, caption = "") {
    const board = room.state.board;
    const svg = core.buildLegoFrame(
        renderBoard(board, room.state.highlight || []),
        "♛ CHESS ♛",
        "purple"
    );

    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";
    const myUsername = me?.username || null;

    if (cmd === "start") {
        const room = core.createRoom("chess", userId, myName, myUsername, {
            state: { board: initBoard(), highlight: [] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        const caption =
            "♛ <b>CHESS ROOM</b> ♛\n\n" +
            "├─────────────────\n" +
            "│ 🎮 Game   → Chess\n" +
            "│ 🆔 Room   → <code>" + room.id + "</code>\n" +
            "│ 👤 Host   → " + myName + "\n" +
            "│ 👥 Player → 1/2\n" +
            "├─────────────────\n" +
            "│ 📖 Share kode room:\n" +
            "│ <code>.chess join " + room.id + "</code>\n" +
            "├─────────────────\n" +
            "│ ⏳ Tunggu player kedua join...\n" +
            "╰─────────────────";

        await sendBoard(client, chatId, room, caption);
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .chess join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, myUsername);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });

        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room itu" });

        const caption =
            "♛ <b>CHESS START!</b> ♛\n\n" +
            "├─────────────────\n" +
            "│ 🎮 Room    → " + r.room.id + "\n" +
            "│ 👤 White   → " + r.room.players[0].name + "\n" +
            "│ 👤 Black   → " + r.room.players[1].name + "\n" +
            "├─────────────────\n" +
            "│ 🎯 Turn    → " + r.room.players[0].name + " (White)\n" +
            "│ 📖 Gerak: <code>.chess move e2 e4</code>\n" +
            "╰─────────────────";

        await sendBoard(client, chatId, r.room, caption);
        return;
    }

    if (cmd === "move") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "chess" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Lu ga di game chess aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) {
            return client.sendMessage(chatId, { message: "✕ Bukan turn lu. Sekarang: " + currentPlayer.name });
        }

        const from = args[1]?.toLowerCase();
        const to = args[2]?.toLowerCase();

        if (!from || !to || from.length !== 2 || to.length !== 2) {
            return client.sendMessage(chatId, { message: "▸ .chess move e2 e4" });
        }

        const fc = FILES.indexOf(from[0]);
        const fr = 8 - parseInt(from[1]);
        const tc = FILES.indexOf(to[0]);
        const tr = 8 - parseInt(to[1]);

        if (fc < 0 || fr < 0 || fr > 7 || tc < 0 || tr < 0 || tr > 7) {
            return client.sendMessage(chatId, { message: "✕ Koordinat invalid" });
        }

        const piece = room.state.board[fr][fc];
        if (!piece) return client.sendMessage(chatId, { message: "✕ Ga ada piece di " + from });

        const isWhite = room.turn % 2 === 0;
        if (isWhite && piece !== piece.toUpperCase()) return client.sendMessage(chatId, { message: "✕ Itu bukan piece lu" });
        if (!isWhite && piece === piece.toUpperCase()) return client.sendMessage(chatId, { message: "✕ Itu bukan piece lu" });

        const captured = room.state.board[tr][tc];

        room.state.board[tr][tc] = piece;
        room.state.board[fr][fc] = "";
        room.state.highlight = [[fr, fc], [tr, tc]];
        room.moveHistory.push({ from, to, piece, at: Date.now() });
        room.turn++;

        if (captured && captured.toLowerCase() === "k") {
            const winner = room.players[room.turn % 2];
            await sendBoard(client, chatId, room, "♛ CHECKMATE! " + winner.name + " menang!");
            return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
        }

        core.saveRoom(room);

        const next = room.players[room.turn % 2];
        const caption =
            "♛ <b>CHESS</b> ♛\n\n" +
            "├─────────────────\n" +
            "│ Move     → " + from + " → " + to + "\n" +
            "│ Piece    → " + UNICODE[piece] + "\n" +
            "│ Capture  → " + (captured ? "YES (" + UNICODE[captured] + ")" : "No") + "\n" +
            "├─────────────────\n" +
            "│ 🎯 Next  → " + next.name + "\n" +
            "╰─────────────────";

        await sendBoard(client, chatId, room, caption);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "♛ <b>CHESS</b> ♛\n\n" +
            "├─────────────────\n" +
            "│ ▪ .chess start\n" +
            "│ ▪ .chess join [KODE]\n" +
            "│ ▪ .chess move [from] [to]\n" +
            "│   Contoh: .chess move e2 e4\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "chess",
    handler,
    description: "Chess PVP (2 player)",
    category: "game"
};