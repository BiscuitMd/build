async function handler(userId, client, msg, args) {
    const text = args.join(" ");
    if (!text) return client.sendMessage(msg.message.chatId, { message: "📖 .upper [text]" });
    await client.sendMessage(msg.message.chatId, { message: text.toUpperCase() });
}

module.exports = { command: "upper", handler, description: "Ubah ke HURUF BESAR", category: "text" };