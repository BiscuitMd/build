async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    const packname = args.join(" ") || "SpartaX";
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply stiker + .take [packname]" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const { Api } = require("telegram");
        await client.sendFile(chatId, {
            file: buf,
            attributes: [new Api.DocumentAttributeSticker({
                alt: "🤖",
                stickerset: new Api.InputStickerSetEmpty()
            })]
        });
        await client.sendMessage(chatId, { message: `✅ Stiker di-take` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "take", handler, description: "Ambil stiker user lain", category: "media" };