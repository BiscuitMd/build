const os = require("os");
const fs = require("fs");
const path = require("path");

function formatBytes(b) {
    if (b < 1024) return b + " B";
    if (b < 1048576) return (b / 1024).toFixed(2) + " KB";
    if (b < 1073741824) return (b / 1048576).toFixed(2) + " MB";
    return (b / 1073741824).toFixed(2) + " GB";
}

function formatTime(sec) {
    const d = Math.floor(sec / 86400);
    const h = Math.floor((sec % 86400) / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = Math.floor(sec % 60);
    return d + "d " + h + "h " + m + "m " + s + "s";
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;

    try {
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;
        const memPercent = ((usedMem / totalMem) * 100).toFixed(1);

        const cpus = os.cpus();
        const load = os.loadavg();

        const text =
            "╭───────────────────╮\n" +
            "│   ◉  SYSMON        │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ SISTEM\n" +
            "├───────────────────\n" +
            "│ ▪ Hostname  → " + os.hostname() + "\n" +
            "│ ▪ Platform  → " + os.platform() + " " + os.arch() + "\n" +
            "│ ▪ CPU       → " + cpus[0].model.slice(0, 25) + "\n" +
            "│ ▪ Cores     → " + cpus.length + "\n" +
            "│ ▪ Uptime    → " + formatTime(os.uptime()) + "\n" +
            "├───────────────────\n" +
            "│ ◆ MEMORY\n" +
            "├───────────────────\n" +
            "│ ▪ Total     → " + formatBytes(totalMem) + "\n" +
            "│ ▪ Used      → " + formatBytes(usedMem) + " (" + memPercent + "%)\n" +
            "│ ▪ Free      → " + formatBytes(freeMem) + "\n" +
            "├───────────────────\n" +
            "│ ◆ LOAD AVERAGE\n" +
            "├───────────────────\n" +
            "│ ▪ 1m  → " + load[0].toFixed(2) + "\n" +
            "│ ▪ 5m  → " + load[1].toFixed(2) + "\n" +
            "│ ▪ 15m → " + load[2].toFixed(2) + "\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    } catch (e) {
        return client.sendMessage(chatId, { message: "✕ Error: " + e.message });
    }
}

module.exports = {
    command: "sysmon",
    handler,
    description: "Monitor RAM/CPU/uptime server",
    category: "monitor"
};