async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let target = args.join(" ") || "siapa aja";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) target = msgs[0].sender?.firstName || "dia";
    }

    const emotes = ["(っ˘̩╭╮˘̩)っ", "ノ( º _ ºノ)", "(╯°□°)╯", "(ノಠ益ಠ)ノ"];
    const e = emotes[Math.floor(Math.random() * emotes.length)];
    await client.sendMessage(chatId, { message: `${e} *SLAP* ${target}!` });
}

module.exports = { command: "slap", handler, description: "Slap user", category: "fun" };