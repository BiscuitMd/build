const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .reverseimage" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Reverse image search...` });

    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");

        // Upload ke imgbb gratis
        const FormData = require("form-data");
        const fd = new FormData();
        fd.append("image", buf.toString("base64"));
        const up = await axios.post("https://api.imgbb.com/1/upload?key=demo", fd, { timeout: 30000 }).catch(() => null);

        let text = `🔍 REVERSE IMAGE\n\n`;
        if (up?.data?.data?.url) {
            text += `▸ Uploaded: ${up.data.data.url}\n\n`;
        }
        text += `<b>Check manual:</b>\n`;
        text += `▸ Google: https://images.google.com/\n`;
        text += `▸ Yandex: https://yandex.com/images/\n`;
        text += `▸ TinEye: https://tineye.com/\n`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "reverseimage", handler, description: "Reverse image search", category: "osint" };