const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const [amount, from, to] = args;
    if (!amount || !from || !to) {
        return client.sendMessage(chatId, { message: "📖 .currency [jumlah] [from] [to]\nContoh: .currency 100 USD IDR" });
    }
    try {
        const r = await axios.get(`https://api.frankfurter.app/latest?amount=${amount}&from=${from.toUpperCase()}&to=${to.toUpperCase()}`, { timeout: 15000 });
        const result = r.data?.rates?.[to.toUpperCase()];
        if (!result) throw new Error("Kurs ga ditemukan");
        await client.sendMessage(chatId, { message: `💱 ${amount} ${from.toUpperCase()} = ${result} ${to.toUpperCase()}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "currency", handler, description: "Convert currency", category: "tools" };