const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_iqc.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

function escapeXml(s) {
    return String(s).replace(/[<>&'"]/g, c => ({
        "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
    }[c]));
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || { iq: 120, name: "Unknown", footer: "SpartaX IQC" };

    if (cmd === "set") {
        const iq = parseInt(args[1]);
        if (isNaN(iq) || iq < 1 || iq > 300) return client.sendMessage(chatId, { message: "▸ .iqc set [1-300]" });
        db[userId].iq = iq;
        write(db);
        return client.sendMessage(chatId, { message: "✓ IQ diset: " + iq });
    }

    if (cmd === "name") {
        const name = args.slice(1).join(" ");
        if (!name) return client.sendMessage(chatId, { message: "▸ .iqc name [nama]" });
        db[userId].name = name;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Nama: " + name });
    }

    if (cmd === "footer") {
        const footer = args.slice(1).join(" ");
        if (!footer) return client.sendMessage(chatId, { message: "▸ .iqc footer [teks]" });
        db[userId].footer = footer;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Footer: " + footer });
    }

    if (cmd === "gen" || !cmd) {
        const iq = db[userId].iq;
        const name = args.slice(1).join(" ") || db[userId].name;
        const footer = db[userId].footer;

        const level =
            iq >= 140 ? "GENIUS" :
            iq >= 120 ? "SUPERIOR" :
            iq >= 100 ? "NORMAL" :
            iq >= 80 ? "DULL" :
            iq >= 60 ? "BORDERLINE" : "DEFICIENT";

        const svg =
            `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="500" viewBox="0 0 800 500">` +
            `<defs>` +
            `<linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">` +
            `<stop offset="0%" style="stop-color:#0f0c29"/>` +
            `<stop offset="50%" style="stop-color:#302b63"/>` +
            `<stop offset="100%" style="stop-color:#24243e"/>` +
            `</linearGradient>` +
            `</defs>` +
            `<rect width="800" height="500" fill="url(#bg)"/>` +
            `<rect x="40" y="40" width="720" height="420" rx="20" fill="rgba(255,255,255,0.05)" stroke="rgba(255,255,255,0.15)" stroke-width="2"/>` +
            `<text x="400" y="110" font-family="Arial,sans-serif" font-size="28" font-weight="bold" fill="#a78bfa" text-anchor="middle" letter-spacing="4">IQ TEST RESULT</text>` +
            `<text x="400" y="240" font-family="Arial,sans-serif" font-size="140" font-weight="bold" fill="#ffffff" text-anchor="middle">${iq}</text>` +
            `<text x="400" y="290" font-family="Arial,sans-serif" font-size="22" fill="#c4b5fd" text-anchor="middle" letter-spacing="3">${level}</text>` +
            `<line x1="200" y1="330" x2="600" y2="330" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>` +
            `<text x="400" y="370" font-family="Arial,sans-serif" font-size="20" fill="#e5e7eb" text-anchor="middle">${escapeXml(name)}</text>` +
            `<text x="400" y="430" font-family="Arial,sans-serif" font-size="14" fill="#6b7280" text-anchor="middle" letter-spacing="2">${escapeXml(footer)}</text>` +
            `</svg>`;

        try {
            const sharp = require("sharp");
            const png = await sharp(Buffer.from(svg)).png().toBuffer();
            const { CustomFile } = require("telegram/client/uploads");
            const file = new CustomFile("iqc.png", png.length, "", png);

            await client.sendFile(chatId, {
                file,
                caption: "◆ IQC GENERATED\n\n▸ " + name + " — " + iq + " (" + level + ")"
            });
        } catch (e) {
            return client.sendMessage(chatId, {
                message: "✕ Gagal bikin gambar (butuh sharp): " + e.message
            });
        }
        return;
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ◇  IQC GENERATOR │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ CURRENT\n" +
        "├───────────────────\n" +
        "│ ▪ IQ     → " + db[userId].iq + "\n" +
        "│ ▪ Name   → " + db[userId].name + "\n" +
        "│ ▪ Footer → " + db[userId].footer + "\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .iqc gen [nama]\n" +
        "│ ▪ .iqc set [1-300]\n" +
        "│ ▪ .iqc name [nama]\n" +
        "│ ▪ .iqc footer [teks]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "iqc",
    handler,
    description: "Generator IQC (gambar hasil tes IQ)",
    category: "tools"
};