const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ") || "anime";
    const loading = await client.sendMessage(chatId, { message: "⏳ Cari wallpaper..." });
    try {
        const r = await axios.get(`https://api.unsplash.com/photos/random?query=${encodeURIComponent(query)}&orientation=landscape`, {
            headers: { Authorization: "Client-ID demo" },
            timeout: 15000
        }).catch(() => null);

        const imgUrl = r?.data?.urls?.full || `https://source.unsplash.com/1920x1080/?${encodeURIComponent(query)}`;
        const img = await axios.get(imgUrl, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: `🖼️ Wallpaper: ${query}`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "wallpaper", handler, description: "Wallpaper random HD", category: "download" };