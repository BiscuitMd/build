async function handler(userId, client, msg, args) {
    const text = args.join(" ");
    if (!text) return client.sendMessage(msg.message.chatId, { message: "📖 .count [text]" });
    const chars = text.length;
    const words = text.trim().split(/\s+/).length;
    const lines = text.split("\n").length;
    await client.sendMessage(msg.message.chatId, {
        message: `📊 Count:\n▸ Karakter: ${chars}\n▸ Kata: ${words}\n▸ Baris: ${lines}`
    });
}

module.exports = { command: "count", handler, description: "Hitung karakter", category: "text" };