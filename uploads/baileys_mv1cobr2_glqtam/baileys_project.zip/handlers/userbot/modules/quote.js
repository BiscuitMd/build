const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.quotable.io/random", { timeout: 15000 });
        const q = r.data;
        await client.sendMessage(chatId, {
            message: `💭 "${q.content}"\n\n— ${q.author}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "quote", handler, description: "Random quote", category: "fun" };