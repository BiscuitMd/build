const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ");
    if (!query) return client.sendMessage(chatId, { message: "📖 .pastbin [keyword]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Cari di Pastebin...` });

    try {
        const url = `https://psbdmp.ws/api/search/${encodeURIComponent(query)}`;
        const r = await axios.get(url, { timeout: 20000 });
        const dumps = r.data?.data || [];
        if (dumps.length === 0) throw new Error("Gaada hasil");

        const text =
            `🔍 PASTEBIN SEARCH: ${query}\n\n` +
            `▸ Total: ${dumps.length}\n\n` +
            dumps.slice(0, 15).map(d => `▸ https://pastebin.com/${d.id}`).join("\n");

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "pastbin", handler, description: "Search Pastebin dumps", category: "osint" };