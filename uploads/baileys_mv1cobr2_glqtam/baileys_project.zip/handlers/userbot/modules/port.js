const net = require("net");

const COMMON_PORTS = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 3306, 3389, 5432, 5900, 6379, 8080, 8443, 27017];

function checkPort(host, port, timeout = 3000) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        socket.setTimeout(timeout);
        socket.on("connect", () => { socket.destroy(); resolve(true); });
        socket.on("timeout", () => { socket.destroy(); resolve(false); });
        socket.on("error", () => { socket.destroy(); resolve(false); });
        socket.connect(port, host);
    });
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const host = args[0];
    if (!host) return client.sendMessage(chatId, { message: "📖 .port [host/ip]\nCheck 18 common port" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Scan port ${host}...` });

    try {
        const results = await Promise.all(COMMON_PORTS.map(async (p) => {
            const open = await checkPort(host, p);
            return { port: p, open };
        }));

        const open = results.filter(r => r.open);
        const closed = results.filter(r => !r.open);

        let text = `🔍 PORT SCAN ${host}\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        text += `✅ OPEN (${open.length}):\n`;
        text += open.length > 0 ? open.map(r => `▸ ${r.port}`).join("\n") : "▸ (gaada)";
        text += `\n\n❌ CLOSED (${closed.length}):\n`;
        text += closed.map(r => r.port).join(", ");
        text += `\n━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "port", handler, description: "Scan port terbuka", category: "osint" };