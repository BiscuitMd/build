function toVapor(text) {
    return text.split("").map(c => {
        const code = c.charCodeAt(0);
        if (code >= 33 && code <= 126) return String.fromCharCode(code + 0xFEE0);
        return c;
    }).join("");
}

function toBold(text) {
    const map = { "a":"𝗮","b":"𝗯","c":"𝗰","d":"𝗱","e":"𝗲","f":"𝗳","g":"𝗴","h":"𝗵","i":"𝗶","j":"𝗷","k":"𝗸","l":"𝗹","m":"𝗺","n":"𝗻","o":"𝗼","p":"𝗽","q":"𝗾","r":"𝗿","s":"𝘀","t":"𝘁","u":"𝘂","v":"𝘃","w":"𝘄","x":"𝘅","y":"𝘆","z":"𝘇","A":"𝗔","B":"𝗕","C":"𝗖","D":"𝗗","E":"𝗘","F":"𝗙","G":"𝗚","H":"𝗛","I":"𝗜","J":"𝗝","K":"𝗞","L":"𝗟","M":"𝗠","N":"𝗡","O":"𝗢","P":"𝗣","Q":"𝗤","R":"𝗥","S":"𝗦","T":"𝗧","U":"𝗨","V":"𝗩","W":"𝗪","X":"𝗫","Y":"𝗬","Z":"𝗭" };
    return text.split("").map(c => map[c] || c).join("");
}

function toItalic(text) {
    const map = { "a":"𝘢","b":"𝘣","c":"𝘤","d":"𝘥","e":"𝘦","f":"𝘧","g":"𝘨","h":"𝘩","i":"𝘪","j":"𝘫","k":"𝘬","l":"𝘭","m":"𝘮","n":"𝘯","o":"𝘰","p":"𝘱","q":"𝘲","r":"𝘳","s":"𝘴","t":"𝘵","u":"𝘶","v":"𝘷","w":"𝘸","x":"𝘹","y":"𝘺","z":"𝘻","A":"𝘈","B":"𝘉","C":"𝘊","D":"𝘋","E":"𝘌","F":"𝘍","G":"𝘎","H":"𝘏","I":"𝘐","J":"𝘑","K":"𝘒","L":"𝘓","M":"𝘔","N":"𝘕","O":"𝘖","P":"𝘗","Q":"𝘘","R":"𝘙","S":"𝘚","T":"𝘛","U":"𝘜","V":"𝘝","W":"𝘞","X":"𝘟","Y":"𝘠","Z":"𝘡" };
    return text.split("").map(c => map[c] || c).join("");
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) {
        return client.sendMessage(chatId, {
            message: "📖 Command .style:\n▸ .style bold [text]\n▸ .style italic [text]\n▸ .style vapor [text]"
        });
    }

    const [mode, ...rest] = args;
    const content = rest.join(" ") || text;

    let result;
    if (mode === "bold") result = toBold(content);
    else if (mode === "italic") result = toItalic(content);
    else if (mode === "vapor") result = toVapor(content);
    else result = toVapor(text);

    await client.sendMessage(chatId, { message: result });
}

module.exports = { command: "style", handler, description: "Ubah text jadi style unicode", category: "text" };