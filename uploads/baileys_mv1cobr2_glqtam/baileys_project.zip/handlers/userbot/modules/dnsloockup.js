const dns = require("dns").promises;

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const domain = args[0];
    if (!domain) return client.sendMessage(chatId, { message: "📖 .dnslookup [domain.com]" });

    try {
        const [a, aaaa, mx, ns, txt, cname, soa] = await Promise.all([
            dns.resolve4(domain).catch(() => []),
            dns.resolve6(domain).catch(() => []),
            dns.resolveMx(domain).catch(() => []),
            dns.resolveNs(domain).catch(() => []),
            dns.resolveTxt(domain).catch(() => []),
            dns.resolveCname(domain).catch(() => []),
            dns.resolveSoa(domain).catch(() => null)
        ]);

        const text =
            `🌐 DNS LOOKUP: ${domain}\n\n` +
            `▸ A: ${a.join(", ") || "-"}\n` +
            `▸ AAAA: ${aaaa.join(", ") || "-"}\n` +
            `▸ CNAME: ${cname.join(", ") || "-"}\n` +
            `▸ MX: ${mx.map(m => `${m.priority} ${m.exchange}`).join(", ") || "-"}\n` +
            `▸ NS: ${ns.join(", ") || "-"}\n` +
            `▸ TXT: ${txt.map(t => t.join("")).join(" | ").slice(0, 200) || "-"}\n` +
            `▸ SOA: ${soa ? `${soa.nsname} / ${soa.hostmaster}` : "-"}`;

        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "dnslookup", handler, description: "DNS lookup lengkap", category: "osint" };