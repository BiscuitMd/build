const core = require("./gamecore");

function shuffled() {
    const arr = [1, 2, 3, 4, 5, 6, 7, 8, 0];
    for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

function isSolvable(arr) {
    let inversions = 0;
    for (let i = 0; i < arr.length; i++) {
        for (let j = i + 1; j < arr.length; j++) {
            if (arr[i] && arr[j] && arr[i] > arr[j]) inversions++;
        }
    }
    return inversions % 2 === 0;
}

function renderPuzzle(board, moves) {
    let cells = "";
    const size = 130;
    const offset = 60;

    for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) {
            const n = board[r * 3 + c];
            const x = offset + c * size;
            const y = offset + 40 + r * size;

            if (n === 0) {
                cells += `<rect x="${x}" y="${y}" width="${size}" height="${size}" rx="12" fill="rgba(0,0,0,0.3)" stroke="#fbbf24" stroke-width="3" stroke-dasharray="8"/>`;
            } else {
                cells += `<rect x="${x}" y="${y}" width="${size}" height="${size}" rx="12" fill="#3b82f6" stroke="#1e40af" stroke-width="3"/>`;
                cells += `<text x="${x + size / 2}" y="${y + size / 2 + 30}" font-family="Arial Black" font-size="70" font-weight="900" fill="#fff" text-anchor="middle">${n}</text>`;
            }
        }
    }

    cells += `<text x="400" y="530" font-family="Arial" font-size="20" fill="#fbbf24" text-anchor="middle">Moves: ${moves}</text>`;

    return cells;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderPuzzle(room.state.board, room.state.moves || 0), "🧩 PUZZLE 🧩", "orange");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        let board;
        do { board = shuffled(); } while (!isSolvable(board));

        const room = core.createRoom("puzzle", userId, myName, null, {
            state: { board, moves: 0 },
            maxPlayers: 1,
            chatId: String(chatId)
        });

        const caption =
            "🧩 <b>PUZZLE 3x3</b> 🧩\n\n" +
            "├─────────────────\n" +
            "│ 🆔 Room → " + room.id + "\n" +
            "│ 🎯 Goal → 1 2 3 / 4 5 6 / 7 8 _\n" +
            "├─────────────────\n" +
            "│ 📖 Move: <code>.puzzle move [angka]</code>\n" +
            "│ 📖 Contoh: .puzzle move 5\n" +
            "├─────────────────\n" +
            "│ ⏱ Mulai! Semakin cepat makin bagus\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    if (cmd === "move") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "puzzle" && r.status === "waiting");
        if (!room) return client.sendMessage(chatId, { message: "✕ Start dulu: .puzzle start" });

        const num = parseInt(args[1]);
        const board = room.state.board;
        const idx = board.indexOf(num);
        const zeroIdx = board.indexOf(0);

        if (idx === -1) return client.sendMessage(chatId, { message: "✕ Angka " + num + " ga ada" });

        const ir = Math.floor(idx / 3), ic = idx % 3;
        const zr = Math.floor(zeroIdx / 3), zc = zeroIdx % 3;

        const dist = Math.abs(ir - zr) + Math.abs(ic - zc);
        if (dist !== 1) return client.sendMessage(chatId, { message: "✕ Angka " + num + " ga bisa digerakin" });

        board[zeroIdx] = num;
        board[idx] = 0;
        room.state.moves++;

        const solved = board.join(",") === "1,2,3,4,5,6,7,8,0";

        if (solved) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🎉 PUZZLE SOLVED dalam " + room.state.moves + " moves!");
            return core.checkWinAndReward(room, userId, myName, client, chatId);
        }

        core.saveRoom(room);
        await sendGame(client, chatId, room, "🧩 Move " + num + " ok — Moves: " + room.state.moves);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "🧩 <b>PUZZLE</b> 🧩\n\n" +
            "├─────────────────\n" +
            "│ ▪ .puzzle start\n" +
            "│ ▪ .puzzle move [angka]\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "puzzle",
    handler,
    description: "Sliding puzzle 3x3",
    category: "game"
};