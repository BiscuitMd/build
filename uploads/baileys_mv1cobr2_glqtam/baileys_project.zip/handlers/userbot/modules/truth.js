const TRUTHS = [
    "Siapa orang yang paling sering lu pikirin?",
    "Apa hal paling memalukan yang pernah lu lakuin?",
    "Pernah bohong ke ortu? Apa?",
    "Siapa crush lu sekarang?",
    "Apa kebiasaan buruk lu yang ga bisa diilangin?",
    "Pernah nangis karena apa?",
    "Apa hal yang lu sesalin?",
    "Siapa orang yang paling lu benci?",
    "Pernah suka sama temen sendiri?",
    "Apa rahasia yang belum pernah lu cerita?"
];

async function handler(userId, client, msg, args) {
    const t = TRUTHS[Math.floor(Math.random() * TRUTHS.length)];
    await client.sendMessage(msg.message.chatId, { message: `🎯 TRUTH:\n\n${t}` });
}

module.exports = { command: "truth", handler, description: "Truth or dare — Truth", category: "fun" };