async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = null;

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    } else if (args[0]) {
        targetId = args[0];
    }

    if (!targetId) return client.sendMessage(chatId, { message: "📖 Reply user + .kick" });

    try {
        await client.kickParticipant(chatId, targetId);
        await client.sendMessage(chatId, { message: `✅ User ${targetId} di-kick` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ Gagal kick: ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "kick", handler, description: "Kick user dari group", category: "admin" };