async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = null;
    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    } else if (args[0]) targetId = args[0];

    if (!targetId) return client.sendMessage(chatId, { message: "📖 Reply user + .promote" });

    try {
        await client.invoke(new (require("telegram").Api.channels.EditAdmin)({
            channel: chatId,
            userId: targetId,
            adminRights: new (require("telegram").Api.ChatAdminRights)({
                changeInfo: true,
                postMessages: true,
                editMessages: true,
                deleteMessages: true,
                banUsers: true,
                inviteUsers: true,
                pinMessages: true,
                addAdmins: false,
                anonymous: false,
                manageCall: true,
                other: true
            }),
            rank: "Admin"
        }));
        await client.sendMessage(chatId, { message: `👑 User ${targetId} di-promote jadi admin` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "promote", handler, description: "Promote user jadi admin", category: "admin" };