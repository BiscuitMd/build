const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ").trim();
    if (!query) return client.sendMessage(chatId, { message: "📖 .image [query]" });
    const loading = await client.sendMessage(chatId, { message: "🖼️ Cari gambar..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/s/gimage?query=${encodeURIComponent(query)}`, { timeout: 30000 });
        const list = r.data?.data || [];
        if (list.length === 0) throw new Error("No result");
        const pick = list[Math.floor(Math.random() * list.length)];
        const imgUrl = typeof pick === "string" ? pick : (pick.url || pick.image);
        const img = await axios.get(imgUrl, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(img.data), caption: `🖼️ ${query}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "image", handler, description: "Google image search", category: "download" };