async function handler(userId, client, msg, args) {
    const name = args.join(" ") || "Kamu";
    const percent = Math.floor(Math.random() * 101);
    await client.sendMessage(msg.message.chatId, {
        message: `🏳️‍🌈 How gay is ${name}?\n\n▸ ${percent}% gay 🌈`
    });
}

module.exports = { command: "howgay", handler, description: "How gay meter", category: "fun" };