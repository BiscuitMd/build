async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const core = require("./gamecore");

    const coins = core.getCoin(userId);

    const text =
        "🎮 <b>GAME CENTER</b> 🎮\n\n" +
        "├───────────────────\n" +
        "│ 💰 Coin lu: <b>" + coins + "</b> / 20\n" +
        "│ 📊 Progress: " + "█".repeat(Math.floor(Math.min(coins, 20) / 2)) + "░".repeat(10 - Math.floor(Math.min(coins, 20) / 2)) + "\n" +
        "├───────────────────\n" +
        "│ <b>🎯 PVP GAMES</b>\n" +
        "├───────────────────\n" +
        "│ ▪ .chess [start/join/link]\n" +
        "│ ▪ .uno [start/join/link]\n" +
        "│ ▪ .poker [start/join/link]\n" +
        "│ ▪ .billiard [start/join/link]\n" +
        "│ ▪ .pokemon [start/join/link]\n" +
        "├───────────────────\n" +
        "│ <b>🎲 SOLO / CO-OP</b>\n" +
        "├───────────────────\n" +
        "│ ▪ .ular [start/join]\n" +
        "│ ▪ .puzzle [start/join]\n" +
        "│ ▪ .botol [start/join]\n" +
        "│ ▪ .mancing [start/join]\n" +
        "│ ▪ .zombie [start/join]\n" +
        "├───────────────────\n" +
        "│ <b>💰 REWARD</b>\n" +
        "├───────────────────\n" +
        "│ ▪ Win game → +1 coin\n" +
        "│ ▪ 20 coin → userbot gratis 7 hari\n" +
        "│ ▪ .claim → tukar coin\n" +
        "│ ▪ .gamecoin top → leaderboard\n" +
        "├───────────────────\n" +
        "│ <b>📖 CARA MAIN</b>\n" +
        "├───────────────────\n" +
        "│ ▪ .[game] start → buat room\n" +
        "│ ▪ Share kode room ke temen\n" +
        "│ ▪ .[game] join [KODE] → masuk\n" +
        "│ ▪ .[game] move [aksi] → gerak\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text, parseMode: "html" });
}

module.exports = {
    command: "menugame",
    handler,
    description: "Menu utama game",
    category: "game",
    commands: ["game", "games", "menu_game"]
};