const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args.join(" ").trim();
    if (!url || !(url.includes("twitter") || url.includes("x.com"))) {
        return client.sendMessage(chatId, { message: "📖 .twitter [url]" });
    }
    const loading = await client.sendMessage(chatId, { message: "⏳ Download Twitter..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/d/twitter?url=${encodeURIComponent(url)}`, { timeout: 40000 });
        const d = r.data?.data;
        const mediaUrl = d?.video || d?.url || d?.download;
        if (!mediaUrl) throw new Error("No media URL");
        const v = await axios.get(mediaUrl, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(v.data),
            caption: "🐦 Twitter",
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "twitter", handler, description: "Download Twitter/X video", category: "download" };