async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply pesan + .pin" });
    try {
        await client.pinMessage(chatId, replyTo, { notify: true });
        await client.sendMessage(chatId, { message: "📌 Pesan di-pin" });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "pin", handler, description: "Pin pesan", category: "admin" };