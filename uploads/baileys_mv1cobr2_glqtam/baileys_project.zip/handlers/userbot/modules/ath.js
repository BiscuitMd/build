const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const coin = args[0]?.toLowerCase();
    if (!coin) return client.sendMessage(chatId, { message: "📖 .ath [coin]\nContoh: .ath bitcoin" });

    const loading = await client.sendMessage(chatId, { message: `🏆 ATH ${coin}...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin}`, { timeout: 20000 });
        const md = r.data?.market_data;
        if (!md) throw new Error("Coin ga ditemukan");

        const current = md.current_price.usd;
        const ath = md.ath.usd;
        const fromAth = ((current - ath) / ath * 100).toFixed(2);

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message:
                `🏆 ${coin.toUpperCase()} ATH\n\n` +
                `▸ Current: $${current.toLocaleString("id-ID")}\n` +
                `▸ ATH: $${ath.toLocaleString("id-ID")}\n` +
                `▸ Date ATH: ${new Date(md.ath_date.usd).toLocaleDateString("id-ID")}\n` +
                `▸ From ATH: ${fromAth}%\n` +
                `▸ ATL: $${md.atl.usd.toLocaleString("id-ID")}`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "ath", handler, description: "ATH crypto", category: "crypto" };