const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .robots [domain.com]" });

    const domain = url.startsWith("http") ? url : `https://${url}`;
    const loading = await client.sendMessage(chatId, { message: `🤖 Baca robots.txt...` });

    try {
        const r = await axios.get(`${domain}/robots.txt`, { timeout: 15000, validateStatus: () => true });
        if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: `🤖 ${domain}/robots.txt\n\n${String(r.data).slice(0, 4000)}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "robots", handler, description: "Baca robots.txt", category: "osint" };