const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args[0];
    if (!query) return client.sendMessage(chatId, { message: "📖 .pastecheck [email/keyword]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Check paste dumps...` });

    try {
        const r = await axios.get(`https://psbdmp.ws/api/search/${encodeURIComponent(query)}`, { timeout: 20000 });
        const dumps = r.data?.data || [];

        let text = `🔍 PASTEBIN CHECK\n\n▸ Query: ${query}\n▸ Found: ${dumps.length}\n\n`;
        if (dumps.length > 0) {
            text += `▸ Recent dumps:\n`;
            text += dumps.slice(0, 10).map(d => `▸ https://pastebin.com/${d.id}`).join("\n");
        }

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "pastecheck", handler, description: "Check paste dumps", category: "osint" };