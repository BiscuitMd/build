const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args[0];
    if (!query) return client.sendMessage(chatId, { message: "📖 .socialscan [username/email]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Social scan...` });

    try {
        // Instagram public API
        let ig = "❌";
        try {
            const r = await axios.get(`https://www.instagram.com/${query}/?__a=1&__d=dis`, {
                timeout: 10000, validateStatus: () => true,
                headers: { "User-Agent": "Mozilla/5.0" }
            });
            if (r.status === 200 && r.data?.graphql?.user) ig = `✅ ${r.data.graphql.user.full_name || query} | Followers: ${r.data.graphql.user.edge_followed_by?.count || 0}`;
        } catch {}

        // TikTok
        let tt = "❌";
        try {
            const r = await axios.get(`https://www.tiktok.com/@${query}`, {
                timeout: 10000, validateStatus: () => true,
                headers: { "User-Agent": "Mozilla/5.0" }
            });
            if (r.status === 200 && String(r.data).includes("uniqueId")) tt = "✅ Ada";
        } catch {}

        const text =
            `🔍 SOCIAL SCAN: ${query}\n\n` +
            `▸ Instagram: ${ig}\n` +
            `▸ TikTok: ${tt}`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "socialscan", handler, description: "Scan social media", category: "osint" };