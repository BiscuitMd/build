const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "💰 Ambil harga BTC..." });
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd,idr&include_24hr_change=true&include_market_cap=true", { timeout: 15000 });
        const d = r.data.bitcoin;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, {
            message:
                `₿ BITCOIN (BTC)\n\n` +
                `▸ USD: $${d.usd?.toLocaleString("id-ID")}\n` +
                `▸ IDR: Rp${d.idr?.toLocaleString("id-ID")}\n` +
                `▸ 24h: ${d.usd_24h_change?.toFixed(2)}%\n` +
                `▸ Market Cap: $${(d.usd_market_cap / 1e9).toFixed(2)}B`
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "btc", handler, description: "Harga Bitcoin", category: "crypto" };