const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_alerts.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || [];

    if (cmd === "add") {
        const coin = args[1]?.toLowerCase();
        const price = parseFloat(args[2]);
        if (!coin || !price) return client.sendMessage(chatId, { message: "📖 .alerts add [coin] [target-price]" });
        db[userId].push({ coin, price, createdAt: Date.now() });
        write(db);
        return client.sendMessage(chatId, { message: `✅ Alert set: ${coin} @ $${price}` });
    }

    if (cmd === "del") {
        const idx = parseInt(args[1]) - 1;
        if (isNaN(idx) || !db[userId][idx]) return client.sendMessage(chatId, { message: "📖 .alerts del [index]" });
        db[userId].splice(idx, 1);
        write(db);
        return client.sendMessage(chatId, { message: `✅ Alert dihapus` });
    }

    if (cmd === "list" || !cmd) {
        const list = db[userId];
        if (list.length === 0) return client.sendMessage(chatId, { message: "📋 Alert kosong\n\nPakai: .alerts add [coin] [price]" });
        const text = `📋 Crypto Alerts:\n\n${list.map((a, i) => `${i + 1}. ${a.coin} @ $${a.price}`).join("\n")}`;
        return client.sendMessage(chatId, { message: text });
    }

    await client.sendMessage(chatId, { message: "📖 .alerts add/del/list" });
}

module.exports = { command: "alerts", handler, description: "Price alerts crypto", category: "crypto" };