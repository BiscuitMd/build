async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .emojify [text]" });
    const map = { a:"🅰️", b:"🅱️", c:"🌜", d:"🌛", e:"📧", f:"🎏", g:"🌀", h:"♓", i:"ℹ️", j:"🎷", k:"🎋", l:"👢", m:"〽️", n:"🎵", o:"🅾️", p:"🅿️", q:"🍳", r:"🌱", s:"💲", t:"🌴", u:"⛎", v:"♈", w:"〰️", x:"❌", y:"🍸", z:"💤", " ":" " };
    const out = text.toLowerCase().split("").map(c => map[c] || c).join("");
    await client.sendMessage(chatId, { message: out });
}

module.exports = { command: "emojify", handler, description: "Ubah text jadi emoji", category: "text" };