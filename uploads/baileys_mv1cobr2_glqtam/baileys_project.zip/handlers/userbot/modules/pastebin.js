const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .pastebin [text]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Upload ke pastebin..." });
    try {
        const r = await axios.post("https://paste.rs/", text, { headers: { "Content-Type": "text/plain" }, timeout: 20000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: `📋 Paste: ${r.data}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "pastebin", handler, description: "Upload text ke pastebin", category: "tools" };