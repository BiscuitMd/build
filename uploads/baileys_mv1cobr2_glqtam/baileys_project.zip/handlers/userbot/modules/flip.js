async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .flip [text]" });
    const table = { a:"ɐ", b:"q", c:"ɔ", d:"p", e:"ǝ", f:"ɟ", g:"ƃ", h:"ɥ", i:"ᴉ", j:"ɾ", k:"ʞ", l:"l", m:"ɯ", n:"u", o:"o", p:"d", q:"b", r:"ɹ", s:"s", t:"ʇ", u:"n", v:"ʌ", w:"ʍ", x:"x", y:"ʎ", z:"z", "?":"¿", "!":"¡", ".":"˙", ",":"'", "'":"," };
    const flipped = text.toLowerCase().split("").map(c => table[c] || c).reverse().join("");
    await client.sendMessage(chatId, { message: flipped });
}

module.exports = { command: "flip", handler, description: "Flip text upside down", category: "fun" };