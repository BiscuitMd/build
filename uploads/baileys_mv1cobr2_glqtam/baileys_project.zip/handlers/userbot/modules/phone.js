const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const phone = args[0];
    if (!phone) return client.sendMessage(chatId, { message: "📖 .phone [nomor]\nContoh: .phone +6281234567890" });

    const clean = phone.replace(/[^0-9+]/g, "");
    const loading = await client.sendMessage(chatId, { message: `📱 Lookup nomor...` });

    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/tools/nomorhoki?phone=${encodeURIComponent(clean)}`, { timeout: 20000 }).catch(() => null);
        let text = `📱 PHONE LOOKUP\n\n━━━━━━━━━━━━━━━━━━━━\n▸ Nomor: ${clean}\n`;

        if (r?.data?.data) {
            const d = r.data.data;
            text += `▸ Operator: ${d.operator || "-"}\n`;
            text += `▸ Region: ${d.region || "-"}\n`;
        } else {
            // Fallback: cek negara
            text += `▸ Internasional: +${clean.replace(/^\+/, "")}\n`;
            text += `▸ Info lebih lengkap: https://free-lookup.net/${clean}\n`;
            text += `\n<i>API gratis terbatas, cek manual di link.</i>\n`;
        }

        text += `━━━━━━━━━━━━━━━━━━━━`;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "phone", handler, description: "Lookup nomor telepon", category: "osint" };