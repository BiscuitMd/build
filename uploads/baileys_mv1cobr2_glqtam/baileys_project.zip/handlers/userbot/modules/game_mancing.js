const core = require("./gamecore");

const FISH = [
    { name: "Ikan Kecil", emoji: "🐟", point: 1, chance: 0.5 },
    { name: "Ikan Sedang", emoji: "🐠", point: 3, chance: 0.25 },
    { name: "Ikan Besar", emoji: "🐡", point: 5, chance: 0.15 },
    { name: "Hiu", emoji: "🦈", point: 10, chance: 0.07 },
    { name: "Ikan Legendaris", emoji: "🐉", point: 25, chance: 0.03 }
];

function renderGame(room) {
    let svg = "";
    svg += `<rect x="60" y="180" width="680" height="400" rx="30" fill="#0891b2" stroke="#164e63" stroke-width="8"/>`;

    for (let i = 0; i < 12; i++) {
        const x = 100 + (i * 60) % 600;
        const y = 220 + Math.floor(i / 3) * 90;
        svg += `<text x="${x}" y="${y}" font-size="30">🌊</text>`;
    }

    svg += `<text x="400" y="250" font-family="Arial Black" font-size="24" fill="#fbbf24" text-anchor="middle">🎣 MANCING IKAN</text>`;

    const myIdx = room.turn % 2;
    svg += `<text x="400" y="380" font-family="Arial" font-size="20" fill="#fff" text-anchor="middle">Skor ${room.players[0].name}: ${room.state.scores[0]}</text>`;
    svg += `<text x="400" y="420" font-family="Arial" font-size="20" fill="#fff" text-anchor="middle">Skor ${room.players[1].name}: ${room.state.scores[1]}</text>`;

    svg += `<text x="400" y="500" font-family="Arial Black" font-size="22" fill="#fbbf24" text-anchor="middle">Turn: ${room.players[myIdx].name}</text>`;
    svg += `<text x="400" y="540" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">Cast ${room.state.casts}/10 kali</text>`;

    return svg;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderGame(room), "🎣 MANCING 🐟", "blue");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const room = core.createRoom("mancing", userId, myName, null, {
            state: { scores: [0, 0], casts: 0, log: [] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "🎣 <b>MANCING IKAN</b> 🐟\n\n│ 🆔 <code>" + room.id + "</code>\n│ <code>.mancing join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .mancing join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        await sendGame(client, chatId, r.room,
            "🎣 <b>START!</b>\n\n│ 🎯 Turn: " + r.room.players[0].name + "\n│ 📖 <code>.mancing cast</code>"
        );
        return;
    }

    if (cmd === "cast") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "mancing" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        let caught = null;
        const roll = Math.random();
        let acc = 0;
        for (const f of FISH) {
            acc += f.chance;
            if (roll < acc) { caught = f; break; }
        }

        if (!caught) caught = FISH[0];

        const myIdx = room.turn % 2;
        room.state.scores[myIdx] += caught.point;
        room.state.casts++;
        room.turn++;

        let eventText = "🎣 Dapat: " + caught.emoji + " " + caught.name + " (+" + caught.point + ")";

        if (room.state.casts >= 10) {
            const winner = room.state.scores[0] > room.state.scores[1] ? room.players[0] : room.players[1];
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🏆 " + winner.name + " menang!");
            return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
        }

        core.saveRoom(room);

        await sendGame(client, chatId, room,
            "🎣 <b>MANCING</b>\n\n│ " + currentPlayer.name + "\n│ " + eventText + "\n│ Next: " + room.players[room.turn % 2].name
        );
        return;
    }

    return client.sendMessage(chatId, {
        message: "🎣 <b>MANCING</b>\n\n├─────────────────\n│ ▪ .mancing start\n│ ▪ .mancing join [KODE]\n│ ▪ .mancing cast\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "mancing",
    handler,
    description: "Mancing ikan PVP",
    category: "game",
    commands: ["fishing"]
};