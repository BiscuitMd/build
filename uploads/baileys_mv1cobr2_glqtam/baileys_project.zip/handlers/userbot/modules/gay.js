async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let name = args[0] || "Kamu";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) name = msgs[0].sender?.firstName || "Dia";
    }

    const percent = Math.floor(Math.random() * 101);
    const bar = "🏳️‍🌈".repeat(Math.ceil(percent / 10)) + "⬛".repeat(10 - Math.ceil(percent / 10));
    await client.sendMessage(chatId, {
        message: `🏳️‍🌈 Gay meter: ${name}\n\n${bar}\n▸ ${percent}% gay`
    });
}

module.exports = { command: "gay", handler, description: "Cek gay meter", category: "fun" };