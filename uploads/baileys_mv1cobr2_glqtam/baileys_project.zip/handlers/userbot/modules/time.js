async function handler(userId, client, msg, args) {
    const now = new Date();
    const wib = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
    const text =
        `🕐 WAKTU\n\n` +
        `▸ WIB: ${wib.toLocaleString("id-ID")}\n` +
        `▸ UTC: ${now.toISOString().slice(0, 19).replace("T", " ")}\n` +
        `▸ Unix: ${Math.floor(now.getTime() / 1000)}`;
    await client.sendMessage(msg.message.chatId, { message: text });
}

module.exports = { command: "time", handler, description: "Cek waktu sekarang", category: "info" };