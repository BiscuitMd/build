const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_stegano.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || { vault: {} };

    if (cmd === "hide") {
        const key = args[1];
        const text = args.slice(2).join(" ");
        if (!key || !text) return client.sendMessage(chatId, { message: "▸ .stegano hide [key] [pesan]" });

        const zeros = "\u200B";
        const encoded = text.split("").map(c => {
            const bin = c.charCodeAt(0).toString(2).padStart(8, "0");
            return bin.split("").map(b => b === "0" ? "\u200B" : "\u200C").join("");
        }).join("\u2060");

        db[userId].vault[key] = { text, hidden: encoded, at: Date.now() };
        write(db);

        return client.sendMessage(chatId, {
            message: "✓ Pesan disisipkan\n\n▸ Key: " + key + "\n▸ Pakai .stegano show " + key
        });
    }

    if (cmd === "show") {
        const key = args[1];
        if (!key || !db[userId].vault[key]) return client.sendMessage(chatId, { message: "✕ Key gaada" });
        const data = db[userId].vault[key];
        return client.sendMessage(chatId, {
            message: "◆ HIDDEN MESSAGE\n\n" + data.text
        });
    }

    if (cmd === "list") {
        const keys = Object.keys(db[userId].vault);
        if (!keys.length) return client.sendMessage(chatId, { message: "▸ Vault kosong" });
        let out = "";
        keys.forEach((k, i) => { out += "│ " + (i + 1) + ". " + k + "\n"; });
        return client.sendMessage(chatId, { message: "◆ STEGANO VAULT\n\n" + out });
    }

    if (cmd === "del") {
        const key = args[1];
        if (!key || !db[userId].vault[key]) return client.sendMessage(chatId, { message: "✕ Key gaada" });
        delete db[userId].vault[key];
        write(db);
        return client.sendMessage(chatId, { message: "✓ Dihapus: " + key });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚿  STEGANO       │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .stegano hide [key] [pesan]\n" +
        "│ ▪ .stegano show [key]\n" +
        "│ ▪ .stegano list\n" +
        "│ ▪ .stegano del [key]\n" +
        "╰───────────────────\n\n" +
        "▸ Zero-width character encoding";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "stegano",
    handler,
    description: "Steganography zero-width",
    category: "security"
};