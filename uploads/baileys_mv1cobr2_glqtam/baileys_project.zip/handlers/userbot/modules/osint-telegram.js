const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const target = args[0] || msg.message.replyTo?.senderId?.toString();

    if (!target) return client.sendMessage(chatId, { message: "▸ .tginfo [@username/ID] atau reply pesan" });

    try {
        const entity = await client.getEntity(target);
        const full = await client.invoke(new Api.users.GetFullUser({ id: entity.id }));

        const u = full.users[0];
        const fu = full.fullUser;

        const name = [u.firstName, u.lastName].filter(Boolean).join(" ") || "-";
        const status = u.status;
        const className = status?.className || "Unknown";

        let statusText = "Unknown";
        if (className === "UserStatusOnline") statusText = "● ONLINE";
        else if (className === "UserStatusOffline") statusText = "○ OFFLINE (" + new Date(status.wasOnline * 1000).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + ")";
        else if (className === "UserStatusRecently") statusText = "○ RECENTLY";
        else if (className === "UserStatusLastWeek") statusText = "○ LAST WEEK";
        else if (className === "UserStatusLastMonth") statusText = "○ LAST MONTH";

        const text =
            "╭───────────────────╮\n" +
            "│   ◎  TG INFO       │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ PROFILE\n" +
            "├───────────────────\n" +
            "│ ▪ ID         → <code>" + entity.id + "</code>\n" +
            "│ ▪ Name       → " + name + "\n" +
            "│ ▪ Username   → " + (u.username ? "@" + u.username : "-") + "\n" +
            "│ ▪ Phone      → " + (u.phone || "-") + "\n" +
            "│ ▪ Bio        → " + (fu.about || "-") + "\n" +
            "├───────────────────\n" +
            "│ ◆ BADGE\n" +
            "├───────────────────\n" +
            "│ ▪ Premium    → " + (u.premium ? "✓ YES" : "✕ NO") + "\n" +
            "│ ▪ Verified   → " + (u.verified ? "✓ YES" : "✕ NO") + "\n" +
            "│ ▪ Scam       → " + (u.scam ? "⚠️ YES" : "✓ NO") + "\n" +
            "│ ▪ Fake       → " + (u.fake ? "⚠️ YES" : "✓ NO") + "\n" +
            "│ ▪ Bot        → " + (u.bot ? "YES" : "NO") + "\n" +
            "├───────────────────\n" +
            "│ ◆ STATUS\n" +
            "├───────────────────\n" +
            "│ ▪ Last seen  → " + statusText + "\n" +
            "│ ▪ Common     → " + (fu.commonChatsCount || 0) + " chats\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        return client.sendMessage(chatId, { message: "✕ Error: " + e.message });
    }
}

module.exports = {
    command: "tginfo",
    handler,
    description: "Info lengkap user Telegram",
    category: "osint",
    commands: ["tgtrack", "userinfo"]
};