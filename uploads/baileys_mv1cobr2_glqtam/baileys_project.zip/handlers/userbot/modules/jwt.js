async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    if (cmd === "decode") {
        const token = args[1];
        if (!token) return client.sendMessage(chatId, { message: "▸ .jwt decode [token]" });

        try {
            const parts = token.split(".");
            if (parts.length !== 3) throw new Error("Format JWT invalid (harus 3 part)");

            const header = JSON.parse(Buffer.from(parts[0], "base64").toString("utf8"));
            const payload = JSON.parse(Buffer.from(parts[1], "base64").toString("utf8"));

            const text =
                "◆ JWT DECODED\n\n" +
                "├─────────────────\n" +
                "│ ◆ HEADER\n" +
                "├─────────────────\n" +
                "│ " + JSON.stringify(header, null, 2).replace(/\n/g, "\n│ ") + "\n" +
                "├─────────────────\n" +
                "│ ◆ PAYLOAD\n" +
                "├─────────────────\n" +
                "│ " + JSON.stringify(payload, null, 2).replace(/\n/g, "\n│ ") + "\n" +
                "├─────────────────\n" +
                "│ ◆ SIGNATURE\n" +
                "├─────────────────\n" +
                "│ " + parts[2] + "\n" +
                "╰─────────────────";

            return client.sendMessage(chatId, { message: text });
        } catch (e) {
            return client.sendMessage(chatId, { message: "✕ Error: " + e.message });
        }
    }

    if (cmd === "encode") {
        const payloadStr = args.slice(1).join(" ");
        if (!payloadStr) return client.sendMessage(chatId, { message: "▸ .jwt encode [json]" });

        try {
            const header = { alg: "HS256", typ: "JWT" };
            const payload = JSON.parse(payloadStr);

            const b64 = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
            const h = b64(header);
            const p = b64(payload);
            const sig = "unsigned_signature_here";

            return client.sendMessage(chatId, {
                message: "◆ JWT ENCODED\n\n<code>" + h + "." + p + "." + sig + "</code>",
                parseMode: "html"
            });
        } catch (e) {
            return client.sendMessage(chatId, { message: "✕ Payload bukan JSON valid" });
        }
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚿  JWT TOOL      │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .jwt decode [token]\n" +
        "│ ▪ .jwt encode {\"sub\":\"123\"}\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "jwt",
    handler,
    description: "JWT decode/encode",
    category: "security"
};