async function handler(userId, client, msg, args) {
    const text = args.join(" ");
    if (!text) return client.sendMessage(msg.message.chatId, { message: "📖 .reverse [text]" });
    await client.sendMessage(msg.message.chatId, { message: text.split("").reverse().join("") });
}

module.exports = { command: "reverse", handler, description: "Balik text", category: "text" };