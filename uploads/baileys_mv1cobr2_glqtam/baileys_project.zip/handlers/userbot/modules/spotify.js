const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ").trim();
    if (!query) return client.sendMessage(chatId, { message: "📖 .spotify [judul lagu]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Cari di Spotify..." });
    try {
        const search = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=1`, { timeout: 15000 });
        const track = search.data?.data?.[0];
        if (!track) throw new Error("Lagu ga ditemukan");
        const r = await axios.get(`https://api.siputzx.my.id/api/d/spotify?url=${encodeURIComponent(track.link)}`, { timeout: 40000 });
        const url = r.data?.data?.download || r.data?.data?.url;
        if (!url) throw new Error("No download URL");
        const audio = await axios.get(url, { responseType: "arraybuffer", timeout: 120000, maxContentLength: 50 * 1024 * 1024 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(audio.data),
            caption: `🎵 ${track.title}\n▸ ${track.artist.name}`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "spotify", handler, description: "Download Spotify", category: "download" };