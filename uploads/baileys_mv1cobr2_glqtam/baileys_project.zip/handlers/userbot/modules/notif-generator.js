// ═══════════════════════════════════════════
// NOTIF GENERATOR — Auto-generate foto notif buy role
// v1 — Tema kartun emas + putih
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const sharp = require("sharp");

// ═══ GENERATE FOTO NOTIF BUY ROLE ═══
async function generateBuyRoleNotif({
    roleName,
    price,
    status,           // "success" | "failed" | "pending"
    username,         // @username pembeli
    fullName,         // Nama lengkap pembeli
    userPhotoUrl,     // URL foto profile pembeli (optional)
    userId,           // ID pembeli
    timestamp
}) {
    try {
        const W = 1000;
        const H = 600;

        // ═══ Status color ═══
        const statusColors = {
            success: { main: "#10B981", light: "#34D399", dark: "#059669", label: "SUCCESS" },
            failed:  { main: "#EF4444", light: "#F87171", dark: "#DC2626", label: "FAILED" },
            pending: { main: "#F59E0B", light: "#FBBF24", dark: "#D97706", label: "PENDING" }
        };
        const sc = statusColors[status] || statusColors.pending;

        // ═══ Esc helper ═══
        const esc = (s) => String(s || "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&apos;");

        // ═══ Photo profile (circular) ═══
        let photoDataUri = "";
        if (userPhotoUrl) {
            try {
                const axios = require("axios");
                const res = await axios.get(userPhotoUrl, {
                    responseType: "arraybuffer",
                    timeout: 10000
                });
                const buf = Buffer.from(res.data);
                if (buf.length > 100) {
                    const b64 = buf.toString("base64");
                    const ext = userPhotoUrl.includes(".png") ? "png" : "jpeg";
                    photoDataUri = `data:image/${ext};base64,${b64}`;
                }
            } catch (e) {
                console.log("[NOTIF GEN] photo fetch fail:", e.message.slice(0, 80));
            }
        }

        // ═══ SVG Kartun ═══
        const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">

  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F172A"/>
      <stop offset="50%" stop-color="#1E293B"/>
      <stop offset="100%" stop-color="#0F172A"/>
    </linearGradient>

    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FCD34D"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#FCD34D"/>
    </linearGradient>

    <linearGradient id="whiteGoldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FFFFFF"/>
      <stop offset="50%" stop-color="#FEF3C7"/>
      <stop offset="100%" stop-color="#FCD34D"/>
    </linearGradient>

    <radialGradient id="glow">
      <stop offset="0%" stop-color="#FCD34D" stop-opacity="0.3"/>
      <stop offset="100%" stop-color="#FCD34D" stop-opacity="0"/>
    </radialGradient>

    <filter id="goldGlow">
      <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
      <feMerge>
        <feMergeNode in="coloredBlur"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>
  </defs>

  <!-- Background -->
  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>

  <!-- Kartun decorations -->
  <circle cx="80" cy="80" r="250" fill="url(#glow)"/>
  <circle cx="${W - 80}" cy="${H - 80}" r="280" fill="url(#glow)"/>

  <!-- Stars kartun -->
  <text x="150" y="90" font-size="24" fill="#FCD34D" opacity="0.4">◆</text>
  <text x="860" y="120" font-size="20" fill="#FCD34D" opacity="0.3">✦</text>
  <text x="200" y="${H - 50}" font-size="18" fill="#FCD34D" opacity="0.3">✦</text>
  <text x="820" y="${H - 70}" font-size="22" fill="#FCD34D" opacity="0.4">◆</text>

  <!-- Main border frame -->
  <rect x="25" y="25" width="${W - 50}" height="${H - 50}" rx="28"
        fill="#0F172A" fill-opacity="0.6"
        stroke="url(#goldGrad)" stroke-width="3" stroke-opacity="0.9"/>
  <rect x="25" y="25" width="${W - 50}" height="10" rx="5" fill="url(#goldGrad)"/>
  <rect x="25" y="${H - 35}" width="${W - 50}" height="10" rx="5" fill="url(#goldGrad)"/>

  <!-- Top bar title -->
  <text x="${W / 2}" y="85" font-family="Arial, sans-serif" font-size="20" font-weight="bold"
        fill="url(#whiteGoldGrad)" text-anchor="middle" letter-spacing="6">
    SPARTAX USERBOT
  </text>

  <!-- Subtitle -->
  <text x="${W / 2}" y="115" font-family="Arial, sans-serif" font-size="14"
        fill="#FCD34D" text-anchor="middle" letter-spacing="4" opacity="0.85">
    BUY ROLE NOTIFICATION
  </text>

  <!-- Divider -->
  <line x1="120" y1="140" x2="${W - 120}" y2="140" stroke="#FCD34D" stroke-width="1.5" opacity="0.5"/>

  <!-- Status badge (center) -->
  <rect x="${W / 2 - 130}" y="165" width="260" height="60" rx="30"
        fill="${sc.main}" fill-opacity="0.15"
        stroke="${sc.main}" stroke-width="3"/>
  <text x="${W / 2}" y="205" font-family="Arial, sans-serif" font-size="26" font-weight="bold"
        fill="${sc.main}" text-anchor="middle" letter-spacing="4">
    ${esc(sc.label)}
  </text>

  <!-- Profile photo (circular, left) -->
  <circle cx="170" cy="340" r="75" fill="#0F172A" stroke="url(#goldGrad)" stroke-width="4"/>
  ${photoDataUri ? `
  <clipPath id="photoClip">
    <circle cx="170" cy="340" r="68"/>
  </clipPath>
  <image x="102" y="272" width="136" height="136"
         xlink:href="${photoDataUri}"
         clip-path="url(#photoClip)"
         preserveAspectRatio="xMidYMid slice"/>
  ` : `
  <text x="170" y="365" font-family="Arial, sans-serif" font-size="70"
        fill="url(#goldGrad)" text-anchor="middle" font-weight="bold">◆</text>
  `}

  <!-- Gold ring animated (outer) -->
  <circle cx="170" cy="340" r="80" fill="none"
          stroke="url(#goldGrad)" stroke-width="2" stroke-dasharray="8 4" opacity="0.6"/>

  <!-- Info box -->
  <rect x="290" y="265" width="${W - 330}" height="220" rx="20"
        fill="#1E293B" fill-opacity="0.7"
        stroke="#FCD34D" stroke-width="2" stroke-opacity="0.5"/>

  <!-- Info lines -->
  <text x="320" y="310" font-family="Arial, sans-serif" font-size="14"
        fill="#94A3B8" letter-spacing="2">USERNAME</text>
  <text x="${W - 60}" y="310" font-family="Arial, sans-serif" font-size="18" font-weight="bold"
        fill="url(#whiteGoldGrad)" text-anchor="end">
    ${esc(username).slice(0, 28)}
  </text>
  <line x1="320" y1="325" x2="${W - 60}" y2="325" stroke="#475569" stroke-width="1"/>

  <text x="320" y="355" font-family="Arial, sans-serif" font-size="14"
        fill="#94A3B8" letter-spacing="2">NAMA</text>
  <text x="${W - 60}" y="355" font-family="Arial, sans-serif" font-size="18" font-weight="bold"
        fill="url(#whiteGoldGrad)" text-anchor="end">
    ${esc(fullName).slice(0, 28)}
  </text>
  <line x1="320" y1="370" x2="${W - 60}" y2="370" stroke="#475569" stroke-width="1"/>

  <text x="320" y="400" font-family="Arial, sans-serif" font-size="14"
        fill="#94A3B8" letter-spacing="2">ROLE</text>
  <text x="${W - 60}" y="400" font-family="Arial, sans-serif" font-size="18" font-weight="bold"
        fill="#FCD34D" text-anchor="end">
    ${esc(roleName).slice(0, 28)}
  </text>
  <line x1="320" y1="415" x2="${W - 60}" y2="415" stroke="#475569" stroke-width="1"/>

  <text x="320" y="445" font-family="Arial, sans-serif" font-size="14"
        fill="#94A3B8" letter-spacing="2">HARGA</text>
  <text x="${W - 60}" y="445" font-family="Arial, sans-serif" font-size="22" font-weight="bold"
        fill="url(#goldGrad)" text-anchor="end">
    ${esc(price)}
  </text>

  <!-- Footer -->
  <text x="${W / 2}" y="${H - 55}" font-family="Arial, sans-serif" font-size="13"
        fill="#64748B" text-anchor="middle" letter-spacing="2">
    ${esc(timestamp || new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }))}
  </text>

  <text x="${W / 2}" y="${H - 30}" font-family="Arial, sans-serif" font-size="12"
        fill="#FCD34D" text-anchor="middle" letter-spacing="4" opacity="0.7">
    ◆ SPARTAX BUILD SYSTEM ◆
  </text>

</svg>`;

        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch (e) {
        console.log("[NOTIF GEN] ERR:", e.message);
        return null;
    }
}

// ═══ SEND NOTIF KE CHANNEL ═══
async function sendBuyRoleNotif(bot, cfg, data) {
    const channelId = cfg.BUY_ROLE_NOTIF_CHANNEL || cfg.NOTIF_CHANNEL;
    if (!channelId || channelId === "-1001234567890") {
        console.log("[NOTIF GEN] channel not set");
        return;
    }

    try {
        const img = await generateBuyRoleNotif(data);
        if (!img) {
            // Fallback text
            await bot.sendMessage(channelId,
                `${statusIcon(data.status)} <b>BUY ROLE ${data.status.toUpperCase()}</b>\n\n` +
                `${I.bulletOut} Role: <b>${data.roleName}</b>\n` +
                `${I.bulletOut} Harga: <b>${data.price}</b>\n` +
                `${I.bulletOut} User: <a href="tg://user?id=${data.userId}">${data.fullName}</a> (${data.username})`,
                { parse_mode: "HTML" });
            return;
        }

        await bot.sendPhoto(channelId, img, {
            caption:
                `${statusIcon(data.status)} <b>BUY ROLE ${data.status.toUpperCase()}</b>\n\n` +
                `${I.bulletOut} Role: <b>${data.roleName}</b>\n` +
                `${I.bulletOut} Harga: <b>${data.price}</b>\n` +
                `${I.bulletOut} User: <a href="tg://user?id=${data.userId}">${data.fullName}</a>`,
            parse_mode: "HTML"
        });

        console.log(`[NOTIF GEN] ✅ sent to ${channelId}`);
    } catch (e) {
        console.log("[NOTIF GEN] send fail:", e.message);
    }
}

// ═══ ICON HELPER ═══
const I = {
    bulletOut: "▪",
    check: "✓",
    cross: "✕",
    clock: "◉"
};

function statusIcon(status) {
    if (status === "success") return I.check;
    if (status === "failed") return I.cross;
    return I.clock;
}

module.exports = {
    generateBuyRoleNotif,
    sendBuyRoleNotif
};

console.log("[NOTIF GENERATOR] module loaded (v1 — gold cartoon)");