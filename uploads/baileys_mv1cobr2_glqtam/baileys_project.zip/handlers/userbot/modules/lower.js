async function handler(userId, client, msg, args) {
    const text = args.join(" ");
    if (!text) return client.sendMessage(msg.message.chatId, { message: "📖 .lower [text]" });
    await client.sendMessage(msg.message.chatId, { message: text.toLowerCase() });
}

module.exports = { command: "lower", handler, description: "Ubah ke huruf kecil", category: "text" };