const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "📉 Top losers..." });
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1", { timeout: 20000 });
        const sorted = (r.data || []).sort((a, b) => (a.price_change_percentage_24h || 0) - (b.price_change_percentage_24h || 0)).slice(0, 10);
        let text = `📉 TOP LOSERS 24H\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        sorted.forEach((c, i) => {
            text += `${i + 1}. ${c.symbol.toUpperCase()} — $${c.current_price?.toLocaleString("id-ID")} (${c.price_change_percentage_24h?.toFixed(2)}%)\n`;
        });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "loser", handler, description: "Top losers 24h", category: "crypto" };