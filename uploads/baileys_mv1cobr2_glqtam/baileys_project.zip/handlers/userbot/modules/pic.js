const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ") || "nature";
    const loading = await client.sendMessage(chatId, { message: "🖼️ Cari foto..." });
    try {
        const r = await axios.get(`https://api.unsplash.com/photos/random?query=${encodeURIComponent(query)}`, {
            headers: { Authorization: "Client-ID demo" }, timeout: 15000
        }).catch(() => null);
        const imgUrl = r?.data?.urls?.regular || `https://source.unsplash.com/1080x1080/?${encodeURIComponent(query)}`;
        const img = await axios.get(imgUrl, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(img.data), caption: `🖼️ ${query}`, forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "pic", handler, description: "Random foto dari Unsplash", category: "media" };