const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ").trim();
    if (!text) return client.sendMessage(chatId, { message: "📖 .tts [text]" });
    const loading = await client.sendMessage(chatId, { message: "🔊 Text to speech..." });
    try {
        const url = `https://text.pollinations.ai/${encodeURIComponent(text.slice(0, 200))}?model=openai-audio&voice=nova`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(r.data),
            attributes: [new (require("telegram").Api.DocumentAttributeAudio)({ duration: 0, title: "TTS", performer: "SpartaX" })],
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "tts", handler, description: "Text to speech", category: "media" };