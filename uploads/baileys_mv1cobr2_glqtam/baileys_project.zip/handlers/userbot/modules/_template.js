// ═══════════════════════════════════════════
// TEMPLATE MODULE USERBOT TELEGRAM
// Copy file ini buat bikin module baru
// Ganti "template" → nama command lu
// ═══════════════════════════════════════════

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");

    if (!text) {
        await client.sendMessage(chatId, { message: "📖 Pakai: .template [text]" });
        return;
    }

    await client.sendMessage(chatId, { message: `Echo: ${text}` });
}

module.exports = {
    command: "template",
    handler,
    description: "Template module userbot",
    category: "general"
};