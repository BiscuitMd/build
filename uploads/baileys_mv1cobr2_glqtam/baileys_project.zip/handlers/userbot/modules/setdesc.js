async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const desc = args.join(" ").trim();
    if (!desc) return client.sendMessage(chatId, { message: "📖 .setdesc [deskripsi]" });
    try {
        await client.invoke(new (require("telegram").Api.channels.EditAbout)({
            channel: chatId,
            about: desc
        }));
        await client.sendMessage(chatId, { message: `✅ Deskripsi grup diubah` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "setdesc", handler, description: "Ubah deskripsi grup", category: "admin" };