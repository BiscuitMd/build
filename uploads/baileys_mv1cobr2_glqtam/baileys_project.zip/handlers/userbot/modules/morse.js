const MORSE = { A:".-",B:"-...",C:"-.-.",D:"-..",E:".",F:"..-.",G:"--.",H:"....",I:"..",J:".---",K:"-.-",L:".-..",M:"--",N:"-.",O:"---",P:".--.",Q:"--.-",R:".-.",S:"...",T:"-",U:"..-",V:"...-",W:".--",X:"-..-",Y:"-.--",Z:"--..","0":"-----","1":".----","2":"..---","3":"...--","4":"....-","5":".....","6":"-....","7":"--...","8":"---..","9":"----.",".":".-.-.-",",":"--..--","?":"..--..","!":"-.-.--"," ":"/" };
const REVERSE = Object.fromEntries(Object.entries(MORSE).map(([k,v]) => [v,k]));

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mode = args[0]?.toLowerCase();
    const text = args.slice(1).join(" ");
    if (!mode || !text) return client.sendMessage(chatId, { message: "📖 .morse [encode/decode] [text]" });
    if (mode === "encode") {
        const out = text.toUpperCase().split("").map(c => MORSE[c] || c).join(" ");
        return client.sendMessage(chatId, { message: `📡 ${out}` });
    }
    if (mode === "decode") {
        const out = text.split(" ").map(c => REVERSE[c] || c).join("");
        return client.sendMessage(chatId, { message: `📡 ${out}` });
    }
    await client.sendMessage(chatId, { message: "❌ Mode harus encode/decode" });
}

module.exports = { command: "morse", handler, description: "Encode/decode morse", category: "text" };