const crypto = require("crypto");

async function handler(userId, client, msg, args) {
    const text = args.join(" ");
    if (!text) return client.sendMessage(msg.message.chatId, { message: "📖 .hash [text]" });
    const md5 = crypto.createHash("md5").update(text).digest("hex");
    const sha1 = crypto.createHash("sha1").update(text).digest("hex");
    const sha256 = crypto.createHash("sha256").update(text).digest("hex");
    await client.sendMessage(msg.message.chatId, {
        message: `🔒 HASH\n\n▸ MD5:\n\`${md5}\`\n\n▸ SHA1:\n\`${sha1}\`\n\n▸ SHA256:\n\`${sha256}\``
    });
}

module.exports = { command: "hash", handler, description: "Hash text", category: "tools" };