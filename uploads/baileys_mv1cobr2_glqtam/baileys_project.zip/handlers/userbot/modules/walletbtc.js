const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const address = args[0];
    if (!address) return client.sendMessage(chatId, { message: "📖 .walletbtc [BTC address]" });

    const loading = await client.sendMessage(chatId, { message: "🔍 Lookup wallet BTC..." });
    try {
        const [balance, txs] = await Promise.all([
            axios.get(`https://blockchain.info/q/addressbalance/${address}`, { timeout: 15000, responseType: "text" }).catch(() => null),
            axios.get(`https://blockchain.info/rawaddr/${address}?limit=5`, { timeout: 15000 }).catch(() => null)
        ]);

        let text = `₿ BTC WALLET\n\n━━━━━━━━━━━━━━━━━━━━\n▸ Address: ${address}\n`;
        if (balance?.data) {
            text += `▸ Balance: ${(parseInt(balance.data) / 1e8).toFixed(8)} BTC\n`;
        }
        if (txs?.data) {
            text += `▸ Total txs: ${txs.data.n_tx}\n`;
            text += `▸ Received: ${(txs.data.total_received / 1e8).toFixed(8)} BTC\n`;
            text += `▸ Sent: ${(txs.data.total_sent / 1e8).toFixed(8)} BTC\n`;
        }
        text += `▸ Explorer: https://blockchain.info/address/${address}\n━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "walletbtc", handler, description: "Lookup wallet BTC", category: "crypto" };