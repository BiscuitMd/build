const crypto = require("crypto");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    if (cmd === "rsa") {
        const bits = parseInt(args[1]) || 2048;
        if (bits > 4096) return client.sendMessage(chatId, { message: "✕ Max 4096 bits" });

        const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
            modulusLength: bits,
            publicKeyEncoding: { type: "spki", format: "pem" },
            privateKeyEncoding: { type: "pkcs8", format: "pem" }
        });

        await client.sendMessage(chatId, { message: "◆ RSA " + bits + " PUBLIC KEY\n\n<pre>" + publicKey + "</pre>", parseMode: "html" });
        await client.sendMessage(chatId, { message: "◆ RSA " + bits + " PRIVATE KEY\n\n<pre>" + privateKey + "</pre>", parseMode: "html" });
        return;
    }

    if (cmd === "aes") {
        const key = crypto.randomBytes(32).toString("hex");
        const iv = crypto.randomBytes(16).toString("hex");
        return client.sendMessage(chatId, {
            message: "◆ AES-256 KEY\n\n├─────────────────\n│ KEY → <code>" + key + "</code>\n│ IV  → <code>" + iv + "</code>\n╰─────────────────",
            parseMode: "html"
        });
    }

    if (cmd === "uuid") {
        const uuid = crypto.randomUUID();
        return client.sendMessage(chatId, { message: "◆ UUID\n\n<code>" + uuid + "</code>", parseMode: "html" });
    }

    if (cmd === "token") {
        const len = Math.min(parseInt(args[1]) || 32, 256);
        const token = crypto.randomBytes(Math.ceil(len / 2)).toString("hex").slice(0, len);
        return client.sendMessage(chatId, { message: "◆ TOKEN (" + len + " chars)\n\n<code>" + token + "</code>", parseMode: "html" });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚿  GENKEY        │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .genkey rsa [bits]\n" +
        "│ ▪ .genkey aes\n" +
        "│ ▪ .genkey uuid\n" +
        "│ ▪ .genkey token [len]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "genkey",
    handler,
    description: "Generate key RSA/AES/UUID/token",
    category: "security"
};