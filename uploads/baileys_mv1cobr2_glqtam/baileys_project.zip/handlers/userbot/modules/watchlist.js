const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_watchlist.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const coin = args[1]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || [];

    if (cmd === "add" && coin) {
        if (!db[userId].includes(coin)) {
            db[userId].push(coin);
            write(db);
            return client.sendMessage(chatId, { message: `✅ ${coin} ditambah ke watchlist` });
        }
        return client.sendMessage(chatId, { message: `⚠️ ${coin} udah ada` });
    }

    if (cmd === "del" && coin) {
        db[userId] = db[userId].filter(c => c !== coin);
        write(db);
        return client.sendMessage(chatId, { message: `✅ ${coin} dihapus` });
    }

    if (cmd === "list" || !cmd) {
        const list = db[userId];
        if (list.length === 0) return client.sendMessage(chatId, { message: "📋 Watchlist kosong\n\nPakai: .watchlist add [coin]" });
        return client.sendMessage(chatId, { message: `📋 Watchlist:\n${list.map((c, i) => `${i + 1}. ${c}`).join("\n")}` });
    }

    await client.sendMessage(chatId, { message: "📖 .watchlist add [coin] | del [coin] | list" });
}

module.exports = { command: "watchlist", handler, description: "Watchlist crypto", category: "crypto" };