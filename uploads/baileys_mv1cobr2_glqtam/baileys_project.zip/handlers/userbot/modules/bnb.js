const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/simple/price?ids=binancecoin&vs_currencies=usd,idr&include_24hr_change=true", { timeout: 15000 });
        const d = r.data.binancecoin;
        await client.sendMessage(chatId, {
            message: `🟡 BNB\n\n▸ USD: $${d.usd?.toLocaleString("id-ID")}\n▸ IDR: Rp${d.idr?.toLocaleString("id-ID")}\n▸ 24h: ${d.usd_24h_change?.toFixed(2)}%`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "bnb", handler, description: "Harga BNB", category: "crypto" };