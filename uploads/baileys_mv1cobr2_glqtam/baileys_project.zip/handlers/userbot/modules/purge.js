async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    const count = Math.min(parseInt(args[0]) || 10, 100);
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply pesan awal + .purge [jumlah]" });

    try {
        const msgs = await client.getMessages(chatId, { limit: count, minId: replyTo - 1 });
        const ids = msgs.map(m => m.id).filter(id => id !== msg.message.id);
        await client.deleteMessages(chatId, ids, { revoke: true });
        await client.deleteMessages(chatId, [msg.message.id], { revoke: true }).catch(() => {});
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "purge", handler, description: "Hapus banyak pesan", category: "admin" };