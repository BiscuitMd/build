const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .stikerpack" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        await client.sendFile(chatId, {
            file: buf,
            attributes: [new Api.DocumentAttributeSticker({
                alt: "🤖",
                stickerset: new Api.InputStickerSetEmpty()
            })]
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "stikerpack", handler, description: "Bikin stiker dari foto", category: "media" };