const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const username = args[0];
    if (!username) return client.sendMessage(chatId, { message: "📖 .userrecon [username]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Recon user "${username}"...` });

    try {
        const platforms = [
            { name: "GitHub", url: `https://api.github.com/users/${username}` },
            { name: "Reddit", url: `https://www.reddit.com/user/${username}/about.json` },
            { name: "GitLab", url: `https://gitlab.com/api/v4/users?username=${username}` }
        ];

        const results = [];
        for (const p of platforms) {
            try {
                const r = await axios.get(p.url, {
                    timeout: 10000,
                    headers: { "User-Agent": "SpartaX-Bot" },
                    validateStatus: () => true
                });
                if (r.status === 200) {
                    const data = r.data;
                    if (p.name === "GitHub" && data.login) {
                        results.push(`✅ GitHub: ${data.login} | Repos: ${data.public_repos} | Followers: ${data.followers}`);
                    } else if (p.name === "Reddit" && data.data?.name) {
                        results.push(`✅ Reddit: ${data.data.name} | Karma: ${data.data.total_karma}`);
                    } else if (p.name === "GitLab" && Array.isArray(data) && data.length > 0) {
                        results.push(`✅ GitLab: ${data[0].username} | Name: ${data[0].name}`);
                    } else {
                        results.push(`❌ ${p.name}: NotFound`);
                    }
                } else {
                    results.push(`❌ ${p.name}: HTTP ${r.status}`);
                }
            } catch {
                results.push(`❌ ${p.name}: Error`);
            }
        }

        const text = `🔍 USER RECON: ${username}\n\n${results.join("\n")}`;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "userrecon", handler, description: "Recon username di API publik", category: "osint" };