const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const prompt = args.join(" ").trim();
    if (!prompt) return client.sendMessage(chatId, { message: "📖 .imgai [prompt] — AI Image HD" });
    const loading = await client.sendMessage(chatId, { message: "🎨 Generate HD image..." });
    try {
        const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt + ", ultra hd, detailed, 4k, masterpiece")}?width=1280&height=1280&nologo=true&model=flux&seed=${Date.now()}`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 120000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(r.data),
            caption: `🎨 HD: ${prompt.slice(0, 200)}`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "imgai", handler, description: "Generate HD image", category: "ai" };