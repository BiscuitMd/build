const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = null;
    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    } else if (args[0]) targetId = args[0];

    if (!targetId) return client.sendMessage(chatId, { message: "📖 Reply user + .mute" });

    try {
        await client.invoke(new Api.channels.EditBanned({
            channel: chatId,
            participant: targetId,
            bannedRights: new Api.ChatBannedRights({
                untilDate: 0,
                sendMessages: true,
                sendMedia: true,
                sendStickers: true,
                sendGifs: true,
                sendGames: true,
                sendInline: true,
                embedLinks: true
            })
        }));
        await client.sendMessage(chatId, { message: `🔇 User ${targetId} di-mute` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "mute", handler, description: "Mute user di group", category: "admin" };