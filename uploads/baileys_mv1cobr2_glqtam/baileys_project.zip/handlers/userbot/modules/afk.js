const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_afk.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || { afk: false, reason: "", since: 0, autoReply: true };

    if (cmd === "on" || !cmd) {
        const reason = args.slice(1).join(" ") || "AFK";
        db[userId].afk = true;
        db[userId].reason = reason;
        db[userId].since = Date.now();
        write(db);

        return client.sendMessage(chatId, {
            message:
                "✓ AFK MODE ON\n\n" +
                "├─────────────────\n" +
                "│ ▪ Alasan   → " + reason + "\n" +
                "│ ▪ Sejak    → " + new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + "\n" +
                "│ ▪ AutoRP   → " + (db[userId].autoReply ? "ON" : "OFF") + "\n" +
                "╰─────────────────"
        });
    }

    if (cmd === "off") {
        db[userId].afk = false;
        db[userId].reason = "";
        db[userId].since = 0;
        write(db);

        return client.sendMessage(chatId, { message: "✓ AFK OFF — Welcome back!" });
    }

    if (cmd === "set") {
        const reason = args.slice(1).join(" ");
        if (!reason) return client.sendMessage(chatId, { message: "▸ .afk set [alasan]" });
        db[userId].reason = reason;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Alasan AFK: " + reason });
    }

    if (cmd === "autoreply") {
        const v = args[1]?.toLowerCase();
        if (!["on", "off"].includes(v)) return client.sendMessage(chatId, { message: "▸ .afk autoreply on/off" });
        db[userId].autoReply = v === "on";
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-reply: " + v.toUpperCase() });
    }

    if (cmd === "status" || !cmd) {
        const d = db[userId];
        const dur = d.afk && d.since ? Math.floor((Date.now() - d.since) / 1000) : 0;

        const t =
            "╭───────────────────╮\n" +
            "│   ◇  AFK MODE      │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ Status    → " + (d.afk ? "ON" : "OFF") + "\n" +
            "│ ▪ Alasan    → " + (d.reason || "-") + "\n" +
            "│ ▪ Sejak     → " + (d.afk ? Math.floor(dur / 60) + "m " + (dur % 60) + "s lalu" : "-") + "\n" +
            "│ ▪ AutoRP    → " + (d.autoReply ? "ON" : "OFF") + "\n" +
            "├───────────────────\n" +
            "│ ◆ COMMANDS\n" +
            "├───────────────────\n" +
            "│ ▪ .afk on [alasan]\n" +
            "│ ▪ .afk off\n" +
            "│ ▪ .afk set [alasan]\n" +
            "│ ▪ .afk autoreply on/off\n" +
            "│ ▪ .afk status\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: t });
    }

    return client.sendMessage(chatId, { message: "▸ .afk on/off/set/autoreply/status" });
}

async function handleIncoming(userId, client, msg) {
    try {
        const db = read();
        const data = db[userId];
        if (!data || !data.afk || !data.autoReply) return;

        const m = msg.message;
        const text = m.message || m.text || "";
        if (!text || text.startsWith(".")) return;
        if (m.out) return;

        const senderId = m.senderId?.toString() || "";
        if (!senderId) return;

        if (senderId === userId) return;

        const dur = data.since ? Math.floor((Date.now() - data.since) / 1000) : 0;
        const durText = dur < 60 ? dur + "s" : Math.floor(dur / 60) + "m";

        const reply =
            "🌙 AFK — " + (data.reason || "sedang tidak tersedia") + "\n\n" +
            "▪ Sejak: " + durText + " lalu\n" +
            "▪ Nanti dibalas kalau udah online";

        await new Promise(r => setTimeout(r, Math.floor(Math.random() * 1500) + 800));

        try {
            await client.sendMessage(m.chatId || m.peerId, { message: reply, replyTo: m.id });
        } catch {
            await client.sendMessage(m.chatId || m.peerId, { message: reply });
        }

        console.log("[AFK] replied to " + senderId);
    } catch (e) {
        console.log("[AFK] err: " + e.message.slice(0, 100));
    }
}

module.exports = {
    command: "afk",
    handler,
    handleIncoming,
    description: "Mode AFK — auto-respon saat tidur",
    category: "tools"
};