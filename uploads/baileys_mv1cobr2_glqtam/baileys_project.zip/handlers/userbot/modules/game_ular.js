const core = require("./gamecore");

const SNAKES = { 17: 7, 54: 34, 62: 19, 64: 60, 87: 24, 93: 73, 95: 75, 98: 79 };
const LADDERS = { 1: 38, 4: 14, 9: 31, 21: 42, 28: 84, 36: 44, 51: 67, 71: 91, 80: 100 };

function renderBoard(pos) {
    let cells = "";
    const size = 55;
    const offset = 100;

    for (let r = 0; r < 10; r++) {
        for (let c = 0; c < 10; c++) {
            const realRow = 9 - r;
            const realCol = realRow % 2 === 0 ? c : 9 - c;
            const num = realRow * 10 + realCol + 1;

            const x = offset + c * size;
            const y = offset + r * size;

            let fill = (r + c) % 2 === 0 ? "#1e293b" : "#334155";
            if (SNAKES[num]) fill = "#7f1d1d";
            if (LADDERS[num]) fill = "#14532d";

            cells += `<rect x="${x}" y="${y}" width="${size}" height="${size}" fill="${fill}" stroke="#000" stroke-width="1"/>`;
            cells += `<text x="${x + 5}" y="${y + 15}" font-family="Arial" font-size="10" fill="#94a3b8">${num}</text>`;

            if (pos[0] === num) {
                cells += `<circle cx="${x + size / 2}" cy="${y + size / 2}" r="20" fill="#3b82f6" stroke="#fff" stroke-width="2"/>`;
                cells += `<text x="${x + size / 2}" y="${y + size / 2 + 4}" font-family="Arial" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">P1</text>`;
            }
            if (pos[1] === num) {
                cells += `<circle cx="${x + size / 2}" cy="${y + size / 2}" r="20" fill="#ef4444" stroke="#fff" stroke-width="2"/>`;
                cells += `<text x="${x + size / 2}" y="${y + size / 2 + 4}" font-family="Arial" font-size="14" font-weight="900" fill="#fff" text-anchor="middle">P2</text>`;
            }
        }
    }

    return cells;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderBoard(room.state.pos), "🐍 ULAR TANGGA 🪜", "green");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";
    const myUsername = me?.username || null;

    if (cmd === "start") {
        const room = core.createRoom("ular", userId, myName, myUsername, {
            state: { pos: [1, 1], history: [] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        const caption =
            "🐍 <b>ULAR TANGGA</b> 🪜\n\n" +
            "├─────────────────\n" +
            "│ 🆔 Room   → <code>" + room.id + "</code>\n" +
            "│ 👤 Host   → " + myName + "\n" +
            "├─────────────────\n" +
            "│ <code>.ular join " + room.id + "</code>\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .ular join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, myUsername);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        const caption =
            "🐍 <b>ULAR TANGGA START!</b> 🪜\n\n" +
            "├─────────────────\n" +
            "│ 👤 P1 → " + r.room.players[0].name + " 🔵\n" +
            "│ 👤 P2 → " + r.room.players[1].name + " 🔴\n" +
            "├─────────────────\n" +
            "│ 🎯 Turn → " + r.room.players[0].name + "\n" +
            "│ 📖 Roll: <code>.ular roll</code>\n" +
            "╰─────────────────";

        await sendGame(client, chatId, r.room, caption);
        return;
    }

    if (cmd === "roll") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "ular" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Lu ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const myIdx = room.turn % 2;
        const dice = Math.floor(Math.random() * 6) + 1;
        let newPos = room.state.pos[myIdx] + dice;

        let eventText = "🎲 Roll: " + dice;
        if (newPos > 100) newPos = 100;

        if (SNAKES[newPos]) {
            eventText += "\n🐍 Kena ular! Turun ke " + SNAKES[newPos];
            newPos = SNAKES[newPos];
        } else if (LADDERS[newPos]) {
            eventText += "\n🪜 Naik tangga! Ke " + LADDERS[newPos];
            newPos = LADDERS[newPos];
        }

        room.state.pos[myIdx] = newPos;
        room.state.history.push({ player: myIdx, dice, to: newPos, at: Date.now() });

        if (newPos >= 100) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🎉 " + currentPlayer.name + " sampe finish!");
            return core.checkWinAndReward(room, currentPlayer.id, currentPlayer.name, client, chatId);
        }

        room.turn++;
        core.saveRoom(room);

        const caption =
            "🎲 <b>ULAR TANGGA</b>\n\n" +
            "├─────────────────\n" +
            "│ " + currentPlayer.name + "\n" +
            "│ " + eventText + "\n" +
            "│ Posisi  → " + newPos + "/100\n" +
            "├─────────────────\n" +
            "│ 🎯 Next → " + room.players[room.turn % 2].name + "\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "🐍 <b>ULAR TANGGA</b> 🪜\n\n" +
            "├─────────────────\n" +
            "│ ▪ .ular start\n" +
            "│ ▪ .ular join [KODE]\n" +
            "│ ▪ .ular roll\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "ular",
    handler,
    description: "Ular tangga PVP",
    category: "game",
    commands: ["snakeladder", "ulartangga"]
};