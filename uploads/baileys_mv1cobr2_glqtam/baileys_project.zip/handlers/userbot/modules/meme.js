const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://meme-api.com/gimme", { timeout: 15000 });
        const m = r.data;
        const img = await axios.get(m.url, { responseType: "arraybuffer", timeout: 20000 });
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: `😂 ${m.title}\n▸ r/${m.subreddit} | ⬆️ ${m.ups}`,
            forceDocument: false
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "meme", handler, description: "Random meme dari Reddit", category: "fun" };