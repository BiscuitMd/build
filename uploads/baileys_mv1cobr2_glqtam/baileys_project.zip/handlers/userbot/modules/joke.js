const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://official-joke-api.appspot.com/random_joke", { timeout: 15000 });
        const j = r.data;
        await client.sendMessage(chatId, {
            message: `😂 ${j.setup}\n\n${j.punchline}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "joke", handler, description: "Random joke", category: "fun" };