async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const senderId = msg.message.senderId;
    const replyTo = msg.message.replyTo?.replyToMsgId;

    let text = `🆔 INFO\n\n▸ Chat ID: ${chatId}\n▸ Sender ID: ${senderId}`;
    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) text += `\n▸ Reply User ID: ${msgs[0].senderId}`;
    }
    await client.sendMessage(chatId, { message: text });
}

module.exports = { command: "id", handler, description: "Get chat/user ID", category: "info" };