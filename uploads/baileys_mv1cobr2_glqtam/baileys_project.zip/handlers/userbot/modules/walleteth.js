const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const address = args[0];
    if (!address) return client.sendMessage(chatId, { message: "📖 .walleteth [ETH address]\nButuh Etherscan API key" });

    const loading = await client.sendMessage(chatId, { message: "🔍 Lookup wallet ETH..." });
    try {
        const text =
            `Ξ ETH WALLET\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Address: ${address}\n` +
            `▸ Explorer: https://etherscan.io/address/${address}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Cek manual di explorer karena Etherscan butuh API key.</i>`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text, parseMode: "html" });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "walleteth", handler, description: "Lookup wallet ETH", category: "crypto" };