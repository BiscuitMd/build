const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ").trim();
    if (!query) return client.sendMessage(chatId, { message: "📖 .lyrics [judul - artist]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Cari lyrics..." });
    try {
        let title = query, artist = "";
        if (query.includes(" - ")) {
            [title, artist] = query.split(" - ").map(s => s.trim());
        } else if (query.includes(" by ")) {
            [title, artist] = query.split(" by ").map(s => s.trim());
        }
        if (!artist) throw new Error("Format: judul - artist");
        const r = await axios.get(`https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`, { timeout: 20000 });
        const lyrics = r.data?.lyrics;
        if (!lyrics) throw new Error("Lyrics ga ditemukan");
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: `🎵 ${title} — ${artist}\n\n${lyrics.slice(0, 4000)}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "lyrics", handler, description: "Cari lyrics lagu", category: "download" };