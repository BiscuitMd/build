const COMPLIMENTS = [
    "Lu tuh orang paling keren yang pernah gua kenal.",
    "Senyum lu bikin hari gua cerah.",
    "Lu tuh pinter banget, masa depan cerah.",
    "Hati lu tuh emas, jarang ada orang kayak lu.",
    "Lu tuh kayak matahari — selalu bikin hangat.",
    "Gaya lu keren, percaya diri lu tinggi.",
    "Lu tuh inspirasi banyak orang tanpa sadar.",
    "Kebaikan lu bakal balik ke lu berkali-kali.",
    "Lu tuh salah satu orang paling tulus yang gua kenal.",
    "Jangan pernah berubah, lu udah sempurna."
];

async function handler(userId, client, msg, args) {
    const c = COMPLIMENTS[Math.floor(Math.random() * COMPLIMENTS.length)];
    await client.sendMessage(msg.message.chatId, { message: `💐 ${c}` });
}

module.exports = { command: "compliment", handler, description: "Pujian random", category: "fun" };