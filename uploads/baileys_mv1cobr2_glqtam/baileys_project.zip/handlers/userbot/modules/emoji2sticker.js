const axios = require("axios");
const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const emoji = args[0];
    if (!emoji) return client.sendMessage(chatId, { message: "📖 .emoji2sticker 😀" });
    const loading = await client.sendMessage(chatId, { message: "🎨 Bikin stiker..." });
    try {
        const url = `https://emojicdn.elk.sh/${encodeURIComponent(emoji)}?style=apple`;
        const r = await axios.get(url, { responseType: "arraybuffer", timeout: 15000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(r.data),
            attributes: [new Api.DocumentAttributeSticker({
                alt: emoji,
                stickerset: new Api.InputStickerSetEmpty()
            })]
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "emoji2sticker", handler, description: "Emoji jadi stiker", category: "media" };