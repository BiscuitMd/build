const sharp = require("sharp");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    const deg = parseInt(args[0]) || 90;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .rotate [derajat]" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const rotated = await sharp(buf).rotate(deg).jpeg({ quality: 90 }).toBuffer();
        await client.sendFile(chatId, { file: rotated, caption: `🔄 Rotated ${deg}°`, forceDocument: false });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "rotate", handler, description: "Rotate gambar", category: "media" };