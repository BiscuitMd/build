const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const domain = args[0];
    if (!domain) return client.sendMessage(chatId, { message: "📖 .subdomain [domain.com]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Cari subdomain...` });

    try {
        const r = await axios.get(`https://api.hackertarget.com/hostsearch/?q=${domain}`, { timeout: 30000 });
        const lines = String(r.data).split("\n").filter(l => l.includes(","));
        if (lines.length === 0) throw new Error("Gaada subdomain / limit");

        const subs = lines.slice(0, 50).map(l => l.split(",")[0]);
        const text =
            `🔍 SUBDOMAIN ${domain}\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Total: ${lines.length}\n` +
            `▸ Sample (50 pertama):\n` +
            subs.map(s => `▸ ${s}`).join("\n");

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "subdomain", handler, description: "Enum subdomain", category: "osint" };