const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_alertlog.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || [];

    if (cmd === "add") {
        const text = args.slice(1).join(" ");
        if (!text) return client.sendMessage(chatId, { message: "▸ .alertlog add [pesan]" });

        db[userId].push({ text, at: Date.now(), read: false });
        write(db);

        return client.sendMessage(chatId, { message: "✓ Alert disimpan" });
    }

    if (cmd === "list" || !cmd) {
        const list = db[userId].slice(-15).reverse();
        if (!list.length) return client.sendMessage(chatId, { message: "▸ Log kosong\n\nPakai: .alertlog add [pesan]" });

        let out = "";
        list.forEach((a, i) => {
            const t = new Date(a.at).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
            out += "│ " + (i + 1) + ". [" + t + "]\n";
            out += "│   → " + a.text.slice(0, 40) + "\n";
        });

        const text =
            "╭───────────────────╮\n" +
            "│   ◉  ALERTLOG      │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ Total: " + db[userId].length + "\n" +
            "├───────────────────\n" +
            out +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: text });
    }

    if (cmd === "clear") {
        db[userId] = [];
        write(db);
        return client.sendMessage(chatId, { message: "✓ Log dihapus" });
    }

    return client.sendMessage(chatId, { message: "▸ .alertlog add/list/clear" });
}

module.exports = {
    command: "alertlog",
    handler,
    description: "Log alert/event pribadi",
    category: "monitor"
};