const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const ip = args[0];
    if (!ip) return client.sendMessage(chatId, { message: "📖 .ip [ip_address]" });
    try {
        const r = await axios.get(`http://ip-api.com/json/${ip}`, { timeout: 15000 });
        const d = r.data;
        if (d.status !== "success") throw new Error(d.message || "Invalid IP");
        await client.sendMessage(chatId, {
            message:
                `🌍 IP INFO\n\n` +
                `▸ IP: ${d.query}\n` +
                `▸ Negara: ${d.country} (${d.countryCode})\n` +
                `▸ Region: ${d.regionName}\n` +
                `▸ Kota: ${d.city}\n` +
                `▸ ISP: ${d.isp}\n` +
                `▸ Lat/Lon: ${d.lat}, ${d.lon}\n` +
                `▸ Timezone: ${d.timezone}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "ip", handler, description: "Info IP address", category: "tools" };