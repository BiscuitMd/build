const ROASTS = [
    "Muka lu tuh kayak hasil photoshop yang gagal.",
    "Otak lu lebih kosong dari dompet akhir bulan.",
    "Kalo jelek itu penyakit, lu udah stadium 5.",
    "Lu tuh kayak wifi tetangga — kenceng tapi ga bisa diakses.",
    "Cermin aja malu ngeliat muka lu.",
    "Lu tuh kayak film horror — takut ditonton.",
    "Gaya lu bagus, tapi sayang mukanya.",
    "Kalo kepintaran itu uang, lu udah bangkrut.",
    "Lu tuh kayak peta — banyak jalan buntu.",
    "Chat lu kayak spam — ga ada yang mau baca."
];

async function handler(userId, client, msg, args) {
    const r = ROASTS[Math.floor(Math.random() * ROASTS.length)];
    await client.sendMessage(msg.message.chatId, { message: `🔥 ROAST:\n\n${r}` });
}

module.exports = { command: "roast", handler, description: "Roast random", category: "fun" };