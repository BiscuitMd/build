const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/global", { timeout: 15000 });
        const d = r.data?.data;
        await client.sendMessage(chatId, {
            message:
                `💹 GLOBAL MARKET\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Total Market Cap: $${(d.total_market_cap.usd / 1e12).toFixed(3)}T\n` +
                `▸ 24h Change: ${d.market_cap_change_percentage_24h_usd?.toFixed(2)}%\n` +
                `▸ Total Volume: $${(d.total_volume.usd / 1e9).toFixed(2)}B\n` +
                `▸ Active Coins: ${d.active_cryptocurrencies}\n` +
                `▸ Markets: ${d.markets}\n` +
                `━━━━━━━━━━━━━━━━━━━━`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "marketcap", handler, description: "Global market cap crypto", category: "crypto" };