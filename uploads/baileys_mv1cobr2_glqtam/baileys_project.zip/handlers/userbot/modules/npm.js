const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const pkg = args[0];
    if (!pkg) return client.sendMessage(chatId, { message: "📖 .npm [package-name]" });
    try {
        const r = await axios.get(`https://registry.npmjs.org/${pkg}`, { timeout: 15000 });
        const d = r.data;
        const latest = d["dist-tags"]?.latest;
        await client.sendMessage(chatId, {
            message:
                `📦 NPM: ${pkg}\n\n` +
                `▸ Versi terbaru: ${latest}\n` +
                `▸ Deskripsi: ${d.description || "-"}\n` +
                `▸ Author: ${d.author?.name || "-"}\n` +
                `▸ Homepage: ${d.homepage || "-"}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "npm", handler, description: "Info npm package", category: "info" };