async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply video/voice + .tomp3" });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const { Api } = require("telegram");
        await client.sendFile(chatId, {
            file: buf,
            attributes: [new Api.DocumentAttributeAudio({ duration: 0, title: "Audio", performer: "Userbot" })],
            forceDocument: false
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "tomp3", handler, description: "Convert video/voice ke audio", category: "media" };