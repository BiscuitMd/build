const https = require("https");
const { URL } = require("url");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .ssl [domain.com]" });

    const loading = await client.sendMessage(chatId, { message: `🔒 Check SSL...` });

    try {
        const hostname = url.replace(/^https?:\/\//, "").split("/")[0];
        const cert = await new Promise((resolve, reject) => {
            const req = https.request({ host: hostname, port: 443, method: "GET", rejectUnauthorized: false }, (res) => {
                resolve(res.socket.getPeerCertificate());
            });
            req.on("error", reject);
            req.end();
        });

        if (!cert || !cert.subject) throw new Error("Ga bisa ambil cert");

        const text =
            `🔒 SSL INFO: ${hostname}\n\n` +
            `▸ Subject: ${cert.subject.CN || "-"}\n` +
            `▸ Issuer: ${cert.issuer.O || "-"} (${cert.issuer.CN || "-"})\n` +
            `▸ Valid from: ${cert.valid_from}\n` +
            `▸ Valid to: ${cert.valid_to}\n` +
            `▸ Serial: ${cert.serialNumber}\n` +
            `▸ Fingerprint: ${cert.fingerprint}\n` +
            `▸ SAN: ${(cert.subjectaltname || "").split(", ").slice(0, 10).join(", ")}`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "ssl", handler, description: "Info SSL certificate", category: "osint" };