async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .mock [text]" });
    const mocked = text.split("").map((c, i) => i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()).join("");
    await client.sendMessage(chatId, { message: mocked });
}

module.exports = { command: "mock", handler, description: "Mocking text", category: "fun" };