const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const coin = args[0]?.toLowerCase();
    const days = args[1] || "7";
    if (!coin) return client.sendMessage(chatId, { message: "📖 .chart [coin] [days=7]\nContoh: .chart bitcoin 7" });

    const loading = await client.sendMessage(chatId, { message: `📈 Chart ${coin} ${days}d...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/coins/${coin}/market_chart?vs_currency=usd&days=${days}`, { timeout: 20000 });
        const prices = r.data?.prices || [];
        if (prices.length === 0) throw new Error("No data");

        const first = prices[0][1];
        const last = prices[prices.length - 1][1];
        const change = ((last - first) / first * 100).toFixed(2);
        const emoji = change >= 0 ? "🟢" : "🔴";

        // Chart pake quickchart
        const labels = prices.map((p, i) => i % Math.max(1, Math.floor(prices.length / 10)) === 0 ? new Date(p[0]).toISOString().slice(5, 10) : "");
        const values = prices.map(p => p[1]);
        const chartConfig = {
            type: "line",
            data: { labels, datasets: [{ label: `${coin.toUpperCase()} Price (USD)`, data: values, borderColor: change >= 0 ? "#10B981" : "#EF4444", backgroundColor: change >= 0 ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)", fill: true, tension: 0.3, pointRadius: 0 }] },
            options: { plugins: { legend: { labels: { color: "white" } } }, scales: { x: { ticks: { color: "white" }, grid: { color: "rgba(255,255,255,0.1)" } }, y: { ticks: { color: "white" }, grid: { color: "rgba(255,255,255,0.1)" } } } }
        };
        const chartUrl = `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify(chartConfig))}&w=800&h=400&bkg=%231E293B`;

        const img = await axios.get(chartUrl, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: `📈 ${coin.toUpperCase()} (${days}d)\n▸ Current: $${last.toLocaleString("id-ID")}\n▸ Change: ${emoji} ${change}%`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "chart", handler, description: "Chart harga crypto", category: "crypto" };