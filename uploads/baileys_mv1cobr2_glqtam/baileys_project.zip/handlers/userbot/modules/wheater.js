const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const city = args.join(" ").trim();
    if (!city) return client.sendMessage(chatId, { message: "📖 .weather [kota]" });

    try {
        const geo = await axios.get(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1`, { timeout: 15000 });
        const loc = geo.data?.results?.[0];
        if (!loc) throw new Error("Kota ga ditemukan");

        const w = await axios.get(`https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=temperature_2m,weather_code,wind_speed_10m`, { timeout: 15000 });
        const c = w.data.current;

        await client.sendMessage(chatId, {
            message: `🌤️ CUACA ${loc.name.toUpperCase()}\n\n▸ Suhu: ${c.temperature_2m}°C\n▸ Angin: ${c.wind_speed_10m} km/h\n▸ Kode cuaca: ${c.weather_code}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "weather", handler, description: "Cek cuaca", category: "tools" };