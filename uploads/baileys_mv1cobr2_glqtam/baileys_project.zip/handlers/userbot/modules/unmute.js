const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = null;
    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    } else if (args[0]) targetId = args[0];

    if (!targetId) return client.sendMessage(chatId, { message: "📖 Reply user + .unmute" });

    try {
        await client.invoke(new Api.channels.EditBanned({
            channel: chatId,
            participant: targetId,
            bannedRights: new Api.ChatBannedRights({ untilDate: 0 })
        }));
        await client.sendMessage(chatId, { message: `🔊 User ${targetId} di-unmute` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "unmute", handler, description: "Unmute user", category: "admin" };