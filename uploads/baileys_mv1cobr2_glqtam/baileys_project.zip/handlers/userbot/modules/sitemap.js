const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .sitemap [domain.com]" });

    const domain = url.startsWith("http") ? url : `https://${url}`;
    const loading = await client.sendMessage(chatId, { message: `🗺️ Baca sitemap...` });

    try {
        const r = await axios.get(`${domain}/sitemap.xml`, { timeout: 15000, validateStatus: () => true });
        if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
        const urls = String(r.data).match(/<loc>(.*?)<\/loc>/g)?.map(u => u.replace(/<\/?loc>/g, "")) || [];
        const text = `🗺️ SITEMAP ${domain}\n\n▸ Total URL: ${urls.length}\n\n▸ 30 sample:\n${urls.slice(0, 30).join("\n")}`;
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "sitemap", handler, description: "Baca sitemap.xml", category: "osint" };