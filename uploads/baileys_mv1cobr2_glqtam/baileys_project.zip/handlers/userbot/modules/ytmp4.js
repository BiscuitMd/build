const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ").trim();
    if (!query) return client.sendMessage(chatId, { message: "📖 .ytmp4 [judul/url]" });
    const loading = await client.sendMessage(chatId, { message: "⏳ Cari video..." });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(query)}`, { timeout: 40000 });
        const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.download;
        if (!url) throw new Error("No URL");
        const v = await axios.get(url, { responseType: "arraybuffer", timeout: 180000, maxContentLength: 50 * 1024 * 1024 });
        const buf = Buffer.from(v.data);
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: buf,
            caption: `🎬 ${query}\n▸ Size: ${(buf.length / 1024 / 1024).toFixed(2)} MB`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "ytmp4", handler, description: "Download MP4 dari YouTube", category: "download" };