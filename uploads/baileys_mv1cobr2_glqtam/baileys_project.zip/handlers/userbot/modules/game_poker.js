const core = require("./gamecore");

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

function makeDeck() {
    const deck = [];
    for (const s of SUITS) for (const r of RANKS) deck.push({ suit: s, rank: r });
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function cardValue(c) {
    const idx = RANKS.indexOf(c.rank);
    return idx + 2;
}

function evalHand(cards) {
    const values = cards.map(cardValue).sort((a, b) => b - a);
    const suits = cards.map(c => c.suit);
    const allSameSuit = suits.every(s => s === suits[0]);

    const counts = {};
    values.forEach(v => counts[v] = (counts[v] || 0) + 1);
    const freq = Object.values(counts).sort((a, b) => b - a);

    const sorted = [...values];
    const isStraight = sorted.every((v, i) => i === 0 || sorted[i - 1] - v === 1);

    if (allSameSuit && sorted[0] === 14 && sorted[1] === 13 && sorted[2] === 12 && sorted[3] === 11 && sorted[4] === 10)
        return { rank: 9, name: "Royal Flush" };
    if (allSameSuit && isStraight) return { rank: 8, name: "Straight Flush" };
    if (freq[0] === 4) return { rank: 7, name: "Four of a Kind" };
    if (freq[0] === 3 && freq[1] === 2) return { rank: 6, name: "Full House" };
    if (allSameSuit) return { rank: 5, name: "Flush" };
    if (isStraight) return { rank: 4, name: "Straight" };
    if (freq[0] === 3) return { rank: 3, name: "Three of a Kind" };
    if (freq[0] === 2 && freq[1] === 2) return { rank: 2, name: "Two Pair" };
    if (freq[0] === 2) return { rank: 1, name: "One Pair" };
    return { rank: 0, name: "High Card" };
}

function renderCard(c, x, y) {
    const red = c.suit === "♥" || c.suit === "♦";
    const color = red ? "#ef4444" : "#000";
    return `<rect x="${x}" y="${y}" width="90" height="130" rx="8" fill="#fff" stroke="#000" stroke-width="2"/>` +
           `<text x="${x + 12}" y="${y + 30}" font-family="Arial Black" font-size="22" fill="${color}">${c.rank}</text>` +
           `<text x="${x + 12}" y="${y + 55}" font-family="Arial" font-size="24" fill="${color}">${c.suit}</text>` +
           `<text x="${x + 78}" y="${y + 125}" font-family="Arial Black" font-size="22" fill="${color}" text-anchor="end">${c.rank}</text>`;
}

async function sendGame(client, chatId, room, caption = "") {
    const hand = room.state.hands[room.turn % 2];
    let svg = "";

    svg += `<text x="400" y="200" font-family="Arial Black" font-size="22" fill="#fbbf24" text-anchor="middle">YOUR HAND (${hand.length})</text>`;

    hand.forEach((c, i) => {
        svg += renderCard(c, 100 + i * 100, 240);
    });

    svg += `<text x="400" y="450" font-family="Arial Black" font-size="22" fill="#22c55e" text-anchor="middle">OPPONENT: ${room.state.hands[1 - (room.turn % 2)].length} cards</text>`;

    svg += `<text x="400" y="530" font-family="Arial" font-size="18" fill="#fbbf24" text-anchor="middle">Turn: ${room.players[room.turn % 2].name}</text>`;

    const buf = await core.renderSVG(core.buildLegoFrame(svg, "♠ POKER ♥", "red"));
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const deck = makeDeck();
        const hands = [deck.splice(0, 5), deck.splice(0, 5)];

        const room = core.createRoom("poker", userId, myName, null, {
            state: { deck, hands, revealed: [false, false] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "♠ <b>POKER ROOM</b> ♥\n\n│ 🆔 <code>" + room.id + "</code>\n│ <code>.poker join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .poker join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        await sendGame(client, chatId, r.room,
            "♠ <b>POKER START!</b> ♥\n\n│ 🎯 Turn: " + r.room.players[0].name + "\n│ 📖 <code>.poker eval</code> buat reveal & menang"
        );
        return;
    }

    if (cmd === "eval" || cmd === "reveal") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "poker" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        if (room.state.revealed[0]) return client.sendMessage(chatId, { message: "✕ Udah direveal" });

        const h1 = evalHand(room.state.hands[0]);
        const h2 = evalHand(room.state.hands[1]);

        room.state.revealed = [true, true];

        let winner = null;
        if (h1.rank > h2.rank) winner = room.players[0];
        else if (h2.rank > h1.rank) winner = room.players[1];
        else winner = room.players[0];

        core.saveRoom(room);

        const caption =
            "♠ <b>POKER RESULT</b> ♥\n\n" +
            "├─────────────────\n" +
            "│ " + room.players[0].name + " → " + h1.name + "\n" +
            "│ " + room.players[1].name + " → " + h2.name + "\n" +
            "├─────────────────\n" +
            "│ 🏆 Winner → " + winner.name + "\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
    }

    return client.sendMessage(chatId, {
        message:
            "♠ <b>POKER</b> ♥\n\n" +
            "├─────────────────\n" +
            "│ ▪ .poker start\n" +
            "│ ▪ .poker join [KODE]\n" +
            "│ ▪ .poker eval\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "poker",
    handler,
    description: "Poker PVP (5-card draw)",
    category: "game"
};