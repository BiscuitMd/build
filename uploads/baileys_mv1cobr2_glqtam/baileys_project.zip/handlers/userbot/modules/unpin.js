async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        await client.unpinMessage(chatId);
        await client.sendMessage(chatId, { message: "📌 Pesan di-unpin" });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "unpin", handler, description: "Unpin pesan", category: "admin" };