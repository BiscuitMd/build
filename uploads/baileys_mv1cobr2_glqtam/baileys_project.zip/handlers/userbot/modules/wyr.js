const QUESTIONS = [
    ["Bisa terbang", "Bisa baca pikiran"],
    ["Dapet 1M sekarang", "Dapet 100rb tiap hari seumur hidup"],
    ["Pinter tapi miskin", "Bodoh tapi kaya"],
    ["Hidup 100 tahun sendiri", "Hidup 50 tahun bahagia"],
    ["Jadi terkenal", "Jadi kaya tapi ga dikenal"],
    ["Bisa time travel ke masa lalu", "Bisa lihat masa depan"],
    ["Kerja di Google", "Buka startup sendiri"],
    ["Makanan enak tiap hari", "Olahraga 1x seminggu"],
    ["Tidur 4 jam cukup", "Bisa makan apapun tanpa gemuk"],
    ["Bisa ngomong semua bahasa", "Bisa main semua alat musik"]
];

async function handler(userId, client, msg, args) {
    const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
    await client.sendMessage(msg.message.chatId, {
        message: `🤔 WOULD YOU RATHER?\n\n▸ A: ${q[0]}\n▸ B: ${q[1]}\n\n<i>Pilih A atau B!</i>`,
        parseMode: "html"
    });
}

module.exports = { command: "wyr", handler, description: "Would You Rather", category: "fun" };