const DARES = [
    "Kirim voice note nyanyi lagu anak-anak",
    "Chat mantan lu 'kangen'",
    "Update status pake foto jelek lu",
    "Kirim selfie sekarang",
    "Mention 3 orang random di grup",
    "Tulis puisi buat admin grup",
    "Bikin stiker dari muka lu",
    "Telfon temen lu dan bilang 'Aku hamil'",
    "Story pake caption 'Aku suka kamu'",
    "Chat gebetan lu 'Jadian yuk'"
];

async function handler(userId, client, msg, args) {
    const d = DARES[Math.floor(Math.random() * DARES.length)];
    await client.sendMessage(msg.message.chatId, { message: `🎯 DARE:\n\n${d}` });
}

module.exports = { command: "dare", handler, description: "Truth or dare — Dare", category: "fun" };