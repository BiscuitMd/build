async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let name = args[0] || "Kamu";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) name = msgs[0].sender?.firstName || "Dia";
    }

    const iq = Math.floor(Math.random() * 100) + 50;
    let label = "Rata-rata";
    if (iq > 130) label = "Genius 🧠";
    else if (iq > 110) label = "Pintar 🎓";
    else if (iq > 90) label = "Normal 👍";
    else if (iq > 70) label = "Agak lambat 🐢";
    else label = "Butuh bantuan 😅";

    await client.sendMessage(chatId, {
        message: `🧠 IQ Test: ${name}\n\n▸ IQ: ${iq}\n▸ Kategori: ${label}`
    });
}

module.exports = { command: "iqtest", handler, description: "Test IQ random", category: "fun" };