async function handler(userId, client, msg, args) {
    const target = args.join(" ") || "Ini";
    const rating = (Math.random() * 5 + 5).toFixed(1);
    const stars = "⭐".repeat(Math.round(rating));
    await client.sendMessage(msg.message.chatId, {
        message: `⭐ Rating: ${target}\n\n▸ ${stars}\n▸ Score: ${rating}/10`
    });
}

module.exports = { command: "rate", handler, description: "Kasih rating random", category: "fun" };