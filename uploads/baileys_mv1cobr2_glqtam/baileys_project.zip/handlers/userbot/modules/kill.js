async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let target = args.join(" ") || "dia";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) target = msgs[0].sender?.firstName || "dia";
    }

    const methods = ["🔪 nusuk", "💥 ledakin", "🐍 kirim ular", "🎯 tembak", "🧨 lempar granat", "⚡ setrum"];
    const m = methods[Math.floor(Math.random() * methods.length)];
    await client.sendMessage(chatId, { message: `💀 *${target}* di-${m}!` });
}

module.exports = { command: "kill", handler, description: "Bunuh user (fun)", category: "fun" };