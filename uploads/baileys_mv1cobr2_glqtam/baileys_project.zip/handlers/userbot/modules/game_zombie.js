const core = require("./gamecore");

function renderGame(room) {
    let svg = "";

    svg += `<rect x="60" y="180" width="680" height="420" rx="20" fill="#1f2937" stroke="#7f1d1d" stroke-width="4"/>`;

    svg += `<text x="400" y="230" font-family="Arial Black" font-size="26" fill="#ef4444" text-anchor="middle">🧟 ZOMBIE WAVE ${room.state.wave}</text>`;

    const z = room.state.zombieHp;
    const zBarW = Math.max(0, z * 5);
    svg += `<rect x="200" y="280" width="400" height="30" rx="15" fill="#333"/>`;
    svg += `<rect x="200" y="280" width="${zBarW}" height="30" rx="15" fill="#ef4444"/>`;
    svg += `<text x="400" y="300" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">Zombie HP: ${z}/100</text>`;

    const p1hp = room.state.p1Hp;
    const p1w = Math.max(0, p1hp * 4);
    svg += `<rect x="100" y="350" width="250" height="25" rx="12" fill="#333"/>`;
    svg += `<rect x="100" y="350" width="${p1w}" height="25" rx="12" fill="#22c55e"/>`;
    svg += `<text x="225" y="368" font-family="Arial" font-size="14" fill="#fff" text-anchor="middle">P1 HP: ${p1hp}</text>`;

    const p2hp = room.state.p2Hp;
    const p2w = Math.max(0, p2hp * 4);
    svg += `<rect x="450" y="350" width="250" height="25" rx="12" fill="#333"/>`;
    svg += `<rect x="450" y="350" width="${p2w}" height="25" rx="12" fill="#3b82f6"/>`;
    svg += `<text x="575" y="368" font-family="Arial" font-size="14" fill="#fff" text-anchor="middle">P2 HP: ${p2hp}</text>`;

    svg += `<text x="400" y="440" font-family="Arial Black" font-size="80" text-anchor="middle">🧟</text>`;

    svg += `<text x="400" y="540" font-family="Arial" font-size="18" fill="#fbbf24" text-anchor="middle">Turn: ${room.players[room.turn % 2].name}</text>`;
    svg += `<text x="400" y="570" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">Total DMG: ${room.state.totalDamage}</text>`;

    return svg;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderGame(room), "🧟 ZOMBIE ATTACK 🔫", "red");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const room = core.createRoom("zombie", userId, myName, null, {
            state: { zombieHp: 100, wave: 1, p1Hp: 100, p2Hp: 100, totalDamage: 0, turnDamage: [0, 0] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "🧟 <b>ZOMBIE ATTACK</b> 🔫\n\n│ 🆔 <code>" + room.id + "</code>\n│ <code>.zombie join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .zombie join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        await sendGame(client, chatId, r.room,
            "🧟 <b>START!</b>\n\n│ 🎯 Turn: " + r.room.players[0].name + "\n│ 📖 <code>.zombie shoot</code>"
        );
        return;
    }

    if (cmd === "shoot") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "zombie" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const myIdx = room.turn % 2;
        const damage = Math.floor(Math.random() * 20) + 10;

        room.state.zombieHp = Math.max(0, room.state.zombieHp - damage);
        room.state.totalDamage += damage;
        room.state.turnDamage[myIdx] += damage;

        const zombieAttack = Math.floor(Math.random() * 15) + 5;
        if (myIdx === 0) room.state.p1Hp = Math.max(0, room.state.p1Hp - zombieAttack);
        else room.state.p2Hp = Math.max(0, room.state.p2Hp - zombieAttack);

        let eventText = "🔫 " + currentPlayer.name + " hit zombie: -" + damage + " HP\n🧟 Zombie balas: -" + zombieAttack + " HP";

        if (room.state.zombieHp <= 0) {
            const winner = room.state.turnDamage[0] > room.state.turnDamage[1] ? room.players[0] : room.players[1];
            core.saveRoom(room);
            await sendGame(client, chatId, room, "🏆 ZOMBIE KILLED! " + winner.name + " menang!");
            return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
        }

        if (room.state.p1Hp <= 0 || room.state.p2Hp <= 0) {
            const alive = room.state.p1Hp > 0 ? room.players[0] : room.players[1];
            core.saveRoom(room);
            await sendGame(client, chatId, room, "☠️ " + alive.name + " satu-satunya yang hidup! Menang!");
            return core.checkWinAndReward(room, alive.id, alive.name, client, chatId);
        }

        room.turn++;
        core.saveRoom(room);

        await sendGame(client, chatId, room,
            "🧟 <b>ZOMBIE ATTACK</b>\n\n│ " + eventText + "\n│ Zombie HP: " + room.state.zombieHp + "/100\n│ Next: " + room.players[room.turn % 2].name
        );
        return;
    }

    return client.sendMessage(chatId, {
        message: "🧟 <b>ZOMBIE</b>\n\n├─────────────────\n│ ▪ .zombie start\n│ ▪ .zombie join [KODE]\n│ ▪ .zombie shoot\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "zombie",
    handler,
    description: "Zombie attack co-op",
    category: "game",
    commands: ["zombieattack"]
};