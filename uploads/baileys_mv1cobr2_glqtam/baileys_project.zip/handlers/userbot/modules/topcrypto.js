const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const limit = Math.min(parseInt(args[0]) || 10, 20);
    const loading = await client.sendMessage(chatId, { message: `📊 Top ${limit} crypto...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${limit}&page=1`, { timeout: 20000 });
        const list = r.data || [];
        let text = `📊 TOP ${limit} CRYPTO\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        list.forEach((c, i) => {
            const chg = c.price_change_percentage_24h?.toFixed(2);
            const emoji = chg >= 0 ? "🟢" : "🔴";
            text += `${i + 1}. ${emoji} ${c.symbol.toUpperCase()} — $${c.current_price?.toLocaleString("id-ID")} (${chg}%)\n`;
        });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "topcrypto", handler, description: "Top crypto by market cap", category: "crypto" };