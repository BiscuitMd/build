async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let targetId = null;
    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        targetId = msgs[0]?.senderId;
    } else if (args[0]) targetId = args[0];

    if (!targetId) return client.sendMessage(chatId, { message: "📖 Reply user + .demote" });

    try {
        const { Api } = require("telegram");
        await client.invoke(new Api.channels.EditAdmin({
            channel: chatId,
            userId: targetId,
            adminRights: new Api.ChatAdminRights({}),
            rank: ""
        }));
        await client.sendMessage(chatId, { message: `⬇️ User ${targetId} di-demote` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "demote", handler, description: "Demote admin jadi member", category: "admin" };