const crypto = require("crypto");

const ALGOS = ["aes-256-cbc", "aes-192-cbc", "aes-128-cbc"];
const KEY = crypto.createHash("sha256").update("spartax-cipher-key").digest();

function encrypt(text, algo) {
    const iv = crypto.randomBytes(16);
    const c = crypto.createCipheriv(algo, KEY.slice(0, algo === "aes-128-cbc" ? 16 : algo === "aes-192-cbc" ? 24 : 32), iv);
    let e = c.update(text, "utf8", "hex");
    e += c.final("hex");
    return iv.toString("hex") + ":" + e;
}

function decrypt(data, algo) {
    const [ivHex, enc] = data.split(":");
    const iv = Buffer.from(ivHex, "hex");
    const d = crypto.createDecipheriv(algo, KEY.slice(0, algo === "aes-128-cbc" ? 16 : algo === "aes-192-cbc" ? 24 : 32), iv);
    let out = d.update(enc, "hex", "utf8");
    out += d.final("utf8");
    return out;
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    if (cmd === "enc") {
        const text = args.slice(1).join(" ");
        if (!text) return client.sendMessage(chatId, { message: "▸ .cipher enc [teks]" });
        const out = encrypt(text, "aes-256-cbc");
        return client.sendMessage(chatId, {
            message: "◆ ENCRYPTED (AES-256)\n\n<code>" + out + "</code>",
            parseMode: "html"
        });
    }

    if (cmd === "dec") {
        const text = args.slice(1).join(" ");
        if (!text) return client.sendMessage(chatId, { message: "▸ .cipher dec [ciphertext]" });
        try {
            const out = decrypt(text, "aes-256-cbc");
            return client.sendMessage(chatId, {
                message: "◆ DECRYPTED\n\n<code>" + out + "</code>",
                parseMode: "html"
            });
        } catch (e) {
            return client.sendMessage(chatId, { message: "✕ Gagal decrypt: data invalid" });
        }
    }

    if (cmd === "hash") {
        const text = args.slice(1).join(" ");
        if (!text) return client.sendMessage(chatId, { message: "▸ .cipher hash [teks]" });
        const md5 = crypto.createHash("md5").update(text).digest("hex");
        const sha1 = crypto.createHash("sha1").update(text).digest("hex");
        const sha256 = crypto.createHash("sha256").update(text).digest("hex");
        const sha512 = crypto.createHash("sha512").update(text).digest("hex");
        const text2 =
            "◆ HASH\n\n" +
            "├─────────────────\n" +
            "│ MD5    → <code>" + md5 + "</code>\n" +
            "│ SHA1   → <code>" + sha1 + "</code>\n" +
            "│ SHA256 → <code>" + sha256 + "</code>\n" +
            "│ SHA512 → <code>" + sha512 + "</code>\n" +
            "╰─────────────────";
        return client.sendMessage(chatId, { message: text2, parseMode: "html" });
    }

    const text =
        "╭───────────────────╮\n" +
        "│   ⚿  CIPHER        │\n" +
        "╰───────────────────╯\n\n" +
        "├───────────────────\n" +
        "│ ◆ COMMANDS\n" +
        "├───────────────────\n" +
        "│ ▪ .cipher enc [text]\n" +
        "│ ▪ .cipher dec [cipher]\n" +
        "│ ▪ .cipher hash [text]\n" +
        "╰───────────────────";

    return client.sendMessage(chatId, { message: text });
}

module.exports = {
    command: "cipher",
    handler,
    description: "Enkripsi AES-256 + hash generator",
    category: "security"
};