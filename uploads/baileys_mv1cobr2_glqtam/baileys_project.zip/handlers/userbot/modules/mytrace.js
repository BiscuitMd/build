const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: `📍 Trace lokasi HP...` });

    try {
        const r = await axios.get("http://ip-api.com/json/", { timeout: 15000 });
        const d = r.data;
        const text =
            `📍 IP KAMU (server bot)\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ IP: ${d.query}\n` +
            `▸ Country: ${d.country} (${d.countryCode})\n` +
            `▸ Region: ${d.regionName}\n` +
            `▸ City: ${d.city}\n` +
            `▸ ISP: ${d.isp}\n` +
            `▸ Lat/Lon: ${d.lat}, ${d.lon}\n` +
            `▸ Maps: https://www.google.com/maps?q=${d.lat},${d.lon}\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "mytrace", handler, description: "Trace IP server bot", category: "osint" };