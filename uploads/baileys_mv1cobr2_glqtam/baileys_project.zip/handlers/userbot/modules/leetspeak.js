async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .leet [text]" });
    const map = { a:"4", e:"3", i:"1", o:"0", s:"5", t:"7", b:"8", g:"9", l:"1", z:"2" };
    const out = text.toLowerCase().split("").map(c => map[c] || c).join("");
    await client.sendMessage(chatId, { message: out });
}

module.exports = { command: "leet", handler, description: "Leetspeak text", category: "text" };