const { Api } = require("telegram");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) {
        return client.sendMessage(chatId, { message: "📖 Reply foto pake .sticker buat bikin stiker" });
    }
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const target = msgs[0];
        if (!target || !target.media) {
            return client.sendMessage(chatId, { message: "❌ Target bukan media" });
        }
        const file = await client.downloadMedia(target);
        if (!file) return client.sendMessage(chatId, { message: "❌ Gagal download" });
        await client.sendFile(chatId, {
            file,
            forceDocument: false,
            attributes: [new Api.DocumentAttributeSticker({
                alt: "🤖",
                stickerset: new Api.InputStickerSetEmpty()
            })]
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ Error: ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "sticker", handler, description: "Bikin stiker dari foto", category: "media" };