const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.coingecko.com/api/v3/global", { timeout: 15000 });
        const d = r.data?.data;
        const btc = d.market_cap_percentage.btc?.toFixed(2);
        const eth = d.market_cap_percentage.eth?.toFixed(2);
        const others = (100 - parseFloat(btc) - parseFloat(eth)).toFixed(2);
        await client.sendMessage(chatId, {
            message:
                `📊 MARKET DOMINANCE\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ BTC: ${btc}%\n` +
                `▸ ETH: ${eth}%\n` +
                `▸ Others: ${others}%\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Total Market Cap: $${(d.total_market_cap.usd / 1e12).toFixed(2)}T\n` +
                `▸ Total Volume 24h: $${(d.total_volume.usd / 1e9).toFixed(2)}B\n` +
                `▸ Active Coins: ${d.active_cryptocurrencies}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "dominance", handler, description: "Market dominance BTC/ETH", category: "crypto" };