const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "⛽ Gas fee..." });
    try {
        const r = await axios.get("https://api.blocknative.com/gasprices/blockprices?chainid=1", { timeout: 15000 }).catch(() => null);
        if (!r?.data) throw new Error("API butuh key. Cek manual https://etherscan.io/gastracker");

        const data = r.data.blockPrices?.[0]?.estimatedPrices || [];
        let text = `⛽ ETH GAS FEE\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        for (const tier of data) {
            const name = tier.confidence === 99 ? "🐢 Slow" : tier.confidence === 90 ? "🚶 Standard" : tier.confidence === 80 ? "🚗 Fast" : "🚀 Instant";
            text += `${name}: ${tier.price} Gwei\n`;
        }
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "gasfee", handler, description: "Ethereum gas fee", category: "crypto" };