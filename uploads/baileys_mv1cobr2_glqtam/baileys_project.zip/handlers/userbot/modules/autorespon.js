const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_autorespon.json");
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; } }
function write(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2), "utf8"); }

function defaultData() {
    return {
        enabled: false,
        mode: "all",
        reply: "Halo! Pesan lu udah masuk, nanti dibalas ya.",
        custom: {},
        cooldown: 60000,
        blacklist: [],
        whitelist: [],
        lastReply: {},
        stats: { totalReplied: 0, totalSkipped: 0, totalCooldown: 0 }
    };
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    db[userId] = db[userId] || defaultData();
    const data = db[userId];

    if (cmd === "on") {
        data.enabled = true;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-respon ON\n▸ Mode: " + data.mode.toUpperCase() });
    }

    if (cmd === "off") {
        data.enabled = false;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-respon OFF" });
    }

    if (cmd === "set") {
        const text = args.slice(1).join(" ");
        if (!text) return client.sendMessage(chatId, { message: "▸ .autorespon set [teks balasan]" });
        data.reply = text;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Balasan global diset:\n\n\"" + text + "\"" });
    }

    if (cmd === "setuser") {
        const target = args[1];
        const text = args.slice(2).join(" ");
        if (!target || !text) return client.sendMessage(chatId, { message: "▸ .autorespon setuser [@user/ID] [teks]" });

        data.custom[target] = text;
        write(db);

        return client.sendMessage(chatId, { message: "✓ Balasan custom untuk " + target + ":\n\n\"" + text + "\"" });
    }

    if (cmd === "deluser") {
        const target = args[1];
        if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon deluser [@user/ID]" });
        delete data.custom[target];
        write(db);
        return client.sendMessage(chatId, { message: "✓ Custom balasan dihapus untuk: " + target });
    }

    if (cmd === "listuser") {
        const keys = Object.keys(data.custom);
        if (!keys.length) return client.sendMessage(chatId, { message: "▸ Gaada balasan custom" });
        let list = "";
        keys.forEach((k, i) => { list += "│ " + (i + 1) + ". " + k + " → " + data.custom[k].slice(0, 30) + "\n"; });
        return client.sendMessage(chatId, { message: "◆ Custom Balasan\n\n" + list });
    }

    if (cmd === "mode") {
        const m = args[1]?.toLowerCase();
        if (!["all", "dm", "gc"].includes(m)) return client.sendMessage(chatId, { message: "▸ .autorespon mode all/dm/gc" });
        data.mode = m;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Mode: " + m.toUpperCase() });
    }

    if (cmd === "cooldown") {
        const sec = parseInt(args[1]);
        if (isNaN(sec) || sec < 5) return client.sendMessage(chatId, { message: "▸ .autorespon cooldown [detik min 5]" });
        data.cooldown = sec * 1000;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Cooldown: " + sec + "s" });
    }

    if (cmd === "bl" || cmd === "wl") {
        const sub = args[1]?.toLowerCase();
        const target = args[2];
        const key = cmd === "bl" ? "blacklist" : "whitelist";

        if (sub === "add") {
            if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon " + cmd + " add [@user/ID]" });
            if (!data[key].includes(target)) data[key].push(target);
            write(db);
            return client.sendMessage(chatId, { message: "✓ " + cmd.toUpperCase() + ": " + target });
        }

        if (sub === "del") {
            if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon " + cmd + " del [@user/ID]" });
            data[key] = data[key].filter(x => x !== target);
            write(db);
            return client.sendMessage(chatId, { message: "✓ Dihapus: " + target });
        }

        if (sub === "list" || !sub) {
            if (!data[key].length) return client.sendMessage(chatId, { message: "▸ " + key + " kosong" });
            let list = "";
            data[key].forEach((x, i) => { list += "│ " + (i + 1) + ". " + x + "\n"; });
            return client.sendMessage(chatId, { message: "◆ " + cmd.toUpperCase() + "\n\n" + list });
        }
    }

    if (cmd === "reset") {
        db[userId] = defaultData();
        write(db);
        return client.sendMessage(chatId, { message: "✓ Config direset" });
    }

    if (cmd === "status" || !cmd) {
        const t =
            "╭───────────────────╮\n" +
            "│   ◇  AUTORESPOON   │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ STATUS\n" +
            "├───────────────────\n" +
            "│ ▪ Enabled   → " + (data.enabled ? "ON" : "OFF") + "\n" +
            "│ ▪ Mode      → " + data.mode.toUpperCase() + "\n" +
            "│ ▪ Cooldown  → " + (data.cooldown / 1000) + "s\n" +
            "│ ▪ Custom    → " + Object.keys(data.custom).length + " user\n" +
            "│ ▪ Bl/Wl     → " + data.blacklist.length + "/" + data.whitelist.length + "\n" +
            "├───────────────────\n" +
            "│ ◆ BALASAN GLOBAL\n" +
            "├───────────────────\n" +
            "│ " + data.reply.slice(0, 40) + "\n" +
            "├───────────────────\n" +
            "│ ◆ COMMANDS\n" +
            "├───────────────────\n" +
            "│ ▪ .autorespon on/off\n" +
            "│ ▪ .autorespon set [teks]\n" +
            "│ ▪ .autorespon setuser [@user] [teks]\n" +
            "│ ▪ .autorespon deluser [@user]\n" +
            "│ ▪ .autorespon listuser\n" +
            "│ ▪ .autorespon mode all/dm/gc\n" +
            "│ ▪ .autorespon cooldown [detik]\n" +
            "│ ▪ .autorespon bl/wl add/del/list\n" +
            "╰───────────────────";

        return client.sendMessage(chatId, { message: t });
    }

    return client.sendMessage(chatId, { message: "▸ .autorespon on/off/set/setuser/mode/cooldown/bl/wl/status" });
}

async function handleIncoming(userId, client, msg) {
    try {
        const db = read();
        const data = db[userId];
        if (!data || !data.enabled) return;

        const m = msg.message;
        const text = m.message || m.text || "";
        if (!text || text.startsWith(".")) return;
        if (m.out) return;

        const senderId = m.senderId?.toString() || "";
        if (!senderId) return;

        const chatType = m.peerId?.className || "";
        const isDM = chatType.includes("User");
        const isGC = chatType.includes("Chat") || chatType.includes("Channel");

        if (data.mode === "dm" && !isDM) return;
        if (data.mode === "gc" && !isGC) return;

        let senderUsername = null;
        try {
            const ent = await client.getEntity(senderId);
            senderUsername = ent.username || null;
        } catch {}

        if (data.blacklist.includes(senderId)) { data.stats.totalSkipped++; write(db); return; }
        if (senderUsername && data.blacklist.includes("@" + senderUsername)) { data.stats.totalSkipped++; write(db); return; }

        if (data.whitelist.length > 0) {
            const inWL = data.whitelist.includes(senderId) ||
                         (senderUsername && data.whitelist.includes("@" + senderUsername));
            if (!inWL) { data.stats.totalSkipped++; write(db); return; }
        }

        const lastReply = data.lastReply[senderId] || 0;
        if (Date.now() - lastReply < data.cooldown) { data.stats.totalCooldown++; write(db); return; }

        let replyText = data.reply;
        if (data.custom[senderId]) replyText = data.custom[senderId];
        else if (senderUsername && data.custom["@" + senderUsername]) replyText = data.custom["@" + senderUsername];

        await new Promise(r => setTimeout(r, Math.floor(Math.random() * 2000) + 1000));

        try {
            await client.sendMessage(m.chatId || m.peerId, { message: replyText, replyTo: m.id });
        } catch {
            await client.sendMessage(m.chatId || m.peerId, { message: replyText });
        }

        data.lastReply[senderId] = Date.now();
        data.stats.totalReplied++;
        write(db);

        console.log("[AUTORESPOON] replied to " + senderId);
    } catch (e) {
        console.log("[AUTORESPOON] err: " + e.message.slice(0, 100));
    }
}

module.exports = {
    command: "autorespon",
    handler,
    handleIncoming,
    description: "Auto-balas pesan masuk (set teks + custom per user)",
    category: "tools",
    commands: ["ar"]
};