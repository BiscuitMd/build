const core = require("./gamecore");

const COLORS = ["#fbbf24", "#ef4444", "#3b82f6", "#22c55e", "#a855f7", "#f97316", "#ec4899", "#14b8a6"];

function initBalls() {
    const balls = [];
    for (let i = 1; i <= 9; i++) {
        const angle = (i / 10) * Math.PI * 2;
        const r = 20 + i * 15;
        balls.push({
            id: i,
            x: 500 + Math.cos(angle) * r,
            y: 400 + Math.sin(angle) * r,
            color: COLORS[(i - 1) % COLORS.length],
            alive: true
        });
    }
    return balls;
}

function renderTable(room) {
    let svg = "";
    svg += `<rect x="60" y="60" width="680" height="680" rx="30" fill="#166534" stroke="#7c2d12" stroke-width="20"/>`;

    const pockets = [[80, 80], [400, 80], [720, 80], [80, 720], [400, 720], [720, 720]];
    pockets.forEach(([px, py]) => {
        svg += `<circle cx="${px}" cy="${py}" r="22" fill="#000" stroke="#7c2d12" stroke-width="4"/>`;
    });

    svg += `<circle cx="400" cy="400" r="80" fill="#166534" stroke="#fbbf24" stroke-width="3" opacity="0.5"/>`;

    const cue = room.state.cueBall;
    svg += `<circle cx="${cue.x}" cy="${cue.y}" r="16" fill="#fff" stroke="#000" stroke-width="2"/>`;
    svg += `<text x="${cue.x}" y="${cue.y + 5}" font-family="Arial" font-size="12" fill="#000" text-anchor="middle">CUE</text>`;

    room.state.balls.forEach(b => {
        if (!b.alive) return;
        svg += `<circle cx="${b.x}" cy="${b.y}" r="16" fill="${b.color}" stroke="#000" stroke-width="2"/>`;
        svg += `<text x="${b.x}" y="${b.y + 5}" font-family="Arial" font-size="12" font-weight="900" fill="#fff" text-anchor="middle">${b.id}</text>`;
    });

    svg += `<text x="400" y="60" font-family="Arial Black" font-size="22" fill="#fbbf24" text-anchor="middle">BILLIARD</text>`;

    return svg;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderTable(room), "🎱 BILLIARD 🎱", "green");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const room = core.createRoom("billiard", userId, myName, null, {
            state: { balls: initBalls(), cueBall: { x: 200, y: 400 }, scores: [0, 0] },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "🎱 <b>BILLIARD ROOM</b>\n\n" +
            "│ 🆔 <code>" + room.id + "</code>\n" +
            "│ <code>.billiard join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .billiard join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        await sendGame(client, chatId, r.room,
            "🎱 <b>BILLIARD START!</b>\n\n" +
            "│ 🎯 Turn: " + r.room.players[0].name + "\n" +
            "│ 📖 <code>.billiard shoot [power 1-100]</code>"
        );
        return;
    }

    if (cmd === "shoot") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "billiard" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const power = Math.min(100, Math.max(1, parseInt(args[1]) || 50));
        const myIdx = room.turn % 2;

        const alive = room.state.balls.filter(b => b.alive);
        if (!alive.length) return client.sendMessage(chatId, { message: "✕ Semua bola udah masuk" });

        const target = alive[Math.floor(Math.random() * alive.length)];
        const hitChance = power / 100;
        const hit = Math.random() < hitChance;

        let eventText = "🎯 Power: " + power + "%";

        if (hit) {
            target.alive = false;
            room.state.scores[myIdx]++;
            eventText += "\n✅ Bola " + target.id + " masuk! +1 poin";

            const remaining = room.state.balls.filter(b => b.alive);
            if (remaining.length === 0) {
                const winner = room.state.scores[0] > room.state.scores[1] ? room.players[0] : room.players[1];
                core.saveRoom(room);
                await sendGame(client, chatId, room, "🏆 " + winner.name + " menang!");
                return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
            }
        } else {
            eventText += "\n❌ Meleset!";
            room.turn++;
        }

        core.saveRoom(room);

        const caption =
            "🎱 <b>BILLIARD</b>\n\n" +
            "├─────────────────\n" +
            "│ " + currentPlayer.name + " shooting\n" +
            "│ " + eventText + "\n" +
            "├─────────────────\n" +
            "│ Score → " + room.state.scores[0] + " - " + room.state.scores[1] + "\n" +
            "│ Next  → " + room.players[room.turn % 2].name + "\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "🎱 <b>BILLIARD</b> 🎱\n\n" +
            "├─────────────────\n" +
            "│ ▪ .billiard start\n" +
            "│ ▪ .billiard join [KODE]\n" +
            "│ ▪ .billiard shoot [power 1-100]\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "billiard",
    handler,
    description: "Billiard PVP",
    category: "game",
    commands: ["biliar", "pool"]
};