async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ").trim();

    if (!text) {
        return client.sendMessage(chatId, {
            message:
                "╭───────────────────╮\n" +
                "│   ◇  BRAT STICKER  │\n" +
                "╰───────────────────╯\n\n" +
                "├───────────────────\n" +
                "│ ▪ .brat [teks]\n" +
                "│ ▪ Max 3 baris\n" +
                "│ ▪ Background hitam\n" +
                "│ ▪ Teks putih + profile\n" +
                "╰───────────────────"
        });
    }

    try {
        const me = await client.getMe();
        const name = [me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "User";

        const lines = [];
        const words = text.split(" ");
        let cur = "";
        for (const w of words) {
            if ((cur + " " + w).trim().length > 20) {
                lines.push(cur.trim());
                cur = w;
            } else {
                cur = (cur + " " + w).trim();
            }
        }
        if (cur) lines.push(cur);
        if (lines.length > 3) lines.length = 3;

        const svgText = lines.map((l, i) =>
            `<text x="50%" y="${45 + i * 12}%" font-family="Arial,sans-serif" font-size="60" font-weight="bold" fill="#ffffff" text-anchor="middle" dominant-baseline="middle">${escapeXml(l)}</text>`
        ).join("");

        const svg =
            `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">` +
            `<rect width="512" height="512" fill="#000000"/>` +
            svgText +
            `<text x="50%" y="93%" font-family="Arial,sans-serif" font-size="20" fill="#cccccc" text-anchor="middle">${escapeXml(name)}</text>` +
            `<text x="50%" y="97%" font-family="Arial,sans-serif" font-size="14" fill="#888888" text-anchor="middle">SpartaX Userbot</text>` +
            `</svg>`;

        const pngBuffer = await svgToPng(svg, 512, 512);

        const { CustomFile } = require("telegram/client/uploads");
        const file = new CustomFile("brat.png", pngBuffer.length, "", pngBuffer);

        await client.sendFile(chatId, {
            file,
            forceDocument: false,
            attributes: [
                new (require("telegram").Api.DocumentAttributeSticker)({
                    alt: "🔥",
                    stickerset: new (require("telegram").Api.InputStickerSetEmpty)()
                }),
                new (require("telegram").Api.DocumentAttributeFilename)({ fileName: "brat.webp" })
            ]
        });

        console.log("[BRAT] sticker sent");
    } catch (e) {
        console.log("[BRAT] err: " + e.message);
        return client.sendMessage(chatId, { message: "✕ Gagal bikin sticker: " + e.message });
    }
}

function escapeXml(s) {
    return String(s).replace(/[<>&'"]/g, c => ({
        "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
    }[c]));
}

async function svgToPng(svg, width, height) {
    try {
        const sharp = require("sharp");
        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch {
        return Buffer.from(svg);
    }
}

module.exports = {
    command: "brat",
    handler,
    description: "Bikin sticker brat hitam-putih",
    category: "tools"
};