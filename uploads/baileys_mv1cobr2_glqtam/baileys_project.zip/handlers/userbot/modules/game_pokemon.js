const core = require("./gamecore");

const POKEMONS = [
    { name: "Pikachu", emoji: "⚡", hp: 100, atk: 25, color: "#fbbf24" },
    { name: "Charmander", emoji: "🔥", hp: 110, atk: 22, color: "#f97316" },
    { name: "Squirtle", emoji: "💧", hp: 120, atk: 18, color: "#3b82f6" },
    { name: "Bulbasaur", emoji: "🌿", hp: 115, atk: 20, color: "#22c55e" },
    { name: "Eevee", emoji: "🦊", hp: 105, atk: 21, color: "#a16207" },
    { name: "Snorlax", emoji: "😴", hp: 140, atk: 15, color: "#1f2937" },
    { name: "Gengar", emoji: "👻", hp: 95, atk: 28, color: "#7c3aed" },
    { name: "Dragonite", emoji: "🐉", hp: 130, atk: 26, color: "#0891b2" }
];

function pickRandom() {
    return POKEMONS[Math.floor(Math.random() * POKEMONS.length)];
}

function renderBattle(room) {
    const p1 = room.state.p1;
    const p2 = room.state.p2;

    let svg = "";

    // P1 side
    svg += `<rect x="60" y="180" width="320" height="280" rx="20" fill="${p1.color}" stroke="#000" stroke-width="4" opacity="0.85"/>`;
    svg += `<text x="220" y="250" font-family="Arial" font-size="80" text-anchor="middle">${p1.emoji}</text>`;
    svg += `<text x="220" y="320" font-family="Arial Black" font-size="24" fill="#fff" text-anchor="middle">${p1.name}</text>`;
    svg += `<text x="220" y="350" font-family="Arial" font-size="18" fill="#fff" text-anchor="middle">HP: ${p1.hp}/${p1.maxHp}</text>`;
    const p1BarW = Math.max(0, (p1.hp / p1.maxHp) * 260);
    svg += `<rect x="90" y="370" width="260" height="20" rx="10" fill="#333"/>`;
    svg += `<rect x="90" y="370" width="${p1BarW}" height="20" rx="10" fill="${p1.hp > p1.maxHp * 0.3 ? "#22c55e" : "#ef4444"}"/>`;
    svg += `<text x="220" y="430" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">ATK: ${p1.atk}</text>`;

    // VS
    svg += `<text x="400" y="320" font-family="Arial Black" font-size="50" fill="#fbbf24" text-anchor="middle">VS</text>`;

    // P2 side
    svg += `<rect x="420" y="180" width="320" height="280" rx="20" fill="${p2.color}" stroke="#000" stroke-width="4" opacity="0.85"/>`;
    svg += `<text x="580" y="250" font-family="Arial" font-size="80" text-anchor="middle">${p2.emoji}</text>`;
    svg += `<text x="580" y="320" font-family="Arial Black" font-size="24" fill="#fff" text-anchor="middle">${p2.name}</text>`;
    svg += `<text x="580" y="350" font-family="Arial" font-size="18" fill="#fff" text-anchor="middle">HP: ${p2.hp}/${p2.maxHp}</text>`;
    const p2BarW = Math.max(0, (p2.hp / p2.maxHp) * 260);
    svg += `<rect x="450" y="370" width="260" height="20" rx="10" fill="#333"/>`;
    svg += `<rect x="450" y="370" width="${p2BarW}" height="20" rx="10" fill="${p2.hp > p2.maxHp * 0.3 ? "#22c55e" : "#ef4444"}"/>`;
    svg += `<text x="580" y="430" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">ATK: ${p2.atk}</text>`;

    svg += `<text x="400" y="530" font-family="Arial" font-size="20" fill="#fbbf24" text-anchor="middle">Turn: ${room.players[room.turn % 2].name}</text>`;

    return svg;
}

async function sendGame(client, chatId, room, caption = "") {
    const svg = core.buildLegoFrame(renderBattle(room), "🎮 POKEMON BATTLE 🎮", "yellow");
    const buf = await core.renderSVG(svg);
    await core.sendGameImage(client, chatId, buf, caption);
}

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const p = pickRandom();
        const room = core.createRoom("pokemon", userId, myName, null, {
            state: { p1: { ...p, maxHp: p.hp }, p2: null },
            maxPlayers: 2,
            chatId: String(chatId)
        });

        await sendGame(client, chatId, room,
            "🎮 <b>POKEMON BATTLE</b>\n\n" +
            "│ 🆔 <code>" + room.id + "</code>\n" +
            "│ 🐾 " + p.emoji + " " + p.name + "\n" +
            "│ <code>.pokemon join " + room.id + "</code>"
        );
        return;
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .pokemon join [KODE]" });

        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        const p2 = pickRandom();
        r.room.state.p2 = { ...p2, maxHp: p2.hp };
        core.saveRoom(r.room);

        await sendGame(client, chatId, r.room,
            "🎮 <b>BATTLE START!</b>\n\n" +
            "│ 🎯 Turn: " + r.room.players[0].name + "\n" +
            "│ 📖 <code>.pokemon attack</code>"
        );
        return;
    }

    if (cmd === "attack") {
        const room = Object.values(core.ROOMS).find(r => r.players.some(p => p.id === userId) && r.gameType === "pokemon" && r.status === "playing");
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (currentPlayer.id !== userId) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const myIdx = room.turn % 2;
        const myMon = myIdx === 0 ? room.state.p1 : room.state.p2;
        const enemyMon = myIdx === 0 ? room.state.p2 : room.state.p1;

        const dmg = Math.floor(myMon.atk * (0.7 + Math.random() * 0.6));
        enemyMon.hp = Math.max(0, enemyMon.hp - dmg);

        let eventText = myMon.emoji + " " + myMon.name + " attack! Damage: " + dmg;

        if (enemyMon.hp <= 0) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, "💀 " + enemyMon.name + " kalah! " + myMon.name + " menang!");
            return core.checkWinAndReward(room, currentPlayer.id, currentPlayer.name, client, chatId);
        }

        room.turn++;
        core.saveRoom(room);

        const caption =
            "🎮 <b>POKEMON BATTLE</b>\n\n" +
            "├─────────────────\n" +
            "│ " + eventText + "\n" +
            "│ Enemy HP → " + enemyMon.hp + "/" + enemyMon.maxHp + "\n" +
            "├─────────────────\n" +
            "│ 🎯 Next → " + room.players[room.turn % 2].name + "\n" +
            "╰─────────────────";

        await sendGame(client, chatId, room, caption);
        return;
    }

    return client.sendMessage(chatId, {
        message:
            "🎮 <b>POKEMON BATTLE</b> 🎮\n\n" +
            "├─────────────────\n" +
            "│ ▪ .pokemon start\n" +
            "│ ▪ .pokemon join [KODE]\n" +
            "│ ▪ .pokemon attack\n" +
            "╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "pokemon",
    handler,
    description: "Pokemon card battle PVP",
    category: "game",
    commands: ["poke"]
};