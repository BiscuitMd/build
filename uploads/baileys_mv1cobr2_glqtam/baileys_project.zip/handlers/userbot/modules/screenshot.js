const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args.join(" ").trim();
    if (!url || !url.startsWith("http")) {
        return client.sendMessage(chatId, { message: "📖 .screenshot [url]" });
    }
    const loading = await client.sendMessage(chatId, { message: "📸 Screenshot..." });
    try {
        const api = `https://image.thum.io/get/width/1280/crop/1024/${url}`;
        const r = await axios.get(api, { responseType: "arraybuffer", timeout: 45000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(r.data), forceDocument: false, caption: `📸 ${url}` });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "screenshot", handler, description: "Screenshot website", category: "tools" };