const axios = require("axios");
const FormData = require("form-data");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) return client.sendMessage(chatId, { message: "📖 Reply foto + .removebg" });
    const loading = await client.sendMessage(chatId, { message: "🎨 Remove background..." });
    try {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        const buf = await client.downloadMedia(msgs[0]);
        if (!buf) throw new Error("Gagal download");
        const fd = new FormData();
        fd.append("image_file", buf, { filename: "image.jpg" });
        fd.append("size", "auto");
        const r = await axios.post("https://api.remove.bg/v1.0/removebg", fd, {
            headers: { ...fd.getHeaders(), "X-Api-Key": "demo" },
            responseType: "arraybuffer",
            timeout: 60000
        }).catch(() => null);
        if (!r || r.status !== 200) throw new Error("API remove.bg butuh API key. Daftar di remove.bg");
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, { file: Buffer.from(r.data), caption: "🎨 No BG", forceDocument: false });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "removebg", handler, description: "Hapus background foto", category: "media" };