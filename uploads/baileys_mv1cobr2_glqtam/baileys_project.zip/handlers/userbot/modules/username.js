const axios = require("axios");

const PLATFORMS = {
    instagram: "https://www.instagram.com/{}/",
    twitter: "https://twitter.com/{}",
    github: "https://github.com/{}",
    reddit: "https://www.reddit.com/user/{}",
    tiktok: "https://www.tiktok.com/@{}",
    youtube: "https://www.youtube.com/@{}",
    facebook: "https://www.facebook.com/{}",
    pinterest: "https://www.pinterest.com/{}",
    telegram: "https://t.me/{}",
    twitch: "https://www.twitch.tv/{}",
    steam: "https://steamcommunity.com/id/{}",
    spotify: "https://open.spotify.com/user/{}",
    medium: "https://medium.com/@{}",
    deviantart: "https://www.deviantart.com/{}",
    soundcloud: "https://soundcloud.com/{}",
    gitlab: "https://gitlab.com/{}",
    bitbucket: "https://bitbucket.org/{}",
    vk: "https://vk.com/{}",
    snapchat: "https://www.snapchat.com/add/{}",
    tumblr: "https://{}.tumblr.com"
};

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const username = args[0];
    if (!username) return client.sendMessage(chatId, { message: "📖 .username [username]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Check username "${username}" di 20 platform...` });

    try {
        const results = await Promise.allSettled(
            Object.entries(PLATFORMS).map(async ([name, urlTemplate]) => {
                const url = urlTemplate.replace("{}", username);
                try {
                    const r = await axios.get(url, {
                        timeout: 8000,
                        maxRedirects: 5,
                        validateStatus: () => true,
                        headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" }
                    });
                    if (r.status === 200) {
                        const body = String(r.data).toLowerCase();
                        if (body.includes("not found") || body.includes("page not found") || body.includes("doesn't exist") || body.includes("user not found")) {
                            return { name, url, found: false };
                        }
                        return { name, url, found: true };
                    }
                    return { name, url, found: false };
                } catch {
                    return { name, url, found: false };
                }
            })
        );

        const found = results.filter(r => r.status === "fulfilled" && r.value.found).map(r => r.value);
        const notFound = results.filter(r => r.status === "fulfilled" && !r.value.found).map(r => r.value);

        let text = `🔍 OSINT: ${username}\n\n`;
        text += `━━━━━━━━━━━━━━━━━━━━\n`;
        text += `✅ DITEMUKAN (${found.length}):\n`;
        if (found.length > 0) {
            for (const f of found) text += `▸ ${f.name}: ${f.url}\n`;
        } else {
            text += `▸ (gaada)\n`;
        }
        text += `\n❌ TIDAK DITEMUKAN (${notFound.length}):\n`;
        text += notFound.map(f => `▸ ${f.name}`).join("\n");

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "username", handler, description: "Check username di banyak platform", category: "osint" };