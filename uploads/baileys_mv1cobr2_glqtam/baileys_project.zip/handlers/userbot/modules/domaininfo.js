const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const domain = args[0]?.replace(/^https?:\/\//, "").split("/")[0];
    if (!domain) return client.sendMessage(chatId, { message: "📖 .domaininfo [domain.com]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Recon domain ${domain}...` });

    try {
        const dns = require("dns").promises;
        const [a, mx, ns, txt] = await Promise.all([
            dns.resolve4(domain).catch(() => []),
            dns.resolveMx(domain).catch(() => []),
            dns.resolveNs(domain).catch(() => []),
            dns.resolveTxt(domain).catch(() => [])
        ]);

        // WHOIS via API
        let whois = null;
        try {
            const r = await axios.get(`https://api.siputzx.my.id/api/tools/whois?domain=${domain}`, { timeout: 20000 });
            whois = r.data?.data;
        } catch {}

        const text =
            `🔍 DOMAIN RECON\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Domain: ${domain}\n` +
            `▸ A Record: ${a.length > 0 ? a.join(", ") : "-"}\n` +
            `▸ NS: ${ns.length > 0 ? ns.join(", ") : "-"}\n` +
            `▸ MX: ${mx.length > 0 ? mx.map(m => m.exchange).join(", ") : "-"}\n` +
            `▸ TXT: ${txt.length > 0 ? txt.map(t => t.join("")).join(" | ").slice(0, 200) : "-"}\n`;

        if (whois) {
            text += `━━━━━━━━━━━━━━━━━━━━\n`;
            text += `▸ Registrar: ${whois.registrar || "-"}\n`;
            text += `▸ Created: ${whois.creationDate || "-"}\n`;
            text += `▸ Expires: ${whois.expirationDate || "-"}\n`;
            text += `▸ Status: ${(whois.status || []).join(", ").slice(0, 150) || "-"}\n`;
        }

        text += `━━━━━━━━━━━━━━━━━━━━`;

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "domaininfo", handler, description: "Domain recon + WHOIS", category: "osint" };