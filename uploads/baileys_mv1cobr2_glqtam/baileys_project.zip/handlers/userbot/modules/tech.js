const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const url = args[0];
    if (!url) return client.sendMessage(chatId, { message: "📖 .tech [url]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Detect technology...` });

    try {
        const r = await axios.get(url, { timeout: 20000, validateStatus: () => true });
        const html = String(r.data).toLowerCase();
        const headers = r.headers;

        const detected = [];
        if (/wp-content|wordpress/.test(html)) detected.push("WordPress");
        if (/drupal/.test(html)) detected.push("Drupal");
        if (/joomla/.test(html)) detected.push("Joomla");
        if (/react|_next|__next/.test(html)) detected.push("React/Next.js");
        if (/vue\.js|vuejs/.test(html)) detected.push("Vue.js");
        if (/angular/.test(html)) detected.push("Angular");
        if (/jquery/.test(html)) detected.push("jQuery");
        if (/bootstrap/.test(html)) detected.push("Bootstrap");
        if (/tailwind/.test(html)) detected.push("Tailwind");
        if (/laravel/.test(html)) detected.push("Laravel");
        if (/django/.test(html)) detected.push("Django");
        if (/flask/.test(html)) detected.push("Flask");
        if (/express/.test(headers["x-powered-by"] || "")) detected.push("Express");
        if (/php/.test(headers["x-powered-by"] || "")) detected.push("PHP");
        if (/nginx/.test(headers.server || "")) detected.push("Nginx");
        if (/apache/.test(headers.server || "")) detected.push("Apache");
        if (/cloudflare/.test(headers.server || "")) detected.push("Cloudflare");

        const text =
            `🔍 TECH STACK ${url}\n\n` +
            `▸ Status: ${r.status}\n` +
            `▸ Server: ${headers.server || "-"}\n` +
            `▸ Powered by: ${headers["x-powered-by"] || "-"}\n` +
            `▸ Detected (${detected.length}):\n` +
            (detected.length > 0 ? detected.map(t => `▸ ${t}`).join("\n") : "▸ (ga kedetek)");

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "tech", handler, description: "Detect tech stack website", category: "osint" };