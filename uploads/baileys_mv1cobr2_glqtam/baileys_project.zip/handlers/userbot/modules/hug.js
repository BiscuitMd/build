async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const replyTo = msg.message.replyTo?.replyToMsgId;
    let target = args.join(" ") || "semua";

    if (replyTo) {
        const msgs = await client.getMessages(chatId, { ids: [replyTo] });
        if (msgs[0]) target = msgs[0].sender?.firstName || "dia";
    }

    const emotes = ["(っ◔◡◔)っ ♥", "(づ｡◕‿‿◕｡)づ", "ʕっ•ᴥ•ʔっ", "(っ˘ω˘ς)"];
    const e = emotes[Math.floor(Math.random() * emotes.length)];
    await client.sendMessage(chatId, { message: `${e} *HUGS* ${target} 💕` });
}

module.exports = { command: "hug", handler, description: "Hug user", category: "fun" };