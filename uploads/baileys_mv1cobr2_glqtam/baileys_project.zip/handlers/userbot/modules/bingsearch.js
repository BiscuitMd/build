const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ");
    if (!query) return client.sendMessage(chatId, { message: "📖 .bingsearch [query]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Search...` });

    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/s/bing?query=${encodeURIComponent(query)}`, { timeout: 20000 }).catch(() => null);
        const results = r?.data?.data || [];

        let text = `🔍 BING: ${query}\n\n▸ Found: ${results.length}\n\n`;
        text += results.slice(0, 10).map((r, i) => `${i + 1}. ${r.title}\n${r.url}`).join("\n\n");

        if (results.length === 0) {
            text += `Gaada hasil, coba manual: https://www.bing.com/search?q=${encodeURIComponent(query)}`;
        }

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "bingsearch", handler, description: "Search via Bing", category: "osint" };