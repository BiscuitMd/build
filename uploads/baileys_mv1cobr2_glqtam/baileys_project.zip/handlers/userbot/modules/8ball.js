const ANSWERS = [
    "✅ Pasti iya", "✅ Iya dong", "✅ Yakin banget", "✅ Tentu",
    "🤔 Mungkin iya", "🤔 Bisa jadi", "🤔 Kayaknya sih", "🤔 Coba lagi nanti",
    "❌ Ga mungkin", "❌ Jangan harap", "❌ Nggak", "❌ Sama sekali nggak",
    "😐 Ragu", "😐 Ga jelas", "😐 Tanya lagi nanti"
];

async function handler(userId, client, msg, args) {
    const q = args.join(" ");
    if (!q) return client.sendMessage(msg.message.chatId, { message: "📖 .8ball [pertanyaan]" });
    const ans = ANSWERS[Math.floor(Math.random() * ANSWERS.length)];
    await client.sendMessage(msg.message.chatId, {
        message: `🎱 Pertanyaan: ${q}\n\n▸ Jawaban: ${ans}`
    });
}

module.exports = { command: "8ball", handler, description: "Magic 8-ball", category: "fun" };