const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const country = args.join(" ");
    if (!country) return client.sendMessage(chatId, { message: "📖 .country [nama negara]" });
    try {
        const r = await axios.get(`https://restcountries.com/v3.1/name/${encodeURIComponent(country)}`, { timeout: 15000 });
        const d = r.data?.[0];
        if (!d) throw new Error("Negara ga ditemukan");
        await client.sendMessage(chatId, {
            message:
                `🌍 ${d.name.common}\n\n` +
                `▸ Nama resmi: ${d.name.official}\n` +
                `▸ Ibukota: ${(d.capital || []).join(", ") || "-"}\n` +
                `▸ Populasi: ${d.population?.toLocaleString("id-ID") || "-"}\n` +
                `▸ Region: ${d.region || "-"}\n` +
                `▸ Mata uang: ${Object.values(d.currencies || {}).map(c => c.name).join(", ")}`
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "country", handler, description: "Info negara", category: "info" };