const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ");
    if (!text) return client.sendMessage(chatId, { message: "📖 .emoji [text]" });
    try {
        const r = await axios.get(`https://api.siputzx.my.id/api/tools/emojimix?emoji1=${encodeURIComponent(text)}`, { timeout: 15000 }).catch(() => null);
        if (r?.data?.data?.url) {
            const img = await axios.get(r.data.data.url, { responseType: "arraybuffer", timeout: 20000 });
            return client.sendFile(chatId, { file: Buffer.from(img.data), forceDocument: false });
        }
        throw new Error("Gagal");
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "emoji", handler, description: "Mix emoji", category: "text" };