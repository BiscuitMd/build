const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://api.thecatapi.com/v1/images/search", { timeout: 15000 });
        const url = r.data?.[0]?.url;
        if (!url) throw new Error("No image");
        const img = await axios.get(url, { responseType: "arraybuffer", timeout: 20000 });
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: "🐱 Meow!",
            forceDocument: false
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "cat", handler, description: "Random cat pic", category: "fun" };