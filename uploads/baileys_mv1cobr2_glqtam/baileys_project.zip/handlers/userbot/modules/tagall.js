async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const text = args.join(" ") || "📢 ATTENTION";

    try {
        const participants = await client.getParticipants(chatId);
        if (participants.length === 0) throw new Error("Gaada participant");

        let mentions = "";
        for (const p of participants) {
            mentions += `[${p.firstName || "User"}](tg://user?id=${p.id}) `;
        }

        await client.sendMessage(chatId, {
            message: `${text}\n\n${mentions}`,
            parseMode: "markdown"
        });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "tagall", handler, description: "Mention semua member", category: "group" };