const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const sub = args[0] || "memes";
    const loading = await client.sendMessage(chatId, { message: `⏳ r/${sub}...` });
    try {
        const r = await axios.get(`https://www.reddit.com/r/${sub}/hot.json?limit=50`, { headers: { "User-Agent": "SpartaX-Bot" }, timeout: 20000 });
        const posts = r.data?.data?.children?.filter(c => c.data.url && (c.data.url.endsWith(".jpg") || c.data.url.endsWith(".png") || c.data.url.endsWith(".jpeg") || c.data.url.endsWith(".gif")));
        if (!posts || posts.length === 0) throw new Error("No image post");
        const pick = posts[Math.floor(Math.random() * Math.min(posts.length, 30))].data;
        const img = await axios.get(pick.url, { responseType: "arraybuffer", timeout: 30000 });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendFile(chatId, {
            file: Buffer.from(img.data),
            caption: `🔥 ${pick.title.slice(0, 200)}\n▸ r/${sub} | ⬆️ ${pick.ups}`,
            forceDocument: false
        });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "reddit", handler, description: "Random post dari subreddit", category: "download" };