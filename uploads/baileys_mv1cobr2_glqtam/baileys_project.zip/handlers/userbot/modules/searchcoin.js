const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const query = args.join(" ");
    if (!query) return client.sendMessage(chatId, { message: "📖 .searchcoin [query]" });

    const loading = await client.sendMessage(chatId, { message: `🔍 Search coin...` });
    try {
        const r = await axios.get(`https://api.coingecko.com/api/v3/search?query=${encodeURIComponent(query)}`, { timeout: 15000 });
        const list = r.data?.coins || [];
        if (list.length === 0) throw new Error("Gaada hasil");

        let text = `🔍 SEARCH: ${query}\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        list.slice(0, 10).forEach((c, i) => {
            text += `${i + 1}. ${c.name} (${c.symbol})\n▸ ID: ${c.id}\n▸ Rank: #${c.market_cap_rank || "-"}\n\n`;
        });

        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "searchcoin", handler, description: "Search crypto by name", category: "crypto" };