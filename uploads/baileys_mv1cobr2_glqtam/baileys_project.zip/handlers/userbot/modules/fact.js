const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    try {
        const r = await axios.get("https://uselessfacts.jsph.pl/api/v2/facts/random?language=en", { timeout: 15000 });
        await client.sendMessage(chatId, { message: `🤓 FACT:\n\n${r.data.text}` });
    } catch (e) {
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 100)}` });
    }
}

module.exports = { command: "fact", handler, description: "Fun fact random", category: "fun" };