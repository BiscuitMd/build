const axios = require("axios");

async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const loading = await client.sendMessage(chatId, { message: "📰 Crypto news..." });
    try {
        const r = await axios.get("https://min-api.cryptocompare.com/data/v2/news/?lang=EN", { timeout: 15000 });
        const list = r.data?.Data || [];
        let text = `📰 CRYPTO NEWS\n\n━━━━━━━━━━━━━━━━━━━━\n`;
        list.slice(0, 8).forEach((n, i) => {
            text += `${i + 1}. ${n.title}\n▸ ${n.source} | ${new Date(n.published_on * 1000).toLocaleString("id-ID")}\n▸ ${n.url}\n\n`;
        });
        await client.deleteMessages(chatId, [loading.id], { revoke: true }).catch(() => {});
        await client.sendMessage(chatId, { message: text.slice(0, 4000) });
    } catch (e) {
        try { await client.deleteMessages(chatId, [loading.id], { revoke: true }); } catch {}
        await client.sendMessage(chatId, { message: `❌ ${e.message.slice(0, 150)}` });
    }
}

module.exports = { command: "cryptonews", handler, description: "Berita crypto terbaru", category: "crypto" };