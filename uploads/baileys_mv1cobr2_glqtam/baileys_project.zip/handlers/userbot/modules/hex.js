async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const mode = args[0]?.toLowerCase();
    const text = args.slice(1).join(" ");
    if (!mode || !text) return client.sendMessage(chatId, { message: "📖 .hex [encode/decode] [text]" });

    if (mode === "encode") {
        const out = Buffer.from(text, "utf8").toString("hex");
        return client.sendMessage(chatId, { message: out });
    }
    if (mode === "decode") {
        try {
            const out = Buffer.from(text, "hex").toString("utf8");
            return client.sendMessage(chatId, { message: out });
        } catch {
            return client.sendMessage(chatId, { message: "❌ Invalid hex" });
        }
    }
    await client.sendMessage(chatId, { message: "❌ Mode harus encode/decode" });
}

module.exports = { command: "hex", handler, description: "Encode/decode hex", category: "text" };