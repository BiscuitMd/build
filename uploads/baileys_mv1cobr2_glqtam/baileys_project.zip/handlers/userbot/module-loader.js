const fs = require("fs");
const path = require("path");

const MODULES_DIR = path.join(__dirname, "modules");
const MODULES = new Map();

// ═══ ICON SET ═══
const CATEGORY_ICON = {
    ai: "◈",
    download: "▣",
    fun: "✦",
    tools: "⚙",
    info: "◉",
    media: "▤",
    text: "▥",
    crypto: "◆",
    osint: "◎",
    admin: "▲",
    group: "▦",
    build: "▧",
    forward: "⇒",
    general: "▪",
    userbot: "●",
    music: "♫",
    panel: "■"
    security: "⚿",
    monitor: "◉",
    game: "◆",
};

function getCategoryEmoji(cat) {
    return CATEGORY_ICON[cat] || "▪";
}

// ═══════════════════════════════════════════
// LOAD ALL MODULES
// ═══════════════════════════════════════════
function loadAll() {
    if (!fs.existsSync(MODULES_DIR)) {
        console.log("[UBOT LOADER] folder modules gaada, skip");
        return;
    }

    const files = fs.readdirSync(MODULES_DIR).filter(f =>
        f.endsWith(".js") &&
        !f.startsWith("_") &&
        f !== "notif-generator.js"  // skip helper
    );

    let loaded = 0;
    let failed = 0;

    for (const file of files) {
        try {
            const modPath = path.join(MODULES_DIR, file);
            delete require.cache[require.resolve(modPath)];
            const mod = require(modPath);

            if (mod && mod.command && typeof mod.handler === "function") {
                MODULES.set(mod.command, mod);

                if (Array.isArray(mod.commands)) {
                    for (const c of mod.commands) {
                        if (!MODULES.has(c)) MODULES.set(c, mod);
                    }
                }

                loaded++;
            } else {
                failed++;
            }
        } catch (e) {
            failed++;
            console.log(`[UBOT LOADER] ✕ ${file} error: ${e.message.slice(0, 100)}`);
        }
    }

    console.log(`[UBOT LOADER] ✅ loaded: ${loaded} module | ⚠️ failed: ${failed}`);
    console.log(`[UBOT LOADER] Total module aktif: ${MODULES.size}`);
}

// ═══════════════════════════════════════════
// EXECUTE — Handler utama
// ═══════════════════════════════════════════
async function execute(userId, client, msg, cmd, args, bot) {
    // ═══ BUILD COMMAND (6 command build) ═══
    if (cmd === "build" || cmd.startsWith("build_")) {
        try {
            const build = require("./modules/build");
            if (build && typeof build.handler === "function") {
                await build.handler(userId, client, msg, args);
                return true;
            }
        } catch (e) {
            console.log("[UBOT CMD] .build err:", e.message.slice(0, 150));
            try {
                await client.sendMessage(msg.message.chatId, {
                    message: `✕ Error build: ${e.message.slice(0, 150)}`
                });
            } catch {}
            return true;
        }
    }

    // ═══ AUTOFW + ADDBL + DELBL + LISTBL ═══
    if (cmd === "autofw" || cmd === "addbl" || cmd === "delbl" || cmd === "listbl") {
        try {
            const autofw = require("./modules/autofw");
            if (autofw && typeof autofw.handler === "function") {
                await autofw.handler(userId, client, msg, args, bot);
                return true;
            }
        } catch (e) {
            console.log(`[UBOT CMD] .${cmd} err:`, e.message.slice(0, 150));
            try {
                await client.sendMessage(msg.message.chatId, {
                    message: `✕ Error ${cmd}: ${e.message.slice(0, 150)}`
                });
            } catch {}
            return true;
        }
    }

    // ═══ MENU + HELP — Handle di login.js ═══
    if (cmd === "menu" || cmd === "help" || cmd === "h" || cmd.startsWith("menu_")) {
        return false;
    }

    // ═══ MODULE NORMAL ═══
    const mod = MODULES.get(cmd);
    if (!mod) return false;

    try {
        await mod.handler(userId, client, msg, args, bot);
        return true;
    } catch (e) {
        console.log(`[UBOT CMD] .${cmd} err:`, e.message.slice(0, 150));
        try {
            await client.sendMessage(msg.message.chatId, {
                message: `✕ Error .${cmd}: ${e.message.slice(0, 150)}`
            });
        } catch {}
        return true;
    }
}

// ═══ LIST ALL MODULES ═══
function listModules() {
    const result = [];
    const seen = new Set();

    for (const [cmd, mod] of MODULES.entries()) {
        const key = mod.command;
        if (seen.has(key)) continue;
        seen.add(key);

        result.push({
            command: mod.command,
            description: mod.description || "",
            category: mod.category || "general"
        });
    }

    return result;
}

// ═══ GROUP BY CATEGORY ═══
function groupByCategory() {
    const list = listModules();
    const groups = {};
    for (const m of list) {
        const cat = m.category || "general";
        if (!groups[cat]) groups[cat] = [];
        groups[cat].push(m);
    }
    for (const cat in groups) {
        groups[cat].sort((a, b) => a.command.localeCompare(b.command));
    }
    return groups;
}

function getCategoryList() {
    const groups = groupByCategory();
    return Object.keys(groups).sort();
}

function getModulesByCategory(category) {
    const groups = groupByCategory();
    return groups[category] || [];
}

function countModules() {
    return listModules().length;
}

function hasModule(cmd) {
    return MODULES.has(cmd);
}

function searchModules(query) {
    const q = String(query || "").toLowerCase();
    if (!q) return [];

    return listModules().filter(m =>
        m.command.toLowerCase().includes(q) ||
        (m.description || "").toLowerCase().includes(q) ||
        (m.category || "").toLowerCase().includes(q)
    );
}

// ═══ INIT ═══
loadAll();

// ═══ EXPORT ═══
module.exports = {
    execute,
    listModules,
    groupByCategory,
    getCategoryList,
    getModulesByCategory,
    getCategoryEmoji,
    countModules,
    hasModule,
    searchModules,
    loadAll,
    MODULES,
    MODULES_DIR
};

console.log("[UBOT LOADER] module-loader v4 ready");