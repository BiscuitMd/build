const cfg = require("../config");

const COLORS = {
    success: { g1: "#10B981", g2: "#059669", label: "SUCCESS", icon: "✅", color: "#10B981" },
    failed: { g1: "#EF4444", g2: "#DC2626", label: "FAILED", icon: "✖️", color: "#EF4444" },
    info: { g1: "#3B82F6", g2: "#2563EB", label: "INFO", icon: "ℹ️", color: "#3B82F6" },
    warning: { g1: "#F59E0B", g2: "#D97706", label: "WARNING", icon: "⚠️", color: "#F59E0B" },
    user: { g1: "#8B5CF6", g2: "#7C3AED", label: "NEW USER", icon: "𖡛", color: "#8B5CF6" }
};

function escXml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

async function generateStatusImage({
    title = "NOTIFIKASI",
    subtitle = "",
    status = "info",
    fields = [],
    footer = ""
}) {
    const sharp = require("sharp");

    const W = 1000;
    const H = 500;
    const c = COLORS[status] || COLORS.info;

    const fieldRows = fields.slice(0, 6).map((f, i) => {
        const y = 240 + i * 42;
        return `
  <text x="80" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="18" fill="#94A3B8">${escXml(f.label)}</text>
  <text x="${W - 80}" y="${y}" font-family="Arial, Helvetica, sans-serif" font-size="18" font-weight="bold" fill="#FFFFFF" text-anchor="end">${escXml(String(f.value).slice(0, 40))}</text>
  <line x1="80" y1="${y + 12}" x2="${W - 80}" y2="${y + 12}" stroke="#334155" stroke-width="1" opacity="0.4"/>
        `;
    }).join("");

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F172A"/>
      <stop offset="50%" stop-color="#1E293B"/>
      <stop offset="100%" stop-color="#0F172A"/>
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${c.g1}"/>
      <stop offset="100%" stop-color="${c.g2}"/>
    </linearGradient>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <circle cx="80" cy="80" r="180" fill="${c.color}" opacity="0.08"/>
  <circle cx="${W - 80}" cy="${H - 80}" r="200" fill="${c.color}" opacity="0.06"/>

  <rect x="30" y="30" width="${W - 60}" height="${H - 60}" rx="20" fill="#FFFFFF" fill-opacity="0.04" stroke="${c.color}" stroke-width="2" stroke-opacity="0.4"/>

  <rect x="30" y="30" width="${W - 60}" height="6" rx="3" fill="url(#accent)"/>

  <text x="${W / 2}" y="85" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#94A3B8" text-anchor="middle" letter-spacing="3">𖡛 MULTI FUNGSI NOTIFICATION</text>

  <rect x="${W / 2 - 130}" y="115" width="260" height="50" rx="25" fill="${c.color}" opacity="0.15" stroke="${c.color}" stroke-width="2"/>
  <text x="${W / 2}" y="148" font-family="Arial, Helvetica, sans-serif" font-size="22" font-weight="bold" fill="${c.color}" text-anchor="middle" letter-spacing="2">${c.icon} ${c.label}</text>

  <text x="${W / 2}" y="200" font-family="Arial, Helvetica, sans-serif" font-size="28" font-weight="bold" fill="#FFFFFF" text-anchor="middle" letter-spacing="1">${escXml(title).slice(0, 45)}</text>

  ${subtitle ? `<text x="${W / 2}" y="225" font-family="Arial, Helvetica, sans-serif" font-size="14" fill="#94A3B8" text-anchor="middle">${escXml(subtitle).slice(0, 60)}</text>` : ""}

  ${fieldRows}

  ${footer ? `<text x="${W / 2}" y="${H - 45}" font-family="Arial, Helvetica, sans-serif" font-size="13" fill="#64748B" text-anchor="middle">${escXml(footer).slice(0, 80)}</text>` : ""}
</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendStatus(bot, {
    title,
    subtitle,
    status = "info",
    fields = [],
    footer,
    caption,
    chatId
}) {
    const target = chatId || cfg.NOTIF_CHANNEL;
    if (!target || target === "-1001234567890") {
        console.log("[NOTIFY] skip — NOTIF_CHANNEL default");
        return;
    }

    const finalCaption = caption || `<b>${COLORS[status].icon} ${title}</b>`;

    try {
        const img = await generateStatusImage({ title, subtitle, status, fields, footer });
        await bot.sendPhoto(target, img, { caption: finalCaption, parse_mode: "HTML" });
        console.log("[NOTIFY]", status, "OK");
    } catch (e) {
        console.log("[NOTIFY] sendPhoto FAIL:", e.message);
        try {
            await bot.sendMessage(target, finalCaption, { parse_mode: "HTML" });
        } catch (e2) {
            console.log("[NOTIFY] sendMessage FAIL:", e2.message);
        }
    }
}

async function notifySuccess(bot, title, fields = [], caption) {
    return sendStatus(bot, { title, status: "success", fields, caption });
}

async function notifyFailed(bot, title, fields = [], caption) {
    return sendStatus(bot, { title, status: "failed", fields, caption });
}

async function notifyInfo(bot, title, fields = [], caption) {
    return sendStatus(bot, { title, status: "info", fields, caption });
}

async function notifyUser(bot, user, extra = {}) {
    const name = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Unknown";
    const uname = user.username ? "@" + user.username : "-";

    return sendStatus(bot, {
        title: "USER BARU /START",
        status: "user",
        fields: [
            { label: "𖡛 Nama", value: name },
            { label: "𖡛 Username", value: uname },
            { label: "𖡛 User ID", value: String(user.id) },
            { label: "𖡛 Bahasa", value: user.language_code || "-" },
            { label: "𖡛 Waktu", value: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) },
            ...(extra.fields || [])
        ],
        caption:
            `<b>𖡛 USER BARU</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Nama</b>: ${name}\n` +
            `𖡛 <b>Username</b>: ${uname}\n` +
            `𖡛 <b>ID</b>: <code>${user.id}</code>\n` +
            `𖡛 <b>Waktu</b>: <code>${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
        footer: extra.footer || ""
    });
}

module.exports = {
    sendStatus,
    notifySuccess,
    notifyFailed,
    notifyInfo,
    notifyUser,
    generateStatusImage
};