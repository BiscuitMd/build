const router = require("./router");
const cfg = require("../config");
const ai = require("./ai-engine");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

// ═══ GITHUB BUILDER — safe require ═══
let gh = null;
try {
    gh = require("./github-builder");
    console.log("[AI CODE EDITOR] github-builder loaded");
} catch (e) {
    console.log("[AI CODE EDITOR] github-builder gaada, notif disabled:", e.message);
    gh = { sendBuildNotif: async () => {} };
}

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ CREDIT CHECK ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        try {
            return await bot.editMessageText(text.replace(/<[^>]+>/g, ""), {
                chat_id: chatId, message_id: msgId, ...options
            });
        } catch { return null; }
    }
}

// ═══ MENU ═══
router.registerCallback("menu_aicodeeditor", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < 1) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 AI CODE EDITOR</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Model: <b>Groq Llama 3.3 70B</b> (free)\n` +
            `▸ Biaya: <code>1 credit</code> / edit\n` +
            `▸ Support: <b>.dart, .js, .py, .json, .html, .css, .ts, .kt, .java, .php</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Mode:</b>\n` +
            `▸ 𖡛 Rombak Warna — ganti semua warna\n` +
            `▸ 𖡛 Tambah Fitur — tambah feature baru\n` +
            `▸ 𖡛 Fix Error — analisa + fix error\n` +
            `▸ 𖡛 Optimize — optimize performance\n` +
            `▸ 𖡛 Jelasin Code — jelasin kode lu\n` +
            `▸ 𖡛 Custom Prompt — kasih instruksi sendiri\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file code lu dulu (max 50KB).</i>`;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "aicode_await_file", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[AICODE MENU ERR]", e.message); }
});

// ═══ STEP 1: TERIMA FILE ═══
router.registerMessage("aicode_await_file", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        let code = "";
        let fileName = "code.txt";

        if (msg.document) {
            const fileSize = msg.document.file_size || 0;
            if (fileSize > 50 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 50KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                code = res.data;
                fileName = msg.document.file_name || "code.txt";
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            code = msg.text;
            fileName = "input.txt";
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim file code (.dart / .js / .py) atau ketik langsung.</b>`, { parse_mode: "HTML" });
        }

        if (!code || code.length < 10) {
            return bot.sendMessage(chatId, `<b>✕ Code terlalu pendek.</b>`, { parse_mode: "HTML" });
        }

        if (code.length > 50000) {
            return bot.sendMessage(chatId, `<b>✕ Code terlalu panjang! Max 50KB.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);
        ctx.setState(userId, "aicode_pick_mode", { code, fileName });

        const kb = [
            [
                { text: "𖡛 Rombak Warna", callback_data: "aicode_mode:color", style: "primary" },
                { text: "𖡛 Tambah Fitur", callback_data: "aicode_mode:feature", style: "success" }
            ],
            [
                { text: "𖡛 Fix Error", callback_data: "aicode_mode:fix", style: "primary" },
                { text: "𖡛 Optimize", callback_data: "aicode_mode:optimize", style: "success" }
            ],
            [
                { text: "𖡛 Jelasin Code", callback_data: "aicode_mode:explain", style: "primary" },
                { text: "𖡛 Custom Prompt", callback_data: "aicode_mode:custom", style: "success" }
            ],
            [{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]
        ];

        await bot.sendMessage(chatId,
            `<b>✓ CODE DITERIMA</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName)}</code>\n` +
            `▸ Size: ${(code.length / 1024).toFixed(2)} KB\n` +
            `▸ Baris: ${code.split("\n").length}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih mode:</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[AICODE FILE ERR]", e.message); }
});

// ═══ STEP 2: PILIH MODE ═══
router.registerCallback("aicode_mode", async (bot, q, data, user, ctx) => {
    try {
        const mode = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);

        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis, kirim file ulang", show_alert: true });
        }

        // COLOR
        if (mode === "color") {
            ctx.setState(userId, "aicode_pick_color", { code: st.code, fileName: st.fileName });
            const kb = [
                [{ text: "𖡛 Emas + Putih + Biru", callback_data: "aicode_palette:emas_putih_biru", style: "success" }],
                [{ text: "𖡛 Biru Tua + Ungu", callback_data: "aicode_palette:biru_tua_ungu", style: "primary" }],
                [{ text: "𖡛 Merah + Pink", callback_data: "aicode_palette:merah_pink", style: "danger" }],
                [{ text: "𖡛 Pink + Hitam", callback_data: "aicode_palette:pink_hitam", style: "primary" }],
                [{ text: "𖡛 Hitam + Emas + Putih", callback_data: "aicode_palette:hitam_emas_putih", style: "success" }],
                [{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]
            ];
            return bot.sendMessage(q.message.chat.id,
                `<b>𖡛 ROMBAK WARNA</b>\n\nPilih palet warna baru:`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }

        // FEATURE
        if (mode === "feature") {
            ctx.setState(userId, "aicode_pick_feature", { code: st.code, fileName: st.fileName });
            const features = [
                { id: "weather", label: "𖡛 Cek Cuaca" },
                { id: "prayer", label: "𖡛 Jam Sholat" },
                { id: "puzzle", label: "𖡛 Game Puzzle" },
                { id: "chess", label: "𖡛 Game Catur" },
                { id: "billiard", label: "𖡛 Game Billiard" },
                { id: "chat", label: "𖡛 Chat Public" },
                { id: "savings", label: "𖡛 Menabung QRIS" },
                { id: "ai_helper", label: "𖡛 AI Helper" },
                { id: "bug_test", label: "𖡛 Test Function Bug" }
            ];
            const kb = [];
            for (let i = 0; i < features.length; i += 2) {
                const row = [{ text: features[i].label, callback_data: `aicode_feature:${features[i].id}`, style: "primary" }];
                if (features[i + 1]) row.push({ text: features[i + 1].label, callback_data: `aicode_feature:${features[i + 1].id}`, style: "primary" });
                kb.push(row);
            }
            kb.push([{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]);
            return bot.sendMessage(q.message.chat.id,
                `<b>𖡛 TAMBAH FITUR</b>\n\nPilih fitur yang mau ditambahin:`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }

        // FIX
        if (mode === "fix") {
            ctx.setState(userId, "aicode_fix_error", { code: st.code, fileName: st.fileName });
            return bot.sendMessage(q.message.chat.id,
                `<b>𖡛 FIX ERROR</b>\n\n` +
                `Kirim <b>error message</b> atau <b>file log error</b>.\n\n` +
                `<i>Contoh:</i>\n` +
                `<code>Compiler message: 'xxx' is not defined</code>\n\n` +
                `<i>Kalo gaada error, kirim "skip".</i>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] } });
        }

        // CUSTOM
        if (mode === "custom") {
            ctx.setState(userId, "aicode_custom_prompt", { code: st.code, fileName: st.fileName });
            return bot.sendMessage(q.message.chat.id,
                `<b>𖡛 CUSTOM PROMPT</b>\n\n` +
                `Kirim instruksi lu ke AI.\n\n` +
                `<b>Contoh:</b>\n` +
                `▸ <code>Tambah dark mode di seluruh app</code>\n` +
                `▸ <code>Ubah semua button jadi rounded</code>\n` +
                `▸ <code>Ganti font jadi Google Fonts Poppins</code>\n` +
                `▸ <code>Bikin splash screen animasi</code>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] } });
        }

        // OPTIMIZE / EXPLAIN
        if (mode === "optimize" || mode === "explain") {
            const loading = await bot.sendMessage(q.message.chat.id,
                `<b>𖡛 Processing...</b>\n\n<i>Mode: ${mode}</i>`,
                { parse_mode: "HTML" });

            await bot.answerCallbackQuery(q.id).catch(() => {});
            return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
                mode,
                code: st.code,
                fileName: st.fileName
            });
        }
    } catch (e) {
        console.log("[AICODE MODE ERR]", e.message);
    }
});

// ═══ CALLBACK: PILIH PALET ═══
router.registerCallback("aicode_palette", async (bot, q, data, user, ctx) => {
    try {
        const palette = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);
        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });
        }
        await bot.answerCallbackQuery(q.id).catch(() => {});
        const loading = await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 Rombak Warna...</b>\n\n<i>Palet: ${palette}</i>`,
            { parse_mode: "HTML" });
        return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
            mode: "color", code: st.code, palette, fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE PALETTE ERR]", e.message); }
});

// ═══ CALLBACK: PILIH FITUR ═══
router.registerCallback("aicode_feature", async (bot, q, data, user, ctx) => {
    try {
        const feature = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);
        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });
        }
        await bot.answerCallbackQuery(q.id).catch(() => {});
        const loading = await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 Tambah Fitur...</b>\n\n<i>Fitur: ${feature}</i>`,
            { parse_mode: "HTML" });
        return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
            mode: "feature", code: st.code, feature, fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE FEATURE ERR]", e.message); }
});

// ═══ MESSAGE: FIX ERROR ═══
router.registerMessage("aicode_fix_error", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const userId = String(msg.from.id);
        const chatId = msg.chat.id;
        const st = state;

        if (!st || !st.code) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi habis, kirim ulang code lu.</b>`, { parse_mode: "HTML" });
        }

        let errorMsg = "";

        if (msg.document) {
            if (msg.document.file_size > 200 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 200KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                errorMsg = String(res.data).slice(0, 5000);
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            errorMsg = msg.text.trim();
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim error message atau file log error.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 Fix Error...</b>`,
            { parse_mode: "HTML" });

        return processEdit(bot, chatId, loading.message_id, userId, ctx, {
            mode: "fix", code: st.code,
            errorMsg: errorMsg.toLowerCase() === "skip" ? "" : errorMsg,
            fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE FIX ERROR ERR]", e.message); }
});

// ═══ MESSAGE: CUSTOM PROMPT ═══
router.registerMessage("aicode_custom_prompt", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const userId = String(msg.from.id);
        const chatId = msg.chat.id;
        const st = state;
        const customPrompt = (msg.text || "").trim();

        if (!st || !st.code) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi habis, kirim ulang code lu.</b>`, { parse_mode: "HTML" });
        }

        if (!customPrompt || customPrompt.length < 3) {
            return bot.sendMessage(chatId, `<b>✕ Prompt terlalu pendek.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 Custom Prompt...</b>\n\n<i>${escHtml(customPrompt.slice(0, 100))}</i>`,
            { parse_mode: "HTML" });

        return processEdit(bot, chatId, loading.message_id, userId, ctx, {
            mode: "custom", code: st.code, customPrompt, fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE CUSTOM ERR]", e.message); }
});

// ═══ CANCEL ═══
router.registerCallback("aicode_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[AICODE CANCEL ERR]", e.message); }
});

// ═══ PROCESS EDIT — CORE ═══
async function processEdit(bot, chatId, loadingMsgId, userId, ctx, params) {
    try {
        console.log(`[AICODE PROCESS] mode: ${params.mode} | code: ${params.code.length} chars`);

        // Cek credit
        const c = checkAndDeductCredit(ctx, { id: userId }, 1);
        if (!c.ok) {
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ ${c.error}</b>\n\n<i>Beli credit dulu ya~</i>`,
                { reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] } });
        }

        // Update loading
        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 AI sedang kerja...</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <code>${params.mode}</code>\n` +
            `▸ Code: ${(params.code.length / 1024).toFixed(2)} KB\n` +
            `▸ Provider: <b>Groq</b>\n` +
            `▸ Status: <i>Processing...</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mohon tunggu 5-15 detik...</i>`);

        // Call AI
        let result;
        try {
            result = await ai.editCode({
                mode: params.mode,
                code: params.code,
                palette: params.palette || "",
                feature: params.feature || "",
                errorMsg: params.errorMsg || "",
                customPrompt: params.customPrompt || ""
            });
        } catch (e) {
            console.log("[AICODE EDIT ERR]", e.message);
            result = { ok: false, error: e.message };
        }

        if (!result || !result.ok) {
            const errMsg = (result?.error || "Unknown error").slice(0, 300);
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal process</b>\n\n<code>${escHtml(errMsg)}</code>\n\n` +
                `<i>Coba lagi beberapa saat.</i>`,
                { reply_markup: { inline_keyboard: [[
                    { text: "𖡛 Coba Lagi", callback_data: "menu_aicodeeditor", style: "primary" },
                    { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
                ]] } });
        }

        // Bersihin markdown
        let cleanText = String(result.text || "");
        cleanText = cleanText.replace(/^```(?:dart|javascript|js|python|py|json|html|css|ts|typescript|kotlin|kt|java|php|xml|yaml|yml|bash|sh)?\n?/i, "");
        cleanText = cleanText.replace(/\n?```$/i, "");
        cleanText = cleanText.trim();

        if (!cleanText || cleanText.length < 10) {
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Response AI kosong.</b>\n\n<i>Coba lagi dengan mode lain.</i>`,
                { reply_markup: { inline_keyboard: [[
                    { text: "𖡛 Coba Lagi", callback_data: "menu_aicodeeditor", style: "primary" },
                    { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
                ]] } });
        }

        // Bikin file baru
        const ext = path.extname(params.fileName) || ".txt";
        const baseName = path.basename(params.fileName, ext) || "code";
        const newFileName = `${baseName}_edited${ext}`;
        const newFilePath = path.join(TMP_DIR, `${Date.now()}_${newFileName}`);

        fs.writeFileSync(newFilePath, cleanText, "utf8");

        // Update loading
        await safeEdit(bot, chatId, loadingMsgId,
            `<b>✓ HASIL EDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <code>${params.mode}</code>\n` +
            `▸ File: <code>${newFileName}</code>\n` +
            `▸ Size: ${(cleanText.length / 1024).toFixed(2)} KB\n` +
            `▸ Provider: <code>${result.model || "groq"}</code>\n` +
            `▸ Credit sisa: ${c.credit}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File dikirim di bawah.</i>`);

        // Kirim file
        let sendOk = false;
        try {
            await bot.sendDocument(chatId, newFilePath, {
                caption:
                    `<b>𖡛 AI CODE EDITOR RESULT</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Mode: <code>${params.mode}</code>\n` +
                    `▸ File: <code>${newFileName}</code>\n` +
                    `▸ Provider: <code>${result.model || "groq"}</code>\n` +
                    `▸ Size: ${(cleanText.length / 1024).toFixed(2)} KB\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<i>Copy isi file → timpa file lama di project lu.</i>`,
                parse_mode: "HTML"
            }, { filename: newFileName, contentType: "text/plain" });
            sendOk = true;
        } catch (e) {
            console.log("[AICODE SEND FILE ERR]", e.message);

            const preview = cleanText.slice(0, 3500);
            try {
                await bot.sendMessage(chatId,
                    `<b>𖡛 HASIL (fallback text)</b>\n\n` +
                    `<b>File:</b> <code>${newFileName}</code>\n\n` +
                    `<pre>${escHtml(preview)}</pre>` +
                    (cleanText.length > 3500 ? `\n\n<i>...dipotong (file asli ${(cleanText.length / 1024).toFixed(2)} KB)</i>` : ""),
                    { parse_mode: "HTML" });
                sendOk = true;
            } catch (e2) {
                console.log("[AICODE SEND TEXT ERR]", e2.message);
            }
        }

        try { fs.unlinkSync(newFilePath); } catch {}

        if (!sendOk) {
            await safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal kirim file.</b>\n\n<i>Coba lagi.</i>`,
                { reply_markup: { inline_keyboard: [[
                    { text: "𖡛 Menu", callback_data: "menu_back", style: "danger" }
                ]] } });
            return;
        }

        // Notif channel
        try {
            await gh.sendBuildNotif(bot, {
                status: "success",
                title: `AI Code Editor — ${params.mode}`,
                subtitle: params.fileName,
                fields: [
                    { label: "Mode", value: params.mode },
                    { label: "File", value: params.fileName.slice(0, 30) },
                    { label: "Size", value: (cleanText.length / 1024).toFixed(2) + " KB" },
                    { label: "Provider", value: result.model || "groq" },
                    { label: "Credit", value: String(c.credit) }
                ],
                footer: `User: ${userId}`
            });
        } catch (e) {
            console.log("[AICODE NOTIF ERR]", e.message.slice(0, 100));
        }

        console.log(`[AICODE PROCESS] ✅ done | provider: ${result.model}`);
    } catch (e) {
        console.log("[AICODE PROCESS ERR]", e.message);
        console.log("[AICODE PROCESS STACK]", e.stack);
        await safeEdit(bot, chatId, loadingMsgId,
            `<b>✕ Error:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`);
    }
}

module.exports = {};
console.log("[AI CODE EDITOR] module loaded (v4 — Groq sync)");