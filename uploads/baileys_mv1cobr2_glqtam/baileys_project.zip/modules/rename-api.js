// ═══════════════════════════════════════════
// RENAME API — Rename API base project
// v2 — Case-insensitive replace, fix "ga nemu pattern"
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const gh = require("./github-builder");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("EFATAL") || msg.includes("AggregateError")) {
            await new Promise(r => setTimeout(r, 3000));
            try {
                return await bot.editMessageText(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch { return null; }
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch { return null; }
        }
        if (msg.includes("message is not modified")) return null;
        return null;
    }
}

const SKIP_DIRS = new Set([
    "node_modules", ".git", ".github", "build", "dist",
    ".gradle", "__pycache__", ".vscode", ".idea",
    "venv", "env", ".venv", "target", "out", "bin", "obj"
]);

const TEXT_EXTS = [
    ".js", ".ts", ".mjs", ".cjs", ".json", ".env", ".txt",
    ".yml", ".yaml", ".config", ".conf", ".ini", ".properties",
    ".html", ".htm", ".css", ".scss", ".md", ".xml",
    ".py", ".php", ".java", ".kt", ".dart", ".rb", ".go", ".rs", ".sh", ".bash"
];

function findAllFiles(dir, results = []) {
    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); }
    catch { return results; }

    for (const item of items) {
        const full = path.join(dir, item.name);
        if (item.isDirectory()) {
            if (SKIP_DIRS.has(item.name)) continue;
            findAllFiles(full, results);
        } else {
            results.push(full);
        }
    }
    return results;
}

function isTextFile(file) {
    const ext = path.extname(file).toLowerCase();
    const base = path.basename(file).toLowerCase();
    const isEnvFile = base.startsWith(".env") || base === ".gitignore" || base === "dockerfile" || base === "makefile" || base === "procfile" || base === "readme.md";
    if (!TEXT_EXTS.includes(ext) && !isEnvFile) return false;

    try {
        const fd = fs.openSync(file, "r");
        const buf = Buffer.alloc(8192);
        const bytesRead = fs.readSync(fd, buf, 0, 8192, 0);
        fs.closeSync(fd);
        for (let i = 0; i < bytesRead; i++) {
            if (buf[i] === 0) return false;
        }
        return true;
    } catch {
        return false;
    }
}

function escapeRegex(str) {
    return String(str).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// ═══ API RENAME TYPES ═══
// Semua tipe pake pendekatan "cari oldValue di file, ganti jadi newValue"
// Biar fleksibel apapun formatnya (PORT=3000, PORT: 3000, "PORT": 3000, dll)
const API_RENAME_TYPES = {
    port: {
        id: "port",
        label: "Port",
        desc: "Ubah port server di .env, index.js, config.js",
        hintLama: "Contoh: 3000",
        hintBaru: "Contoh: 8080",
        // Keyword yang nunjukin konteks port
        contextKeywords: ["PORT", "port", "Port", "PORT_SERVER", "SERVER_PORT"]
    },
    tokenbot: {
        id: "tokenbot",
        label: "Token Bot",
        desc: "Ubah token bot Telegram",
        hintLama: "Contoh: 1234567890:OLD_TOKEN_XXX",
        hintBaru: "Contoh: 1234567890:NEW_TOKEN_XXX",
        contextKeywords: ["BOT_TOKEN", "TOKEN_BOT", "bot_token", "botToken", "telegram_token"]
    },
    username: {
        id: "username",
        label: "Username / Owner",
        desc: "Ubah username / owner di config",
        hintLama: "Contoh: oldusername",
        hintBaru: "Contoh: newusername",
        contextKeywords: ["USERNAME", "OWNER", "owner_username", "ownerUsername", "OWNER_USERNAME", "owner_id", "OWNER_ID"]
    },
    link: {
        id: "link",
        label: "Link / Domain",
        desc: "Ubah semua link / domain di config",
        hintLama: "Contoh: https://olddomain.com",
        hintBaru: "Contoh: https://newdomain.com",
        contextKeywords: ["LINK_GROUP", "GROUP_LINK", "BASE_URL", "WEB_URL", "url", "link", "BASE_DOMAIN", "DOMAIN"]
    },
    nama: {
        id: "nama",
        label: "Nama Bot / Script",
        desc: "Ubah nama bot / script",
        hintLama: "Contoh: OldBotName",
        hintBaru: "Contoh: NewBotName",
        contextKeywords: ["BOT_NAME", "NAMA_BOT", "SCRIPT_NAME", "bot_name", "script_name", "app_name"]
    }
};

function scanForOldValue(extractDir, type, oldValue) {
    const allFiles = findAllFiles(extractDir);
    const found = [];
    const oldLower = String(oldValue).toLowerCase();

    for (const file of allFiles) {
        try {
            if (!isTextFile(file)) continue;
            const content = fs.readFileSync(file, "utf8");
            const contentLower = content.toLowerCase();

            if (contentLower.includes(oldLower)) {
                found.push(path.relative(extractDir, file));
            }
        } catch {}
    }
    return found;
}

function replaceApiValue(extractDir, type, oldValue, newValue) {
    const allFiles = findAllFiles(extractDir);
    const results = [];
    const oldEsc = escapeRegex(oldValue);
    // Regex exact match case-insensitive
    const regex = new RegExp(oldEsc, "gi");

    for (const file of allFiles) {
        try {
            if (!isTextFile(file)) continue;
            const content = fs.readFileSync(file, "utf8");
            const matches = content.match(regex);
            if (!matches || matches.length === 0) continue;

            const newContent = content.replace(regex, newValue);
            if (newContent === content) continue;

            fs.writeFileSync(file, newContent, "utf8");
            results.push({
                path: path.relative(extractDir, file),
                matches: matches.length
            });
        } catch (e) {
            console.log("[RENAME API] skip:", file, e.message);
        }
    }

    return results;
}

// ═══ MENU ═══
router.registerCallback("menu_renameapi", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < cfg.CREDIT_PER_USE) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>▸ RENAME API</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Support: Port, Token Bot, Username, Link, Nama\n` +
            `▸ Kirim: <b>file .zip</b> API base\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Cara kerja:</b>\n` +
            `1. Upload API .zip\n` +
            `2. Pilih tipe rename\n` +
            `3. Kirim nilai LAMA\n` +
            `4. Kirim nilai BARU\n` +
            `5. Bot kirim file hasil\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mulai dengan kirim file .zip:</i>`;

        ctx.clearState(user.id);
        ctx.setState(user.id, "renameapi_await_zip", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renameapi_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[RENAME API MENU ERR]", e.message); }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("renameapi_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "api.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        if (msg.document.file_size > 20 * 1024 * 1024) {
            return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 20MB.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>▸ Menerima API zip</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(1)}]</code> <b>1%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Download file...</i>`,
            { parse_mode: "HTML" });

        const jobId = gh.newJobId("renameapi");
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        let zipPath;
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const res = await axios.get(fileLink, {
                responseType: "arraybuffer",
                timeout: 60000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            zipPath = path.join(workDir, fname);
            fs.writeFileSync(zipPath, Buffer.from(res.data));
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download:</b>\n<code>${e.message.slice(0, 200)}</code>`);
        }

        ctx.clearState(userId);
        ctx.setState(userId, "renameapi_pick_type", { jobId, zipPath, fname });

        const kb = Object.values(API_RENAME_TYPES).map(t => ([
            { text: "▸ " + t.label, callback_data: `renameapi_type:${t.id}` }
        ]));
        kb.push([{ text: "✕ Batal", callback_data: "renameapi_cancel", style: "danger" }]);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ RENAME API — Pilih Tipe</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Job: <code>${jobId}</code>\n` +
            `▸ File: <code>${fname}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih tipe:</b>`,
            { reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[RENAME API AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ PILIH TIPE — Minta LAMA ═══
router.registerCallback("renameapi_type", async (bot, q, data, user, ctx) => {
    try {
        await bot.answerCallbackQuery(q.id, { text: "Memproses...", show_alert: false }).catch(() => {});

        const typeId = data.split(":")[1];
        const type = API_RENAME_TYPES[typeId];

        if (!type) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Tipe invalid</b>`, { parse_mode: "HTML" });
        }

        const prev = ctx.getState(user.id) || {};
        if (!prev.jobId || !prev.zipPath) {
            ctx.clearState(user.id);
            return bot.sendMessage(q.message.chat.id, `<b>✕ Sesi hilang.</b>`, { parse_mode: "HTML" });
        }

        ctx.setState(user.id, "renameapi_await_old", {
            typeId,
            jobId: prev.jobId,
            zipPath: prev.zipPath,
            fname: prev.fname
        });

        await bot.sendMessage(q.message.chat.id,
            `<b>▸ ${type.label.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Info: ${type.desc}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Langkah 1/2: Kirim nilai LAMA</b>\n\n` +
            `▸ Format: <code>${type.hintLama}</code>\n\n` +
            `<i>Ini nilai yang ada di API lu sekarang.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renameapi_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[RENAME API TYPE ERR]", e.message); }
});

// ═══ TERIMA LAMA — Verifikasi + Minta BARU ═══
router.registerMessage("renameapi_await_old", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const oldValue = (msg.text || "").trim();

        if (!oldValue) {
            return bot.sendMessage(chatId, `<b>✕ Kirim nilai lama.</b>`, { parse_mode: "HTML" });
        }

        const type = API_RENAME_TYPES[state.typeId];
        const { jobId, zipPath } = state;

        workDir = path.join(TMP_DIR, jobId);
        const extractDir = path.join(workDir, "extracted");
        if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

        if (!fs.existsSync(path.join(extractDir, ".extracted"))) {
            try {
                const zip = new AdmZip(zipPath);
                zip.extractAllTo(extractDir, true);
                fs.writeFileSync(path.join(extractDir, ".extracted"), "1");
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal extract:</b>\n<code>${e.message.slice(0, 200)}</code>`, { parse_mode: "HTML" });
            }
        }

        const foundFiles = scanForOldValue(extractDir, type, oldValue);

        let reportText = `<b>🔍 VERIFIKASI NILAI LAMA</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Tipe: <b>${type.label}</b>\n` +
            `▸ Nilai lama: <code>${oldValue}</code>\n` +
            `▸ Ditemukan di: <code>${foundFiles.length}</code> file\n`;

        if (foundFiles.length > 0) {
            reportText += `━━━━━━━━━━━━━━━━━━━━\n<b>File:</b>\n`;
            for (const f of foundFiles.slice(0, 10)) reportText += `▸ <code>${f}</code>\n`;
            if (foundFiles.length > 10) reportText += `▸ <i>...dan ${foundFiles.length - 10} file lain</i>\n`;
        }

        reportText += `━━━━━━━━━━━━━━━━━━━━\n\n`;

        if (foundFiles.length === 0) {
            reportText += `⚠️ <b>Nilai lama TIDAK ditemukan!</b>\n\n<i>Cek lagi nilai lama lu.</i>`;
        } else {
            reportText += `<b>Langkah 2/2: Kirim nilai BARU</b>\n\n▸ Format: <code>${type.hintBaru}</code>`;
        }

        ctx.setState(userId, "renameapi_await_new", {
            typeId: state.typeId,
            jobId,
            zipPath,
            fname: state.fname,
            oldValue
        });

        await bot.sendMessage(chatId, reportText, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renameapi_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[RENAME API OLD ERR]", e.message); }
});

// ═══ TERIMA BARU — Proses ═══
router.registerMessage("renameapi_await_new", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const newValue = (msg.text || "").trim();

        if (!newValue) return bot.sendMessage(chatId, `<b>✕ Kirim nilai baru.</b>`, { parse_mode: "HTML" });

        const { typeId, jobId, zipPath, fname, oldValue } = state;
        const type = API_RENAME_TYPES[typeId];

        if (!jobId || !zipPath || !typeId) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi hilang.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);

        const loading = await bot.sendMessage(chatId,
            `<b>▸ Memproses Rename API</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(10)}]</code> <b>10%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Lama: <code>${oldValue}</code>\n` +
            `▸ Baru: <code>${newValue}</code>\n` +
            `<i>Processing...</i>`,
            { parse_mode: "HTML" });

        workDir = path.join(TMP_DIR, jobId);
        const extractDir = path.join(workDir, "extracted");

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ Memproses</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(30)}]</code> <b>30%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Scan file...</i>`);

        const changes = replaceApiValue(extractDir, type, oldValue, newValue);
        console.log("[RENAME API] changes:", JSON.stringify(changes));

        let replacedCount = changes.length;
        let totalMatches = changes.reduce((a, c) => a + c.matches, 0);
        const filesProcessed = changes.map(c => c.path);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ Memproses</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(80)}]</code> <b>80%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Membuat zip...</i>`);

        if (replacedCount === 0) {
            await safeEdit(bot, chatId, loading.message_id,
                `<b>⚠️ GA ADA PERUBAHAN</b>\n\n` +
                `▸ Tipe: <b>${type.label}</b>\n` +
                `▸ Lama: <code>${oldValue}</code>\n` +
                `▸ Baru: <code>${newValue}</code>`,
                { parse_mode: "HTML" });
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return;
        }

        const outputZipPath = path.join(workDir, `renamed_${fname}`);
        try {
            const newZip = new AdmZip();
            newZip.addLocalFolder(extractDir);
            newZip.writeZip(outputZipPath);
        } catch (e) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal zip:</b>\n<code>${e.message.slice(0, 200)}</code>`);
        }

        const stat = fs.statSync(outputZipPath);
        const preview = filesProcessed.slice(0, 15).map(f => `▸ <code>${f}</code>`).join("\n");
        const more = filesProcessed.length > 15 ? `\n▸ <i>...dan ${filesProcessed.length - 15} file lain</i>` : "";

        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        try {
            await bot.sendDocument(chatId, outputZipPath, {
                caption:
                    `<b>✓ RENAME API SUCCESS</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Job: <code>${jobId}</code>\n` +
                    `▸ Tipe: <b>${type.label}</b>\n` +
                    `▸ Lama: <code>${oldValue}</code>\n` +
                    `▸ Baru: <code>${newValue}</code>\n` +
                    `▸ File diubah: <code>${replacedCount}</code>\n` +
                    `▸ Total match: <code>${totalMatches}</code>\n` +
                    `▸ Size: ${(stat.size / 1024).toFixed(2)} KB\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<b>File:</b>\n${preview}${more}`,
                parse_mode: "HTML"
            }, { filename: `renamed_${fname}`, contentType: "application/zip" });
        } catch {
            await bot.sendMessage(chatId, `<b>✓ SUCCESS</b> tapi gagal kirim file.`, { parse_mode: "HTML" });
        }

        try {
            await buildNotifier.sendBuildNotif(bot, {
                status: "success",
                feature: `Rename API — ${type.label}`,
                baseName: fname,
                user: { id: userId, first_name: msg.from.first_name || "User", username: msg.from.username },
                subtitle: `${replacedCount} file diubah`,
                fields: [
                    { label: "Tipe", value: type.label },
                    { label: "Lama", value: oldValue },
                    { label: "Baru", value: newValue },
                    { label: "Files", value: String(replacedCount) }
                ]
            });
        } catch {}

        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    } catch (e) {
        console.log("[RENAME API NEW ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ CANCEL ═══
router.registerCallback("renameapi_cancel", async (bot, q, data, user, ctx) => {
    try {
        const st = ctx.getState(user.id);
        if (st && st.jobId) {
            const workDir = path.join(TMP_DIR, st.jobId);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        }
        ctx.clearState(user.id);
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[RENAME API CANCEL ERR]", e.message); }
});

module.exports = { API_RENAME_TYPES, replaceApiValue, scanForOldValue };
console.log("[RENAME API] module loaded");