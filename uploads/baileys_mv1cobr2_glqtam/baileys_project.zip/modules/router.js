const path = require("path");

const handlers = {};

// ═══════════════════════════════════════════
// REGISTER CALLBACK
// ═══════════════════════════════════════════
function registerCallback(prefix, fn) {
    if (handlers[prefix]) {
        console.log("[ROUTER] DUPLIKAT callback:", prefix, "— overwriting");
    }
    handlers[prefix] = fn;
}

function registerMessage(state, fn) {
    if (handlers["msg:" + state]) {
        console.log("[ROUTER] DUPLIKAT state:", state, "— overwriting");
    }
    handlers["msg:" + state] = fn;
}

// ═══════════════════════════════════════════
// AUTO-WRAP
// ═══════════════════════════════════════════
async function wrapAndExecute(handler, bot, q, data, user, ctx) {
    const originalSendMessage = bot.sendMessage.bind(bot);
    const originalSendPhoto = bot.sendPhoto.bind(bot);
    const originalEditMessageText = bot.editMessageText.bind(bot);
    const originalEditMessageCaption = bot.editMessageCaption.bind(bot);
    const originalEditMessageMedia = bot.editMessageMedia.bind(bot);

    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const hasPhoto = !!q.message.photo;

    bot.sendMessage = async (targetChatId, text, options = {}) => {
        if (String(targetChatId) === String(chatId)) {
            try {
                return await originalEditMessageText(text, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: options.parse_mode || "HTML",
                    ...(options.reply_markup ? { reply_markup: options.reply_markup } : {})
                });
            } catch (e) {
                const m = e.message || "";
                if (m.includes("message is not modified")) return { ok: true };
                if (m.includes("there is no text in the message to edit") && hasPhoto) {
                    try {
                        return await originalEditMessageCaption(text, {
                            chat_id: chatId,
                            message_id: msgId,
                            parse_mode: options.parse_mode || "HTML",
                            ...(options.reply_markup ? { reply_markup: options.reply_markup } : {})
                        });
                    } catch {}
                }
                if (m.includes("message to edit not found") || m.includes("MESSAGE_ID_INVALID")) {
                    return originalSendMessage(targetChatId, text, options);
                }
                return originalSendMessage(targetChatId, text, options);
            }
        }
        return originalSendMessage(targetChatId, text, options);
    };

    bot.sendPhoto = async (targetChatId, photo, options = {}) => {
        if (String(targetChatId) === String(chatId)) {
            const caption = options.caption || "";
            const replyMarkup = options.reply_markup || {};

            if (hasPhoto) {
                try {
                    return await originalEditMessageCaption(caption, {
                        chat_id: chatId,
                        message_id: msgId,
                        parse_mode: options.parse_mode || "HTML",
                        reply_markup: replyMarkup
                    });
                } catch (e) {
                    const m = e.message || "";
                    if (m.includes("message is not modified")) return { ok: true };
                    try {
                        return await bot.editMessageReplyMarkup(replyMarkup, {
                            chat_id: chatId,
                            message_id: msgId
                        });
                    } catch (e2) {}
                }
            } else {
                try {
                    return await originalEditMessageMedia({
                        type: "photo",
                        media: photo,
                        caption: caption,
                        parse_mode: options.parse_mode || "HTML"
                    }, {
                        chat_id: chatId,
                        message_id: msgId,
                        reply_markup: replyMarkup
                    });
                } catch (e) {
                    const m = e.message || "";
                    if (m.includes("message is not modified")) return { ok: true };
                }
            }
            return originalSendPhoto(targetChatId, photo, options);
        }
        return originalSendPhoto(targetChatId, photo, options);
    };

    try {
        return await handler(bot, q, data, user, ctx);
    } catch (err) {
        console.log("[CB WRAPPED ERR]", err.message);
        throw err;
    } finally {
        bot.sendMessage = originalSendMessage;
        bot.sendPhoto = originalSendPhoto;
        bot.editMessageText = originalEditMessageText;
        bot.editMessageCaption = originalEditMessageCaption;
        bot.editMessageMedia = originalEditMessageMedia;
    }
}

// ═══════════════════════════════════════════
// ROUTE CALLBACK QUERY
// ═══════════════════════════════════════════
async function routeCallback(bot, q, data, user, ctx) {
    if (!q || !q.from || !q.message) {
        console.log("[ROUTER] invalid callback query");
        return bot.answerCallbackQuery(q?.id || "").catch(() => {});
    }

    if (!ctx || !ctx.db) {
        console.log("[ROUTER] ctx.db MISSING!");
        return bot.answerCallbackQuery(q.id, { text: "Internal error: ctx.db missing", show_alert: true }).catch(() => {});
    }

    if (typeof data !== "string") {
        console.log("[ROUTER] invalid data type:", typeof data);
        return bot.answerCallbackQuery(q.id, { text: "Invalid callback", show_alert: true }).catch(() => {});
    }

    const chatId = q.message.chat?.id;
    if (!chatId) {
        console.log("[ROUTER] no chatId in q.message");
        return bot.answerCallbackQuery(q.id, { text: "Chat context hilang", show_alert: true }).catch(() => {});
    }

    bot.answerCallbackQuery(q.id).catch(() => {});

    const keys = Object.keys(handlers)
        .filter(k => !k.startsWith("msg:"))
        .sort((a, b) => b.length - a.length);

    let handlerKey = null;
    for (const key of keys) {
        if (data === key || data.startsWith(key + ":")) {
            handlerKey = key;
            break;
        }
    }

    if (!handlerKey) {
        console.log("[ROUTER] no handler for callback:", data);
        return bot.answerCallbackQuery(q.id, {
            text: "Handler tidak ditemukan: " + data,
            show_alert: true
        }).catch(() => {});
    }

    try {
        console.log("[ROUTER] → callback:", data, "→ handler:", handlerKey);

        const SKIP_DELETE = [
            "menu_back", "check_join", "redeem_claim",
            "copy_username", "copy_password", "menu_close",
            "syntax_fix", "scriptstore_cancel",
            "panel_create", "panel_egg", "panel_pick_egg",
            "panel_create_type", "addrole_srv", "addrole_do2",
            "addrole_back_srv", "buildpubspec_build", "buildyml_build",
            "w2a_build", "w2a_cancel"
        ];
        const SKIP_DELETE_PREFIX = [
            "addrole_", "panel_setcfg", "panel_setrole",
            "guard_", "tool_hd_level", "textstyler_",
            "gategroup_check", "copy_",
            "panel_egg", "panel_create", "cadp_",
            "buildpubspec_", "buildyml_", "panelpro_",
            "menu_", "tool_", "dev_", "prem_",
            "music_", "scriptstore_", "ai_", "w2a_",
            "renamebase_", "renameapi_", "syntax_", "deploy_",
            "ubot_menu_", "userbot_"
        ];

        const shouldDelete = !SKIP_DELETE.includes(data) &&
                             !SKIP_DELETE_PREFIX.some(p => data.startsWith(p));

        if (shouldDelete) {
            try { await bot.deleteMessage(chatId, q.message.message_id); } catch {}
        }

        if (typeof wrapAndExecute === "function") {
            await wrapAndExecute(handlers[handlerKey], bot, q, data, user, ctx);
        } else {
            await handlers[handlerKey](bot, q, data, user, ctx);
        }
    } catch (e) {
        console.log("[CB ERR]", handlerKey, e.message);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Error: " + e.message.slice(0, 100),
                show_alert: true
            });
        } catch {}
    }
}

// ═══════════════════════════════════════════
// ROUTE MESSAGE
// ═══════════════════════════════════════════
async function routeMessage(bot, msg, state, ctx) {
    if (!msg || !msg.from || !msg.chat) {
        console.log("[ROUTER] invalid message");
        return;
    }

    if (!ctx || !ctx.db) {
        console.log("[ROUTER] ctx.db MISSING (message)");
        return;
    }

    if (!state || !state.state) {
        console.log("[ROUTER] invalid state");
        return;
    }

    // ⚡ FIX: JANGAN clear state kalau command baru aja di-handle
    if (msg.text && msg.text.startsWith("/")) {
        console.log("[ROUTER] skip command (JANGAN clear state):", state.state);
        return;
    }

    const key = "msg:" + state.state;
    console.log("[ROUTER] → message state:", state.state);

    if (!handlers[key]) {
        console.log("[ROUTER] no handler for state:", state.state);
        if (ctx.clearState) ctx.clearState(String(msg.from.id));
        return;
    }

    try {
        return await handlers[key](bot, msg, state, ctx);
    } catch (e) {
        console.log("[MSG ERR]", key, e.message);
        return bot.sendMessage(msg.chat.id,
            "Error: " + e.message.slice(0, 200),
            { parse_mode: "HTML" }).catch(() => {});
    }
}

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports = routeCallback;
module.exports.message = routeMessage;
module.exports.registerCallback = registerCallback;
module.exports.registerMessage = registerMessage;
module.exports.handlers = handlers;

// ═══════════════════════════════════════════
// REQUIRE SEMUA MODUL
// ═══════════════════════════════════════════
require(path.join(__dirname, "menu.js"));
require(path.join(__dirname, "bugtest.js"));
require(path.join(__dirname, "sender.js"));
require(path.join(__dirname, "payment.js"));
require(path.join(__dirname, "report.js"));
require(path.join(__dirname, "chatdev.js"));
require(path.join(__dirname, "developer.js"));
require(path.join(__dirname, "premium.js"));
require(path.join(__dirname, "syntax.js"));
require(path.join(__dirname, "deploy.js"));
require(path.join(__dirname, "tools.js"));
require(path.join(__dirname, "music.js"));
require(path.join(__dirname, "guard.js"));
require(path.join(__dirname, "panel.js"));
require(path.join(__dirname, "panelpro.js"));
require(path.join(__dirname, "order.js"));
require(path.join(__dirname, "scriptstore.js"));
require(path.join(__dirname, "groupgate.js"));
require(path.join(__dirname, "textstyle.js"));
require(path.join(__dirname, "owner.js"));
require(path.join(__dirname, "userpremium.js"));
require(path.join(__dirname, "build-pubspec.js"));
require(path.join(__dirname, "build-yml.js"));
require(path.join(__dirname, "rename-base.js"));
require(path.join(__dirname, "rename-api.js"));
require(path.join(__dirname, "buildmenu.js"));
require(path.join(__dirname, "github-builder.js"));
require(path.join(__dirname, "ai-engine.js"));
require(path.join(__dirname, "ai-chat.js"));
require(path.join(__dirname, "upload-to-link.js"));
require(path.join(__dirname, "file-to-link.js"));
require(path.join(__dirname, "web-to-app.js"));
require(path.join(__dirname, "ai-code-editor.js"));
require(path.join(__dirname, "rename-baileys.js"));
require(path.join(__dirname, "rename-func.js"));

// ═══ USERBOT — register (bukan di folder modules) ═══
require(path.join(__dirname, "..", "handlers", "userbot", "index.js"));
require(path.join(__dirname, "..", "handlers", "userbot", "menu-callback.js"));
require(path.join(__dirname, "..", "handlers", "userbot", "module-loader.js"));

// ═══════════════════════════════════════════
// LOG SUMMARY
// ═══════════════════════════════════════════
console.log("[ROUTER] ===========================");
console.log("[ROUTER] all modules loaded");
console.log("[ROUTER] total callbacks:", Object.keys(handlers).filter(k => !k.startsWith("msg:")).length);
console.log("[ROUTER] total messages:", Object.keys(handlers).filter(k => k.startsWith("msg:")).length);
console.log("[ROUTER] ===========================");