const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");

const GATE_FILE = path.join(__dirname, "..", "database", "groupgate.json");
const _cache = new Map();
const CACHE_TTL = 10000;

// ═══════════════════════════════════════════
// FILE HELPERS
// ═══════════════════════════════════════════
function readGate() {
    try { return JSON.parse(fs.readFileSync(GATE_FILE, "utf8")); } catch { return {}; }
}
function writeGate(d) {
    fs.writeFileSync(GATE_FILE, JSON.stringify(d, null, 2), "utf8");
}

function getGroupData(chatId) {
    const g = readGate();
    const key = String(chatId);
    if (!g[key]) {
        g[key] = { enabled: false, channels: [], muted: {} };
        writeGate(g);
    }
    if (!g[key].muted) g[key].muted = {};
    return g[key];
}

function saveGroupData(chatId, data) {
    const g = readGate();
    const key = String(chatId);
    g[key] = { ...g[key], ...data };
    writeGate(g);
}

function getChannelUsername(url) {
    if (!url) return null;
    url = url.trim();
    if (url.startsWith("@")) return url;
    if (url.includes("t.me/")) {
        let u = url.split("t.me/")[1].split("/")[0].split("?")[0];
        return "@" + u;
    }
    if (url.startsWith("-100")) return url;
    return "@" + url;
}

// ═══════════════════════════════════════════
// ADMIN CHECK
// ═══════════════════════════════════════════
async function isAdmin(bot, chatId, userId) {
    try {
        const m = await bot.getChatMember(chatId, userId);
        return ["creator", "administrator"].includes(m.status);
    } catch { return false; }
}

// ═══════════════════════════════════════════
// CHECK USER JOIN
// ═══════════════════════════════════════════
async function checkUserJoin(bot, userId, chatId) {
    const gd = getGroupData(chatId);
    if (!gd.enabled || !gd.channels || gd.channels.length === 0) return { ok: true, missing: [] };

    const cacheKey = `${chatId}:${userId}`;
    const cached = _cache.get(cacheKey);
    if (cached && Date.now() - cached.at < CACHE_TTL) return cached.result;

    const missing = [];
    for (const ch of gd.channels) {
        try {
            const memberPromise = bot.getChatMember(ch, userId);
            const timeoutPromise = new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 4000));
            const member = await Promise.race([memberPromise, timeoutPromise]);
            const valid = ["creator", "administrator", "member", "restricted"].includes(member.status);
            if (!valid) missing.push(ch);
        } catch {
            missing.push(ch);
        }
    }

    const result = { ok: missing.length === 0, missing };
    _cache.set(cacheKey, { result, at: Date.now() });
    return result;
}

// ═══════════════════════════════════════════
// MUTE USER
// ═══════════════════════════════════════════
async function muteUser(bot, chatId, userId) {
    try {
        await bot.restrictChatMember(chatId, userId, {
            permissions: {
                can_send_messages: false,
                can_send_audios: false,
                can_send_documents: false,
                can_send_photos: false,
                can_send_videos: false,
                can_send_video_notes: false,
                can_send_voice_notes: false,
                can_send_polls: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_change_info: false,
                can_invite_users: false,
                can_pin_messages: false,
                can_manage_topics: false
            }
        }, {
            use_independent_chat_permissions: true
        });
        console.log(`[GATEGROUP] ✅ muted user ${userId} in ${chatId}`);
        return true;
    } catch (e) {
        console.log(`[GATEGROUP] ✖️ mute FAIL for ${userId}:`, e.message);
        return false;
    }
}

// ═══════════════════════════════════════════
// UNMUTE USER
// ═══════════════════════════════════════════
async function unmuteUser(bot, chatId, userId) {
    try {
        await bot.restrictChatMember(chatId, userId, {
            permissions: {
                can_send_messages: true,
                can_send_audios: true,
                can_send_documents: true,
                can_send_photos: true,
                can_send_videos: true,
                can_send_video_notes: true,
                can_send_voice_notes: true,
                can_send_polls: true,
                can_send_other_messages: true,
                can_add_web_page_previews: true,
                can_change_info: false,
                can_invite_users: true,
                can_pin_messages: false,
                can_manage_topics: false
            }
        }, {
            use_independent_chat_permissions: true
        });

        // Verifikasi berhasil
        try {
            const member = await bot.getChatMember(chatId, userId);
            const perms = member.permissions || {};
            console.log(`[GATEGROUP] ✅ unmuted ${userId} | status: ${member.status} | can_send: ${member.can_send_messages ?? perms.can_send_messages ?? "check"}`);
        } catch {}

        return true;
    } catch (e) {
        console.log(`[GATEGROUP] ✕ unmute FAIL for ${userId}:`, e.message);
        return false;
    }
}

// ═══════════════════════════════════════════
// UNMUTE ALL — EMERGENCY
// ═══════════════════════════════════════════
async function unmuteAll(bot, chatId) {
    const gd = getGroupData(chatId);
    if (!gd.muted) return { total: 0, success: 0 };

    const list = Object.keys(gd.muted);
    let success = 0;

    for (const uid of list) {
        const ok = await unmuteUser(bot, chatId, uid);
        if (ok) {
            success++;
            delete gd.muted[uid];
        }
    }

    saveGroupData(chatId, gd);
    _cache.clear();

    return { total: list.length, success };
}

// ═══════════════════════════════════════════
// JOIN KEYBOARD
// ═══════════════════════════════════════════
function joinKeyboard(chatId) {
    const gd = getGroupData(chatId);
    const rows = [];

    if (gd.channels && gd.channels.length > 0) {
        gd.channels.forEach((ch, i) => {
            const url = ch.startsWith("@") ? `https://t.me/${ch.slice(1)}` : `https://t.me/${ch}`;
            rows.push([{ text: `𖡛 Join Channel ${i + 1}`, url }]);
        });
    }

    rows.push([{ text: "𖡛 Refresh Cek Join", callback_data: `gategroup_check:${chatId}` }]);

    return { inline_keyboard: rows };
}

// ═══════════════════════════════════════════
// MENU: PUSH CHANNEL
// ═══════════════════════════════════════════
router.registerCallback("menu_pushchannel", async (bot, q, data, user, ctx) => {
    const chatId = q.message.chat.id;

    if (q.message.chat.type === "private") {
        return bot.answerCallbackQuery(q.id, { text: "✕ Fitur ini cuma di group!", show_alert: true });
    }

    const isAdm = await isAdmin(bot, chatId, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group!", show_alert: true });
    }

    const gd = getGroupData(chatId);
    const status = gd.enabled ? "𖡛 AKTIF" : "𖡛 MATI";
    const list = gd.channels.length > 0
        ? gd.channels.map((c, i) => `${i + 1}. ${c}`).join("\n")
        : "<i>Belum ada channel</i>";

    const caption =
        `<b>𖡛 PUSH CHANNEL</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Group ID</b>: <code>${chatId}</code>\n` +
        `𖡛 <b>Status</b>: ${status}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>𖡛 Channel terdaftar:</b>\n${list}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>User baru wajib join channel di atas buat bisa chat di group ini.</i>\n` +
        `<i>✕ Bot harus admin di channel yang di-add!</i>`;

    const kb = [
        [{ text: "𖡛 Add Channel", callback_data: "gategroup_add", style: "primary" }],
        [{ text: gd.enabled ? "✕ Matikan Gate" : "✓ Aktifkan Gate", callback_data: "gategroup_toggle", style: "success" }]
    ];

    if (gd.channels.length > 0) {
        kb.push([{ text: "𖡛 Hapus Semua Channel", callback_data: "gategroup_clear", style: "danger" }]);
        kb.push([{ text: "𖡛 Unmute All Users", callback_data: "gategroup_unmuteall", style: "success" }]);
    }

    kb.push([{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]);

    await bot.sendMessage(chatId, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
});

// ═══════════════════════════════════════════
// ADD CHANNEL
// ═══════════════════════════════════════════
router.registerCallback("gategroup_add", async (bot, q, data, user, ctx) => {
    const chatId = q.message.chat.id;

    const isAdm = await isAdmin(bot, chatId, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group!", show_alert: true });
    }

    ctx.setState(user.id, "gategroup_add_await", { chatId });

    await bot.sendMessage(chatId,
        `<b>𖡛 ADD CHANNEL</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>Cara pakai:</b>\n` +
        `1. Add bot ke channel target\n` +
        `2. Jadikan bot <b>ADMIN</b> di channel\n` +
        `3. Kirim username channel ke sini\n\n` +
        `<b>Format:</b>\n` +
        `<code>@username_channel</code>\n` +
        `atau\n` +
        `<code>https://t.me/username_channel</code>\n` +
        `atau\n` +
        `<code>-100xxxxxxxxxx</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("gategroup_add_await", async (bot, msg, state, ctx) => {
    const chatId = state.chatId;
    const input = msg.text?.trim();
    if (!input) return;

    ctx.clearState(msg.from.id);

    const channelUsername = getChannelUsername(input);
    if (!channelUsername) {
        return bot.sendMessage(chatId, `<b>✕ Format username salah.</b>`, { parse_mode: "HTML" });
    }

    try {
        const chat = await bot.getChat(channelUsername);

        if (chat.type !== "channel") {
            return bot.sendMessage(chatId, `<b>✕ ${channelUsername} bukan channel.</b>`, { parse_mode: "HTML" });
        }

        // Cek bot admin di channel
        let botIsAdmin = false;
        try {
            const me = await bot.getMe();
            const member = await bot.getChatMember(channelUsername, me.id);
            botIsAdmin = ["creator", "administrator"].includes(member.status);
        } catch (e) {
            console.log("[GATEGROUP] check bot admin fail:", e.message);
        }

        if (!botIsAdmin) {
            return bot.sendMessage(chatId,
                `<b>✕ Bot bukan admin di channel ini!</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `Add bot ke channel <b>${channelUsername}</b> → jadikan <b>ADMIN</b> → coba lagi.`,
                { parse_mode: "HTML" });
        }

        const gd = getGroupData(chatId);
        if (gd.channels.includes(channelUsername)) {
            return bot.sendMessage(chatId, `<b>⚠️ Channel ${channelUsername} udah ada di list.</b>`, { parse_mode: "HTML" });
        }

        gd.channels.push(channelUsername);
        gd.enabled = true;
        saveGroupData(chatId, gd);
        _cache.clear();

        await bot.sendMessage(chatId,
            `<b>✓ CHANNEL DITAMBAHKAN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Channel</b>: ${channelUsername}\n` +
            `𖡛 <b>Nama</b>: ${chat.title || channelUsername}\n` +
            `𖡛 <b>Status Gate</b>: 🟢 AKTIF\n` +
            `𖡛 <b>Total Channel</b>: ${gd.channels.length}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>User baru wajib join channel ini buat chat di group.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[
                { text: "𖡛 Add Channel Lagi", callback_data: "gategroup_add", style: "success" },
                { text: "✕ Menu", callback_data: "menu_pushchannel", style: "danger" }
            ]] } });
    } catch (e) {
        await bot.sendMessage(chatId,
            `<b>✕ Gagal akses channel:</b>\n<code>${e.message}</code>\n\n` +
            `Pastiin:\n1. Username bener\n2. Bot udah di-add ke channel\n3. Bot admin di channel`,
            { parse_mode: "HTML" });
    }
});

// ═══════════════════════════════════════════
// TOGGLE GATE
// ═══════════════════════════════════════════
router.registerCallback("gategroup_toggle", async (bot, q, data, user, ctx) => {
    const chatId = q.message.chat.id;
    const isAdm = await isAdmin(bot, chatId, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group!", show_alert: true });
    }

    const gd = getGroupData(chatId);
    if (!gd.enabled && gd.channels.length === 0) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Add channel dulu!", show_alert: true });
    }

    gd.enabled = !gd.enabled;
    saveGroupData(chatId, gd);
    _cache.clear();

    await bot.answerCallbackQuery(q.id, { text: `Gate: ${gd.enabled ? "𖡛 AKTIF" : "𖡛 MATI"}`, show_alert: true });

    return bot.sendMessage(chatId, `<b>${gd.enabled ? "𖡛 Gate diaktifkan" : "𖡛 Gate dimatikan"}</b>`, { parse_mode: "HTML" });
});

// ═══════════════════════════════════════════
// CLEAR CHANNELS
// ═══════════════════════════════════════════
router.registerCallback("gategroup_clear", async (bot, q, data, user, ctx) => {
    const chatId = q.message.chat.id;
    const isAdm = await isAdmin(bot, chatId, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group!", show_alert: true });
    }

    const gd = getGroupData(chatId);
    gd.channels = [];
    gd.enabled = false;
    saveGroupData(chatId, gd);
    _cache.clear();

    await bot.answerCallbackQuery(q.id, { text: "𖡛 Semua channel dihapus", show_alert: true });
    return bot.sendMessage(chatId, `<b>✅ Semua channel dihapus. Gate mati.</b>`, { parse_mode: "HTML" });
});

// ═══════════════════════════════════════════
// UNMUTE ALL — VIA BUTTON
// ═══════════════════════════════════════════
router.registerCallback("gategroup_unmuteall", async (bot, q, data, user, ctx) => {
    const chatId = q.message.chat.id;
    const isAdm = await isAdmin(bot, chatId, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group!", show_alert: true });
    }

    await bot.answerCallbackQuery(q.id, { text: "𖡛 Unmuting semua user...", show_alert: false });

    const result = await unmuteAll(bot, chatId);

    await bot.sendMessage(chatId,
        `<b>✓ UNMUTE ALL</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 Total: <code>${result.total}</code>\n` +
        `✓ Berhasil: <code>${result.success}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━`,
        { parse_mode: "HTML" });
});

// ═══════════════════════════════════════════
// REFRESH CEK JOIN — FIXED
// ═══════════════════════════════════════════
router.registerCallback("gategroup_check", async (bot, q, data, user, ctx) => {
    const parts = data.split(":");
    const chatId = parseInt(parts[1]);

    console.log("[GATEGROUP CHECK] user:", q.from.id, "chat:", chatId);

    // 🔥 CLEAR CACHE biar cek fresh
    _cache.delete(`${chatId}:${q.from.id}`);

    // Jeda dikit biar Telegram update
    await new Promise(r => setTimeout(r, 500));

    const result = await checkUserJoin(bot, q.from.id, chatId);
    console.log("[GATEGROUP CHECK] result:", result);

    if (result.ok) {
        console.log("[GATEGROUP CHECK] ✅ user join — unmuting...");

        const ok = await unmuteUser(bot, chatId, q.from.id);

        if (ok) {
            // Hapus dari muted list
            const gd = getGroupData(chatId);
            if (gd.muted) {
                delete gd.muted[q.from.id];
                saveGroupData(chatId, gd);
            }

            // Clear cache lagi
            _cache.delete(`${chatId}:${q.from.id}`);

            await bot.answerCallbackQuery(q.id, {
                text: "✓ Lu udah join! Sekarang bisa chat.",
                show_alert: true
            }).catch(() => {});

            // Kirim pesan konfirmasi
            try {
                const msgConfirm = await bot.sendMessage(chatId,
                    `<b>✓ <a href="tg://user?id=${q.from.id}">${q.from.first_name}</a> udah join!</b>\n\n` +
                    `<i>Sekarang bisa chat di group ini.</i>`,
                    { parse_mode: "HTML" });
                setTimeout(() => bot.deleteMessage(chatId, msgConfirm.message_id).catch(() => {}), 10000);
            } catch (e) {
                console.log("[GATEGROUP] send confirm fail:", e.message);
            }

            // Hapus pesan tombol
            try { await bot.deleteMessage(chatId, q.message.message_id); } catch {}
        } else {
            // Retry sekali
            console.log("[GATEGROUP CHECK] retry unmute...");
            await new Promise(r => setTimeout(r, 1500));
            const retryOk = await unmuteUser(bot, chatId, q.from.id);

            await bot.answerCallbackQuery(q.id, {
                text: retryOk
                    ? "✓ Berhasil unmute! Coba chat sekarang."
                    : "✕ Gagal unmute. Pastikan bot admin group dengan izin 'Restrict Members'.",
                show_alert: true
            }).catch(() => {});
        }
    } else {
        console.log("[GATEGROUP CHECK] ✖️ belum join:", result.missing);
        await bot.answerCallbackQuery(q.id, {
            text: `✕ Lu belum join ${result.missing.length} channel!`,
            show_alert: true
        }).catch(() => {});
    }
});

// ═══════════════════════════════════════════
// HANDLE MESSAGE — AUTO UNMUTE
// ═══════════════════════════════════════════
module.exports.handleMessage = async function (bot, msg, ctx) {
    if (!msg.chat || (msg.chat.type !== "group" && msg.chat.type !== "supergroup")) return;
    if (!msg.from || msg.from.is_bot) return;

    const chatId = msg.chat.id;
    const userId = msg.from.id;

    const gd = getGroupData(chatId);
    if (!gd.enabled || !gd.channels || gd.channels.length === 0) return;

    // Owner & admin bypass
    if (ctx.db.isOwner(userId)) return;

    const isAdm = await isAdmin(bot, chatId, userId);
    if (isAdm) return;

    const result = await checkUserJoin(bot, userId, chatId);

    if (!result.ok) {
        // Delete message
        try { await bot.deleteMessage(chatId, msg.message_id); } catch {}

        // Mute user
        await muteUser(bot, chatId, userId);

        // Record muted
        gd.muted = gd.muted || {};
        gd.muted[userId] = Date.now();
        saveGroupData(chatId, gd);

        // Kirim pesan join
        try {
            await bot.sendMessage(chatId,
                `<b>⚠️ WAJIB JOIN CHANNEL</b>\n\n` +
                `<a href="tg://user?id=${userId}">${msg.from.first_name}</a>, ` +
                `lu harus join channel dulu:\n\n` +
                gd.channels.map((c, i) => `${i + 1}. ${c}`).join("\n") +
                `\n\n<i>Setelah join, klik 𖡛 Refresh Cek Join.</i>`,
                { parse_mode: "HTML", reply_markup: joinKeyboard(chatId) });
        } catch {}
    } else {
        // 🔥 AUTO UNMUTE kalau user udah join
        if (gd.muted && gd.muted[userId]) {
            console.log("[GATEGROUP] 🔥 auto-unmute user", userId);
            const ok = await unmuteUser(bot, chatId, userId);
            if (ok) {
                delete gd.muted[userId];
                saveGroupData(chatId, gd);
                _cache.delete(`${chatId}:${userId}`);
            }
        }
    }
};

// ═══════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════
module.exports.getGroupData = getGroupData;
module.exports.saveGroupData = saveGroupData;
module.exports.unmuteAll = unmuteAll;
module.exports.unmuteUser = unmuteUser;
module.exports.muteUser = muteUser;
module.exports.checkUserJoin = checkUserJoin;
module.exports._cache = _cache;