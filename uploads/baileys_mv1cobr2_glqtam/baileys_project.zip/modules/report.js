const router = require("./router");
const cfg = require("../config");

router.registerCallback("menu_report", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "report_await", {});
    await bot.sendPhoto(q.message.chat.id, cfg.FOTO.REPORT, {
        caption: `<b>𖡛 REPORT BUG</b>\n\n━━━━━━━━━━━━━━━━━━━━\n<i>Kirim pesan error / bug yang lu temuin di bot ini.</i>\nSertakan screenshot / teks error nya.\n━━━━━━━━━━━━━━━━━━━━`,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
    });
});

router.registerMessage("report_await", async (bot, msg, state, ctx) => {
    const reportId = "RPT" + Date.now();
    const reports = ctx.db.read("reports");
    reports[reportId] = {
        id: reportId, userId: msg.from.id, username: msg.from.username || "-",
        text: msg.text || "[media]", fileId: msg.photo ? msg.photo[msg.photo.length - 1].file_id : null,
        status: "pending", createdAt: Date.now()
    };
    ctx.db.write("reports", reports);

    const body = `<b>𖡛 REPORT BARU</b>\n\n━━━━━━━━━━━━━━━━━━━━\n𖡛 <code>${reportId}</code>\n𖡛 User: <a href="tg://user?id=${msg.from.id}">${msg.from.id}</a>\n━━━━━━━━━━━━━━━━━━━━\n${msg.text || "[foto]"}`;
    const kb = { inline_keyboard: [[{ text: "💬 Balas", callback_data: `report_reply:${reportId}` }]] };
    if (msg.photo) {
        await bot.sendPhoto(cfg.OWNER_ID, msg.photo[msg.photo.length - 1].file_id, { caption: body, parse_mode: "HTML", reply_markup: kb });
    } else {
        await bot.sendMessage(cfg.OWNER_ID, body, { parse_mode: "HTML", reply_markup: kb });
    }
    await bot.sendMessage(msg.chat.id, `<b>✅ Report terkirim ke owner.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("report_reply", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(q.from.id)) return;
    const reportId = data.split(":")[1];
    ctx.setState(q.from.id, "report_reply_await", { reportId });
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 Kirim balasan lu untuk report ${reportId}:</b>`, { parse_mode: "HTML" });
});

router.registerMessage("report_reply_await", async (bot, msg, state, ctx) => {
    const reports = ctx.db.read("reports");
    const r = reports[state.reportId];
    if (!r) return bot.sendMessage(msg.chat.id, "✖️ Report tidak ditemukan.", { parse_mode: "HTML" });
    r.status = "replied";
    r.reply = msg.text;
    ctx.db.write("reports", reports);
    await bot.sendMessage(r.userId,
        `<b>𖡛 BALASAN OWNER</b>\n\n𖡛 Report: <code>${state.reportId}</code>\n━━━━━━━━━━━━━━━━━━━━\n${msg.text}`,
        { parse_mode: "HTML" });
    await bot.sendMessage(msg.chat.id, `<b>✅ Balasan terkirim ke user.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});