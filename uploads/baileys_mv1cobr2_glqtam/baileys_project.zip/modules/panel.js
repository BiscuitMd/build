// ═══════════════════════════════════════════
// PANEL — Panel Management
// v3 — Fix /addrole state null (paksa String ID)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");

const PANEL_FILE = path.join(__dirname, "..", "database", "panel.json");

// ═══════════════════════════════════════════
// SAFE EDIT
// ═══════════════════════════════════════════
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msgId,
            parse_mode: "HTML",
            ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;

        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    ...options
                });
            } catch {}
        }

        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch { return null; }
        }

        return null;
    }
}

// ═══════════════════════════════════════════
// READ / WRITE PANEL
// ═══════════════════════════════════════════
function readPanel() {
    const DEFAULT = { users: {}, groups: [], servers: {}, adp: { "1": {}, "2": {} }, config: { plta: "", pltc: "", domain: "" } };
    try {
        const raw = JSON.parse(fs.readFileSync(PANEL_FILE, "utf8"));
        if (!raw.users || typeof raw.users !== "object") raw.users = {};
        if (!raw.groups || !Array.isArray(raw.groups)) raw.groups = [];
        if (!raw.servers || typeof raw.servers !== "object") raw.servers = {};
        if (!raw.adp || typeof raw.adp !== "object") raw.adp = { "1": {}, "2": {} };
        if (!raw.adp["1"]) raw.adp["1"] = {};
        if (!raw.adp["2"]) raw.adp["2"] = {};
        if (!raw.config || typeof raw.config !== "object") raw.config = { plta: "", pltc: "", domain: "" };
        try {
            if (cfg.MAIN_GROUP_ID && cfg.MAIN_GROUP_ID !== "-1001234567890") {
                const has = raw.groups.some(g => String(g) === String(cfg.MAIN_GROUP_ID));
                if (!has) {
                    raw.groups.push(cfg.MAIN_GROUP_ID);
                    fs.writeFileSync(PANEL_FILE, JSON.stringify(raw, null, 2), "utf8");
                }
            }
        } catch {}
        return raw;
    } catch {
        fs.writeFileSync(PANEL_FILE, JSON.stringify(DEFAULT, null, 2), "utf8");
        return DEFAULT;
    }
}

function writePanel(d) {
    if (!d.users) d.users = {};
    if (!d.groups) d.groups = [];
    if (!d.servers) d.servers = {};
    if (!d.adp) d.adp = { "1": {}, "2": {} };
    if (!d.config) d.config = { plta: "", pltc: "", domain: "" };
    fs.writeFileSync(PANEL_FILE, JSON.stringify(d, null, 2), "utf8");
}

// ═══════════════════════════════════════════
// ROLE SYSTEM
// ═══════════════════════════════════════════
const ROLE_ORDER = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];

const ROLE_PERMS = {
    reseller: ["create_panel"],
    admin: ["create_panel", "add_reseller", "cadp"],
    owner: ["create_panel", "add_reseller", "add_admin", "cadp"],
    partner: ["create_panel", "add_reseller", "add_admin", "add_owner", "cadp"],
    tangankanann: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "cadp"],
    ceo: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "add_tangankanann", "cadp", "delete_offline"],
    developer: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "add_tangankanann", "add_ceo", "cadp", "delete_offline"]
};

const ROLE_LABEL = {
    reseller: "𖡛 Reseller", admin: "𖡛 Admin", owner: "𖡛 Owner",
    partner: "𖡛 Partner", tangankanann: "𖡛 Tangan Kanan",
    ceo: "𖡛 CEO", developer: "𖡛 Developer"
};

function hasPerm(role, perm) { if (!role) return false; return (ROLE_PERMS[role] || []).includes(perm); }
function roleRank(role) { return ROLE_ORDER.indexOf(role); }
function canAddRole(actorRole, targetRole) {
    if (!actorRole || !targetRole) return false;
    const ar = roleRank(actorRole), tr = roleRank(targetRole);
    if (ar < 0 || tr < 0) return false;
    if (ar === 0) return false;
    return tr < ar;
}
function isOwnerBot(id, ctx) { return ctx.db.isOwner(id); }

function ensureUser(id, role, days, credit, scope = "illegal") {
    const p = readPanel();
    const key = String(id);
    const now = Date.now();
    p.users[key] = {
        id: key, role, scope,
        expiresAt: now + days * 24 * 60 * 60 * 1000,
        credit,
        createdAt: (p.users[key] && p.users[key].createdAt) || now,
        updatedAt: now
    };
    writePanel(p);
    return p.users[key];
}

function checkExpired() {
    const p = readPanel();
    let changed = false;
    const now = Date.now();
    for (const uid in p.users) {
        if (p.users[uid].expiresAt && now > p.users[uid].expiresAt) { delete p.users[uid]; changed = true; }
    }
    if (changed) writePanel(p);
}

function generatePassword(len = 12) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
    let out = "";
    for (let i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

function normalizeUrl(d) {
    if (!d || d === "belum diset") return "https://t.me/biscuitMD";
    if (d.startsWith("http://") || d.startsWith("https://")) return d;
    return "https://" + d;
}

function isGroupAllowed(chatId) {
    const p = readPanel();
    if (String(chatId) === String(cfg.MAIN_GROUP_ID)) return true;
    return (p.groups || []).some(g => String(g) === String(chatId));
}

setInterval(checkExpired, 60 * 1000);
checkExpired();

async function canDMUser(bot, userId) {
    try {
        const chat = await bot.getChat(userId);
        return chat && chat.type === "private";
    } catch {
        return false;
    }
}

// ═══════════════════════════════════════════
// SEND ADP KE PRIVATE
// ═══════════════════════════════════════════
async function sendAdpToPrivate(bot, userId, data, fallbackChatId) {
    const { username, password, domain, scopeLabel, adpId } = data;

    const caption =
        `<b>✓ ADP BERHASIL DIBUAT</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>ID</b>: <code>${adpId}</code>\n` +
        `𖡛 <b>Username</b>: <code>${username}</code>\n` +
        `𖡛 <b>Password</b>: <code>${password}</code>\n` +
        `𖡛 <b>Server</b>: ${scopeLabel}\n` +
        `𖡛 <b>Panel</b>: <code>https://${domain}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Simpan data ini. Jangan share ke siapapun.</i>`;

    const kb = [
        [
            { text: "𖡛 Copy Username", copy_text: { text: username } },
            { text: "𖡛 Copy Password", copy_text: { text: password } }
        ],
        [{ text: "𖡛 Buka Panel", url: normalizeUrl(domain) }]
    ];

    try {
        await bot.sendMessage(userId, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
        return { ok: true };
    } catch (e) {
        if (fallbackChatId) {
            try {
                await bot.sendMessage(fallbackChatId,
                    `<b>⚠️ ADP BERHASIL DIBUAT</b>\n\nData udah dikirim ke DM user.`,
                    { parse_mode: "HTML" });
            } catch {}
        }
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// SEND PANEL KE PRIVATE
// ═══════════════════════════════════════════
async function sendPanelToPrivate(bot, userId, data, fallbackChatId) {
    const { username, password, domain, eggLabel, ram, scope, expiresAt, creditLeft } = data;
    const scopeLabel = scope === "legal" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

    const caption =
        `<b>𖡛 PANEL BERHASIL DIBUAT</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Username</b>: <code>${username}</code>\n` +
        `▸ <b>Password</b>: <code>${password}</code>\n` +
        `▸ <b>Egg</b>: ${eggLabel}\n` +
        `▸ <b>RAM</b>: ${ram}\n` +
        `▸ <b>Server</b>: ${scopeLabel}\n` +
        `▸ <b>Domain</b>: <code>${domain}</code>\n` +
        `▸ <b>Expired</b>: ${Math.ceil((expiresAt - Date.now()) / 86400000)} hari\n` +
        `▸ <b>Credit Sisa</b>: <code>${creditLeft}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Simpan data di atas. Jangan share ke siapapun.</i>`;

    const kb = [
        [
            { text: "𖡛 Copy Username", copy_text: { text: username } },
            { text: "𖡛 Copy Password", copy_text: { text: password } }
        ],
        [{ text: "𖡛 Buka Domain Panel", url: normalizeUrl(domain) }]
    ];

    const img = cfg.FOTO.PANEL || cfg.FOTO.MENU;

    try {
        await bot.sendPhoto(userId, img, {
            caption,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
        return { ok: true, to: "private" };
    } catch (e) {
        try {
            await bot.sendMessage(userId, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
            return { ok: true, to: "private" };
        } catch (e2) {
            if (fallbackChatId) {
                try {
                    await bot.sendMessage(fallbackChatId,
                        `<b>⚠️ PANEL BERHASIL DIBUAT</b>\n\n<i>Data panel udah dikirim ke DM user.</i>`,
                        { parse_mode: "HTML" });
                } catch {}
            }
            return { ok: false, to: "fail", error: e2.message };
        }
    }
}

// ═══════════════════════════════════════════
// MENU PANEL LEGACY
// ═══════════════════════════════════════════
router.registerCallback("menu_panel_legacy", async (bot, q, data, user, ctx) => {
    try {
        if (q.message.chat.type === "private" || !isGroupAllowed(q.message.chat.id)) {
            return bot.answerCallbackQuery(q.id, { text: "AKSES DI TOLAK", show_alert: true });
        }
        await bot.sendMessage(q.message.chat.id, `<b>▸ PANEL</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[MENU PANEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// CREATE PANEL
// ═══════════════════════════════════════════
router.registerCallback("panel_create", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx || !ctx.db) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Internal error.</b>`, { parse_mode: "HTML" }).catch(() => {});
        }

        const chatId = q.message.chat.id;
        const chatType = q.message.chat.type;

        if (chatType === "private" || !isGroupAllowed(chatId)) {
            return bot.sendMessage(chatId, `<b>✕ AKSES DI TOLAK</b>`, { parse_mode: "HTML" });
        }

        const p = readPanel();
        const uid = String(user.id);
        const rec = (p.users && p.users[uid]) || null;
        if (!rec && !isOwnerBot(user.id, ctx)) {
            return bot.sendMessage(chatId, `<b>✕ Belum di-add admin!</b>`, { parse_mode: "HTML" });
        }

        if (rec && rec.credit < 1) {
            return bot.sendMessage(chatId, `<b>✕ Credit habis!</b>`, { parse_mode: "HTML" });
        }

        const scope = (rec && rec.scope) || "illegal";
        const isOwner2 = isOwnerBot(user.id, ctx);

        const rows = [];
        rows.push([{ text: "▸ Panel ILEGAL", callback_data: "panel_create_type:illegal", style: "primary" }]);
        if (scope === "legal" || isOwner2) {
            rows.push([{ text: "▸ Panel LEGAL", callback_data: "panel_create_type:legal", style: "success" }]);
        }
        rows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        await bot.sendMessage(chatId,
            `<b>▸ CREATE PANEL</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Role: <b>${rec ? (ROLE_LABEL[rec.role] || rec.role) : "Owner Bot"}</b>\n` +
            `▸ Scope: ${scope === "illegal" ? "Ilegal" : "Legal + Ilegal"}\n` +
            `▸ Credit: <code>${rec ? rec.credit : "∞"}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) {
        console.log("[PANEL CREATE ERR]", e.message);
        return bot.sendMessage(q.message.chat.id, `<b>✕ Coba lagi.</b>`, { parse_mode: "HTML" }).catch(() => {});
    }
});

router.registerCallback("panel_create_type", async (bot, q, data, user, ctx) => {
    try {
        const type = data.split(":")[1];
        const p = readPanel();
        const uid = String(user.id);
        const rec = (p.users && p.users[uid]) || null;
        if (type === "legal") {
            const scope = (rec && rec.scope) || (isOwnerBot(user.id, ctx) ? "legal" : "illegal");
            if (scope !== "legal" && !isOwnerBot(user.id, ctx)) {
                return bot.answerCallbackQuery(q.id, { text: "✕ AKSES DITOLAK", show_alert: true });
            }
        }
        ctx.setState(uid, "panel_create_pick_egg", { scope: type });
        const rows = [];
        const eggs = cfg.EGG_15 || [];
        for (let i = 0; i < eggs.length; i += 2) {
            const row = [{ text: eggs[i].name, callback_data: `panel_pick_egg:${eggs[i].id}:${type}` }];
            if (eggs[i + 1]) row.push({ text: eggs[i + 1].name, callback_data: `panel_pick_egg:${eggs[i + 1].id}:${type}` });
            rows.push(row);
        }
        rows.push([{ text: "✕ Batal", callback_data: "menu_back" }]);
        await bot.sendMessage(q.message.chat.id,
            `<b>${type === "illegal" ? "ILEGAL" : "LEGAL"} — PILIH EGG</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[PANEL CREATE TYPE ERR]", e.message); }
});

router.registerCallback("panel_pick_egg", async (bot, q, data, user, ctx) => {
    try {
        const parts = data.split(":");
        const eggId = parts[1];
        const type = parts[2] || "illegal";
        const egg = (cfg.EGG_15 || []).find(e => e.id === eggId);
        if (!egg) return bot.answerCallbackQuery(q.id, { text: "Egg tidak valid", show_alert: true });
        ctx.setState(String(user.id), "panel_create_username", { egg: eggId, scope: type });
        await bot.sendMessage(q.message.chat.id,
            `<b>${egg.name} — ${type}</b>\n\nKirim <b>username</b> panel:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
    } catch (e) { console.log("[PANEL PICK EGG ERR]", e.message); }
});

router.registerMessage("panel_create_username", async (bot, msg, state, ctx) => {
    try {
        const username = msg.text?.trim();
        if (!username) return;
        if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Username invalid!</b>`, { parse_mode: "HTML" });
        }
        const eggId = state.egg;
        const scope = state.scope || "illegal";
        const egg = (cfg.EGG_15 || []).find(e => e.id === eggId);
        if (!egg) {
            ctx.clearState(String(msg.from.id));
            return bot.sendMessage(msg.chat.id, `<b>✕ Egg tidak valid.</b>`, { parse_mode: "HTML" });
        }
        const rams = (cfg.RAM_OPTIONS && cfg.RAM_OPTIONS[egg.category]) || cfg.RAM_OPTIONS.nodejs || ["1GB"];
        ctx.setState(String(msg.from.id), "panel_create_ram", { egg: eggId, username, scope });
        const rows = [];
        for (let i = 0; i < rams.length; i += 2) {
            const row = [{ text: `▸ ${rams[i]}`, callback_data: `panel_egg:${eggId}:${rams[i]}:${scope}` }];
            if (rams[i + 1]) row.push({ text: `▸ ${rams[i + 1]}`, callback_data: `panel_egg:${eggId}:${rams[i + 1]}:${scope}` });
            rows.push(row);
        }
        rows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);
        await bot.sendMessage(msg.chat.id, `<b>𖡛 PILIH RAM</b>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[PANEL CREATE USERNAME ERR]", e.message); }
});

router.registerCallback("panel_egg", async (bot, q, data, user, ctx) => {
    try {
        const parts = data.split(":");
        const eggId = parts[1];
        const ram = parts[2];
        const scope = parts[3] || "illegal";
        const uid = String(user.id);
        const st = ctx.getState(uid);
        if (!st || !st.username) return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });

        const p = readPanel();
        const rec = (p.users && p.users[uid]) || null;
        if (!rec && !isOwnerBot(user.id, ctx)) return bot.answerCallbackQuery(q.id, { text: "Belum di-add admin!", show_alert: true });

        if (scope === "legal") {
            if ((!rec || rec.scope !== "legal") && !isOwnerBot(user.id, ctx)) {
                return bot.answerCallbackQuery(q.id, { text: "✕ AKSES DITOLAK", show_alert: true });
            }
        }

        const dmOk = await canDMUser(bot, user.id);
        if (!dmOk) {
            ctx.clearState(uid);
            return bot.answerCallbackQuery(q.id, {
                text: "⚠️ Buka DM bot dulu & klik /start!",
                show_alert: true
            }).catch(() => {});
        }

        try {
            const gate = require("./gate.js");
            if (typeof gate.checkJoin === "function") {
                const join = await gate.checkJoin(bot, user.id);
                if (join && !join.ok) {
                    ctx.clearState(uid);
                    return bot.answerCallbackQuery(q.id, {
                        text: "⚠️ Join channel dulu!",
                        show_alert: true
                    }).catch(() => {});
                }
            }
        } catch {}

        if (rec) {
            if (rec.credit < 1) return bot.answerCallbackQuery(q.id, { text: "Credit habis!", show_alert: true });
            rec.credit -= 1;
            p.users[uid] = rec;
            writePanel(p);
        }

        const username = st.username;
        ctx.clearState(uid);
        const panel = scope === "legal" ? cfg.PANEL_LEGAL : cfg.PANEL_ILLEGAL;
        const domain = panel.DOMAIN || "belum diset";
        const password = generatePassword(12);
        const egg = (cfg.EGG_15 || []).find(e => e.id === eggId);
        const eggLabel = egg ? egg.name : eggId;

        const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
        const creditLeft = rec ? rec.credit : "∞";

        p.servers = p.servers || {};
        p.servers[username] = {
            username, password, egg: eggId, eggLabel, ram, scope, domain,
            owner: user.id, chatId: q.message.chat.id,
            createdAt: Date.now(),
            expiresAt,
            status: "unknown", cpu: 0, lastCheck: 0
        };
        writePanel(p);

        const result = await sendPanelToPrivate(bot, user.id, {
            username, password, domain, eggLabel, ram, scope, expiresAt, creditLeft
        }, q.message.chat.id);

        if (result.ok) {
            await bot.sendMessage(q.message.chat.id,
                `<b>✓ PANEL DIBUAT</b>\n\n` +
                `▸ User: <a href="tg://user?id=${user.id}">${user.first_name || "User"}</a>\n` +
                `▸ Username: <code>${username}</code>\n` +
                `▸ Server: ${scope === "legal" ? "Legal" : "Ilegal"}\n\n` +
                `<i>Data lengkap udah dikirim ke DM user.</i>`,
                { parse_mode: "HTML" });
        }
    } catch (e) {
        console.log("[PANEL EGG ERR]", e.message);
        try {
            await bot.sendMessage(q.message.chat.id,
                `<b>✕ Gagal create panel.</b>\n\n<code>${e.message.slice(0, 150)}</code>`,
                { parse_mode: "HTML" });
        } catch {}
    }
});

// ═══════════════════════════════════════════
// COPY BUTTONS
// ═══════════════════════════════════════════
router.registerCallback("copy_username", async (bot, q, data) => {
    try {
        const username = data.split(":").slice(1).join(":");
        await bot.answerCallbackQuery(q.id, {
            text: `✓ Username: ${username}`,
            show_alert: true,
            cache_time: 0
        }).catch(() => {});
    } catch (e) { console.log("[COPY USERNAME ERR]", e.message); }
});

router.registerCallback("copy_password", async (bot, q, data) => {
    try {
        const password = data.split(":").slice(1).join(":");
        await bot.answerCallbackQuery(q.id, {
            text: `✓ Password: ${password}`,
            show_alert: true,
            cache_time: 0
        }).catch(() => {});
    } catch (e) { console.log("[COPY PASSWORD ERR]", e.message); }
});

// ═══════════════════════════════════════════
// HANDLE /addrole
// ═══════════════════════════════════════════
module.exports.handleAddRole = async function (bot, msg, ctx) {
    try {
        const userId = String(msg.from.id);
        const chatId = msg.chat.id;

        console.log("[ADDROLE] === MULAI ===");
        console.log("[ADDROLE] from.id:", userId, "| chat.type:", msg.chat.type);
        console.log("[ADDROLE] reply ada?", !!msg.reply_to_message);

        if (msg.chat.type === "private") {
            return bot.sendMessage(chatId,
                `<b>✕ Command ini cuma bisa di GROUP.</b>\n\n` +
                `<b>Contoh pakai:</b>\n` +
                `<code>/addrole</code> (sambil reply pesan target)\n\n` +
                `<i>Pastiin group udah di-add admin bot lewat /addgroup.</i>`,
                { parse_mode: "HTML" });
        }

        if (!isGroupAllowed(chatId)) {
            return bot.sendMessage(chatId,
                `<b>✕ Group ini belum terdaftar.</b>\n\n` +
                `Owner harus add dulu pakai <code>/addgroup</code> di group ini.`,
                { parse_mode: "HTML" });
        }

        const p = readPanel();
        const actor = p.users[userId];
        const actorRole = actor?.role;
        const isOwner = ctx.db.isOwner(userId);
        const target = msg.reply_to_message?.from;

        if (!target) {
            return bot.sendMessage(chatId,
                `<b>𖡛 ADD ROLE — CARA PAKAI</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `<b>Langkah:</b>\n` +
                `1. Reply pesan user yang mau di-add\n` +
                `2. Ketik <code>/addrole</code>\n` +
                `3. Pilih server (Ilegal / Legal)\n` +
                `4. Pilih role\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>Contoh:</b>\n` +
                `<i>(reply pesan target)</i>\n` +
                `<code>/addrole</code>`,
                { parse_mode: "HTML" });
        }

        const roleMap = {
            reseller: [],
            admin: ["reseller"],
            owner: ["reseller", "admin"],
            partner: ["reseller", "admin", "owner"],
            tangankanann: ["reseller", "admin", "owner", "partner"],
            ceo: ["reseller", "admin", "owner", "partner", "tangankanann"],
            developer: ["reseller", "admin", "owner", "partner", "tangankanann", "ceo"]
        };
        let available = [];
        if (isOwner) available = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        else if (actorRole && roleMap[actorRole]) available = roleMap[actorRole];

        if (available.length === 0) {
            return bot.sendMessage(chatId,
                `<b>✕ Akses Ditolak!</b>\n\n` +
                `Lu ${actorRole ? `role <b>${ROLE_LABEL[actorRole] || actorRole}</b>` : "belum punya role"}.`,
                { parse_mode: "HTML" });
        }

        const targetId = String(target.id);
        const stateData = {
            targetId,
            targetName: target.first_name || "User",
            available,
            _ts: Date.now()
        };

        // ⚡ SET STATE — paksa pake String ID
        console.log("[ADDROLE] Set state untuk user", userId);
        ctx.setState(userId, "addrole_pick_server", stateData);

        // Verify state
        const verify = ctx.getState(userId);
        console.log("[ADDROLE] Verify state:", JSON.stringify(verify));

        if (!verify || !verify.targetId) {
            console.log("[ADDROLE] ⚠️ State gagal, retry pake number");
            ctx.setState(Number(userId), "addrole_pick_server", stateData);
            const verify2 = ctx.getState(Number(userId));
            console.log("[ADDROLE] Verify state v2:", JSON.stringify(verify2));
        }

        await bot.sendMessage(chatId,
            `<b>𖡛 ADD ROLE</b>\n\n` +
            `▸ Target: <a href="tg://user?id=${targetId}">${target.first_name || "User"}</a>\n` +
            `▸ Lu: ${isOwner ? "Owner Bot" : (ROLE_LABEL[actorRole] || actorRole)}\n\n` +
            `<b>Pilih Server:</b>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Server 1 (Ilegal)", callback_data: "addrole_srv:illegal", style: "success" }],
                        [{ text: "𖡛 Server 2 (Legal)", callback_data: "addrole_srv:legal", style: "success" }],
                        [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            });

        console.log("[ADDROLE] === SELESAI ===");
    } catch (e) {
        console.log("[ADDROLE ERR]", e.message);
        console.log("[ADDROLE STACK]", e.stack);
        await bot.sendMessage(msg.chat.id,
            `<b>✕ Error:</b>\n<code>${e.message.slice(0, 150)}</code>`,
            { parse_mode: "HTML" }).catch(() => {});
    }
};

// ═══════════════════════════════════════════
// CALLBACK: PILIH SERVER — FIXED
// ═══════════════════════════════════════════
router.registerCallback("addrole_srv", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        console.log("[ADDROLE_SRV] === MULAI ===");
        console.log("[ADDROLE_SRV] user.id:", userId, "| data:", data);

        await bot.answerCallbackQuery(q.id, { text: "Memproses...", show_alert: false }).catch(() => {});

        const scope = data.split(":")[1] || "illegal";
        console.log("[ADDROLE_SRV] scope:", scope);

        // ⚡ COBA SEMUA KEMUNGKINAN TIPE ID
        let st = ctx.getState(userId);
        if (!st || !st.targetId) {
            console.log("[ADDROLE_SRV] getState(string) null, coba number...");
            st = ctx.getState(Number(userId));
        }
        if (!st || !st.targetId) {
            console.log("[ADDROLE_SRV] getState(number) null, coba id asli...");
            st = ctx.getState(user.id);
        }

        console.log("[ADDROLE_SRV] state yang didapet:", JSON.stringify(st));

        if (!st || !st.targetId) {
            console.log("[ADDROLE_SRV] ❌ STATE NULL!");
            return bot.sendMessage(chatId,
                `<b>✕ Sesi habis.</b>\n\n<i>Ulangi dari awal.</i>\n\n` +
                `<b>Cara pakai:</b>\n` +
                `1. Reply pesan target\n` +
                `2. Ketik <code>/addrole</code>`,
                { parse_mode: "HTML" });
        }

        ctx.setState(userId, "addrole_pick_role", {
            targetId: st.targetId,
            targetName: st.targetName,
            available: st.available,
            scope,
            _ts: Date.now()
        });

        const verify = ctx.getState(userId);
        console.log("[ADDROLE_SRV] verify state baru:", JSON.stringify(verify));

        const rows = [];
        for (const r of (st.available || [])) {
            rows.push([{ text: `${ROLE_LABEL[r] || r}`, callback_data: `addrole_do2:${r}`, style: "success" }]);
        }
        rows.push([{ text: "𖡛 Ganti Server", callback_data: "addrole_back_srv", style: "primary" }]);
        rows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        try {
            await bot.editMessageText(
                `<b>𖡛 ADD ROLE</b>\n\n` +
                `▸ Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n` +
                `▸ Server: <b>${scope === "legal" ? "Server 2 (Legal)" : "Server 1 (Ilegal)"}</b>\n\n` +
                `<b>Pilih Role:</b>`,
                {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: rows }
                });
        } catch (e) {
            if (!e.message.includes("message is not modified")) {
                await bot.sendMessage(chatId,
                    `<b>𖡛 ADD ROLE</b>\n\n` +
                    `▸ Target: ${st.targetName}\n` +
                    `▸ Server: ${scope}\n\n` +
                    `<b>Pilih Role:</b>`,
                    { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
            }
        }

        console.log("[ADDROLE_SRV] === SELESAI ===");
    } catch (e) {
        console.log("[ADDROLE SRV ERR]", e.message);
        console.log("[ADDROLE SRV STACK]", e.stack);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Error: " + e.message.slice(0, 100),
                show_alert: true
            }).catch(() => {});
        } catch {}
    }
});

// ═══════════════════════════════════════════
// CALLBACK: GANTI SERVER — FIXED
// ═══════════════════════════════════════════
router.registerCallback("addrole_back_srv", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        console.log("[ADDROLE_BACK] user:", userId);
        await bot.answerCallbackQuery(q.id, { text: "Balik...", show_alert: false }).catch(() => {});

        let st = ctx.getState(userId);
        if (!st || !st.targetId) st = ctx.getState(Number(userId));
        if (!st || !st.targetId) st = ctx.getState(user.id);

        console.log("[ADDROLE_BACK] state:", JSON.stringify(st));

        if (!st || !st.targetId) {
            return bot.sendMessage(chatId,
                `<b>✕ Sesi habis.</b>\n\n<i>Ulangi dari awal.</i>`,
                { parse_mode: "HTML" });
        }

        ctx.setState(userId, "addrole_pick_server", {
            targetId: st.targetId,
            targetName: st.targetName,
            available: st.available,
            _ts: Date.now()
        });

        try {
            await bot.editMessageText(
                `<b>𖡛 ADD ROLE</b>\n\n` +
                `▸ Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n\n` +
                `<b>Pilih Server:</b>`,
                {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "𖡛 Server 1 (Ilegal)", callback_data: "addrole_srv:illegal", style: "success" }],
                            [{ text: "𖡛 Server 2 (Legal)", callback_data: "addrole_srv:legal", style: "success" }],
                            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
                        ]
                    }
                });
        } catch {}
    } catch (e) {
        console.log("[ADDROLE BACK ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// CALLBACK: PILIH ROLE + DO — FIXED
// ═══════════════════════════════════════════
router.registerCallback("addrole_do2", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        console.log("[ADDROLE_DO2] user:", userId, "| data:", data);
        await bot.answerCallbackQuery(q.id, { text: "Memproses...", show_alert: false }).catch(() => {});

        const role = data.split(":")[1];
        let st = ctx.getState(userId);
        if (!st || !st.targetId) st = ctx.getState(Number(userId));
        if (!st || !st.targetId) st = ctx.getState(user.id);

        console.log("[ADDROLE_DO2] state:", JSON.stringify(st));

        if (!st || !st.targetId || !st.scope) {
            return bot.sendMessage(chatId,
                `<b>✕ Sesi habis.</b>\n\n<i>Ulangi dari awal.</i>`,
                { parse_mode: "HTML" });
        }

        const p = readPanel();
        const actor = p.users[userId];
        const actorRole = actor?.role;
        const isOwner = ctx.db.isOwner(userId);
        const roleMap = {
            reseller: [],
            admin: ["reseller"],
            owner: ["reseller", "admin"],
            partner: ["reseller", "admin", "owner"],
            tangankanann: ["reseller", "admin", "owner", "partner"],
            ceo: ["reseller", "admin", "owner", "partner", "tangankanann"],
            developer: ["reseller", "admin", "owner", "partner", "tangankanann", "ceo"]
        };
        let available = [];
        if (isOwner) available = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        else if (actorRole && roleMap[actorRole]) available = roleMap[actorRole];

        if (!available.includes(role)) {
            return bot.answerCallbackQuery(q.id, { text: "Lu ga boleh add role ini!", show_alert: true });
        }

        ensureUser(st.targetId, role, 30, 10, st.scope);
        const scopeLabel = st.scope === "legal" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

        ctx.clearState(userId);

        try { await bot.deleteMessage(chatId, msgId).catch(() => {}); } catch {}

        await bot.sendMessage(chatId,
            `<b>✓ ROLE DITAMBAHKAN</b>\n\n` +
            `▸ Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n` +
            `▸ Role: <b>${ROLE_LABEL[role] || role}</b>\n` +
            `▸ Server: <b>${scopeLabel}</b>\n` +
            `▸ Durasi: 30 hari | 10 credit`,
            { parse_mode: "HTML" });

        await bot.sendMessage(st.targetId,
            `<b>ROLE BARU</b>\n\n` +
            `▸ Role: <b>${ROLE_LABEL[role] || role}</b>\n` +
            `▸ Server: <b>${scopeLabel}</b>\n` +
            `▸ Durasi: 30 hari\n\n` +
            `<i>Ketik /menu buat akses fitur.</i>`,
            { parse_mode: "HTML" }).catch(() => {});
    } catch (e) {
        console.log("[ADDROLE DO2 ERR]", e.message);
        console.log("[ADDROLE DO2 STACK]", e.stack);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Error: " + e.message.slice(0, 100),
                show_alert: true
            }).catch(() => {});
        } catch {}
    }
});

// ═══════════════════════════════════════════
// HANDLE /addall
// ═══════════════════════════════════════════
module.exports.handleAddAll = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") {
            return bot.sendMessage(msg.chat.id, `<b>✕ Cuma bisa di group.</b>`, { parse_mode: "HTML" });
        }
        if (!isGroupAllowed(msg.chat.id)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Group belum terdaftar.</b>\n\nOwner kirim <code>/addgroup</code> dulu.`,
                { parse_mode: "HTML" });
        }
        if (!ctx.db.isOwner(msg.from.id)) return bot.sendMessage(msg.chat.id, `<b>✕ Owner only.</b>`, { parse_mode: "HTML" });
        const target = msg.reply_to_message?.from;
        if (!target) return bot.sendMessage(msg.chat.id, `<b>✕ Reply target dulu.</b>`, { parse_mode: "HTML" });
        const roles = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        for (const r of roles) ensureUser(target.id, r, 30, 10, "legal");
        await bot.sendMessage(msg.chat.id,
            `<b>✓ ADD ALL ROLE</b>\n\n▸ Target: ${target.first_name}\n` +
            roles.map(r => `▸ ${ROLE_LABEL[r]}`).join("\n"),
            { parse_mode: "HTML" });
    } catch (e) { console.log("[ADDALL ERR]", e.message); }
};

// ═══════════════════════════════════════════
// HANDLE /cadp & /cadp2
// ═══════════════════════════════════════════
module.exports.handleCadp = async function (bot, msg, ctx, serverNum = 1) {
    try {
        const cmd = serverNum === 2 ? "/cadp2" : "/cadp";

        if (msg.chat.type === "private") {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Command ini cuma bisa di GROUP.</b>\n\n` +
                `<b>Contoh pakai:</b>\n` +
                `<code>${cmd} username_panel</code>`,
                { parse_mode: "HTML" });
        }

        if (!isGroupAllowed(msg.chat.id)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Group ini belum terdaftar.</b>\n\n` +
                `Owner harus add dulu pakai <code>/addgroup</code> di group ini.`,
                { parse_mode: "HTML" });
        }

        const p = readPanel();
        const uid = String(msg.from.id);
        const actor = p.users[uid];
        const actorRole = actor?.role;
        const actorScope = actor?.scope || "illegal";
        const isOwner = ctx.db.isOwner(msg.from.id);

        if (!isOwner && !actorRole) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Akses Ditolak!</b>\n\n` +
                `<b>Tutorial:</b>\n` +
                `1. Reply pesan target\n` +
                `2. Ketik <code>/addrole</code> buat di-add jadi admin`,
                { parse_mode: "HTML" });
        }

        if (serverNum === 2 && !isOwner && actorScope !== "legal") {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Lu cuma akses Server 1.</b>`,
                { parse_mode: "HTML" });
        }

        const text = msg.text || "";
        const args = text.split(/\s+/).slice(1);
        let username = args.join(" ").trim();

        if (!username) {
            ctx.setState(uid, `cadp_${serverNum}_await`, { serverNum });
            return bot.sendMessage(msg.chat.id,
                `<b>𖡛 CREATE ADP ${serverNum}</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `<b>Cara pakai:</b>\n` +
                `▸ <code>${cmd} username_panel</code>\n\n` +
                `<b>Aturan username:</b>\n` +
                `▸ Huruf kecil / angka / underscore\n` +
                `▸ Min 3, max 20 karakter\n` +
                `▸ Contoh: <code>admin01</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
                });
        }

        if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Username invalid!</b>`,
                { parse_mode: "HTML" });
        }

        const dmOk = await canDMUser(bot, msg.from.id);
        if (!dmOk) {
            return bot.sendMessage(msg.chat.id,
                `<b>⚠️ Buka DM bot dulu & klik /start!</b>\n\n` +
                `<i>Biar data ADP dikirim ke DM lu.</i>`,
                { parse_mode: "HTML" });
        }

        const password = generatePassword(12);
        const adpId = `ADP${serverNum}${Date.now().toString(36).toUpperCase()}`;
        const panel = serverNum === 2 ? (cfg.PANEL_LEGAL || {}) : (cfg.PANEL_ILLEGAL || {});
        const domainPanel = panel.DOMAIN || "panel.domain.com";

        p.adp = p.adp || { "1": {}, "2": {} };
        p.adp[serverNum] = p.adp[serverNum] || {};
        p.adp[serverNum][username] = {
            id: adpId, username, password, server: serverNum,
            scope: serverNum === 2 ? "legal" : "illegal",
            createdAt: Date.now(), createdBy: msg.from.id
        };
        writePanel(p);

        const scopeLabel = serverNum === 2 ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

        const sendResult = await sendAdpToPrivate(bot, msg.from.id, {
            username, password, domain: domainPanel, scopeLabel, adpId
        }, msg.chat.id);

        if (sendResult.ok) {
            await bot.sendMessage(msg.chat.id,
                `<b>✓ ADP DIBUAT</b>\n\n` +
                `▸ User: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name || "User"}</a>\n` +
                `▸ Username: <code>${username}</code>\n` +
                `▸ Server: ${scopeLabel}\n\n` +
                `<i>Data lengkap udah dikirim ke DM lu.</i>`,
                { parse_mode: "HTML" });
        }
    } catch (e) {
        console.log("[CADP ERR]", e.message);
        await bot.sendMessage(msg.chat.id,
            `<b>✕ Error:</b>\n<code>${e.message.slice(0, 150)}</code>`,
            { parse_mode: "HTML" }).catch(() => {});
    }
};

router.registerMessage("cadp_1_await", async (bot, msg, state, ctx) => {
    const username = msg.text?.trim();
    if (!username) return;
    ctx.clearState(String(msg.from.id));
    const fakeMsg = { ...msg, text: `/cadp ${username}` };
    await module.exports.handleCadp(bot, fakeMsg, ctx, 1);
});

router.registerMessage("cadp_2_await", async (bot, msg, state, ctx) => {
    const username = msg.text?.trim();
    if (!username) return;
    ctx.clearState(String(msg.from.id));
    const fakeMsg = { ...msg, text: `/cadp2 ${username}` };
    await module.exports.handleCadp(bot, fakeMsg, ctx, 2);
});

// ═══════════════════════════════════════════
// BUTTON ADD ROLE
// ═══════════════════════════════════════════
router.registerCallback("panel_addrole", async (bot, q, data, user, ctx) => {
    try {
        await bot.sendMessage(q.message.chat.id, `<b>𖡛 ADD ROLE</b>\n\nReply user + <code>/addrole</code>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[PANEL ADDROLE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// SET CONFIG
// ═══════════════════════════════════════════
router.registerCallback("panel_setconfig", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwnerBot(user.id, ctx)) return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true });
        const p = readPanel();
        const c = p.config;
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 SET CONFIG</b>\n\n▸ PLTA: <code>${c.plta || "-"}</code>\n▸ PLTC: <code>${c.pltc || "-"}</code>\n▸ Domain: <code>${c.domain || "-"}</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [
                [{ text: "𖡛 Set PLTA", callback_data: "panel_setcfg:plta", style: "success" }],
                [{ text: "𖡛 Set PLTC", callback_data: "panel_setcfg:pltc", style: "success" }],
                [{ text: "𖡛 Set Domain", callback_data: "panel_setcfg:domain", style: "success" }],
                [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
            ] } });
    } catch (e) { console.log("[PANEL SETCONFIG ERR]", e.message); }
});

router.registerCallback("panel_setcfg", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwnerBot(user.id, ctx)) return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true });
        const key = data.split(":")[1];
        ctx.setState(String(user.id), "panel_setcfg_await", { key });
        await bot.sendMessage(q.message.chat.id, `<b>Kirim nilai <code>${key}</code>:</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[PANEL SETCFG ERR]", e.message); }
});

router.registerMessage("panel_setcfg_await", async (bot, msg, state, ctx) => {
    try {
        if (!ctx.db.isOwner(msg.from.id)) return;
        const val = msg.text?.trim();
        if (!val) return;
        const p = readPanel();
        p.config[state.key] = val;
        writePanel(p);
        await bot.sendMessage(msg.chat.id, `<b>✓ ${state.key} = <code>${val}</code></b>`, { parse_mode: "HTML" });
        ctx.clearState(String(msg.from.id));
    } catch (e) { console.log("[PANEL SETCFG AWAIT ERR]", e.message); }
});

// ═══════════════════════════════════════════
// INFO ROLE
// ═══════════════════════════════════════════
router.registerCallback("panel_info", async (bot, q, data, user, ctx) => {
    try {
        const p = readPanel();
        const uid = String(user.id);
        const target = (p.users && p.users[uid]) || null;
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 INFO ROLE</b>\n\n▸ ID: <code>${uid}</code>\n▸ Role: <b>${target ? ROLE_LABEL[target.role] : "Owner Bot"}</b>\n▸ Scope: ${target ? target.scope : "Semua"}\n▸ Expired: ${target ? Math.ceil((target.expiresAt - Date.now()) / 86400000) + " hari" : "∞"}\n▸ Credit: <code>${target ? target.credit : "∞"}</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[PANEL INFO ERR]", e.message); }
});

// ═══════════════════════════════════════════
// MONITORING
// ═══════════════════════════════════════════
async function checkAllServers() {
    const p = readPanel();
    const servers = p.servers || {};
    const list = Object.values(servers);
    if (list.length === 0) return null;
    let online = 0, offline = 0, totalCpu = 0, totalRam = 0;
    for (const s of list) {
        if (s.status === "online") { online++; totalCpu += s.cpu || 0; totalRam += s.ram || 0; } else offline++;
    }
    const avgCpu = online > 0 ? (totalCpu / online).toFixed(1) : "0.0";
    const avgRam = online > 0 ? (totalRam / online).toFixed(1) : "0.0";
    return { total: list.length, online, offline, avgCpu, avgRam, time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) };
}

router.registerCallback("panel_monitoring", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwnerBot(user.id, ctx)) {
            return bot.answerCallbackQuery(q.id, { text: "⚠️ OWNER ONLY!", show_alert: true }).catch(() => {});
        }
        await bot.answerCallbackQuery(q.id, { text: "Cek server...", show_alert: false });
        const stat = await checkAllServers();
        if (!stat) return bot.sendMessage(q.message.chat.id, `<b>𖡛 MONITORING</b>\n\n<i>✕ Belum ada server.</i>`, { parse_mode: "HTML" });
        const text =
            `<b>𖡛 SERVER MONITORING</b>\n\n` +
            `𖡛 Total: <code>${stat.total}</code>\n` +
            `𖡛 Online: <code>${stat.online}</code>\n` +
            `𖡛 Offline: <code>${stat.offline}</code>\n` +
            `𖡛 CPU: <code>${stat.avgCpu}%</code>\n` +
            `𖡛 RAM: <code>${stat.avgRam}MB</code>\n` +
            `𖡛 ${stat.time}`;
        const kb = [];
        if (stat.offline > 0) kb.push([{ text: "▸ Delete Offline", callback_data: "panel_delete_offline", style: "success" }]);
        kb.push([{ text: "𖡛 Refresh", callback_data: "panel_monitoring", style: "primary" }]);
        kb.push([{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]);
        await bot.sendMessage(q.message.chat.id, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[PANEL MONITORING ERR]", e.message); }
});

router.registerCallback("panel_delete_offline", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwnerBot(user.id, ctx)) {
            return bot.answerCallbackQuery(q.id, { text: "⚠️ OWNER ONLY!", show_alert: true }).catch(() => {});
        }
        const p = readPanel();
        const servers = p.servers || {};
        let deleted = 0, kept = 0;
        for (const username in servers) {
            if (servers[username].status !== "online") { delete servers[username]; deleted++; } else kept++;
        }
        p.servers = servers;
        writePanel(p);
        await bot.answerCallbackQuery(q.id, { text: `${deleted} server offline dihapus`, show_alert: true });
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 DELETE OFFLINE</b>\n\n▸ Dihapus: <code>${deleted}</code>\n▸ Dipertahankan: <code>${kept}</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[PANEL DELOFFLINE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// HANDLE /add
// ═══════════════════════════════════════════
module.exports.handleAdd = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") {
            return bot.sendMessage(msg.chat.id, `<b>✕ Cuma bisa di group.</b>`, { parse_mode: "HTML" });
        }
        if (!isGroupAllowed(msg.chat.id)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Group belum terdaftar.</b>\n\nOwner kirim <code>/addgroup</code> dulu.`,
                { parse_mode: "HTML" });
        }
        let isAdm = false;
        try {
            const m = await bot.getChatMember(msg.chat.id, msg.from.id);
            isAdm = ["creator", "administrator"].includes(m.status);
        } catch {}
        if (!isAdm && !ctx.db.isOwner(msg.from.id)) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
        }
        const target = msg.reply_to_message?.from;
        if (!target) {
            return bot.sendMessage(msg.chat.id,
                `<b>𖡛 ADD RESELLER</b>\n\n` +
                `<b>Cara pakai:</b>\n` +
                `1. Reply pesan user target\n` +
                `2. Ketik <code>/add</code>`,
                { parse_mode: "HTML" });
        }
        ensureUser(target.id, "reseller", 30, 10, "illegal");
        await bot.sendMessage(msg.chat.id,
            `<b>✓ ADD RESELLER</b>\n\n▸ ${target.first_name}\n▸ Reseller\n▸ Server 1 (Ilegal)\n▸ 30 hari | 10 credit`,
            { parse_mode: "HTML" });
        await bot.sendMessage(target.id, `<b>ROLE BARU</b>\n\nReseller — Server 1`, { parse_mode: "HTML" }).catch(() => {});
    } catch (e) { console.log("[PANEL ADD ERR]", e.message); }
};

// ═══════════════════════════════════════════
// HANDLE /info
// ═══════════════════════════════════════════
module.exports.handleInfoGroup = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") return;
        if (!isGroupAllowed(msg.chat.id)) return;
        const p = readPanel();
        const target = msg.reply_to_message?.from || msg.from;
        const uid = String(target.id);
        const rec = (p.users && p.users[uid]) || null;
        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 INFO USER</b>\n\n▸ ID: <code>${uid}</code>\n▸ Nama: ${[target.first_name, target.last_name].filter(Boolean).join(" ")}\n▸ Username: ${target.username ? "@" + target.username : "-"}\n▸ Role: <b>${rec ? ROLE_LABEL[rec.role] : "Tidak ada"}</b>\n▸ Scope: ${rec ? rec.scope : "-"}\n▸ Expired: <b>${rec ? Math.ceil((rec.expiresAt - Date.now()) / 86400000) + " hari" : "-"}</b>\n▸ Credit: <code>${rec ? rec.credit : "-"}</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[PANEL INFO GROUP ERR]", e.message); }
};

// ═══════════════════════════════════════════
// HANDLE /addgroup
// ═══════════════════════════════════════════
module.exports.handleAddGroup = async function (bot, msg, ctx) {
    try {
        if (!ctx.db.isOwner(msg.from.id)) return bot.sendMessage(msg.chat.id, `<b>✕ Owner only.</b>`, { parse_mode: "HTML" });
        const p = readPanel();
        const isMainGroup = String(msg.chat.id) === String(cfg.MAIN_GROUP_ID);
        if (isMainGroup) return bot.sendMessage(msg.chat.id, `<b>Group ini udah MAIN_GROUP_ID.</b>`, { parse_mode: "HTML" });
        if (!p.groups.some(g => String(g) === String(msg.chat.id))) {
            p.groups.push(String(msg.chat.id));
            writePanel(p);
            await bot.sendMessage(msg.chat.id, `<b>✓ Group ditambah.</b>\n\n▸ <code>${msg.chat.id}</code>`, { parse_mode: "HTML" });
        } else {
            await bot.sendMessage(msg.chat.id, `<b>✓ Group udah ada.</b>`, { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[PANEL ADDGROUP ERR]", e.message); }
};

// ═══════════════════════════════════════════
// MONITORING LOOP
// ═══════════════════════════════════════════
module.exports.startMonitoringLoop = function (bot) {
    console.log("[PANEL] startMonitoringLoop called");
    setInterval(async () => {
        try { await checkAllServers(); } catch (e) {}
    }, 5 * 60 * 1000);
};

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports.ROLE_LABEL = ROLE_LABEL;
module.exports.readPanel = readPanel;
module.exports.writePanel = writePanel;
module.exports.ensureUser = ensureUser;
module.exports.checkAllServers = checkAllServers;
module.exports.generatePassword = generatePassword;
module.exports.normalizeUrl = normalizeUrl;
module.exports.hasPerm = hasPerm;
module.exports.canAddRole = canAddRole;
module.exports.isOwnerBot = isOwnerBot;
console.log("[PANEL] module loaded");