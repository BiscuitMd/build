const router = require("./router");
const cfg = require("../config");

// ═══════════════════════════════════════════
// UNICODE STYLE MAPPINGS
// ═══════════════════════════════════════════
function transform(text, type) {
    switch (type) {
        case "bold_serif":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D400 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D41A + code - 97);
                if (c >= "0" && c <= "9") return String.fromCodePoint(0x1D7CE + code - 48);
                return c;
            });

        case "italic":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D434 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D44E + code - 97);
                return c;
            });

        case "bold_italic":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D468 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D482 + code - 97);
                return c;
            });

        case "script":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D49C + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D4B6 + code - 97);
                return c;
            });

        case "bold_script":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D4D0 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D4EA + code - 97);
                return c;
            });

        case "fraktur":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D504 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D51E + code - 97);
                return c;
            });

        case "double_struck":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D538 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D552 + code - 97);
                if (c >= "0" && c <= "9") return String.fromCodePoint(0x1D7D8 + code - 48);
                return c;
            });

        case "monospace":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1D670 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1D68A + code - 97);
                if (c >= "0" && c <= "9") return String.fromCodePoint(0x1D7F6 + code - 48);
                return c;
            });

        case "small_caps":
            return text.replace(/[A-Za-z]/g, c => {
                const map = {
                    a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ꜰ", g: "ɢ", h: "ʜ", i: "ɪ",
                    j: "ᴊ", k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ",
                    s: "ꜱ", t: "ᴛ", u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ"
                };
                return map[c.toLowerCase()] || c;
            });

        case "superscript":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const map = {
                    a: "ᵃ", b: "ᵇ", c: "ᶜ", d: "ᵈ", e: "ᵉ", f: "ᶠ", g: "ᵍ", h: "ʰ", i: "ⁱ",
                    j: "ʲ", k: "ᵏ", l: "ˡ", m: "ᵐ", n: "ⁿ", o: "ᵒ", p: "ᵖ", q: "�q", r: "ʳ",
                    s: "ˢ", t: "ᵗ", u: "ᵘ", v: "ᵛ", w: "ʷ", x: "ˣ", y: "ʸ", z: "ᶻ",
                    "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
                    "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹"
                };
                return map[c.toLowerCase()] || map[c] || c;
            });

        case "subscript":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const map = {
                    a: "ₐ", e: "ₑ", h: "ₕ", i: "ᵢ", j: "ⱼ", k: "ₖ", l: "ₗ", m: "ₘ", n: "ₙ",
                    o: "ₒ", p: "ₚ", r: "ᵣ", s: "ₛ", t: "ₜ", u: "ᵤ", v: "ᵥ", x: "ₓ",
                    "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
                    "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉"
                };
                return map[c.toLowerCase()] || map[c] || c;
            });

        case "wide":
            return text.split("").map(c => {
                if (c === " ") return "  ";
                return c;
            }).join(" ");

        case "fullwidth":
            return text.replace(/[A-Za-z0-9!-~]/g, c => {
                const code = c.charCodeAt(0);
                if (code >= 33 && code <= 126) return String.fromCodePoint(code + 0xFEE0);
                return c;
            });

        case "circled":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x24B6 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x24D0 + code - 97);
                if (c >= "0" && c <= "9") {
                    if (c === "0") return "⓪";
                    return String.fromCodePoint(0x2460 + code - 49);
                }
                return c;
            });

        case "circled_negative":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1F150 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x1F170 + code - 97);
                return c;
            });

        case "squared":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1F130 + code - 65);
                return c;
            });

        case "squared_negative":
            return text.replace(/[A-Za-z]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1F170 + code - 65);
                return c;
            });

        case "parenthesized":
            return text.replace(/[A-Za-z0-9]/g, c => {
                const code = c.charCodeAt(0);
                if (c >= "A" && c <= "Z") return String.fromCodePoint(0x1F110 + code - 65);
                if (c >= "a" && c <= "z") return String.fromCodePoint(0x249C + code - 97);
                if (c >= "0" && c <= "9") return String.fromCodePoint(0x2474 + code - 49);
                return c;
            });

        case "strikethrough":
            return text.split("").map(c => c + "\u0336").join("");

        case "underline":
            return text.split("").map(c => c + "\u0332").join("");

        case "overline":
            return text.split("").map(c => c + "\u0305").join("");

        case "slash":
            return text.split("").map(c => c + "\u0338").join("");

        case "sparkle":
            return text.split("").map(c => c === " " ? "✦" : c + "✧").join("");

        case "hearts":
            return text.split("").map(c => c === " " ? "♡" : c + "♡").join("");

        case "stars":
            return text.split("").map(c => c === " " ? "★" : c + "☆").join("");

        case "brackets":
            return text.split("").map(c => c === " " ? " " : "「" + c + "」").join("");

        case "dots":
            return text.split("").map(c => c + "\u0307").join("");

        case "upsidedown":
            return text.split("").map(c => {
                const map = {
                    "a": "ɐ", "b": "q", "c": "ɔ", "d": "p", "e": "ǝ", "f": "ɟ",
                    "g": "ƃ", "h": "ɥ", "i": "ᴉ", "j": "ɾ", "k": "ʞ", "l": "l",
                    "m": "ɯ", "n": "u", "o": "o", "p": "d", "q": "b", "r": "ɹ",
                    "s": "s", "t": "ʇ", "u": "n", "v": "ʌ", "w": "ʍ", "x": "x",
                    "y": "ʎ", "z": "z",
                    "A": "∀", "B": "𐐒", "C": "Ɔ", "D": "p", "E": "Ǝ", "F": "Ⅎ",
                    "G": "פ", "H": "H", "I": "I", "J": "ſ", "K": "ʞ", "L": "˥",
                    "M": "W", "N": "N", "O": "O", "P": "Ԁ", "Q": "Q", "R": "ᴚ",
                    "S": "S", "T": "┴", "U": "∩", "V": "Λ", "W": "M", "X": "X",
                    "Y": "⅄", "Z": "Z"
                };
                return map[c] || c;
            }).reverse().join("");

        case "zalgo_light":
            return text.split("").map(c => c + "\u0301\u0302").join("");

        case "zalgo_medium":
            return text.split("").map(c => c + "\u0301\u0302\u0303\u0304").join("");

        case "zalgo_heavy":
            return text.split("").map(c => c + "\u0301\u0302\u0303\u0304\u0305\u0306\u0307\u0308").join("");

        default:
            return text;
    }
}

// ═══════════════════════════════════════════
// STYLE LIST
// ═══════════════════════════════════════════
const STYLE_LIST = [
    { id: "bold_serif", name: "𝗕𝗼𝗹𝗱 𝗦𝗲𝗿𝗶𝗳" },
    { id: "italic", name: "𝘐𝘵𝘢𝘭𝘪𝘤" },
    { id: "bold_italic", name: "𝙄𝙩𝙖𝙡𝙞𝙘 𝘽𝙤𝙡𝙙" },
    { id: "script", name: "𝒮𝒸𝓇𝒾𝓅𝓉" },
    { id: "bold_script", name: "𝓢𝓬𝓻𝓲𝓹𝓽 𝓑𝓸𝓵𝓭" },
    { id: "fraktur", name: "𝔉𝔯𝔞𝔨𝔱𝔲𝔯" },
    { id: "double_struck", name: "𝔻𝕠𝕦𝕓𝕝𝕖 𝕊𝕥𝕣𝕦𝕔𝕜" },
    { id: "monospace", name: "𝙼𝚘𝚗𝚘𝚜𝚙𝚊𝚌𝚎" },
    { id: "small_caps", name: "ꜱᴍᴀʟʟ ᴄᴀᴘꜱ" },
    { id: "superscript", name: "ˢᵘᵖᵉʳˢᶜʳⁱᵖᵗ" },
    { id: "subscript", name: "ₛᵤᵦₛcᵣᵢₚₜ" },
    { id: "wide", name: "Ｗ Ｉ Ｄ Ｅ" },
    { id: "fullwidth", name: "Ｆｕｌｌｗｉｄｔｈ" },
    { id: "circled", name: "Ⓒⓘⓡⓒⓛⓔⓓ" },
    { id: "circled_negative", name: "🅒🅘🅡🅒🅛🅔" },
    { id: "squared", name: "🅂🅠🅄🄰🅁🄴" },
    { id: "parenthesized", name: "🄿🄰🅁🄴🄽" },
    { id: "strikethrough", name: "S̶t̶r̶i̶k̶e̶" },
    { id: "underline", name: "U̲n̲d̲e̲r̲l̲i̲n̲e̲" },
    { id: "overline", name: "O̅v̅e̅r̅l̅i̅n̅e̅" },
    { id: "slash", name: "S̸l̸a̸s̸h̸" },
    { id: "sparkle", name: "S✧p✧a✧r✧k" },
    { id: "hearts", name: "H♡e♡a♡r♡t" },
    { id: "stars", name: "S☆t☆a☆r☆s" },
    { id: "brackets", name: "「B」「r」「a」「c」" },
    { id: "dots", name: "Ḋ̇ö̇ṫ̇ṡ̇" },
    { id: "upsidedown", name: "uʍopǝpᴉsdn" },
    { id: "zalgo_light", name: "Z̡̢a͜͝l̨͜g͝o͝" },
    { id: "zalgo_medium", name: "Z̡̢̨a͜͝l̨͜͝g͝ǫ" },
    { id: "zalgo_heavy", name: "Z̡̢̨̛a͜͠l̨̧͜͝g͝ǫ̛̕" }
];

// ═══════════════════════════════════════════
// MENU: TEXT STYLER
// ═══════════════════════════════════════════
router.registerCallback("tool_textstyler", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "textstyler_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>▸ TEXT STYLER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Kirim teks yang mau lu style.</i>\n` +
        `Contoh: <code>BOT MUTLI FUNGSI</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back" }]] } });
});

router.registerMessage("textstyler_await", async (bot, msg, state, ctx) => {
    const text = msg.text?.trim();
    if (!text) return;

    if (text.length > 100) {
        return bot.sendMessage(msg.chat.id,
            `<b>✕ Teks terlalu panjang</b>\n\nMax 100 karakter.`,
            { parse_mode: "HTML" });
    }

    ctx.clearState(msg.from.id);

    // Simpan teks di state untuk diakses tombol
    ctx.setState(msg.from.id, "textstyler_ready", { originalText: text });

    // Preview semua style — kirim dalam 1 pesan panjang
    let previewText = `<b>𖡛 HASIL STYLE</b>\n\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (let i = 0; i < STYLE_LIST.length; i++) {
        const style = STYLE_LIST[i];
        const styled = transform(text, style.id);
        previewText += `<b>${i + 1}.</b> <code>${styled}</code>\n`;
    }
    previewText += `━━━━━━━━━━━━━━━━━━━━\n<i>Pilih nomor style di bawah:</i>`;

    // Bikin tombol — 3 per baris
    const rows = [];
    for (let i = 0; i < STYLE_LIST.length; i += 3) {
        const row = [];
        for (let j = 0; j < 3 && i + j < STYLE_LIST.length; j++) {
            const idx = i + j;
            row.push({ text: `${idx + 1}`, callback_data: `textstyler_pick:${idx}` });
        }
        rows.push(row);
    }
    rows.push([{ text: "𖡛 Ganti Teks", callback_data: "tool_textstyler", style: "success" }]);
    rows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

    try {
        await bot.sendMessage(msg.chat.id, previewText, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    } catch (e) {
        console.log("[TEXTSTYLER PREVIEW ERR]", e.message);
    }
});

router.registerCallback("textstyler_pick", async (bot, q, data, user, ctx) => {
    const idx = parseInt(data.split(":")[1]);
    const st = ctx.getState(user.id);

    if (!st || !st.originalText) {
        return bot.answerCallbackQuery(q.id, { text: "Sesi habis, ulangi.", show_alert: true });
    }

    const style = STYLE_LIST[idx];
    if (!style) {
        return bot.answerCallbackQuery(q.id, { text: "Style tidak valid", show_alert: true });
    }

    const styled = transform(st.originalText, style.id);

    await bot.answerCallbackQuery(q.id, { text: `Style ${idx + 1} dipilih`, show_alert: false });

    try {
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 HASIL STYLE ${idx + 1}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Original:</b>\n<code>${st.originalText}</code>\n\n` +
            `<b>Styled:</b>\n<code>${styled}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Tap teks di atas untuk copy.</i>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Copy Style", callback_data: `textstyler_copy:${idx}`, style: "success" }],
                        [{ text: "𖡛 Ganti Style", callback_data: "textstyler_back", style: "success" }],
                        [{ text: "✕ Tutup", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            });
    } catch (e) {
        console.log("[TEXTSTYLER PICK ERR]", e.message);
    }
});

router.registerCallback("textstyler_copy", async (bot, q, data, user, ctx) => {
    const idx = parseInt(data.split(":")[1]);
    const st = ctx.getState(user.id);

    if (!st || !st.originalText) {
        return bot.answerCallbackQuery(q.id, { text: "Sesi habis.", show_alert: true });
    }

    const style = STYLE_LIST[idx];
    if (!style) return bot.answerCallbackQuery(q.id, { text: "Style invalid", show_alert: true });

    const styled = transform(st.originalText, style.id);

    await bot.answerCallbackQuery(q.id, {
        text: styled.length > 200 ? styled.slice(0, 200) : styled,
        show_alert: true
    }).catch(() => {});
});

router.registerCallback("textstyler_back", async (bot, q, data, user, ctx) => {
    const st = ctx.getState(user.id);
    if (!st || !st.originalText) {
        return bot.answerCallbackQuery(q.id, { text: "Sesi habis.", show_alert: true });
    }

    const text = st.originalText;

    let previewText = `<b>𖡛 HASIL STYLE</b>\n\n━━━━━━━━━━━━━━━━━━━━\n`;
    for (let i = 0; i < STYLE_LIST.length; i++) {
        const style = STYLE_LIST[i];
        const styled = transform(text, style.id);
        previewText += `<b>${i + 1}.</b> <code>${styled}</code>\n`;
    }
    previewText += `━━━━━━━━━━━━━━━━━━━━\n<i>Pilih nomor style:</i>`;

    const rows = [];
    for (let i = 0; i < STYLE_LIST.length; i += 3) {
        const row = [];
        for (let j = 0; j < 3 && i + j < STYLE_LIST.length; j++) {
            const idx = i + j;
            row.push({ text: `${idx + 1}`, callback_data: `textstyler_pick:${idx}` });
        }
        rows.push(row);
    }
    rows.push([{ text: "▸ Ganti Teks", callback_data: "tool_textstyler", style: "success" }]);
    rows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

    try {
        await bot.editMessageText(previewText, {
            chat_id: q.message.chat.id,
            message_id: q.message.message_id,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    } catch (e) {
        console.log("[TEXTSTYLER BACK ERR]", e.message);
    }

    await bot.answerCallbackQuery(q.id).catch(() => {});
});

module.exports = { transform, STYLE_LIST };