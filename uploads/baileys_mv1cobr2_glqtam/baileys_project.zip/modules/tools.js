// ═══════════════════════════════════════════
// TOOLS — Menu Tools Bot
// v2 — YouTube Downloader Fix + NGL Spam Fix
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const notify = require("./notify");
const crypto = require("crypto");

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function tmpPath(ext = "jpg") {
    return path.join(TMP_DIR, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);
}

async function downloadFile(url, dest, referer = "") {
    const res = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 180000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            ...(referer ? { "Referer": referer } : {})
        }
    });
    fs.writeFileSync(dest, Buffer.from(res.data));
    return dest;
}

function errorMsg(e) {
    if (e.code === "ECONNABORTED") return "Server API timeout";
    if (e.code === "ENOTFOUND") return "Ga bisa akses API";
    if (e.code === "ECONNREFUSED") return "Koneksi ditolak";
    if (e.response?.status) return `HTTP ${e.response.status}`;
    return e.message || "Unknown error";
}

function escapeXml(s) {
    return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

async function sendPhoto(bot, chatId, url, caption, keyboard, q = null) {
    const replyMarkup = keyboard ? { inline_keyboard: keyboard } : undefined;

    if (q && q.message) {
        const msgId = q.message.message_id;
        const hasPhoto = !!q.message.photo;

        if (hasPhoto) {
            try {
                return await bot.editMessageCaption(caption, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    reply_markup: replyMarkup
                });
            } catch (e) {
                if ((e.message || "").includes("message is not modified")) return;
            }
        } else {
            try {
                return await bot.editMessageMedia({
                    type: "photo",
                    media: url,
                    caption,
                    parse_mode: "HTML"
                }, {
                    chat_id: chatId,
                    message_id: msgId,
                    reply_markup: replyMarkup
                });
            } catch {}
        }
    }

    try {
        return await bot.sendPhoto(chatId, url, {
            caption,
            parse_mode: "HTML",
            reply_markup: replyMarkup
        });
    } catch {
        return bot.sendMessage(chatId, caption, {
            parse_mode: "HTML",
            reply_markup: replyMarkup
        });
    }
}

// ═══════════════════════════════════════════
// MENU TOOLS
// ═══════════════════════════════════════════
router.registerCallback("menu_tools", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 MENU TOOLS</b>\n\n━━━━━━━━━━━━━━━━━━━━\nPilih tool yang mau lu pakai:\n𖡛 <b>GRATIS</b> — no credit\n━━━━━━━━━━━━━━━━━━━━`;
    const keyboard = [
        [{ text: "𖡛 Cek Cuaca", callback_data: "tool_cuaca", style: "success" }, { text: "𖡛 Jam Sholat", callback_data: "tool_sholat", style: "success" }],
        [{ text: "𖡛 Downloader", callback_data: "tool_downloader", style: "primary" }, { text: "𖡛 Brat Sticker", callback_data: "tool_brat", style: "primary" }],
        [{ text: "𖡛 HD Upscale", callback_data: "tool_hd", style: "success" }, { text: "𖡛 Cek Ping Web", callback_data: "tool_ping", style: "success" }],
        [{ text: "𖡛 Spam NGL", callback_data: "tool_ngl", style: "primary" }, { text: "𖡛 Anime AI", callback_data: "tool_anime", style: "primary" }],
        [
            { text: "𖡛 Image To Link", callback_data: "menu_filetolink", style: "success" },
            { text: "𖡛 Text Styler", callback_data: "tool_textstyler", style: "success" }
        ],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.TOOLS || cfg.FOTO.MENU, caption, keyboard, q);
});

// ═══════════════════════════════════════════
// CEK CUACA
// ═══════════════════════════════════════════
router.registerCallback("tool_cuaca", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_cuaca_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 CEK CUACA</b>\n\nKirim nama kota:\nContoh: <code>Jakarta</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_cuaca_await", async (bot, msg, state, ctx) => {
    const kota = msg.text?.trim();
    if (!kota) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek cuaca ${kota}...</b>`, { parse_mode: "HTML" });

    try {
        const geo = await axios.get("https://geocoding-api.open-meteo.com/v1/search", {
            params: { name: kota, count: 1, language: "id" }, timeout: 10000
        });
        if (!geo.data.results || geo.data.results.length === 0) {
            return bot.editMessageText(`<b>✕ Kota "${kota}" ga ditemukan.</b>`, {
                chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
            });
        }
        const loc = geo.data.results[0];
        const w = await axios.get("https://api.open-meteo.com/v1/forecast", {
            params: {
                latitude: loc.latitude, longitude: loc.longitude,
                current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
                timezone: "auto"
            }, timeout: 10000
        });
        const cur = w.data.current;
        const codes = {
            0: "Cerah", 1: "Cerah Berawan", 2: "Berawan", 3: "Mendung",
            45: "Berkabut", 48: "Kabut Beku", 51: "Gerimis Ringan", 53: "Gerimis",
            55: "Gerimis Lebat", 61: "Hujan Ringan", 63: "Hujan", 65: "Hujan Lebat",
            71: "Salju Ringan", 73: "Salju", 75: "Salju Lebat", 80: "Hujan Lokal",
            81: "Hujan Lokal Lebat", 82: "Hujan Sangat Lebat", 95: "Badai Petir", 96: "Badai + Hujan Es"
        };

        await bot.editMessageText(
            `<b>𖡛 CUACA ${loc.name.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Lokasi: ${loc.name}, ${loc.country}\n` +
            `𖡛 Suhu: <b>${cur.temperature_2m}°C</b>\n` +
            `𖡛 Terasa: ${cur.apparent_temperature}°C\n` +
            `𖡛 Kelembapan: ${cur.relative_humidity_2m}%\n` +
            `𖡛 Angin: ${cur.wind_speed_10m} km/h\n` +
            `𖡛 Cuaca: ${codes[cur.weather_code] || "Unknown"}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Real-time dari Open-Meteo</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[CUACA ERR]", e.code, e.message);
        await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
            chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

// ═══════════════════════════════════════════
// JAM SHOLAT
// ═══════════════════════════════════════════
router.registerCallback("tool_sholat", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_sholat_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 JADWAL SHOLAT</b>\n\nKirim nama kota:\nContoh: <code>Jakarta</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back" }]] } });
});

router.registerMessage("tool_sholat_await", async (bot, msg, state, ctx) => {
    const kota = msg.text?.trim();
    if (!kota) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek jadwal sholat ${kota}...</b>`, { parse_mode: "HTML" });

    try {
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, "0");
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const yyyy = today.getFullYear();

        const res = await axios.get(`https://api.aladhan.com/v1/timingsByCity/${dd}-${mm}-${yyyy}`, {
            params: { city: kota, country: "Indonesia", method: 11 }, timeout: 10000
        });
        if (!res.data || !res.data.data) throw new Error("Data tidak tersedia");

        const t = res.data.data.timings;
        const meta = res.data.data.meta;

        await bot.editMessageText(
            `<b>𖡛 JADWAL SHOLAT ${kota.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Tanggal: ${meta.date.readable}\n` +
            `𖡛 Hijriah: ${meta.date.hijri.day} ${meta.date.hijri.month.en} ${meta.date.hijri.year}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Imsak: <code>${t.Imsak}</code>\n` +
            `𖡛 Subuh: <code>${t.Fajr}</code>\n` +
            `𖡛 Syuruq: <code>${t.Sunrise}</code>\n` +
            `𖡛 Dzuhur: <code>${t.Dhuhr}</code>\n` +
            `𖡛 Ashar: <code>${t.Asr}</code>\n` +
            `𖡛 Maghrib: <code>${t.Maghrib}</code>\n` +
            `𖡛 Isya: <code>${t.Isha}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Real-time dari Aladhan</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[SHOLAT ERR]", e.code, e.message);
        await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
            chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

// ═══════════════════════════════════════════
// MENU: DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("tool_downloader", async (bot, q, data, user, ctx) => {
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Pilih platform:\n` +
        `▸ 𖡛 <b>TikTok</b> — No WM + HD\n` +
        `▸ 𖡛 <b>Instagram</b> — No WM + HD\n` +
        `▸ 𖡛 <b>YouTube</b> — Video HD (shorts + full)\n` +
        `━━━━━━━━━━━━━━━━━━━━`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [{ text: "𖡛 TikTok", callback_data: "dl_tiktok", style: "primary" }],
                [{ text: "𖡛 Instagram", callback_data: "dl_instagram", style: "primary" }],
                [{ text: "𖡛 YouTube", callback_data: "dl_youtube", style: "primary" }],
                [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
            ] }
        });
});

// ═══════════════════════════════════════════
// TIKTOK DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("dl_tiktok", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_tiktok_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 TIKTOK DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim URL TikTok:\n` +
        `𖡛 <b>Format</b>: Video, Foto, Slide\n` +
        `𖡛 <b>Output</b>: No WM + HD\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Contoh: https://tiktok.com/@user/video/xxx</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_tiktok_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("tiktok")) return bot.sendMessage(msg.chat.id, "<b>✕ URL TikTok ga valid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Download video...</b>`, { parse_mode: "HTML" });

    try {
        const res = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`, { timeout: 15000 });
        if (!res.data || !res.data.data) throw new Error("Gagal ambil data");
        const d = res.data.data;
        const videoUrl = d.hdplay || d.play;
        const title = d.title || "TikTok Video";

        const vidPath = tmpPath("mp4");
        await downloadFile(videoUrl, vidPath);

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendVideo(msg.chat.id, vidPath, {
            caption: `<b>✓ TIKTOK NO WM</b>\n\n𖡛 ${title.slice(0, 100)}\n𖡛 @${d.author?.unique_id || "unknown"}\n𖡛 ${d.duration}s`,
            parse_mode: "HTML"
        });

        try { fs.unlinkSync(vidPath); } catch {}
    } catch (e) {
        console.log("[TIKTOK ERR]", e.message);
        await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
            chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

// ═══════════════════════════════════════════
// INSTAGRAM DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("dl_instagram", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_instagram_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 INSTAGRAM DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim URL Instagram:\n` +
        `𖡛 <b>Support</b>: Post, Reels, IGTV, Slide\n` +
        `𖡛 <b>Output</b>: HD + No Watermark\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Contoh: https://instagram.com/p/xxx</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_instagram_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("instagram")) return bot.sendMessage(msg.chat.id, "<b>✕ URL invalid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Download Instagram HD...</b>`, { parse_mode: "HTML" });

    const APIS = [
        {
            name: "siputzx",
            get: async () => {
                const r = await axios.get(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.data && Array.isArray(r.data.data) && r.data.data.length > 0) {
                    return r.data.data.map(x => ({
                        url: x.url || x.download_url || x.src,
                        isVideo: x.url ? /\.mp4|video/i.test(x.url) : true,
                        thumb: x.thumbnail || null
                    }));
                }
                return null;
            }
        },
        {
            name: "ryzendesu",
            get: async () => {
                const r = await axios.get(`https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.data && Array.isArray(r.data.data)) {
                    return r.data.data.map(x => ({
                        url: x.url || x.download_url,
                        isVideo: /\.mp4/i.test(x.url || ""),
                        thumb: x.thumbnail
                    }));
                }
                return null;
            }
        },
        {
            name: "vreden",
            get: async () => {
                const r = await axios.get(`https://api.vreden.my.id/api/igdownload?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.result && Array.isArray(r.data.result) && r.data.result.length > 0) {
                    return r.data.result.map(x => ({
                        url: x.url || x.download_url,
                        isVideo: /\.mp4/i.test(x.url || ""),
                        thumb: x.thumbnail
                    }));
                }
                return null;
            }
        }
    ];

    let mediaList = null;
    let usedApi = "";

    for (const api of APIS) {
        try {
            console.log(`[IG] Coba API: ${api.name}`);
            const result = await api.get();
            if (result && result.length > 0) {
                mediaList = result.filter(m => m.url && m.url.startsWith("http"));
                if (mediaList.length > 0) {
                    usedApi = api.name;
                    console.log(`[IG] ✓ ${api.name} → ${mediaList.length} media`);
                    break;
                }
            }
        } catch (e) {
            console.log(`[IG] ✕ ${api.name} error:`, e.message.slice(0, 100));
        }
    }

    if (!mediaList || mediaList.length === 0) {
        return bot.editMessageText(
            `<b>✕ Gagal download Instagram</b>\n\n` +
            `<i>Kemungkinan:</i>\n` +
            `𖡛 Post private / ga public\n` +
            `𖡛 API server lagi down\n` +
            `𖡛 URL bukan post/reels valid\n\n` +
            `<i>Coba lagi beberapa saat.</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    }

    await bot.editMessageText(
        `<b>𖡛 Downloading ${mediaList.length} media...</b>`,
        { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });

    let success = 0;
    let failed = 0;

    for (let i = 0; i < mediaList.length; i++) {
        const media = mediaList[i];
        const ext = media.isVideo ? "mp4" : "jpg";
        const tmp = tmpPath(ext);

        try {
            await downloadFile(media.url, tmp);
            const stat = fs.statSync(tmp);

            if (stat.size < 1000) throw new Error("File corrupt");

            const caption =
                `<b>✓ INSTAGRAM HD</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `𖡛 Media: ${i + 1}/${mediaList.length}\n` +
                `𖡛 Type: ${media.isVideo ? "𖡛 Video" : "𖡛 Foto"}\n` +
                `𖡛 Size: ${(stat.size / 1024 / 1024).toFixed(2)} MB\n` +
                `𖡛 Quality: HD No WM\n` +
                `━━━━━━━━━━━━━━━━━━━━`;

            if (media.isVideo) {
                await bot.sendVideo(msg.chat.id, tmp, {
                    caption,
                    parse_mode: "HTML",
                    supports_streaming: true
                });
            } else {
                await bot.sendPhoto(msg.chat.id, tmp, {
                    caption,
                    parse_mode: "HTML"
                });
            }

            success++;
        } catch (e) {
            console.log(`[IG] Send fail ${i + 1}:`, e.message);
            failed++;
        } finally {
            try { fs.unlinkSync(tmp); } catch {}
        }
    }

    try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

    if (success === 0) {
        await bot.sendMessage(msg.chat.id,
            `<b>✕ Gagal kirim media Instagram</b>\n\n<i>Kemungkinan file terlalu besar atau server error.</i>`,
            { parse_mode: "HTML" });
    } else if (success < mediaList.length) {
        await bot.sendMessage(msg.chat.id,
            `<b>✓ Partial sukses</b>\n\n▸ Sukses: ${success}\n▸ Gagal: ${failed}`,
            { parse_mode: "HTML" });
    }

    try {
        await notify.notifySuccess(bot, "IG DOWNLOAD", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Media", value: `${success}/${mediaList.length}` },
            { label: "API", value: usedApi }
        ]).catch(() => {});
    } catch {}
});

// ═══════════════════════════════════════════
// YOUTUBE DOWNLOADER — FIX SHORTS + FULL VIDEO
// ═══════════════════════════════════════════
function extractYouTubeId(url) {
    // Support:
    // - https://youtu.be/xxx
    // - https://youtube.com/watch?v=xxx
    // - https://youtube.com/shorts/xxx
    // - https://m.youtube.com/watch?v=xxx
    // - https://www.youtube.com/embed/xxx
    const patterns = [
        /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
        /(?:m\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/v\/)([a-zA-Z0-9_-]{11})/
    ];
    for (const p of patterns) {
        const m = url.match(p);
        if (m && m[1]) return m[1];
    }
    return null;
}

router.registerCallback("dl_youtube", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_youtube_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>▶️ YOUTUBE DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>Support Link:</b>\n` +
        `▸ <code>youtube.com/watch?v=xxx</code>\n` +
        `▸ <code>youtu.be/xxx</code>\n` +
        `▸ <code>youtube.com/shorts/xxx</code>\n` +
        `▸ <code>m.youtube.com/watch?v=xxx</code>\n\n` +
        `<b>Output:</b> Video MP4 HD\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Kirim link YouTube:</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_youtube_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("youtu")) return bot.sendMessage(msg.chat.id, "<b>✕ URL invalid.</b>", { parse_mode: "HTML" });

    const videoId = extractYouTubeId(url);
    if (!videoId) {
        return bot.sendMessage(msg.chat.id,
            `<b>✕ Link YouTube ga valid!</b>\n\n` +
            `<b>Format yang didukung:</b>\n` +
            `▸ <code>youtube.com/watch?v=xxx</code>\n` +
            `▸ <code>youtu.be/xxx</code>\n` +
            `▸ <code>youtube.com/shorts/xxx</code>`,
            { parse_mode: "HTML" });
    }

    ctx.clearState(msg.from.id);

    console.log("[YT] URL:", url, "→ videoId:", videoId);

    const loading = await bot.sendMessage(msg.chat.id,
        `<b>▶️ Youtube Download</b>\n\n` +
        `▸ Video ID: <code>${videoId}</code>\n` +
        `▸ Status: Fetching video info...\n\n` +
        `<i>Mohon tunggu...</i>`,
        { parse_mode: "HTML" });

    // Helper: coba API satu per satu
    const APIS = [
        {
            name: "siputzx-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.data?.dl) {
                    return {
                        videoUrl: r.data.data.dl,
                        title: r.data.data.title || "YouTube Video",
                        author: r.data.data.author || "-",
                        duration: r.data.data.duration || "?",
                        thumb: r.data.data.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "ryzendesu-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.ryzendesu.vip/api/downloader/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.url) {
                    return {
                        videoUrl: r.data.url,
                        title: r.data.title || "YouTube Video",
                        author: r.data.author || "-",
                        duration: r.data.duration || "?",
                        thumb: r.data.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "vreden-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.vreden.my.id/api/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.result?.download?.url) {
                    return {
                        videoUrl: r.data.result.download.url,
                        title: r.data.result.title || "YouTube Video",
                        author: r.data.result.author || "-",
                        duration: r.data.result.duration || "?",
                        thumb: r.data.result.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "zahwazein-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.zahwazein.xyz/downloader/ytmp4?apikey=isi_api_key&url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.result?.url) {
                    return {
                        videoUrl: r.data.result.url,
                        title: r.data.result.title || "YouTube Video",
                        author: r.data.result.author || "-",
                        duration: r.data.result.duration || "?",
                        thumb: r.data.result.thumbnail
                    };
                }
                return null;
            }
        }
    ];

    let data = null;
    let usedApi = "";

    for (const api of APIS) {
        try {
            console.log(`[YT] Coba API: ${api.name}`);
            const result = await api.get();
            if (result && result.videoUrl) {
                data = result;
                usedApi = api.name;
                console.log(`[YT] ✓ ${api.name} sukses`);
                break;
            }
            console.log(`[YT] ✕ ${api.name} gagal`);
        } catch (e) {
            console.log(`[YT] ✗ ${api.name} error:`, e.message.slice(0, 100));
        }
    }

    if (!data) {
        return bot.editMessageText(
            `<b>✕ Gagal download YouTube</b>\n\n` +
            `<i>Kemungkinan:</i>\n` +
            `▸ Video private / age-restricted\n` +
            `▸ Video copyrighted (block download)\n` +
            `▸ API server down\n\n` +
            `<i>Coba video lain atau ulangi beberapa saat.</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    }

    // Update loading dengan info video
    await bot.editMessageText(
        `<b>▶️ Downloading video...</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Title</b>: <code>${String(data.title).slice(0, 60)}</code>\n` +
        `▸ <b>Author</b>: <code>${data.author}</code>\n` +
        `▸ <b>Duration</b>: <code>${data.duration}</code>\n` +
        `▸ <b>API</b>: <code>${usedApi}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Mohon tunggu, file mungkin gede...</i>`,
        { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });

    try {
        const vidPath = tmpPath("mp4");
        await downloadFile(data.videoUrl, vidPath, "https://www.youtube.com/");
        const stat = fs.statSync(vidPath);
        const sizeMB = stat.size / 1024 / 1024;

        console.log(`[YT] Downloaded: ${sizeMB.toFixed(2)} MB`);

        // Kalau file > 49MB, kasih link aja
        if (sizeMB > 49) {
            await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
            await bot.sendMessage(msg.chat.id,
                `<b>⚠️ Video terlalu besar</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Title: ${String(data.title).slice(0, 80)}\n` +
                `▸ Size: <code>${sizeMB.toFixed(2)} MB</code>\n` +
                `▸ Limit TG: <code>50 MB</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>▶️ Download manual:</b>\n` +
                `<code>${data.videoUrl}</code>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [
                        [{ text: "▶️ Buka Video", url: data.videoUrl }],
                        [{ text: "▶️ Lihat di YouTube", url }]
                    ] }
                });
            try { fs.unlinkSync(vidPath); } catch {}
            return;
        }

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendVideo(msg.chat.id, vidPath, {
            caption:
                `<b>✓ YOUTUBE HD</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ <b>${String(data.title).slice(0, 80)}</b>\n` +
                `▸ Author: <code>${data.author}</code>\n` +
                `▸ Duration: <code>${data.duration}</code>\n` +
                `▸ Size: <code>${sizeMB.toFixed(2)} MB</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Kualitas: HD</i>`,
            parse_mode: "HTML",
            supports_streaming: true
        });

        try { fs.unlinkSync(vidPath); } catch {}

        try {
            await notify.notifySuccess(bot, "YT DOWNLOAD", [
                { label: "User", value: msg.from.first_name || "User" },
                { label: "Title", value: String(data.title).slice(0, 40) },
                { label: "Size", value: sizeMB.toFixed(2) + " MB" },
                { label: "API", value: usedApi }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[YT DOWNLOAD ERR]", e.message);
        await bot.editMessageText(
            `<b>✕ Gagal download video</b>\n\n<code>${errorMsg(e)}</code>\n\n` +
            `<i>Coba lagi beberapa saat.</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    }
});

// ═══════════════════════════════════════════
// BRAT STICKER
// ═══════════════════════════════════════════
router.registerCallback("tool_brat", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_brat_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 BRAT STICKER</b>\n\nKirim teks yang mau dijadikan sticker:\n<i>Max 200 karakter.</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_brat_await", async (bot, msg, state, ctx) => {
    const text = msg.text?.trim();
    if (!text) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Membuat sticker...</b>`, { parse_mode: "HTML" });

    try {
        let avatarBuffer = null;
        try {
            const photos = await bot.getUserProfilePhotos(msg.from.id, { limit: 1 });
            if (photos && photos.total_count > 0) {
                const fileId = photos.photos[0][0].file_id;
                const fileLink = await bot.getFileLink(fileId);
                const avatarRes = await axios.get(fileLink, { responseType: "arraybuffer", timeout: 15000 });
                avatarBuffer = Buffer.from(avatarRes.data);
            }
        } catch (e) {
            console.log("[BRAT] avatar fail:", e.message);
        }

        const firstName = msg.from.first_name || "User";
        const lastName = msg.from.last_name || "";
        const fullName = [firstName, lastName].filter(Boolean).join(" ");
        const username = msg.from.username ? `@${msg.from.username}` : "no_username";
        const initial = firstName.charAt(0).toUpperCase();

        const W = 512;
        const H = 512;

        const words = String(text).slice(0, 200).split(/\s+/);
        const lines = [];
        let current = "";
        for (const w of words) {
            if ((current + " " + w).trim().length > 18) {
                lines.push(current.trim());
                current = w;
            } else {
                current = (current + " " + w).trim();
            }
        }
        if (current) lines.push(current);
        const showLines = lines.slice(0, 7);
        const fontSize = showLines.length > 5 ? 26 : showLines.length > 3 ? 32 : 40;
        const startY = 260;

        const textElements = showLines.map((line, i) =>
            `<text x="${W / 2}" y="${startY + i * (fontSize + 8)}" font-family="Arial, Helvetica, sans-serif" font-size="${fontSize}" font-weight="bold" fill="#FFFFFF" text-anchor="middle">${escapeXml(line)}</text>`
        ).join("");

        const baseSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect width="${W}" height="${H}" fill="#000000"/>
  <text x="${W / 2}" y="${H - 20}" font-family="Arial" font-size="11" fill="#6b7280" text-anchor="middle">𖡛 spartaX</text>
  ${textElements}
</svg>`;

        const sharp = require("sharp");
        let baseBuffer = await sharp(Buffer.from(baseSvg)).png().toBuffer();

        if (avatarBuffer) {
            try {
                const avatarSize = 64;
                const avatarRounded = await sharp(avatarBuffer)
                    .resize(avatarSize, avatarSize, { fit: "cover" })
                    .composite([{
                        input: Buffer.from(
                            `<svg width="${avatarSize}" height="${avatarSize}"><circle cx="${avatarSize / 2}" cy="${avatarSize / 2}" r="${avatarSize / 2}" fill="#fff"/></svg>`
                        ),
                        blend: "dest-in"
                    }])
                    .png()
                    .toBuffer();

                const nameSvg = `<svg width="${W}" height="100" xmlns="http://www.w3.org/2000/svg">
                    <text x="105" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">${escapeXml(fullName.slice(0, 25))}</text>
                    <text x="105" y="72" font-family="Arial, Helvetica, sans-serif" font-size="15" fill="#9ca3af">${escapeXml(username)}</text>
                </svg>`;
                const nameBuffer = await sharp(Buffer.from(nameSvg)).png().toBuffer();

                baseBuffer = await sharp(baseBuffer)
                    .composite([
                        { input: avatarRounded, top: 30, left: 30 },
                        { input: nameBuffer, top: 30, left: 0 }
                    ])
                    .png()
                    .toBuffer();
            } catch (e) {
                console.log("[BRAT] overlay fail:", e.message);
            }
        } else {
            const initialSvg = `<svg width="${W}" height="100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="62" cy="62" r="32" fill="#1f2937" stroke="#ffffff" stroke-width="2"/>
                <text x="62" y="74" font-family="Arial" font-size="32" font-weight="bold" fill="#ffffff" text-anchor="middle">${escapeXml(initial)}</text>
                <text x="110" y="55" font-family="Arial" font-size="20" font-weight="bold" fill="#FFFFFF">${escapeXml(fullName.slice(0, 25))}</text>
                <text x="110" y="80" font-family="Arial" font-size="15" fill="#9ca3af">${escapeXml(username)}</text>
            </svg>`;
            const overlayBuffer = await sharp(Buffer.from(initialSvg)).png().toBuffer();
            baseBuffer = await sharp(baseBuffer)
                .composite([{ input: overlayBuffer, top: 30, left: 0 }])
                .png()
                .toBuffer();
        }

        const tmp = tmpPath("png");
        fs.writeFileSync(tmp, baseBuffer);

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendSticker(msg.chat.id, tmp, {
            reply_markup: { inline_keyboard: [[{ text: "𖡛 Menu", callback_data: "menu_back" }]] }
        });
        try { fs.unlinkSync(tmp); } catch {}

        try {
            await notify.notifySuccess(bot, "BRAT STICKER", [
                { label: "User", value: fullName.slice(0, 30) },
                { label: "Teks", value: text.slice(0, 30) }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[BRAT ERR]", e.message);
        try {
            await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
                chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
            });
        } catch {
            await bot.sendMessage(msg.chat.id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, { parse_mode: "HTML" });
        }
    }
});

// ═══════════════════════════════════════════
// HD UPSCALE
// ═══════════════════════════════════════════
router.registerCallback("tool_hd", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_hd_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 HD UPSCALE</b>\n\nKirim foto/video yang mau di-HD-kan:`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_hd_await", async (bot, msg, state, ctx) => {
    if (!msg.photo && !msg.video) return bot.sendMessage(msg.chat.id, "<b>✕ Kirim foto/video.</b>", { parse_mode: "HTML" });

    const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : msg.video.file_id;
    const isVideo = !!msg.video;

    ctx.setState(msg.from.id, "tool_hd_pick", { fileId, isVideo });
    await bot.sendMessage(msg.chat.id,
        `<b>𖡛 PILIH LEVEL HD</b>\n\nSemakin gede, semakin HD:`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [{ text: "𖡛 2x HD", callback_data: "tool_hd_level:2", style: "success" }],
                [{ text: "𖡛 3x HD", callback_data: "tool_hd_level:3", style: "success" }],
                [{ text: "𖡛 4x HD", callback_data: "tool_hd_level:4", style: "success" }],
                [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
            ] }
        });
});

router.registerCallback("tool_hd_level", async (bot, q, data, user, ctx) => {
    const level = parseInt(data.split(":")[1]) || 2;
    const st = ctx.getState(user.id);
    if (!st || !st.fileId) return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });

    ctx.clearState(user.id);
    await bot.answerCallbackQuery(q.id, { text: `Upscale ${level}x...` });

    const loading = await bot.sendMessage(q.message.chat.id, `<b>𖡛 Upscale ${level}x...</b>`, { parse_mode: "HTML" });

    try {
        const fileLink = await bot.getFileLink(st.fileId);
        const img = await axios.get(fileLink, { responseType: "arraybuffer", timeout: 30000 });

        const sharp = require("sharp");
        const metadata = await sharp(Buffer.from(img.data)).metadata();
        const newWidth = Math.min((metadata.width || 512) * level, 4096);
        const newHeight = Math.min((metadata.height || 512) * level, 4096);

        const upscaled = await sharp(Buffer.from(img.data))
            .resize(newWidth, newHeight, { kernel: sharp.kernel.lanczos3, fit: "fill" })
            .sharpen({ sigma: 1.5, m1: 1.0, m2: 0.5 })
            .modulate({ brightness: 1.05, saturation: 1.15 })
            .linear(1.1, -10)
            .jpeg({ quality: 98, chromaSubsampling: "4:4:4" })
            .toBuffer();

        const tmp = tmpPath("jpg");
        fs.writeFileSync(tmp, upscaled);

        await bot.deleteMessage(q.message.chat.id, loading.message_id).catch(() => {});

        if (st.isVideo) {
            await bot.sendDocument(q.message.chat.id, tmp, {
                caption: `<b>✓ HD ${level}x</b>\n\n𖡛 ${metadata.width}x${metadata.height} → ${newWidth}x${newHeight}`,
                parse_mode: "HTML"
            });
        } else {
            await bot.sendPhoto(q.message.chat.id, tmp, {
                caption:
                    `<b>✓ HD ${level}x</b>\n\n` +
                    `𖡛 Resolusi: ${metadata.width}x${metadata.height} → <b>${newWidth}x${newHeight}</b>\n` +
                    `𖡛 Size: ${(upscaled.length / 1024).toFixed(2)} KB`,
                parse_mode: "HTML"
            });
        }

        try { fs.unlinkSync(tmp); } catch {}

        try {
            await notify.notifySuccess(bot, "HD UPSCALE", [
                { label: "User", value: q.from.first_name || "User" },
                { label: "Level", value: level + "x" },
                { label: "Resolusi", value: `${newWidth}x${newHeight}` }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[HD ERR]", e.message);
        await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
            chat_id: q.message.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

// ═══════════════════════════════════════════
// CEK PING WEB
// ═══════════════════════════════════════════
router.registerCallback("tool_ping", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_ping_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 CEK PING WEB</b>\n\nKirim domain website:\nContoh: <code>google.com</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_ping_await", async (bot, msg, state, ctx) => {
    let domain = msg.text?.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!domain || !domain.includes(".")) return bot.sendMessage(msg.chat.id, "<b>✕ Domain invalid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek ${domain}...</b>`, { parse_mode: "HTML" });

    try {
        const start = Date.now();
        let res;
        try {
            res = await axios.get(`https://${domain}`, { timeout: 10000, validateStatus: () => true });
        } catch {
            res = await axios.get(`http://${domain}`, { timeout: 10000, validateStatus: () => true });
        }
        const ping = Date.now() - start;
        const https_valid = res.request?.res?.socket?.encrypted || domain.includes("https");
        const secure = https_valid ? "HTTPS (Aman)" : "HTTP (Kurang Aman)";

        await bot.editMessageText(
            `<b>𖡛 HASIL CEK ${domain}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Ping: <code>${ping}ms</code>\n` +
            `𖡛 Status: <code>${res.status} ${res.statusText}</code>\n` +
            `𖡛 Keamanan: ${secure}\n` +
            `𖡛 Check: ${new Date().toLocaleString("id-ID")}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Ping ${ping < 300 ? "Cepat" : ping < 1000 ? "Sedang" : "Lambat"}</i>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[PING ERR]", e.message);
        await bot.editMessageText(`<b>✕ Website ga bisa diakses:</b>\n<code>${errorMsg(e)}</code>`, {
            chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

// ═══════════════════════════════════════════
// SPAM NGL — FIX BENERAN KEKIRIM
// ═══════════════════════════════════════════
router.registerCallback("tool_ngl", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_ngl_user", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 SPAM NGL</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim username NGL (tanpa @):\n` +
        `<b>Contoh:</b> <code>spartax</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Pastiin username NGL bener & aktif.</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_ngl_user", async (bot, msg, state, ctx) => {
    const user = msg.text?.trim().replace(/^@/, "").replace(/https?:\/\/ngl\.link\//i, "").replace(/\//g, "");
    if (!user) return;
    if (!/^[a-zA-Z0-9._]+$/.test(user)) {
        return bot.sendMessage(msg.chat.id, `<b>✕ Username NGL invalid.</b>`, { parse_mode: "HTML" });
    }
    ctx.setState(msg.from.id, "tool_ngl_count", { nglUser: user });
    await bot.sendMessage(msg.chat.id,
        `<b>Username:</b> <code>${user}</code>\n\n` +
        `<b>Berapa kali spam? (max 100)</b>`,
        { parse_mode: "HTML" });
});

router.registerMessage("tool_ngl_count", async (bot, msg, state, ctx) => {
    const count = Math.min(parseInt(msg.text) || 1, 100);
    if (count < 1) return bot.sendMessage(msg.chat.id, `<b>✕ Minimal 1.</b>`, { parse_mode: "HTML" });
    ctx.setState(msg.from.id, "tool_ngl_text", { nglUser: state.nglUser, count });
    await bot.sendMessage(msg.chat.id, `<b>Kirim teks spam nya:</b>`, { parse_mode: "HTML" });
});

router.registerMessage("tool_ngl_text", async (bot, msg, state, ctx) => {
    const text = msg.text?.trim();
    if (!text) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id,
        `<b>▸ Spam NGL</b>\n\n` +
        `▸ Target: <code>${state.nglUser}</code>\n` +
        `▸ Total: <code>${state.count}</code>\n` +
        `▸ Progress: 0/${state.count}`,
        { parse_mode: "HTML" });

    let success = 0;
    let failed = 0;
    const errors = [];

    // Header NGL lengkap
    const HEADERS = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Origin": "https://ngl.link",
        "Referer": `https://ngl.link/${state.nglUser}`,
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive"
    };

    for (let i = 0; i < state.count; i++) {
        let attempt = 0;
        let maxAttempts = 3;
        let successThis = false;

        while (attempt < maxAttempts && !successThis) {
            attempt++;
            try {
                // Generate device ID panjang (NGL butuh panjang)
                const deviceId = crypto.randomUUID().replace(/-/g, "") + crypto.randomBytes(8).toString("hex");

                const body = new URLSearchParams({
                    username: state.nglUser,
                    question: text,
                    deviceId: deviceId,
                    gameSlug: "",
                    referrer: ""
                }).toString();

                const res = await axios.post(
                    "https://ngl.link/api/submit",
                    body,
                    {
                        headers: HEADERS,
                        timeout: 20000,
                        validateStatus: () => true
                    }
                );

                // Cek response — NGL kasih {success: true} atau status 200
                const isSuccess =
                    (res.status >= 200 && res.status < 300) &&
                    (res.data?.success === true || res.data?.status === "ok" || res.data === "" || typeof res.data === "object");

                if (isSuccess) {
                    success++;
                    successThis = true;
                } else if (res.status === 429) {
                    if (attempt < maxAttempts) {
                        // Rate limit — tunggu lebih lama
                        console.log(`[NGL] Rate limited, retry ${attempt}/${maxAttempts}`);
                        await new Promise(r => setTimeout(r, 5000));
                        continue;
                    } else {
                        failed++;
                        if (errors.length < 3) errors.push(`Rate limit (429)`);
                    }
                } else if (res.status === 404) {
                    // Username ga ada
                    if (errors.length < 3) errors.push(`Username "${state.nglUser}" ga ditemukan`);
                    failed++;
                    // Break total loop kalau username salah
                    i = state.count;
                    break;
                } else {
                    if (attempt < maxAttempts) {
                        await new Promise(r => setTimeout(r, 2000));
                        continue;
                    }
                    failed++;
                    if (errors.length < 3) errors.push(`HTTP ${res.status}`);
                }
            } catch (e) {
                if (attempt < maxAttempts) {
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                }
                failed++;
                if (errors.length < 3) errors.push(e.message.slice(0, 50));
            }
        }

        // Update progress
        if ((i + 1) % 3 === 0 || i === state.count - 1) {
            try {
                await bot.editMessageText(
                    `<b>▸ Spam NGL</b>\n\n` +
                    `▸ Target: <code>${state.nglUser}</code>\n` +
                    `▸ Progress: ${i + 1}/${state.count}\n` +
                    `▸ ✓ Sukses: <b>${success}</b>\n` +
                    `▸ ✕ Gagal: <b>${failed}</b>`,
                    { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
            } catch {}
        }

        // Delay 1500ms antar request (aman dari rate limit)
        await new Promise(r => setTimeout(r, 1500));
    }

    // Hasil akhir
    let resultMsg =
        `<b>${success > 0 ? "✓" : "✕"} SPAM NGL SELESAI</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ Target: <code>${state.nglUser}</code>\n` +
        `▸ Pesan: <i>${text.slice(0, 100)}</i>\n` +
        `▸ Total: <code>${state.count}</code>\n` +
        `▸ ✓ Sukses: <b>${success}</b>\n` +
        `▸ ✕ Gagal: <b>${failed}</b>\n`;

    if (errors.length > 0) {
        resultMsg += `━━━━━━━━━━━━━━━━━━━━\n<b>Error:</b>\n`;
        for (const e of errors) resultMsg += `▸ <code>${e}</code>\n`;
    }

    if (success === 0) {
        resultMsg += `\n<b>Kemungkinan gagal:</b>\n`;
        resultMsg += `▸ Username NGL salah / ga aktif\n`;
        resultMsg += `▸ NGL blok IP server (VPS)\n`;
        resultMsg += `▸ Coba pakai VPN / proxy\n`;
    }

    resultMsg += `━━━━━━━━━━━━━━━━━━━━`;

    await bot.editMessageText(resultMsg, {
        chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
    });

    try {
        await notify.notifySuccess(bot, "SPAM NGL", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Target", value: state.nglUser },
            { label: "Sukses", value: `${success}/${state.count}` }
        ]).catch(() => {});
    } catch {}
});

// ═══════════════════════════════════════════
// ANIME AI
// ═══════════════════════════════════════════
router.registerCallback("tool_anime", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_anime_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 ANIME AI</b>\n\nKirim foto/video yang mau dijadikan anime HD:`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_anime_await", async (bot, msg, state, ctx) => {
    if (!msg.photo && !msg.video) return bot.sendMessage(msg.chat.id, "<b>✕ Kirim foto/video.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : msg.video.file_id;
    const isVideo = !!msg.video;

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Proses anime AI...</b>`, { parse_mode: "HTML" });

    try {
        const fileLink = await bot.getFileLink(fileId);
        const api = `https://api.siputzx.my.id/api/ai/animediffusion?url=${encodeURIComponent(fileLink)}`;
        const res = await axios.get(api, { responseType: "arraybuffer", timeout: 60000 });

        const tmp = tmpPath(isVideo ? "mp4" : "jpg");
        fs.writeFileSync(tmp, Buffer.from(res.data));

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        if (isVideo) {
            await bot.sendVideo(msg.chat.id, tmp, { caption: `<b>✓ ANIME HD</b>`, parse_mode: "HTML" });
        } else {
            await bot.sendPhoto(msg.chat.id, tmp, { caption: `<b>✓ ANIME HD</b>`, parse_mode: "HTML" });
        }
        try { fs.unlinkSync(tmp); } catch {}
    } catch (e) {
        console.log("[ANIME ERR]", e.message);
        await bot.editMessageText(`<b>✕ Error:</b> <code>${errorMsg(e)}</code>`, {
            chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML"
        });
    }
});

module.exports = {};
console.log("[TOOLS] module loaded");