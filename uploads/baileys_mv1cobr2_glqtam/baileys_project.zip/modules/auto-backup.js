// ═══════════════════════════════════════════
// AUTO BACKUP — Backup script otomatis ke owner
// v2 — FIX: skip backup lama, max 40MB, kirim guaranteed
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const fs = require("fs");
const path = require("path");
const AdmZip = require("adm-zip");

const ROOT = path.join(__dirname, "..");
const BACKUP_DIR = path.join(ROOT, "database", "backups");
const BACKUP_INTERVAL_MS = 30 * 60 * 1000; // 30 menit

// ⚡ LIMIT — backup max 40 MB biar aman dikirim Telegram
const MAX_TOTAL_SIZE = 40 * 1024 * 1024;       // 40 MB total
const MAX_FILE_SIZE = 3 * 1024 * 1024;         // 3 MB per file
const MAX_BACKUP_FILES_KEEP = 3;               // simpen 3 backup aja

// ⚡ SKIP DIR — WAJIB biar backup ga numpuk
const SKIP_DIRS = new Set([
    "node_modules", ".git", ".github",
    "tmp", "tmp_build", "temp",
    "database/backups",           // ← INI BIANG KEROKNYA, skip backup lama
    "database/userbot_sessions",  // sesi WA baileys — file gede
    "sessions", "session", "auth",
    ".gradle", "__pycache__", ".vscode", ".idea",
    "venv", "env", ".venv", "target", "out", "bin", "obj",
    ".dart_tool", "logs", ".cache", "cache",
    ".npm", ".yarn", ".pnpm-store",
    "coverage", ".nyc_output"
]);

// ⚡ SKIP FILE EXT — file gede / temporary
const SKIP_EXT = new Set([
    ".log", ".tmp", ".swp", ".DS_Store",
    ".zip", ".tar", ".tar.gz", ".tgz", ".rar", ".7z",  // ← arsip, skip
    ".mp4", ".mkv", ".avi", ".mov", ".webm",           // ← video
    ".mp3", ".wav", ".ogg", ".m4a", ".flac",           // ← audio
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",  // ← gambar besar
    ".sqlite", ".db", ".sqlite3",                      // ← db file
    ".exe", ".dll", ".so", ".dylib", ".node",          // ← binary
    ".apk", ".aab", ".ipa"                             // ← app
]);

// ⚡ SKIP FILE NAME
const SKIP_FILES = new Set([
    ".env", ".env.local", ".env.production",
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    ".gitignore", ".gitattributes", ".npmrc", ".yarnrc"
]);

let backupTimer = null;
let lastBackupAt = 0;
let lastBackupSize = 0;
let lastBackupPath = null;
let backupCount = 0;
let isRunning = false;

if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

// ═══ COLLECT FILES ═══
function collectFiles(dir, baseDir, files = [], depth = 0) {
    if (depth > 10) return files; // safety

    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); }
    catch { return files; }

    for (const item of items) {
        const full = path.join(dir, item.name);
        const rel = path.relative(baseDir, full).replace(/\\/g, "/");

        if (item.isDirectory()) {
            if (SKIP_DIRS.has(item.name)) continue;
            if (SKIP_DIRS.has(rel)) continue;
            // Cek juga nama folder yang mengandung "backup"
            if (item.name.toLowerCase().includes("backup")) {
                console.log(`[BACKUP] skip folder backup: ${rel}`);
                continue;
            }
            collectFiles(full, baseDir, files, depth + 1);
        } else {
            if (SKIP_FILES.has(item.name)) continue;
            if (SKIP_EXT.has(path.extname(item.name).toLowerCase())) continue;
            if (item.name.endsWith(".zip")) continue;
            if (item.name.startsWith("ubot_backup_")) continue;

            try {
                const stat = fs.statSync(full);
                if (stat.size > MAX_FILE_SIZE) {
                    console.log(`[BACKUP] skip besar: ${rel} (${(stat.size / 1024 / 1024).toFixed(2)} MB)`);
                    continue;
                }
                if (stat.size === 0) continue;
                files.push({ full, rel, size: stat.size });
            } catch {}
        }
    }
    return files;
}

// ═══ MAKE BACKUP ═══
function makeBackup() {
    const startTime = Date.now();
    console.log("[BACKUP] === MULAI BACKUP ===");

    try {
        let files = collectFiles(ROOT, ROOT);
        console.log(`[BACKUP] total file ditemukan: ${files.length}`);

        // Sort by size (kecil dulu) — biar kalau kelebihan limit, file besar dibuang
        files.sort((a, b) => a.size - b.size);

        // Filter total biar ga lebih dari MAX_TOTAL_SIZE
        let totalSize = 0;
        const accepted = [];
        const rejected = [];

        for (const f of files) {
            if (totalSize + f.size > MAX_TOTAL_SIZE) {
                rejected.push(f);
                continue;
            }
            accepted.push(f);
            totalSize += f.size;
        }

        console.log(`[BACKUP] accepted: ${accepted.length} files (${(totalSize / 1024 / 1024).toFixed(2)} MB)`);
        console.log(`[BACKUP] rejected: ${rejected.length} files (kelebihan limit ${(MAX_TOTAL_SIZE / 1024 / 1024).toFixed(0)} MB)`);

        const zip = new AdmZip();

        let added = 0;
        for (const f of accepted) {
            try {
                // Tambahin file ke zip dengan path rel
                zip.addLocalFile(f.full, path.dirname(f.rel) === "." ? "" : path.dirname(f.rel));
                added++;
            } catch (e) {
                console.log(`[BACKUP] skip ${f.rel}:`, e.message.slice(0, 80));
            }
        }

        console.log(`[BACKUP] ${added}/${accepted.length} file di-zip`);

        // Metadata
        const meta = {
            createdAt: new Date().toISOString(),
            totalFiles: added,
            totalSize,
            backupNumber: backupCount + 1,
            uptime: process.uptime(),
            memoryUsage: {
                rss: Math.round(process.memoryUsage().rss / 1024 / 1024) + " MB",
                heapUsed: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + " MB"
            },
            nodeVersion: process.version,
            platform: process.platform,
            pid: process.pid,
            skippedFiles: rejected.length
        };
        zip.addFile("BACKUP_INFO.json", Buffer.from(JSON.stringify(meta, null, 2)));

        const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        const zipPath = path.join(BACKUP_DIR, `backup_${timestamp}.zip`);

        zip.writeZip(zipPath);

        const stat = fs.statSync(zipPath);
        console.log(`[BACKUP] ✅ saved: ${zipPath} (${(stat.size / 1024 / 1024).toFixed(2)} MB)`);

        // ⚡ SAFETY: kalau hasil zip > 45 MB, hapus — jangan kirim
        if (stat.size > 45 * 1024 * 1024) {
            console.log(`[BACKUP] ⚠️ file terlalu besar (${(stat.size / 1024 / 1024).toFixed(2)} MB), hapus`);
            try { fs.unlinkSync(zipPath); } catch {}
            return { ok: false, error: `Backup terlalu besar (${(stat.size / 1024 / 1024).toFixed(2)} MB)` };
        }

        lastBackupAt = Date.now();
        lastBackupSize = stat.size;
        lastBackupPath = zipPath;
        backupCount++;

        // ⚡ Hapus backup lama — simpen max 3
        try {
            const allBackups = fs.readdirSync(BACKUP_DIR)
                .filter(f => f.startsWith("backup_") && f.endsWith(".zip"))
                .map(f => ({
                    name: f,
                    path: path.join(BACKUP_DIR, f),
                    mtime: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime()
                }))
                .sort((a, b) => b.mtime - a.mtime); // terbaru dulu

            if (allBackups.length > MAX_BACKUP_FILES_KEEP) {
                const toDelete = allBackups.slice(MAX_BACKUP_FILES_KEEP);
                for (const f of toDelete) {
                    try {
                        fs.unlinkSync(f.path);
                        console.log(`[BACKUP] hapus backup lama: ${f.name}`);
                    } catch {}
                }
            }
        } catch (e) {
            console.log("[BACKUP] cleanup err:", e.message);
        }

        const duration = ((Date.now() - startTime) / 1000).toFixed(2);
        console.log(`[BACKUP] === SELESAI (${duration}s) ===`);

        return {
            ok: true,
            path: zipPath,
            size: stat.size,
            files: added,
            duration
        };
    } catch (e) {
        console.log("[BACKUP] ❌ ERR:", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ SEND TO OWNER (WITH RETRY) ═══
async function sendBackupToOwner(bot, cfg, result) {
    if (!result || !result.ok) return;

    const stat = fs.statSync(result.path);
    const sizeMB = (stat.size / 1024 / 1024).toFixed(2);
    const uptime = Math.floor(process.uptime());
    const uptimeText = `${Math.floor(uptime / 3600)}h ${Math.floor((uptime % 3600) / 60)}m`;

    const caption =
        `<b>𖡛 AUTO BACKUP #${backupCount}</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ Time: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n` +
        `▸ Files: <code>${result.files}</code>\n` +
        `▸ Size: <code>${sizeMB} MB</code>\n` +
        `▸ Duration: <code>${result.duration}s</code>\n` +
        `▸ Uptime: <code>${uptimeText}</code>\n` +
        `▸ Node: <code>${process.version}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Backup otomatis tiap 30 menit.</i>`;

    // Retry 3x kalau gagal
    for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            await bot.sendDocument(cfg.OWNER_ID, result.path, {
                caption,
                parse_mode: "HTML"
            }, {
                filename: `spartax_backup_${backupCount}.zip`,
                contentType: "application/zip"
            });

            console.log(`[BACKUP] ✅ dikirim ke owner (attempt ${attempt})`);
            return;
        } catch (e) {
            console.log(`[BACKUP] ❌ attempt ${attempt} gagal:`, e.message.slice(0, 200));

            // Kalau error file too big → skip
            if (e.message.includes("file is too big") || e.message.includes("Request Entity Too Large")) {
                console.log("[BACKUP] file terlalu besar untuk Telegram, skip");
                return;
            }

            // Kalau bukan attempt terakhir, tunggu 5 detik
            if (attempt < 3) await new Promise(r => setTimeout(r, 5000));
        }
    }

    console.log("[BACKUP] ❌ semua attempt gagal");
}

// ═══ RUN BACKUP + SEND ═══
async function runBackupAndSend(bot, cfg) {
    if (isRunning) {
        console.log("[BACKUP] ⚠️ masih running, skip");
        return { ok: false, error: "Masih running" };
    }

    isRunning = true;
    try {
        const result = makeBackup();
        if (result.ok) {
            await sendBackupToOwner(bot, cfg, result);
        }
        return result;
    } finally {
        isRunning = false;
    }
}

// ═══ START AUTO BACKUP ═══
function startAutoBackup(bot, cfg) {
    if (backupTimer) {
        console.log("[BACKUP] timer udah jalan, skip");
        return;
    }

    console.log(`[BACKUP] start auto-backup setiap ${BACKUP_INTERVAL_MS / 60000} menit`);

    // Backup pertama: 5 menit setelah start
    setTimeout(async () => {
        console.log("[BACKUP] === INITIAL BACKUP ===");
        await runBackupAndSend(bot, cfg);
    }, 5 * 60 * 1000);

    backupTimer = setInterval(async () => {
        console.log("[BACKUP] === SCHEDULED BACKUP ===");
        await runBackupAndSend(bot, cfg);
    }, BACKUP_INTERVAL_MS);
}

// ═══ STOP AUTO BACKUP ═══
function stopAutoBackup() {
    if (backupTimer) {
        clearInterval(backupTimer);
        backupTimer = null;
        console.log("[BACKUP] auto-backup stopped");
    }
}

// ═══ STATUS ═══
function getStatus() {
    return {
        running: !!backupTimer,
        isCurrentlyRunning: isRunning,
        intervalMin: BACKUP_INTERVAL_MS / 60000,
        lastBackupAt,
        lastBackupSize,
        lastBackupPath,
        backupCount,
        maxTotalSizeMB: MAX_TOTAL_SIZE / 1024 / 1024,
        maxFileSizeMB: MAX_FILE_SIZE / 1024 / 1024,
        maxKeep: MAX_BACKUP_FILES_KEEP
    };
}

// ═══ REGISTER COMMANDS ═══
function registerCommands(bot, cfg) {
    bot.onText(/^\/backup(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
        if (String(msg.from.id) !== String(cfg.OWNER_ID)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ OWNER ONLY</b>\n\n<i>Command ini cuma buat owner bot.</i>`,
                { parse_mode: "HTML" });
        }

        const args = (msg.text || "").split(/\s+/).slice(1);
        const sub = args[0]?.toLowerCase();

        // STATUS
        if (sub === "status") {
            const s = getStatus();
            return bot.sendMessage(msg.chat.id,
                `<b>𖡛 BACKUP STATUS</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Auto: ${s.running ? "🟢 ON" : "🔴 OFF"}\n` +
                `▸ Interval: <code>${s.intervalMin} menit</code>\n` +
                `▸ Backup count: <code>${s.backupCount}</code>\n` +
                `▸ Last backup: ${s.lastBackupAt ? new Date(s.lastBackupAt).toLocaleString("id-ID") : "-"}\n` +
                `▸ Last size: <code>${s.lastBackupSize ? (s.lastBackupSize / 1024 / 1024).toFixed(2) + " MB" : "-"}</code>\n` +
                `▸ Max total: <code>${s.maxTotalSizeMB} MB</code>\n` +
                `▸ Max per file: <code>${s.maxFileSizeMB} MB</code>\n` +
                `▸ Max keep: <code>${s.maxKeep} file</code>\n` +
                `▸ Currently running: ${s.isCurrentlyRunning ? "⏳ Yes" : "No"}\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML" });
        }

        // NOW
        if (sub === "now") {
            const loading = await bot.sendMessage(msg.chat.id,
                `<b>⏳ Running backup...</b>\n\n<i>Proses 10-60 detik.</i>`,
                { parse_mode: "HTML" });

            const result = await runBackupAndSend(bot, cfg);

            try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

            if (result.ok) {
                await bot.sendMessage(msg.chat.id,
                    `<b>✅ BACKUP SELESAI</b>\n\n` +
                    `▸ Files: <code>${result.files}</code>\n` +
                    `▸ Size: <code>${(result.size / 1024 / 1024).toFixed(2)} MB</code>\n` +
                    `▸ Duration: <code>${result.duration}s</code>`,
                    { parse_mode: "HTML" });
            } else {
                await bot.sendMessage(msg.chat.id,
                    `<b>❌ BACKUP GAGAL</b>\n\n<code>${(result.error || "").slice(0, 200)}</code>`,
                    { parse_mode: "HTML" });
            }
            return;
        }

        // LIST
        if (sub === "list") {
            try {
                const list = fs.readdirSync(BACKUP_DIR)
                    .filter(f => f.endsWith(".zip"))
                    .map(f => {
                        const stat = fs.statSync(path.join(BACKUP_DIR, f));
                        return { name: f, size: stat.size, mtime: stat.mtime };
                    })
                    .sort((a, b) => b.mtime - a.mtime)
                    .slice(0, 10);

                if (list.length === 0) {
                    return bot.sendMessage(msg.chat.id, `<b>📋 Belum ada backup.</b>`, { parse_mode: "HTML" });
                }

                const text = list.map((b, i) =>
                    `${i + 1}. <code>${b.name}</code>\n   ▸ ${(b.size / 1024 / 1024).toFixed(2)} MB — ${b.mtime.toLocaleString("id-ID")}`
                ).join("\n");

                return bot.sendMessage(msg.chat.id,
                    `<b>📋 BACKUP LIST (10 terbaru)</b>\n\n${text}`,
                    { parse_mode: "HTML" });
            } catch (e) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Error:</b> ${e.message}`, { parse_mode: "HTML" });
            }
        }

        // CLEAN — hapus semua backup
        if (sub === "clean") {
            try {
                const files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith(".zip"));
                let deleted = 0;
                for (const f of files) {
                    try { fs.unlinkSync(path.join(BACKUP_DIR, f)); deleted++; } catch {}
                }
                return bot.sendMessage(msg.chat.id,
                    `<b>🧹 CLEAN BACKUP</b>\n\n▸ Dihapus: <code>${deleted}</code> file`,
                    { parse_mode: "HTML" });
            } catch (e) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Error:</b> ${e.message}`, { parse_mode: "HTML" });
            }
        }

        // START
        if (sub === "start") {
            startAutoBackup(bot, cfg);
            return bot.sendMessage(msg.chat.id, `<b>✅ Auto-backup: ON</b>\n\n▸ Interval: 30 menit`, { parse_mode: "HTML" });
        }

        // STOP
        if (sub === "stop") {
            stopAutoBackup();
            return bot.sendMessage(msg.chat.id, `<b>❌ Auto-backup: OFF</b>`, { parse_mode: "HTML" });
        }

        // HELP
        return bot.sendMessage(msg.chat.id,
            `<b>𖡛 AUTO BACKUP — OWNER</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <code>/backup now</code> — Backup sekarang\n` +
            `▸ <code>/backup status</code> — Status backup\n` +
            `▸ <code>/backup list</code> — List backup terbaru\n` +
            `▸ <code>/backup clean</code> — Hapus semua backup\n` +
            `▸ <code>/backup start</code> — Aktifin auto-backup\n` +
            `▸ <code>/backup stop</code> — Matiin auto-backup\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Max size: ${MAX_TOTAL_SIZE / 1024 / 1024} MB | Max per file: ${MAX_FILE_SIZE / 1024 / 1024} MB | Keep ${MAX_BACKUP_FILES_KEEP} terbaru</i>`,
            { parse_mode: "HTML" });
    });
}

module.exports = {
    startAutoBackup,
    stopAutoBackup,
    runBackupAndSend,
    makeBackup,
    getStatus,
    registerCommands,
    BACKUP_DIR,
    BACKUP_INTERVAL_MS,
    MAX_TOTAL_SIZE,
    MAX_FILE_SIZE
};

console.log("[AUTO BACKUP] module loaded (v2 — fixed size)");