// ═══════════════════════════════════════════
// GROUP TOOLS — Command Management Group
// /promote /ban /mute /unmute /close /open /unban /pin
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const path = require("path");
const fs = require("fs");
const guard = require("./guard");

// ═══ HELPERS ═══
async function isAdmin(bot, chatId, userId) {
    try {
        const m = await bot.getChatMember(chatId, userId);
        return ["creator", "administrator"].includes(m.status);
    } catch {
        return false;
    }
}

async function botIsAdmin(bot, chatId) {
    try {
        const me = await bot.getMe();
        const m = await bot.getChatMember(chatId, me.id);
        return ["creator", "administrator"].includes(m.status);
    } catch {
        return false;
    }
}

function parseDuration(str) {
    if (!str) return null;
    str = str.toLowerCase().trim();

    // Format: 1s, 5m, 1h, 1d, 1w
    const match = str.match(/^(\d+)\s*(s|m|h|d|w)$/);
    if (!match) return null;

    const num = parseInt(match[1]);
    const unit = match[2];

    const mult = {
        s: 1000,
        m: 60 * 1000,
        h: 60 * 60 * 1000,
        d: 24 * 60 * 60 * 1000,
        w: 7 * 24 * 60 * 60 * 1000
    };

    return num * mult[unit];
}

function formatDuration(ms) {
    if (ms < 60 * 1000) return Math.floor(ms / 1000) + "s";
    if (ms < 60 * 60 * 1000) return Math.floor(ms / 60000) + "m";
    if (ms < 24 * 60 * 60 * 1000) return Math.floor(ms / 3600000) + "h";
    return Math.floor(ms / 86400000) + "d";
}

// ═══════════════════════════════════════════
// REGISTER COMMANDS
// ═══════════════════════════════════════════
module.exports.register = function (bot, ctx) {

    // ═══ /promote ═══
    bot.onText(/^\/promote(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin! Add dulu.</b>`, { parse_mode: "HTML" });
            }

            const target = msg.reply_to_message?.from;
            if (!target) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /promote</b>\n\n` +
                    `▸ Reply pesan user yang mau di-promote\n` +
                    `▸ Atau tag: <code>/promote @username</code>`,
                    { parse_mode: "HTML" });
            }

            await bot.promoteChatMember(msg.chat.id, target.id, {
                can_change_info: true,
                can_delete_messages: true,
                can_invite_users: true,
                can_restrict_members: true,
                can_pin_messages: true,
                can_promote_members: false
            });

            await bot.sendMessage(msg.chat.id,
                `<b>✓ USER DI-PROMOTE</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ User: <a href="tg://user?id=${target.id}">${target.first_name || "User"}</a>\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[PROMOTE ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal promote:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /ban ═══
    bot.onText(/^\/ban(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin!</b>`, { parse_mode: "HTML" });
            }

            const target = msg.reply_to_message?.from;
            if (!target) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /ban</b>\n\n` +
                    `▸ Reply pesan user yang mau di-ban\n` +
                    `▸ Atau tag: <code>/ban @username</code>`,
                    { parse_mode: "HTML" });
            }

            await bot.banChatMember(msg.chat.id, target.id);
            await bot.sendMessage(msg.chat.id,
                `<b>🚫 USER DI-BAN</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ User: <a href="tg://user?id=${target.id}">${target.first_name || "User"}</a>\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Pesan terakhir user udah dihapus.</i>`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[BAN ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal ban:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /unban ═══
    bot.onText(/^\/unban(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }

            const args = match?.[1]?.trim();
            let targetId = null;

            if (args) {
                // Parse user ID atau username
                if (/^\d+$/.test(args)) {
                    targetId = parseInt(args);
                } else {
                    return bot.sendMessage(msg.chat.id,
                        `<b>📌 CARA PAKAI /unban</b>\n\n` +
                        `▸ <code>/unban 123456789</code> — pake user ID`,
                        { parse_mode: "HTML" });
                }
            } else if (msg.reply_to_message?.from) {
                targetId = msg.reply_to_message.from.id;
            }

            if (!targetId) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /unban</b>\n\n` +
                    `▸ <code>/unban 123456789</code>\n` +
                    `▸ Atau reply pesan user`,
                    { parse_mode: "HTML" });
            }

            await bot.unbanChatMember(msg.chat.id, targetId, { only_if_banned: true });

            // Hapus dari daftar banned bot (kalau ada)
            const g = guard.getGroup(msg.chat.id);
            if (g.banned && g.banned[targetId]) {
                delete g.banned[targetId];
                guard.saveGroup(msg.chat.id, g);
            }

            await bot.sendMessage(msg.chat.id,
                `<b>✓ USER DI-UNBAN</b>\n\n` +
                `▸ User ID: <code>${targetId}</code>\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[UNBAN ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal unban:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /mute [durasi] ═══
    bot.onText(/^\/mute(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin!</b>`, { parse_mode: "HTML" });
            }

            const target = msg.reply_to_message?.from;
            if (!target) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /mute</b>\n\n` +
                    `▸ <code>/mute 5m</code> — mute 5 menit (reply user)\n` +
                    `▸ <code>/mute 1h</code> — mute 1 jam\n` +
                    `▸ <code>/mute 1d</code> — mute 1 hari\n\n` +
                    `<b>Satuan:</b> <code>s</code> (detik), <code>m</code> (menit), <code>h</code> (jam), <code>d</code> (hari), <code>w</code> (minggu)`,
                    { parse_mode: "HTML" });
            }

            const durArg = match?.[1]?.trim();
            let duration = null;
            if (durArg) {
                duration = parseDuration(durArg);
                if (!duration) {
                    return bot.sendMessage(msg.chat.id,
                        `<b>✕ Durasi invalid!</b>\n\nFormat: <code>/mute 5m</code> (5 menit)\nSatuan: <code>s, m, h, d, w</code>`,
                        { parse_mode: "HTML" });
                }
            }

            const permissions = {
                can_send_messages: false,
                can_send_media_messages: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_send_polls: false,
                can_change_info: false,
                can_invite_users: false,
                can_pin_messages: false
            };

            let until = 0;
            if (duration) {
                until = Math.floor((Date.now() + duration) / 1000);
                permissions.until_date = until;
            }

            await bot.restrictChatMember(msg.chat.id, target.id, { permissions });

            const durText = duration ? formatDuration(duration) : "PERMANEN";

            await bot.sendMessage(msg.chat.id,
                `<b>🔇 USER DI-MUTE</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ User: <a href="tg://user?id=${target.id}">${target.first_name || "User"}</a>\n` +
                `▸ Durasi: <b>${durText}</b>\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[MUTE ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal mute:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /unmute ═══
    bot.onText(/^\/unmute(?:@\w+)?(?:\s+(.+))?$/, async (msg, match) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }

            const target = msg.reply_to_message?.from;
            if (!target) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /unmute</b>\n\n` +
                    `▸ Reply pesan user yang mau di-unmute`,
                    { parse_mode: "HTML" });
            }

            await bot.restrictChatMember(msg.chat.id, target.id, {
                permissions: {
                    can_send_messages: true,
                    can_send_media_messages: true,
                    can_send_other_messages: true,
                    can_add_web_page_previews: true,
                    can_send_polls: true,
                    can_invite_users: true
                }
            });

            await bot.sendMessage(msg.chat.id,
                `<b>🔊 USER DI-UNMUTE</b>\n\n` +
                `▸ User: <a href="tg://user?id=${target.id}">${target.first_name || "User"}</a>\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[UNMUTE ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal unmute:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /close ═══
    bot.onText(/^\/close(?:@\w+)?$/, async (msg) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin!</b>`, { parse_mode: "HTML" });
            }

            // Set permission default: cabut can_send_messages untuk member
            await bot.setChatPermissions(msg.chat.id, {
                can_send_messages: false,
                can_send_media_messages: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_send_polls: false
            });

            const g = guard.getGroup(msg.chat.id);
            g.closed = true;
            guard.saveGroup(msg.chat.id, g);

            await bot.sendMessage(msg.chat.id,
                `<b>🔒 GROUP DITUTUP</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Status: <b>Read-Only</b>\n` +
                `▸ Cuma admin yang bisa kirim pesan\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Ketik /open untuk buka lagi.</i>`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[CLOSE ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal close:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /open ═══
    bot.onText(/^\/open(?:@\w+)?$/, async (msg) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin!</b>`, { parse_mode: "HTML" });
            }

            await bot.setChatPermissions(msg.chat.id, {
                can_send_messages: true,
                can_send_media_messages: true,
                can_send_other_messages: true,
                can_add_web_page_previews: true,
                can_send_polls: true,
                can_invite_users: true
            });

            const g = guard.getGroup(msg.chat.id);
            g.closed = false;
            guard.saveGroup(msg.chat.id, g);

            await bot.sendMessage(msg.chat.id,
                `<b>🔓 GROUP DIBUKA</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Status: <b>Normal</b>\n` +
                `▸ Semua member bisa kirim pesan\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[OPEN ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal open:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });

    // ═══ /pin ═══
    bot.onText(/^\/pin(?:@\w+)?$/, async (msg) => {
        try {
            if (msg.chat.type === "private") return;
            if (!await isAdmin(bot, msg.chat.id, msg.from.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Cuma admin group!</b>`, { parse_mode: "HTML" });
            }
            if (!await botIsAdmin(bot, msg.chat.id)) {
                return bot.sendMessage(msg.chat.id, `<b>✕ Bot bukan admin!</b>`, { parse_mode: "HTML" });
            }

            const target = msg.reply_to_message;
            if (!target) {
                return bot.sendMessage(msg.chat.id,
                    `<b>📌 CARA PAKAI /pin</b>\n\n` +
                    `▸ Reply pesan yang mau di-pin`,
                    { parse_mode: "HTML" });
            }

            await bot.pinChatMessage(msg.chat.id, target.message_id, { disable_notification: false });

            await bot.sendMessage(msg.chat.id,
                `<b>📌 PESAN DI-PIN</b>\n\n` +
                `▸ By: <a href="tg://user?id=${msg.from.id}">${msg.from.first_name}</a>`,
                { parse_mode: "HTML" });
        } catch (e) {
            console.log("[PIN ERR]", e.message);
            await bot.sendMessage(msg.chat.id, `<b>✕ Gagal pin:</b>\n<code>${e.message.slice(0, 150)}</code>`, { parse_mode: "HTML" }).catch(() => {});
        }
    });
};

module.exports.isAdmin = isAdmin;
module.exports.botIsAdmin = botIsAdmin;

console.log("[GROUP TOOLS] module loaded");