const router = require("./router");
const cfg = require("../config");

router.registerCallback("menu_buildmenu", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        const role = ctx.db.isOwner(user.id) ? "❰ OWNER ❱" : (u.premium ? "❰ PREMIUM ❱" : "❰ FREE ❱");

        const caption =
            `<b>𖡛 BUILD MENU</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Role: <b>${role}</b>\n` +
            `𖡛 Credit: <code>${u.credit}</code>\n` +
            `𖡛 Biaya: <b>${cfg.CREDIT_PER_USE} credit</b> / fitur\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Fitur tersedia:</b>\n` +
            `𖡛 Build Pubspec — Build Flutter APK\n` +
            `𖡛 Build Yaml — Build Native APK\n` +
            `𖡛 Rename Base — Rename base project\n` +
            `𖡛 Rename API — Rename API keys\n` +
            `𖡛 Rename Baileys — Ganti versi Baileys\n` +
            `𖡛 Rename Function Bug — Ganti nama function\n` +
            `𖡛 AI Code Editor — Edit code pake AI\n` +
            `𖡛 Web to App — Convert web ke APK\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Semua fitur = PUBLIC. Butuh credit.</i>`;

        const kb = [
            [
                { text: "𖡛 Build Pubspec", callback_data: "menu_buildpubspec", style: "success" },
                { text: "𖡛 Build Yaml", callback_data: "menu_buildyml", style: "success" }
            ],
            [
                { text: "𖡛 Rename Base", callback_data: "menu_renamebase", style: "primary" },
                { text: "𖡛 Rename API", callback_data: "menu_renameapi", style: "primary" }
            ],
            [
                { text: "𖡛 Rename Baileys", callback_data: "menu_renamebaileys", style: "success" },
                { text: "𖡛 Rename Function", callback_data: "menu_renamefunc", style: "success" }
            ],
            [
                { text: "🛠️ AI Code Editor", callback_data: "menu_aicodeeditor", style: "success" },
                { text: "𖡛 Web to App", callback_data: "menu_webtoapp", style: "success" }
            ],
            [
                { text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "success" }
            ],
            [
                { text: "▸ Menu Utama", callback_data: "menu_back", style: "danger" }
            ]
        ];

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) {
        console.log("[BUILD MENU ERR]", e.message);
    }
});

console.log("[BUILDMENU] module loaded");