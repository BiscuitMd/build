const router = require("./router");

router.registerCallback("prem_addcredit", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isPremium(q.from.id) && !ctx.db.isOwner(q.from.id)) return;
    ctx.setState(q.from.id, "prem_addcredit_amount", {});
    await bot.sendMessage(q.message.chat.id, `<b>🪙 ADD CREDIT PREMIUM</b>\n\nBerapa credit? (max 500)`, { parse_mode: "HTML" });
});
router.registerMessage("prem_addcredit_amount", async (bot, msg, state, ctx) => {
    if (!ctx.db.isPremium(msg.from.id) && !ctx.db.isOwner(msg.from.id)) return;
    const amt = Math.min(parseInt(msg.text) || 0, 500);
    ctx.db.addCredit(msg.from.id, amt);
    await bot.sendMessage(msg.chat.id, `<b>✓ +${amt} credit masuk ke akun lu.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("prem_createredeem", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isPremium(q.from.id) && !ctx.db.isOwner(q.from.id)) return;
    ctx.setState(q.from.id, "prem_redeem_name", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 CREATE REDEEM</b>\n\nKirim nama code:`, { parse_mode: "HTML" });
});
router.registerMessage("prem_redeem_name", async (bot, msg, state, ctx) => {
    ctx.setState(msg.from.id, "prem_redeem_credit", { name: msg.text.trim().toUpperCase() });
    await bot.sendMessage(msg.chat.id, `<b>Berapa credit? (max 500)</b>`, { parse_mode: "HTML" });
});
router.registerMessage("prem_redeem_credit", async (bot, msg, state, ctx) => {
    const credit = Math.min(parseInt(msg.text) || 0, 500);
    ctx.setState(msg.from.id, "prem_redeem_limit", { name: state.name, credit });
    await bot.sendMessage(msg.chat.id, `<b>Berapa orang?</b>`, { parse_mode: "HTML" });
});
router.registerMessage("prem_redeem_limit", async (bot, msg, state, ctx) => {
    const limit = parseInt(msg.text) || 1;
    const redeems = ctx.db.read("redeem");
    redeems[state.name] = { name: state.name, credit: state.credit, limit, claimed: [], createdAt: Date.now(), active: true, creator: msg.from.id };
    ctx.db.write("redeem", redeems);
    const users = ctx.db.allUsers();
    let sent = 0;
    for (const uid in users) {
        try {
            await bot.sendMessage(uid,
                `<b>𖡛 CODE REDEEM BARU!</b>\n\n𖡛 <code>${state.name}</code>\n🪙 ${state.credit} credit\n𖡛 Limit: ${limit}`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Claim", callback_data: `redeem_claim:${state.name}` }]] } });
            sent++;
        } catch {}
    }
    await bot.sendMessage(msg.chat.id, `<b>✓ Redeem dibuat & dikirim ke ${sent} user.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});