const router = require("./router");
const cfg = require("../config");

router.registerCallback("menu_chatdev", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "chatdev_await", {});
    await bot.sendPhoto(q.message.chat.id, cfg.FOTO.CHATDEV, {
        caption: `<b>𖡛 CHAT DEVELOPER</b>\n\n━━━━━━━━━━━━━━━━━━━━\n<i>Kirim pesan lu, nanti bakal diteruskan ke developer.</i>\nBalasan developer akan masuk ke chat ini.\n━━━━━━━━━━━━━━━━━━━━`,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
    });
});

router.registerMessage("chatdev_await", async (bot, msg, state, ctx) => {
    const body = `<b>𖡛 PESAN DARI USER</b>\n\n━━━━━━━━━━━━━━━━━━━━\n𖡛 User: <a href="tg://user?id=${msg.from.id}">${msg.from.id}</a>\n𖡛 <code>${msg.from.id}</code>\n━━━━━━━━━━━━━━━━━━━━\n${msg.text || "[media]"}`;
    const kb = { inline_keyboard: [[{ text: "𖡛 Balas", callback_data: `chatdev_reply:${msg.from.id}` }]] };
    if (msg.photo) {
        await bot.sendPhoto(cfg.OWNER_ID, msg.photo[msg.photo.length - 1].file_id, { caption: body, parse_mode: "HTML", reply_markup: kb });
    } else {
        await bot.sendMessage(cfg.OWNER_ID, body, { parse_mode: "HTML", reply_markup: kb });
    }
    await bot.sendMessage(msg.chat.id, `<b>✓ Pesan terkirim ke developer.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("chatdev_reply", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(q.from.id)) return;
    const uid = data.split(":")[1];
    ctx.setState(q.from.id, "chatdev_reply_await", { uid });
    await bot.sendMessage(q.message.chat.id, `<b>💬 Kirim balasan ke user <code>${uid}</code>:</b>`, { parse_mode: "HTML" });
});

router.registerMessage("chatdev_reply_await", async (bot, msg, state, ctx) => {
    await bot.sendMessage(state.uid, `<b>💬 BALASAN DEVELOPER</b>\n\n━━━━━━━━━━━━━━━━━━━━\n${msg.text}`, { parse_mode: "HTML" });
    await bot.sendMessage(msg.chat.id, `<b>✓ Terkirim.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});