const router = require("./router");
const cfg = require("../config");

const pendingDeploy = new Map();

router.registerCallback("menu_deploy", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 DEPLOY HTML</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>𖡛 Kirim file .html / .zip yang mau di-deploy.</i>\n` +
        `𖡛 Setelah terkirim, lu bakal pilih platform:\n` +
        `𖡛 Vercel — hosting publik\n` +
        `𖡛 Netflix — hosting privat\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
    ctx.setState(user.id, "deploy_await", {});
    await bot.sendMessage(q.message.chat.id, caption, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
    });
});

router.registerMessage("deploy_await", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!msg.document) {
        return bot.sendMessage(chatId, "✕ Kirim file .html / .zip.", { parse_mode: "HTML" });
    }

    const fname = msg.document.file_name || "file.html";
    if (!fname.endsWith(".html") && !fname.endsWith(".zip") && !fname.endsWith(".htm")) {
        return bot.sendMessage(chatId, "✕ Format harus .html / .htm / .zip.", { parse_mode: "HTML" });
    }

    const user = ctx.db.getUser(userId);
    if (user.credit < 1) {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, "✕ Credit habis! Buy credit dulu.", {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
        });
    }

    pendingDeploy.set(userId, {
        fileId: msg.document.file_id,
        fileName: fname,
        fileSize: msg.document.file_size
    });

    ctx.clearState(userId);

    await bot.sendMessage(chatId,
        `<b>𖡛 FILE DITERIMA</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 File: <code>${fname}</code>\n` +
        `𖡛 Size: <code>${(msg.document.file_size / 1024).toFixed(2)} KB</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>𖡛 Pilih platform deploy:</b>`,
        {
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𖡛 VERCEL", callback_data: "deploy_go:vercel", style: "primary" }],
                    [{ text: "𖡛 NETFLIX", callback_data: "deploy_go:netflix", style: "primary" }],
                    [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
                ]
            }
        });
});

router.registerCallback("deploy_go", async (bot, q, data, user, ctx) => {
    const platform = data.split(":")[1];
    const pend = pendingDeploy.get(user.id);

    if (!pend) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Sesi expired, kirim file ulang", show_alert: true });
    }

    const user2 = ctx.db.getUser(user.id);
    if (user2.credit < 1) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Credit habis", show_alert: true });
    }

    ctx.db.saveUser(user.id, { credit: user2.credit - 1 });

    await bot.answerCallbackQuery(q.id, { text: `𖡛 Deploying ke ${platform.toUpperCase()}...` });

    const loading = await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 DEPLOYING...</b>\n\n` +
        `Platform: <b>${platform.toUpperCase()}</b>\n` +
        `File: <code>${pend.fileName}</code>\n\n` +
        `<i>Mohon tunggu...</i>`,
        { parse_mode: "HTML" });

    try {
        const deployUrl = await deployFile(bot, pend, platform);

        await bot.sendMessage(cfg.OWNER_ID,
            `<b>𖡛 NEW DEPLOY</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 User: <a href="tg://user?id=${user.id}">${user.id}</a>\n` +
            `𖡛 Platform: <b>${platform.toUpperCase()}</b>\n` +
            `𖡛 File: <code>${pend.fileName}</code>\n` +
            `𖡛 URL: ${deployUrl}\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" }).catch(() => {});

        if (cfg.NOTIF_CHANNEL && cfg.NOTIF_CHANNEL !== "-1004389804220") {
            await bot.sendMessage(cfg.NOTIF_CHANNEL,
                `<b>✓ DEPLOY SUCCESS</b>\n\n` +
                `User: <code>${user.id}</code>\n` +
                `Platform: <b>${platform.toUpperCase()}</b>\n` +
                `File: <code>${pend.fileName}</code>`,
                { parse_mode: "HTML" }).catch(() => {});
        }

        await bot.editMessageText(
            `<b>✓ DEPLOY SUCCESS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Platform: <b>${platform.toUpperCase()}</b>\n` +
            `𖡛 File: <code>${pend.fileName}</code>\n` +
            `𖡛 URL: <code>${deployUrl}</code>\n` +
            `𖡛 Sisa credit: <code>${ctx.db.getUser(user.id).credit}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            {
                chat_id: q.message.chat.id,
                message_id: loading.message_id,
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Buka URL", url: deployUrl, style: "primary" }],
                        [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            });

    } catch (e) {
        await bot.editMessageText(
            `<b>✕ DEPLOY FAILED</b>\n\n` +
            `<code>${e.message}</code>`,
            { chat_id: q.message.chat.id, message_id: loading.message_id, parse_mode: "HTML" });

        if (cfg.NOTIF_CHANNEL && cfg.NOTIF_CHANNEL !== "-1004389804220") {
            await bot.sendMessage(cfg.NOTIF_CHANNEL,
                `<b>✕ DEPLOY FAILED</b>\n\n` +
                `User: <code>${user.id}</code>\n` +
                `Error: <code>${e.message}</code>`,
                { parse_mode: "HTML" }).catch(() => {});
        }
    }

    pendingDeploy.delete(user.id);
});

async function deployFile(bot, pend, platform) {
    const fileLink = await bot.getFileLink(pend.fileId);

    if (platform === "vercel") {
        return await deployVercel(fileLink, pend.fileName);
    } else if (platform === "netflix") {
        return await deployNetflix(fileLink, pend.fileName);
    }
    throw new Error("Platform tidak dikenal");
}

async function deployVercel(fileLink, fileName) {
    const axios = require("axios");
    const token = require("../config").VERCEL.TOKEN;

    if (!token || token === "ISI_VERCEL_TOKEN_LU") {
        throw new Error("✕ Vercel token belum di-set di config.js");
    }

    const res = await axios.get(fileLink, { responseType: "text" });
    const html = res.data;

    const projectName = `spartax-${Date.now().toString(36)}`;

    const createProject = await axios.post("https://api.vercel.com/v11/projects", {
        name: projectName,
        framework: null
    }, {
        headers: { Authorization: `Bearer ${token}` }
    }).catch(e => {
        throw new Error("Gagal create project: " + (e.response?.data?.error?.message || e.message));
    });

    const projectId = createProject.data.id;

    const deployRes = await axios.post("https://api.vercel.com/v13/deployments", {
        name: projectName,
        files: [
            {
                file: "index.html",
                data: Buffer.from(html, "utf8").toString("base64"),
                encoding: "base64"
            }
        ],
        projectSettings: {
            framework: null
        },
        target: "production"
    }, {
        headers: { Authorization: `Bearer ${token}` }
    }).catch(e => {
        throw new Error("Gagal deploy: " + (e.response?.data?.error?.message || e.message));
    });

    const deployUrl = `https://${deployRes.data.url}`;
    return deployUrl;
}

async function deployNetflix(fileLink, fileName) {
    const axios = require("axios");
    const cfg = require("../config");
    const token = cfg.NETFLIX.TOKEN;
    const apiUrl = cfg.NETFLIX.API_URL;

    if (!token || token === "ISI_NETFLIX_TOKEN_LU") {
        throw new Error("✕ Netflix token belum di-set di config.js");
    }

    const res = await axios.get(fileLink, { responseType: "text" });
    const html = res.data;

    const projectName = `spartax-nf-${Date.now().toString(36)}`;

    const deployRes = await axios.post(`${apiUrl}/deploy`, {
        name: projectName,
        files: [
            { path: "index.html", content: html }
        ]
    }, {
        headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
        }
    }).catch(e => {
        throw new Error("Netflix deploy gagal: " + (e.response?.data?.message || e.message));
    });

    if (deployRes.data && deployRes.data.url) {
        return deployRes.data.url;
    }

    return `https://${projectName}.netflix-deploy.app`;
}