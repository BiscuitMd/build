// ═══════════════════════════════════════════
// SCRIPT STORE — Buy/Sell Scripts
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const notify = require("./notify");

const STORE_FILE = path.join(__dirname, "..", "database", "scripts.json");
const SCRIPTS_DIR = path.join(__dirname, "..", "scripts_store");
const ORDERS_FILE = path.join(__dirname, "..", "database", "script_orders.json");

if (!fs.existsSync(SCRIPTS_DIR)) fs.mkdirSync(SCRIPTS_DIR, { recursive: true });
if (!fs.existsSync(STORE_FILE)) fs.writeFileSync(STORE_FILE, "{}", "utf8");
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "{}", "utf8");

function readStore() {
    try { return JSON.parse(fs.readFileSync(STORE_FILE, "utf8")); } catch { return {}; }
}
function writeStore(d) { fs.writeFileSync(STORE_FILE, JSON.stringify(d, null, 2), "utf8"); }
function readOrders() {
    try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); } catch { return {}; }
}
function writeOrders(d) { fs.writeFileSync(ORDERS_FILE, JSON.stringify(d, null, 2), "utf8"); }

function isOwner(id, ctx) { return ctx.db.isOwner(id); }
function makeOrderId() { return "SCR" + Date.now() + Math.random().toString(36).slice(2, 5).toUpperCase(); }

// ═══════════════════════════════════════════
// MENU UTAMA
// ═══════════════════════════════════════════
router.registerCallback("menu_scriptstore", async (bot, q, data, user, ctx) => {
    try {
        const store = readStore();
        const list = Object.keys(store);

        if (list.length === 0) {
            return bot.sendMessage(q.message.chat.id,
                `<b>𖡛 SCRIPT STORE</b>\n\n━━━━━━━━━━━━━━━━━━━━\n<i>Belum ada script tersedia.</i>\n━━━━━━━━━━━━━━━━━━━━`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [
                        ...(isOwner(user.id, ctx) ? [[{ text: "𖡛 Add Script (Owner)", callback_data: "scriptstore_add", style: "danger" }]] : []),
                        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
                    ] }
                });
        }

        const rows = list.map(id => {
            const s = store[id];
            return [{ text: `𖡛 ${s.name} — Rp${s.harga.toLocaleString("id-ID")}`, callback_data: `scriptstore_buy:${id}` }];
        });

        if (isOwner(user.id, ctx)) {
            rows.push([{ text: "𖡛 Add Script (Owner)", callback_data: "scriptstore_add", style: "danger" }]);
            rows.push([{ text: "𖡛 Hapus Script (Owner)", callback_data: "scriptstore_del_list", style: "danger" }]);
        }
        rows.push([{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]);

        const caption =
            `<b>𖡛 SCRIPT STORE</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Total Script</b>: <code>${list.length}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Pilih script yang mau lu beli:</i>`;

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    } catch (e) { console.log("[SCRIPTSTORE MENU ERR]", e.message); }
});

// ═══════════════════════════════════════════
// ADD SCRIPT (OWNER)
// ═══════════════════════════════════════════
router.registerCallback("scriptstore_add", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(user.id, ctx)) {
            return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });
        }

        // ⚠️ FORCE CLEAR dulu biar ga nyangkut state lama
        ctx.clearState(user.id);

        ctx.setState(user.id, "scriptstore_add_await", {});

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 ADD SCRIPT</b>\n\n━━━━━━━━━━━━━━━━━━━━\n` +
            `1. Kirim <b>file .zip</b> script\n` +
            `2. Bot bakal minta nama & harga\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[SCRIPTSTORE ADD ERR]", e.message); }
});

// ═══ STEP 1: TERIMA ZIP ═══
router.registerMessage("scriptstore_add_await", async (bot, msg, state, ctx) => {
    try {
        if (!isOwner(msg.from.id, ctx)) {
            ctx.clearState(msg.from.id);
            return;
        }

        // ⚠️ Skip kalau command
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        if (!msg.document) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Kirim file .zip</b>\n\nAtau klik tombol batal buat keluar.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        const fname = msg.document.file_name || "script.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ File harus .zip</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        if (msg.document.file_size > 50 * 1024 * 1024) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ File terlalu besar!</b>\n\nMax 50MB.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        // ⚠️ CLEAR STATE LAMA, set state baru
        ctx.clearState(msg.from.id);
        ctx.setState(msg.from.id, "scriptstore_add_name", {
            fileId: msg.document.file_id,
            fileName: fname,
            fileSize: msg.document.file_size
        });

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 FILE DITERIMA</b>\n\n` +
            `𖡛 <code>${fname}</code> (${(msg.document.file_size / 1024).toFixed(1)} KB)\n\n` +
            `<b>Kirim nama script:</b>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[SCRIPTSTORE AWAIT ERR]", e.message); }
});

// ═══ STEP 2: TERIMA NAMA ═══
router.registerMessage("scriptstore_add_name", async (bot, msg, state, ctx) => {
    try {
        if (!isOwner(msg.from.id, ctx)) {
            ctx.clearState(msg.from.id);
            return;
        }

        const text = msg.text?.trim();

        // ⚠️ Kalau command, clear state
        if (text && text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        if (!text) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim nama script.</b>`, { parse_mode: "HTML" });
        }

        if (text.length > 64) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Nama terlalu panjang (max 64 karakter).</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        if (!state.fileId || !state.fileName) {
            ctx.clearState(msg.from.id);
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Data hilang.</b>\n\nUlangi dari awal.`,
                { parse_mode: "HTML" });
        }

        // ⚠️ CLEAR, set state baru dengan nama
        ctx.clearState(msg.from.id);
        ctx.setState(msg.from.id, "scriptstore_add_price", {
            fileId: state.fileId,
            fileName: state.fileName,
            fileSize: state.fileSize,
            name: text
        });

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 NAMA DITERIMA</b>\n\n` +
            `𖡛 <b>Nama</b>: <code>${text}</code>\n\n` +
            `<b>Kirim harga script (angka, contoh: 15000):</b>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[SCRIPTSTORE NAME ERR]", e.message); }
});

// ═══ STEP 3: TERIMA HARGA ═══
router.registerMessage("scriptstore_add_price", async (bot, msg, state, ctx) => {
    try {
        if (!isOwner(msg.from.id, ctx)) {
            ctx.clearState(msg.from.id);
            return;
        }

        const text = msg.text?.trim();

        // ⚠️ Kalau command, clear state
        if (text && text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        if (!text) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Kirim harga dalam bentuk angka.</b>\n\nContoh: <code>15000</code>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        // Parse angka
        const cleaned = text.replace(/[^\d]/g, "");
        const harga = parseInt(cleaned, 10);

        if (!cleaned || isNaN(harga) || harga < 1) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Harga invalid.</b>\n\n` +
                `<b>Yang lu kirim:</b> <code>${text.slice(0, 50)}</code>\n\n` +
                `<b>Kirim angka aja:</b>\n` +
                `▸ <code>15000</code>\n` +
                `▸ <code>Rp15000</code>\n` +
                `▸ <code>15.000</code>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        if (harga > 999999999) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Harga terlalu besar!</b>\n\nMax: <code>999.999.999</code>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel", style: "danger" }]] } });
        }

        // ⚠️ Validasi data lengkap
        if (!state.name || !state.fileId || !state.fileName) {
            ctx.clearState(msg.from.id);
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Data ga lengkap.</b>\n\nUlangi dari awal.`,
                { parse_mode: "HTML" });
        }

        // ⭐ SIMPAN SCRIPT
        const id = "SCR" + Date.now().toString(36).toUpperCase();
        const store = readStore();
        store[id] = {
            id,
            name: state.name,
            harga,
            fileId: state.fileId,
            fileName: state.fileName,
            fileSize: state.fileSize,
            createdAt: Date.now(),
            createdBy: msg.from.id,
            sold: 0
        };
        writeStore(store);

        // ⚠️ WAJIB CLEAR STATE
        ctx.clearState(msg.from.id);

        await bot.sendMessage(msg.chat.id,
            `<b>✓ SCRIPT DITAMBAHKAN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>ID</b>: <code>${id}</code>\n` +
            `𖡛 <b>Nama</b>: ${state.name}\n` +
            `𖡛 <b>Harga</b>: Rp${harga.toLocaleString("id-ID")}\n` +
            `𖡛 <b>File</b>: <code>${state.fileName}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[
                { text: "𖡛 Lihat Store", callback_data: "menu_scriptstore", style: "success" },
                { text: "𖡛 Add Lagi", callback_data: "scriptstore_add", style: "primary" }
            ]] } });
    } catch (e) { console.log("[SCRIPTSTORE PRICE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// CANCEL ADD SCRIPT
// ═══════════════════════════════════════════
router.registerCallback("scriptstore_cancel", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(user.id, ctx)) return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });

        ctx.clearState(user.id);
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });

        await bot.sendMessage(q.message.chat.id,
            `<b>✕ Add script dibatalkan.</b>\n\nKetik /menu buat balik ke menu.`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[SCRIPTSTORE CANCEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// HAPUS SCRIPT
// ═══════════════════════════════════════════
router.registerCallback("scriptstore_del_list", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(user.id, ctx)) return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });

        const store = readStore();
        const list = Object.keys(store);
        if (list.length === 0) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Belum ada script.</b>`, { parse_mode: "HTML" });
        }

        const rows = list.map(id => [{ text: `𖡛 ${store[id].name}`, callback_data: `scriptstore_del:${id}` }]);
        rows.push([{ text: "⬅️ Kembali", callback_data: "menu_scriptstore" }]);

        await bot.sendMessage(q.message.chat.id, `<b>Pilih script yang mau dihapus:</b>`, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: rows }
        });
    } catch (e) { console.log("[SCRIPTSTORE DELLIST ERR]", e.message); }
});

router.registerCallback("scriptstore_del", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(user.id, ctx)) return;

        const id = data.split(":")[1];
        const store = readStore();
        if (!store[id]) return bot.answerCallbackQuery(q.id, { text: "✕ Ga ada", show_alert: true });

        const name = store[id].name;
        delete store[id];
        writeStore(store);

        await bot.answerCallbackQuery(q.id, { text: `𖡛 ${name} dihapus`, show_alert: true });
        await bot.sendMessage(q.message.chat.id, `<b>✓ Script "${name}" dihapus.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[SCRIPTSTORE DEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BUY SCRIPT
// ═══════════════════════════════════════════
router.registerCallback("scriptstore_buy", async (bot, q, data, user, ctx) => {
    try {
        const id = data.split(":")[1];
        const store = readStore();
        const script = store[id];
        if (!script) return bot.answerCallbackQuery(q.id, { text: "✕ Script ga ada", show_alert: true });

        const orderId = makeOrderId();
        const orders = readOrders();
        orders[orderId] = {
            id: orderId,
            scriptId: id,
            scriptName: script.name,
            harga: script.harga,
            fileName: script.fileName,
            userId: user.id,
            username: user.username || "-",
            firstName: user.first_name || "User",
            status: "pending",
            createdAt: Date.now()
        };
        writeOrders(orders);

        const caption =
            `<b>𖡛 PEMBAYARAN SCRIPT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Order ID</b>: <code>${orderId}</code>\n` +
            `𖡛 <b>Script</b>: ${script.name}\n` +
            `𖡛 <b>Harga</b>: <b>Rp${script.harga.toLocaleString("id-ID")}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Scan QRIS di atas, lalu kirim bukti transfer ke bot ini.</i>`;

        try {
            await bot.sendPhoto(q.message.chat.id, cfg.FOTO.QRIS, {
                caption,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel_buy", style: "danger" }]] }
            });
        } catch {
            await bot.sendMessage(q.message.chat.id, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel_buy", style: "danger" }]] }
            });
        }

        ctx.clearState(user.id);
        ctx.setState(user.id, "scriptstore_proof", { orderId });
    } catch (e) { console.log("[SCRIPTSTORE BUY ERR]", e.message); }
});

router.registerCallback("scriptstore_cancel_buy", async (bot, q, data, user, ctx) => {
    try {
        const st = ctx.getState(user.id);
        if (st && st.orderId) {
            const orders = readOrders();
            if (orders[st.orderId]) {
                orders[st.orderId].status = "cancelled";
                orders[st.orderId].cancelledAt = Date.now();
                writeOrders(orders);
            }
        }
        ctx.clearState(user.id);
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Pembelian dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[SCRIPTSTORE CANCELBUY ERR]", e.message); }
});

// ═══════════════════════════════════════════
// PROOF
// ═══════════════════════════════════════════
router.registerMessage("scriptstore_proof", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Kirim foto bukti transfer!</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "scriptstore_cancel_buy", style: "danger" }]] } });
        }

        const orders = readOrders();
        const order = orders[state.orderId];
        if (!order) {
            ctx.clearState(msg.from.id);
            return bot.sendMessage(msg.chat.id, `<b>✕ Order expired.</b>`, { parse_mode: "HTML" });
        }

        order.proofFileId = msg.photo[msg.photo.length - 1].file_id;
        order.proofSentAt = Date.now();
        order.status = "waiting";
        writeOrders(orders);

        // ⚠️ CLEAR STATE
        ctx.clearState(msg.from.id);

        const caption =
            `<b>𖡛 ORDER SCRIPT BARU</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Order ID</b>: <code>${order.id}</code>\n` +
            `𖡛 <b>User</b>: <a href="tg://user?id=${order.userId}">${order.firstName}</a>\n` +
            `𖡛 <code>${order.userId}</code>\n` +
            `𖡛 <b>Script</b>: ${order.scriptName}\n` +
            `𖡛 <b>Harga</b>: <b>Rp${order.harga.toLocaleString("id-ID")}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        const kb = { inline_keyboard: [[
            { text: "✓ ACC", callback_data: `scriptstore_acc:${order.id}`, style: "success" },
            { text: "✕ TOLAK", callback_data: `scriptstore_rej:${order.id}`, style: "danger" }
        ]] };

        try {
            await bot.sendPhoto(cfg.OWNER_ID, order.proofFileId, {
                caption, parse_mode: "HTML", reply_markup: kb
            });
        } catch {
            await bot.sendMessage(cfg.OWNER_ID, caption, { parse_mode: "HTML", reply_markup: kb });
        }

        await bot.sendMessage(msg.chat.id, `<b>✓ Bukti terkirim ke owner.</b>`, { parse_mode: "HTML" });

        try {
            await notify.notifyInfo(bot, "ORDER SCRIPT PENDING", [
                { label: "𖡛 Order ID", value: order.id },
                { label: "𖡛 User", value: order.firstName },
                { label: "𖡛 Script", value: order.scriptName },
                { label: "𖡛 Harga", value: "Rp" + order.harga.toLocaleString("id-ID") }
            ], `<b>𖡛 ORDER SCRIPT</b>\n\nUser: ${order.firstName}\nScript: ${order.scriptName}`);
        } catch {}
    } catch (e) { console.log("[SCRIPTSTORE PROOF ERR]", e.message); }
});

// ═══════════════════════════════════════════
// OWNER ACC / REJECT
// ═══════════════════════════════════════════
router.registerCallback("scriptstore_acc", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });

        const orderId = data.split(":")[1];
        const orders = readOrders();
        const order = orders[orderId];
        if (!order) return bot.answerCallbackQuery(q.id, { text: "✕ Order ga ada", show_alert: true });

        const store = readStore();
        const script = store[order.scriptId];
        if (!script) return bot.answerCallbackQuery(q.id, { text: "✕ Script udah dihapus", show_alert: true });

        order.status = "success";
        order.approvedAt = Date.now();
        writeOrders(orders);

        script.sold = (script.sold || 0) + 1;
        writeStore(store);

        await bot.answerCallbackQuery(q.id, { text: "✓ ACC — script dikirim", show_alert: true });

        try {
            const fileLink = await bot.getFileLink(script.fileId);
            const axios = require("axios");
            const res = await axios.get(fileLink, { responseType: "arraybuffer", timeout: 60000 });
            const buf = Buffer.from(res.data);

            await bot.sendDocument(order.userId, buf, {
                caption:
                    `<b>✓ SCRIPT DELIVERED</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `𖡛 <b>Order ID</b>: <code>${orderId}</code>\n` +
                    `𖡛 <b>Script</b>: ${script.name}\n` +
                    `𖡛 <b>Harga</b>: Rp${order.harga.toLocaleString("id-ID")}\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<i>Terima kasih udah beli!</i>`,
                parse_mode: "HTML"
            }, { filename: script.fileName });
        } catch (e) {
            console.log("[SCRIPTSTORE ACC ERR]", e.message);
            await bot.sendMessage(order.userId,
                `<b>⚠️ Script gagal dikirim otomatis.</b>\n\nOwner bakal kirim manual. Order: <code>${orderId}</code>`,
                { parse_mode: "HTML" }).catch(() => {});
        }

        await bot.sendMessage(q.message.chat.id,
            `<b>✓ Order ${orderId} di-ACC.</b>\nScript udah kekirim ke user.`,
            { parse_mode: "HTML" });

        try {
            await notify.notifySuccess(bot, "ORDER SCRIPT SUCCESS", [
                { label: "𖡛 Order ID", value: order.id },
                { label: "𖡛 User", value: order.firstName },
                { label: "𖡛 Script", value: order.scriptName },
                { label: "𖡛 Harga", value: "Rp" + order.harga.toLocaleString("id-ID") }
            ], `<b>✓ SCRIPT TERJUAL</b>\n\nUser: ${order.firstName}\nScript: ${order.scriptName}`);
        } catch {}
    } catch (e) { console.log("[SCRIPTSTORE ACC2 ERR]", e.message); }
});

router.registerCallback("scriptstore_rej", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });

        const orderId = data.split(":")[1];
        const orders = readOrders();
        const order = orders[orderId];
        if (!order) return bot.answerCallbackQuery(q.id, { text: "✕ Order ga ada", show_alert: true });

        order.status = "failed";
        order.rejectedAt = Date.now();
        writeOrders(orders);

        await bot.answerCallbackQuery(q.id, { text: "✖️ Ditolak", show_alert: true });

        await bot.sendMessage(order.userId,
            `<b>✕ ORDER DITOLAK</b>\n\nOrder ID: <code>${orderId}</code>\n\n<i>Bukti transfer ga valid.</i>`,
            { parse_mode: "HTML" }).catch(() => {});

        await bot.sendMessage(q.message.chat.id, `<b>✕ Order ${orderId} ditolak.</b>`, { parse_mode: "HTML" });

        try {
            await notify.notifyFailed(bot, "ORDER SCRIPT REJECTED", [
                { label: "𖡛 Order ID", value: order.id },
                { label: "𖡛 User", value: order.firstName },
                { label: "𖡛 Script", value: order.scriptName }
            ], `<b>✕ SCRIPT REJECTED</b>\n\nUser: ${order.firstName}\nScript: ${order.scriptName}`);
        } catch {}
    } catch (e) { console.log("[SCRIPTSTORE REJ ERR]", e.message); }
});

module.exports = { readStore, writeStore, readOrders, writeOrders };
console.log("[SCRIPTSTORE] module loaded");