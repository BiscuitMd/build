const router = require("./router");
const cfg = require("../config");
const notify = require("./notify");

// ═══════════════════════════════════════════
// HELPER
// ═══════════════════════════════════════════
function creditTiers() {
    const tiers = [];
    for (let i = 1; i <= 5; i++) {
        tiers.push({ credit: i, harga: i * 100 });
    }
    return tiers;
}

async function sendPhoto(bot, chatId, url, caption, keyboard) {
    try {
        return await bot.sendPhoto(chatId, url, {
            caption,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: keyboard }
        });
    } catch {
        return bot.sendMessage(chatId, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: keyboard }
        });
    }
}

// ═══════════════════════════════════════════
// MENU: BUY CREDIT
// ═══════════════════════════════════════════
router.registerCallback("menu_buycredit", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>▸ BUY CREDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ 1 credit = Rp100\n` +
            `▸ Max credit = 500\n` +
            `▸ Credit lu sekarang: <code>${user.credit}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Pilih paket credit:</i>`;

        const keyboard = creditTiers().map(t => ([
            { text: `▸ ${t.credit} Credit — Rp${t.harga.toLocaleString("id-ID")}`, callback_data: `buycredit_pick:${t.credit}`, style: "success" }
        ]));
        keyboard.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.BUY_CREDIT, caption, keyboard);
    } catch (e) {
        console.log("[BUYCREDIT MENU ERR]", e.message);
    }
});

router.registerCallback("buycredit_pick", async (bot, q, data, user, ctx) => {
    try {
        const credit = parseInt(data.split(":")[1]);
        const harga = credit * 100;

        const caption =
            `<b>▸ PEMBAYARAN CREDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Credit: <b>${credit}</b>\n` +
            `▸ Harga: <b>Rp${harga.toLocaleString("id-ID")}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Scan QRIS di atas, kirim bukti transfer ke bot ini.</i>`;

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.QRIS, caption, [
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ]);

        ctx.setState(user.id, "buycredit_proof", { credit, harga });
    } catch (e) {
        console.log("[BUYCREDIT PICK ERR]", e.message);
    }
});

router.registerMessage("buycredit_proof", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto bukti transfer!</b>`, { parse_mode: "HTML" });
        }

        const ownerCaption =
            `<b>▸ BUKTI TRANSFER CREDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ User: <a href="tg://user?id=${msg.from.id}">${msg.from.id}</a>\n` +
            `▸ Credit: <code>${state.credit}</code>\n` +
            `▸ Harga: <code>Rp${state.harga.toLocaleString("id-ID")}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await bot.sendPhoto(cfg.OWNER_ID, msg.photo[msg.photo.length - 1].file_id, {
            caption: ownerCaption,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [[
                    { text: "✓ ACC", callback_data: `payacc_credit:${msg.from.id}:${state.credit}`, style: "success" },
                    { text: "✕ TOLAK", callback_data: `payrej:${msg.from.id}`, style: "danger" }
                ]]
            }
        });

        await bot.sendMessage(msg.chat.id,
            `<b>✓ Bukti terkirim ke owner.</b>\n\n<i>Tunggu konfirmasi.</i>`,
            { parse_mode: "HTML" });

        await notify.notifyInfo(bot, "BUKTI CREDIT", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Credit", value: String(state.credit) },
            { label: "Harga", value: "Rp" + state.harga.toLocaleString("id-ID") }
        ]).catch(() => {});

        ctx.clearState(msg.from.id);
    } catch (e) {
        console.log("[BUYCREDIT PROOF ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// MENU: BUY PREMIUM
// ═══════════════════════════════════════════
router.registerCallback("menu_buypremium", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>▸ BUY PREMIUM</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Harga: <b>Rp${cfg.HARGA.PREMIUM.toLocaleString("id-ID")}</b>\n\n` +
            `<b>Benefit Premium:</b>\n` +
            `▸ Akses MENU PREMIUM\n` +
            `▸ Bisa kirim credit ke user lain\n` +
            `▸ Bisa create code redeem\n` +                 
            `▸ Akses fitur eksklusif\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.BUY_PREMIUM, caption, [
            [{ text: "▸ Beli Sekarang", callback_data: "buypremium_go", style: "success" }],
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ]);
    } catch (e) {
        console.log("[BUYPREMIUM MENU ERR]", e.message);
    }
});

router.registerCallback("buypremium_go", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>▸ PEMBAYARAN PREMIUM</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Harga: <b>Rp${cfg.HARGA.PREMIUM.toLocaleString("id-ID")}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Scan QRIS di atas, kirim bukti transfer ke bot ini.</i>`;

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.QRIS, caption, [
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ]);

        ctx.setState(user.id, "buypremium_proof", {});
    } catch (e) {
        console.log("[BUYPREMIUM GO ERR]", e.message);
    }
});

router.registerMessage("buypremium_proof", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto bukti transfer!</b>`, { parse_mode: "HTML" });
        }

        const ownerCaption =
            `<b>▸ BUKTI TRANSFER PREMIUM</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ User: <a href="tg://user?id=${msg.from.id}">${msg.from.id}</a>\n` +
            `▸ Harga: <code>Rp${cfg.HARGA.PREMIUM.toLocaleString("id-ID")}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await bot.sendPhoto(cfg.OWNER_ID, msg.photo[msg.photo.length - 1].file_id, {
            caption: ownerCaption,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [[
                    { text: "✓ ACC PREMIUM", callback_data: `payacc_premium:${msg.from.id}`, style: "success" },
                    { text: "✕ TOLAK", callback_data: `payrej:${msg.from.id}`, style: "danger" }
                ]]
            }
        });

        await bot.sendMessage(msg.chat.id,
            `<b>✓ Bukti terkirim ke owner.</b>\n\n<i>Tunggu konfirmasi.</i>`,
            { parse_mode: "HTML" });

        await notify.notifyInfo(bot, "BUKTI PREMIUM", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Harga", value: "Rp" + cfg.HARGA.PREMIUM.toLocaleString("id-ID") }
        ]).catch(() => {});

        ctx.clearState(msg.from.id);
    } catch (e) {
        console.log("[BUYPREMIUM PROOF ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// MENU: BUY SCRIPT
// ═══════════════════════════════════════════
router.registerCallback("menu_buyscript", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>▸ BUY SCRIPT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ No Up: <b>Rp${cfg.HARGA.SCRIPT_NO_UP.toLocaleString("id-ID")}</b>\n` +
            `▸ Full Up: <b>Rp${cfg.HARGA.SCRIPT_FULL_UP.toLocaleString("id-ID")}</b>\n\n` +
            `<b>Full Up Benefit:</b>\n` +
            `▸ Script lengkap\n` +
            `▸ Free update\n` +
            `▸ Join group update\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.BUY_SCRIPT, caption, [
            [{ text: `▸ No Up — Rp${cfg.HARGA.SCRIPT_NO_UP.toLocaleString("id-ID")}`, callback_data: "buyscript_pick:noup", style: "success" }],
            [{ text: `▸ Full Up — Rp${cfg.HARGA.SCRIPT_FULL_UP.toLocaleString("id-ID")}`, callback_data: "buyscript_pick:fullup", style: "primary" }],
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ]);
    } catch (e) {
        console.log("[BUYSCRIPT MENU ERR]", e.message);
    }
});

router.registerCallback("buyscript_pick", async (bot, q, data, user, ctx) => {
    try {
        const tipe = data.split(":")[1];
        const harga = tipe === "noup" ? cfg.HARGA.SCRIPT_NO_UP : cfg.HARGA.SCRIPT_FULL_UP;

        const caption =
            `<b>▸ PEMBAYARAN SCRIPT (${tipe.toUpperCase()})</b>\n\n` +
            `▸ Harga: <b>Rp${harga.toLocaleString("id-ID")}</b>\n\n` +
            `<i>Scan QRIS, kirim bukti transfer.</i>`;

        await sendPhoto(bot, q.message.chat.id, cfg.FOTO.QRIS, caption, [
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ]);

        ctx.setState(user.id, "buyscript_proof", { tipe, harga });
    } catch (e) {
        console.log("[BUYSCRIPT PICK ERR]", e.message);
    }
});

router.registerMessage("buyscript_proof", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto bukti transfer!</b>`, { parse_mode: "HTML" });
        }

        const ownerCaption =
            `<b>▸ BUKTI TRANSFER SCRIPT (${state.tipe})</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ User: <a href="tg://user?id=${msg.from.id}">${msg.from.id}</a>\n` +
            `▸ Tipe: <code>${state.tipe.toUpperCase()}</code>\n` +
            `▸ Harga: <code>Rp${state.harga.toLocaleString("id-ID")}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        await bot.sendPhoto(cfg.OWNER_ID, msg.photo[msg.photo.length - 1].file_id, {
            caption: ownerCaption,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [[
                    { text: "✓ ACC SCRIPT", callback_data: `payacc_script:${msg.from.id}:${state.tipe}`, style: "success" },
                    { text: "✕ TOLAK", callback_data: `payrej:${msg.from.id}`, style: "danger" }
                ]]
            }
        });

        await bot.sendMessage(msg.chat.id,
            `<b>✓ Bukti terkirim ke owner.</b>\n\n<i>Tunggu konfirmasi.</i>`,
            { parse_mode: "HTML" });

        ctx.clearState(msg.from.id);
    } catch (e) {
        console.log("[BUYSCRIPT PROOF ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// ACC / TOLAK
// ═══════════════════════════════════════════
router.registerCallback("payacc_credit", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) {
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const [, uid, credit] = data.split(":");
        const newCredit = ctx.db.addCredit(uid, parseInt(credit));

        await bot.sendMessage(uid,
            `<b>✓ CREDIT MASUK</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ +<code>${credit}</code> credit\n` +
            `▸ Total: <code>${newCredit}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" }).catch(() => {});

        await bot.sendMessage(q.message.chat.id,
            `<b>✓ ACC</b> — credit +${credit} untuk <code>${uid}</code>`,
            { parse_mode: "HTML" });

        await notify.notifySuccess(bot, "CREDIT ACC", [
            { label: "User ID", value: uid },
            { label: "Credit", value: credit }
        ]).catch(() => {});
    } catch (e) {
        console.log("[PAYACC CREDIT ERR]", e.message);
    }
});

router.registerCallback("payacc_premium", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) {
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const uid = data.split(":")[1];
        ctx.db.setPremium(uid, true);

        // Kirim notif ke user
        await bot.sendMessage(uid,
            `<b>✓ PREMIUM AKTIF</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Status: <b>PREMIUM</b>\n` +
            `▸ Akses: Menu Premium + Spam OTP\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Ketik /start buat liat menu baru.</i>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[{ text: "▸ Buka Menu", callback_data: "menu_userpremium", style: "primary" }]]
                }
            }).catch(() => {});

        await bot.sendMessage(q.message.chat.id,
            `<b>✓ ACC PREMIUM</b> — <code>${uid}</code>`,
            { parse_mode: "HTML" });

        await notify.notifySuccess(bot, "PREMIUM ACC", [
            { label: "User ID", value: uid }
        ]).catch(() => {});
    } catch (e) {
        console.log("[PAYACC PREMIUM ERR]", e.message);
    }
});

router.registerCallback("payacc_script", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) {
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const [, uid, tipe] = data.split(":");
        let msg = `<b>✓ SCRIPT DELIVERED</b>\n\n▸ Tipe: <b>${tipe.toUpperCase()}</b>\n\n`;

        if (tipe === "fullup") {
            msg += `▸ Script: <a href="https://t.me/biscuitMD">Klik di sini</a>\n`;
            msg += `▸ Group Update: ${cfg.GROUP_UPDATE}`;
        } else {
            msg += `▸ Script: <a href="https://t.me/biscuitMD">Klik di sini</a>`;
        }

        await bot.sendMessage(uid, msg, { parse_mode: "HTML" }).catch(() => {});
        await bot.sendMessage(q.message.chat.id,
            `<b>✓ ACC SCRIPT</b> — ${tipe} untuk <code>${uid}</code>`,
            { parse_mode: "HTML" });
    } catch (e) {
        console.log("[PAYACC SCRIPT ERR]", e.message);
    }
});

router.registerCallback("payrej", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(q.from.id)) {
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const uid = data.split(":")[1];

        await bot.sendMessage(uid,
            `<b>✕ PEMBAYARAN DITOLAK</b>\n\n<i>Bukti transfer ga valid atau ada masalah.</i>`,
            { parse_mode: "HTML" }).catch(() => {});

        await bot.sendMessage(q.message.chat.id,
            `<b>✕ DITOLAK</b> — <code>${uid}</code>`,
            { parse_mode: "HTML" });

        await notify.notifyFailed(bot, "PEMBAYARAN DITOLAK", [
            { label: "User ID", value: uid }
        ]).catch(() => {});
    } catch (e) {
        console.log("[PAYREJ ERR]", e.message);
    }
});