const router = require("./router");
const cfg = require("../config");

function isOwner(ctx, id) { return ctx.db.isOwner(id); }

// ═══════════════════════════════════════════
// MENU OWNER
// ═══════════════════════════════════════════
router.registerCallback("menu_owner", async (bot, q, data, user, ctx) => {
    try {
        // ⚠️ Cek owner — kalau bukan owner, tolak
        if (!isOwner(ctx, user.id)) {
            return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true }).catch(() => {});
        }

        const caption =
            `<b>▸ MENU OWNER</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Selamat datang Owner\n` +
            `Pilih menu:\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        const kb = [
            [
                { text: "▸ Add Credit", callback_data: "dev_addcredit", style: "success" },
                { text: "▸ Add Premium", callback_data: "dev_addpremium", style: "success" }
            ],
            [
                { text: "▸ Add Script", callback_data: "dev_addscript", style: "primary" },
                { text: "▸ Create Redeem", callback_data: "dev_createredeem", style: "primary" }
            ],
            [
                { text: "▸ Ban User", callback_data: "dev_banuser", style: "success" },
                { text: "▸ Unban User", callback_data: "dev_unbanuser", style: "success" }
            ],
            [
                { text: "▸ Add Fitur", callback_data: "dev_addfitur", style: "primary" },
                { text: "▸ Del Fitur", callback_data: "dev_delfitur", style: "primary" }
            ],
            [
                { text: "▸ Add Bot", callback_data: "dev_addbot", style: "success" },
                { text: "▸ Del Bot", callback_data: "dev_delbot", style: "success" }
            ],
            [
                { text: "▸ Del Credit", callback_data: "dev_delcredit", style: "primary" },
                { text: "▸ Del Premium", callback_data: "dev_delpremium", style: "primary" }
            ],
            [
                { text: "▸ Del Redeem", callback_data: "dev_delredeem", style: "success" }
            ],
            [
                { text: "▸ Broadcast", callback_data: "dev_broadcast", style: "primary" }
            ],
            [
                { text: "✕ Tutup", callback_data: "menu_close", style: "danger" }
            ]
        ];

        await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[MENU OWNER ERR]", e.message);
    }
});