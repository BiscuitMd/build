// ═══════════════════════════════════════════
// GUARD — Group Guard + Group Tools Menu
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");

const GUARD_FILE = path.join(__dirname, "..", "database", "guard.json");

function readGuard() {
    try {
        return JSON.parse(fs.readFileSync(GUARD_FILE, "utf8"));
    } catch {
        return {};
    }
}

function writeGuard(d) {
    fs.writeFileSync(GUARD_FILE, JSON.stringify(d, null, 2), "utf8");
}

function getGroup(id) {
    const g = readGuard();
    if (!g[id]) {
        g[id] = {
            antilink: false,
            antifoto: false,
            antifwch: false,
            antifw: false,
            antifotobokep: false,
            antispam: false,
            warns: {},
            muted: {},
            spamTracker: {}
        };
        writeGuard(g);
    }
    return g[id];
}

function saveGroup(id, data) {
    const g = readGuard();
    g[id] = { ...g[id], ...data };
    writeGuard(g);
}

async function isAdmin(bot, chatId, userId) {
    try {
        const m = await bot.getChatMember(chatId, userId);
        return ["creator", "administrator"].includes(m.status);
    } catch {
        return false;
    }
}

async function muteUser(bot, chatId, userId) {
    try {
        await bot.restrictChatMember(chatId, userId, {
            permissions: { can_send_messages: false, can_send_media_messages: false, can_send_other_messages: false, can_add_web_page_previews: false }
        });
        return true;
    } catch {
        return false;
    }
}

async function unmuteUser(bot, chatId, userId) {
    try {
        await bot.restrictChatMember(chatId, userId, {
            permissions: { can_send_messages: true, can_send_media_messages: true, can_send_other_messages: true, can_add_web_page_previews: true }
        });
        return true;
    } catch {
        return false;
    }
}

function adminUnmuteKb(chatId, userId) {
    return { inline_keyboard: [[{ text: "𖡛 UNMUTE (Admin Only)", callback_data: `guard_unmute:${chatId}:${userId}` }]] };
}

// ═══════════════════════════════════════════
// MENU: GROUP TOOLS — Gabungan 2 Button
// ═══════════════════════════════════════════
router.registerCallback("menu_group", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.sendMessage(q.message.chat.id, `<b>✕ Fitur ini cuma untuk admin group!</b>`, { parse_mode: "HTML" });
    }

    const caption =
        `<b>𖡛 GROUP TOOLS</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ Group: <b>${q.message.chat.title || "Private"}</b>\n` +
        `▸ Admin: <a href="tg://user?id=${user.id}">${user.first_name || "Admin"}</a>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>Pilih menu:</b>\n` +
        `▸ 🛡️ <b>Group Guard</b> — Auto moderasi (antilink, antifoto, dll)\n` +
        `▸ ⚙️ <b>Group Management</b> — Welcome, Left, Promote, Ban, Mute, dll`;

    const kb = [
        [{ text: "🛡️ GROUP GUARD", callback_data: "menu_guard", style: "success" }],
        [{ text: "⚙️ GROUP MANAGEMENT", callback_data: "menu_group_management", style: "primary" }],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];

    await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
});

// ═══════════════════════════════════════════
// MENU: GROUP GUARD (existing + tombol balik)
// ═══════════════════════════════════════════
router.registerCallback("menu_guard", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.sendMessage(q.message.chat.id, `<b>✕ Fitur ini cuma untuk admin group!</b>`, { parse_mode: "HTML" });
    }
    const gid = q.message.chat.id;
    const g = getGroup(gid);
    const caption =
        `<b>🛡️ GROUP GUARD</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Group: <b>${q.message.chat.title || gid}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Toggle fitur moderasi otomatis di bawah:`;

    const kb = [
        [{ text: `${g.antilink ? "✓" : "✕"} Antilink`, callback_data: "guard_toggle:antilink", style: "success" }],
        [{ text: `${g.antifoto ? "✓" : "✕"} Antifoto`, callback_data: "guard_toggle:antifoto", style: "primary" }],
        [{ text: `${g.antifwch ? "✓" : "✕"} Antifw Channel`, callback_data: "guard_toggle:antifwch", style: "success" }],
        [{ text: `${g.antifw ? "✓" : "✕"} Antifw Channel`, callback_data: "guard_toggle:antifw", style: "primary" }],
        [{ text: `${g.antifotobokep ? "✓" : "✕"} Antifoto BOKEP`, callback_data: "guard_toggle:antifotobokep", style: "success" }],
        [{ text: `${g.antispam ? "✓" : "✕"} Antispam`, callback_data: "guard_toggle:antispam", style: "primary" }],
        [{ text: "⬅️ Balik ke Group Tools", callback_data: "menu_group", style: "danger" }]
    ];
    await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
});

router.registerCallback("guard_toggle", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✖️ Admin only!", show_alert: true });
    }
    const key = data.split(":")[1];
    const gid = q.message.chat.id;
    const g = getGroup(gid);
    g[key] = !g[key];
    saveGroup(gid, g);
    await bot.answerCallbackQuery(q.id, { text: `${key.toUpperCase()} → ${g[key] ? "ON" : "OFF"}`, show_alert: false });

    try {
        await bot.editMessageReplyMarkup({
            inline_keyboard: [
                [{ text: `${g.antilink ? "✓" : "✕"} Antilink`, callback_data: "guard_toggle:antilink", style: "success" }],
                [{ text: `${g.antifoto ? "✓" : "✕"} Antifoto`, callback_data: "guard_toggle:antifoto", style: "primary" }],
                [{ text: `${g.antifwch ? "✓" : "✕"} Antifw Channel`, callback_data: "guard_toggle:antifwch", style: "success" }],
                [{ text: `${g.antifw ? "✓" : "✕"} Antifw Channel`, callback_data: "guard_toggle:antifw", style: "primary" }],
                [{ text: `${g.antifotobokep ? "✓" : "✕"} Antifoto BOKEP`, callback_data: "guard_toggle:antifotobokep", style: "success" }],
                [{ text: `${g.antispam ? "✓" : "✕"} Antispam`, callback_data: "guard_toggle:antispam", style: "primary" }],
                [{ text: "⬅️ Balik ke Group Tools", callback_data: "menu_group", style: "danger" }]
            ]
        }, { chat_id: q.message.chat.id, message_id: q.message.message_id });
    } catch {}
});

router.registerCallback("guard_unmute", async (bot, q, data, user, ctx) => {
    const [, chatId, targetId] = data.split(":");
    const isAdm = await isAdmin(bot, parseInt(chatId), user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Cuma admin group yang bisa unmute!", show_alert: true });
    }
    const ok = await unmuteUser(bot, parseInt(chatId), parseInt(targetId));
    if (ok) {
        await bot.answerCallbackQuery(q.id, { text: "✓ User di-unmute", show_alert: true });
        await bot.sendMessage(chatId, `<b>✅ <a href="tg://user?id=${targetId}">${targetId}</a> udah di-unmute.</b>`, { parse_mode: "HTML" });
    } else {
        await bot.answerCallbackQuery(q.id, { text: "✕ Gagal unmute (bot bukan admin?)", show_alert: true });
    }
});

// ═══════════════════════════════════════════
// MENU: GROUP MANAGEMENT (Welcome, Left, dll)
// ═══════════════════════════════════════════
router.registerCallback("menu_group_management", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.sendMessage(q.message.chat.id, `<b>✕ Fitur ini cuma untuk admin group!</b>`, { parse_mode: "HTML" });
    }

    const gid = q.message.chat.id;
    const g = getGroup(gid);

    const welcomeStatus = g.welcomeEnabled ? "✅ ON" : "❌ OFF";
    const leaveStatus = g.leaveEnabled ? "✅ ON" : "❌ OFF";

    const caption =
        `<b>⚙️ GROUP MANAGEMENT</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Welcome</b>: ${welcomeStatus}\n` +
        `▸ <b>Left</b>: ${leaveStatus}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>Command tersedia:</b>\n` +
        `▸ <code>/setwelcome</code> — Set pesan welcome\n` +
        `▸ <code>/setleave</code> — Set pesan left\n` +
        `▸ <code>/promote</code> — Reply/tag untuk promote\n` +
        `▸ <code>/ban</code> — Reply/tag untuk kick\n` +
        `▸ <code>/mute</code> — Reply/tag + durasi\n` +
        `▸ <code>/unmute</code> — Reply/tag untuk unmute\n` +
        `▸ <code>/close</code> — Tutup group (admin only)\n` +
        `▸ <code>/open</code> — Buka group\n` +
        `▸ <code>/unban</code> — Unban user\n` +
        `▸ <code>/pin</code> — Reply untuk pin pesan\n\n` +
        `<i>Semua command cuma bisa admin group.</i>`;

    const kb = [
        [{ text: `Welcome: ${welcomeStatus}`, callback_data: "gmtoggle:welcome", style: "success" }],
        [{ text: `Left: ${leaveStatus}`, callback_data: "gmtoggle:leave", style: "primary" }],
        [{ text: "🖼️ Set Welcome", callback_data: "menu_setwelcome", style: "success" }],
        [{ text: "🖼️ Set Leave", callback_data: "menu_setleave", style: "primary" }],
        [{ text: "⬅️ Balik ke Group Tools", callback_data: "menu_group", style: "danger" }]
    ];

    await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
});

router.registerCallback("gmtoggle", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✖️ Admin only!", show_alert: true });
    }
    const key = data.split(":")[1];
    const gid = q.message.chat.id;
    const g = getGroup(gid);

    if (key === "welcome") g.welcomeEnabled = !g.welcomeEnabled;
    if (key === "leave") g.leaveEnabled = !g.leaveEnabled;
    saveGroup(gid, g);

    await bot.answerCallbackQuery(q.id, {
        text: key === "welcome"
            ? `Welcome → ${g.welcomeEnabled ? "ON" : "OFF"}`
            : `Left → ${g.leaveEnabled ? "ON" : "OFF"}`,
        show_alert: false
    });

    const welcomeStatus = g.welcomeEnabled ? "✅ ON" : "❌ OFF";
    const leaveStatus = g.leaveEnabled ? "✅ ON" : "❌ OFF";

    try {
        await bot.editMessageReplyMarkup({
            inline_keyboard: [
                [{ text: `Welcome: ${welcomeStatus}`, callback_data: "gmtoggle:welcome", style: "success" }],
                [{ text: `Left: ${leaveStatus}`, callback_data: "gmtoggle:leave", style: "primary" }],
                [{ text: "🖼️ Set Welcome", callback_data: "menu_setwelcome", style: "success" }],
                [{ text: "🖼️ Set Leave", callback_data: "menu_setleave", style: "primary" }],
                [{ text: "⬅️ Balik ke Group Tools", callback_data: "menu_group", style: "danger" }]
            ]
        }, { chat_id: q.message.chat.id, message_id: q.message.message_id });
    } catch {}
});

// ═══════════════════════════════════════════
// SET WELCOME / SET LEAVE — Menu
// ═══════════════════════════════════════════
router.registerCallback("menu_setwelcome", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Admin only!", show_alert: true });
    }

    ctx.setState(user.id, "set_welcome_await", { gid: q.message.chat.id });

    await bot.sendMessage(q.message.chat.id,
        `<b>🖼️ SET WELCOME</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim <b>foto + caption</b> atau <b>teks aja</b>.\n\n` +
        `<b>Placeholder yang bisa dipakai:</b>\n` +
        `▸ <code>{user}</code> — nama user baru\n` +
        `▸ <code>{mention}</code> — tag user baru\n` +
        `▸ <code>{id}</code> — user ID\n` +
        `▸ <code>{group}</code> — nama group\n` +
        `▸ <code>{count}</code> — jumlah member\n\n` +
        `<b>Contoh:</b>\n` +
        `<code>Welcome {mention} ke {group}!</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_group_management", style: "danger" }]] } });
});

router.registerCallback("menu_setleave", async (bot, q, data, user, ctx) => {
    const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
    if (!isAdm && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "Admin only!", show_alert: true });
    }

    ctx.setState(user.id, "set_leave_await", { gid: q.message.chat.id });

    await bot.sendMessage(q.message.chat.id,
        `<b>🖼️ SET LEAVE</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim <b>foto + caption</b> atau <b>teks aja</b>.\n\n` +
        `<b>Placeholder yang bisa dipakai:</b>\n` +
        `▸ <code>{user}</code> — nama user keluar\n` +
        `▸ <code>{mention}</code> — tag user keluar\n` +
        `▸ <code>{id}</code> — user ID\n` +
        `▸ <code>{group}</code> — nama group\n` +
        `▸ <code>{count}</code> — jumlah member\n\n` +
        `<b>Contoh:</b>\n` +
        `<code>Bye {mention}!</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_group_management", style: "danger" }]] } });
});

// ═══════════════════════════════════════════
// HANDLE SET WELCOME MESSAGE
// ═══════════════════════════════════════════
router.registerMessage("set_welcome_await", async (bot, msg, state, ctx) => {
    try {
        const isAdm = await isAdmin(bot, msg.chat.id, msg.from.id);
        if (!isAdm && !ctx.db.isOwner(msg.from.id)) {
            ctx.clearState(msg.from.id);
            return;
        }

        const gid = state.gid;
        const g = getGroup(gid);

        let text = "";
        let photoId = null;

        if (msg.photo && msg.photo.length > 0) {
            photoId = msg.photo[msg.photo.length - 1].file_id;
            text = msg.caption || "Welcome {mention} ke {group}!";
        } else if (msg.text) {
            text = msg.text;
        } else {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto + caption atau teks aja.</b>`, { parse_mode: "HTML" });
        }

        g.welcome = {
            text,
            photo: photoId,
            enabled: true
        };
        g.welcomeEnabled = true;
        saveGroup(gid, g);
        ctx.clearState(msg.from.id);

        await bot.sendMessage(msg.chat.id,
            `<b>✓ WELCOME DI-SET</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Tipe: ${photoId ? "📷 Foto + Caption" : "📝 Teks"}\n` +
            `▸ Preview:\n<code>${text.slice(0, 200)}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Pesan welcome bakal muncul saat ada user baru join.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Balik", callback_data: "menu_group_management", style: "success" }]] } });
    } catch (e) {
        console.log("[SET WELCOME ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// HANDLE SET LEAVE MESSAGE
// ═══════════════════════════════════════════
router.registerMessage("set_leave_await", async (bot, msg, state, ctx) => {
    try {
        const isAdm = await isAdmin(bot, msg.chat.id, msg.from.id);
        if (!isAdm && !ctx.db.isOwner(msg.from.id)) {
            ctx.clearState(msg.from.id);
            return;
        }

        const gid = state.gid;
        const g = getGroup(gid);

        let text = "";
        let photoId = null;

        if (msg.photo && msg.photo.length > 0) {
            photoId = msg.photo[msg.photo.length - 1].file_id;
            text = msg.caption || "Bye {mention}!";
        } else if (msg.text) {
            text = msg.text;
        } else {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto + caption atau teks aja.</b>`, { parse_mode: "HTML" });
        }

        g.leave = {
            text,
            photo: photoId,
            enabled: true
        };
        g.leaveEnabled = true;
        saveGroup(gid, g);
        ctx.clearState(msg.from.id);

        await bot.sendMessage(msg.chat.id,
            `<b>✓ LEAVE DI-SET</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Tipe: ${photoId ? "📷 Foto + Caption" : "📝 Teks"}\n` +
            `▸ Preview:\n<code>${text.slice(0, 200)}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Pesan leave bakal muncul saat ada user keluar.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Balik", callback_data: "menu_group_management", style: "success" }]] } });
    } catch (e) {
        console.log("[SET LEAVE ERR]", e.message);
    }
});

async function addWarn(bot, chatId, userId, reason) {
    const g = getGroup(chatId);
    g.warns[userId] = (g.warns[userId] || 0) + 1;
    const count = g.warns[userId];

    if (count >= 5) {
        const ok = await muteUser(bot, chatId, userId);
        g.muted[userId] = true;
        saveGroup(chatId, g);
        await bot.sendMessage(chatId,
            `<b>𖡛 USER DI-MUTE PERMANEN</b>\n\n` +
            `𖡛 <a href="tg://user?id=${userId}">${userId}</a>\n` +
            `⚠️ Warn: <b>5/5</b>\n` +
            `𖡛 Alasan: ${reason}\n\n` +
            (ok ? `<i>Admin bisa unmute pakai tombol di bawah.</i>` : `<i>Bot ga bisa mute, pastikan bot admin!</i>`),
            { parse_mode: "HTML", reply_markup: adminUnmuteKb(chatId, userId) });
    } else {
        saveGroup(chatId, g);
        await bot.sendMessage(chatId,
            `⚠️ <a href="tg://user?id=${userId}">${userId}</a> — Warn <b>${count}/5</b>\n𖡛 ${reason}`,
            { parse_mode: "HTML" });
    }
}

async function deleteMsg(bot, chatId, msgId) {
    try { await bot.deleteMessage(chatId, msgId); } catch {}
}

// ═══════════════════════════════════════════
// MESSAGE HANDLER — Auto moderasi
// ═══════════════════════════════════════════
module.exports.handleMessage = async function (bot, msg, ctx) {
    if (!msg.chat || (msg.chat.type !== "group" && msg.chat.type !== "supergroup")) return;
    const gid = msg.chat.id;
    const uid = msg.from?.id;
    if (!uid) return;
    const g = getGroup(gid);

    const isAdm = await isAdmin(bot, gid, uid);
    if (isAdm) return;

    if (g.muted && g.muted[uid]) {
        await deleteMsg(bot, gid, msg.message_id);
        return;
    }

    const text = msg.text || msg.caption || "";

    if (g.antilink && /(https?:\/\/|t\.me\/|www\.)/i.test(text)) {
        await deleteMsg(bot, gid, msg.message_id);
        await addWarn(bot, gid, uid, "NO SHARE LINK BEGOK");
        return;
    }

    if (g.antifoto && (msg.photo || msg.video || msg.document)) {
        await deleteMsg(bot, gid, msg.message_id);
        await addWarn(bot, gid, uid, "✕ NO SHARE FOTO BEGOK");
        return;
    }

    if (g.antifwch && msg.forward_from_chat && msg.forward_from_chat.type === "channel") {
        await deleteMsg(bot, gid, msg.message_id);
        await addWarn(bot, gid, uid, "✕ NO SHRE DARI CHANNEL IDIOT");
        return;
    }

    if (g.antifw && (msg.forward_from || msg.forward_from_chat || msg.forward_sender_name)) {
        if (!(msg.forward_from_chat && msg.forward_from_chat.type === "channel")) {
            await deleteMsg(bot, gid, msg.message_id);
            await addWarn(bot, gid, uid, "NO FW ANJINK");
            return;
        }
    }

    if (g.antifotobokep && (msg.photo || msg.video)) {
        const caption = (msg.caption || "").toLowerCase();
        const badWords = ["bokep", "sex", "porn", "nude", "18+", "xxx", "onlyfans", "telanjang"];
        const isBad = badWords.some(w => caption.includes(w));
        if (isBad) {
            await deleteMsg(bot, gid, msg.message_id);
            await addWarn(bot, gid, uid, "NO SHRE 18+ ASW");
            return;
        }
    }

    if (g.antispam) {
        const now = Date.now();
        g.spamTracker[uid] = g.spamTracker[uid] || [];
        g.spamTracker[uid] = g.spamTracker[uid].filter(t => now - t < 5000);
        g.spamTracker[uid].push(now);
        if (g.spamTracker[uid].length > 3) {
            await deleteMsg(bot, gid, msg.message_id);
            await addWarn(bot, gid, uid, "NO SPAM IDIOT ANJING");
            g.spamTracker[uid] = [];
        }
        saveGroup(gid, g);
    }
};

// ═══════════════════════════════════════════
// WELCOME / LEAVE LISTENER
// ═══════════════════════════════════════════
module.exports.handleNewMembers = async function (bot, msg, ctx) {
    try {
        if (!msg.new_chat_members || msg.new_chat_members.length === 0) return;

        const gid = msg.chat.id;
        const g = getGroup(gid);

        if (!g.welcomeEnabled) return;
        if (!g.welcome || !g.welcome.text) return;

        for (const newUser of msg.new_chat_members) {
            if (newUser.is_bot) continue;

            const text = g.welcome.text
                .replace(/{user}/g, newUser.first_name || "User")
                .replace(/{mention}/g, `<a href="tg://user?id=${newUser.id}">${newUser.first_name || "User"}</a>`)
                .replace(/{id}/g, newUser.id)
                .replace(/{group}/g, msg.chat.title || "Group")
                .replace(/{count}/g, msg.chat.members_count || "?");

            try {
                if (g.welcome.photo) {
                    await bot.sendPhoto(gid, g.welcome.photo, {
                        caption: text,
                        parse_mode: "HTML"
                    });
                } else {
                    await bot.sendMessage(gid, text, { parse_mode: "HTML" });
                }
            } catch (e) {
                console.log("[WELCOME SEND ERR]", e.message);
                await bot.sendMessage(gid, text, { parse_mode: "HTML" }).catch(() => {});
            }
        }
    } catch (e) {
        console.log("[WELCOME ERR]", e.message);
    }
};

module.exports.handleLeftMembers = async function (bot, msg, ctx) {
    try {
        if (!msg.left_chat_member) return;

        const gid = msg.chat.id;
        const g = getGroup(gid);

        if (!g.leaveEnabled) return;
        if (!g.leave || !g.leave.text) return;

        const leftUser = msg.left_chat_member;

        const text = g.leave.text
            .replace(/{user}/g, leftUser.first_name || "User")
            .replace(/{mention}/g, `<a href="tg://user?id=${leftUser.id}">${leftUser.first_name || "User"}</a>`)
            .replace(/{id}/g, leftUser.id)
            .replace(/{group}/g, msg.chat.title || "Group")
            .replace(/{count}/g, msg.chat.members_count || "?");

        try {
            if (g.leave.photo) {
                await bot.sendPhoto(gid, g.leave.photo, {
                    caption: text,
                    parse_mode: "HTML"
                });
            } else {
                await bot.sendMessage(gid, text, { parse_mode: "HTML" });
            }
        } catch (e) {
            console.log("[LEAVE SEND ERR]", e.message);
            await bot.sendMessage(gid, text, { parse_mode: "HTML" }).catch(() => {});
        }
    } catch (e) {
        console.log("[LEAVE ERR]", e.message);
    }
};

// ═══════════════════════════════════════════
// EXPORT HELPER
// ═══════════════════════════════════════════
module.exports.getGroup = getGroup;
module.exports.saveGroup = saveGroup;
module.exports.isAdmin = isAdmin;
module.exports.muteUser = muteUser;
module.exports.unmuteUser = unmuteUser;
module.exports.readGuard = readGuard;
module.exports.writeGuard = writeGuard;

// Register menu handler via router
module.exports.registerMenu = function (router) {
    router.registerCallback("menu_guard_cmd", async (bot, q, data, user, ctx) => {
        if (q.message.chat.type === "private") {
            return bot.sendMessage(q.message.chat.id, "✕ Fitur ini cuma di group.", { parse_mode: "HTML" });
        }
        const isAdm = await isAdmin(bot, q.message.chat.id, user.id);
        if (!isAdm && !ctx.db.isOwner(user.id)) {
            return bot.sendMessage(q.message.chat.id, "✕ Cuma admin group!", { parse_mode: "HTML" });
        }
        return router.handlers["menu_guard"] ? router.handlers["menu_guard"](bot, q, data, user, ctx) : null;
    });
};

console.log("[GUARD] module loaded");