const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const notify = require("./notify");

const ORDER_FILE = path.join(__dirname, "..", "database", "orders.json");

function readOrders() {
    try { return JSON.parse(fs.readFileSync(ORDER_FILE, "utf8")); } catch { return {}; }
}
function writeOrders(d) {
    fs.writeFileSync(ORDER_FILE, JSON.stringify(d, null, 2), "utf8");
}
function makeOrderId() {
    return "ORD" + Date.now() + Math.random().toString(36).slice(2, 6).toUpperCase();
}
function normalizeUrl(d) {
    if (!d || d === "belum diset") return "https://t.me/biscuitMD";
    if (d.startsWith("http://") || d.startsWith("https://")) return d;
    return "https://" + d;
}

const ROLE_LABEL = {
    reseller: "𖡛 Reseller", admin: "𖡛 Admin", owner: "𖡛 Owner",
    partner: "𖡛 Partner", tangankanann: "𖡛 Tangan Kanan",
    ceo: "𖡛 CEO", developer: "𖡛 Developer"
};

router.registerCallback("menu_order", async (bot, q, data, user, ctx) => {
    const caption =
        `<b>𖡛 AUTO ORDER ROLE</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>𖡛 PANEL ILEGAL</b>\n` +
        `𖡛 Reseller — Rp1.000\n` +
        `𖡛 Admin — Rp2.000\n` +
        `𖡛 Owner — Rp3.000\n` +
        `𖡛 Partner — Rp4.000\n` +
        `𖡛 Tangan Kanan — Rp5.000\n` +
        `𖡛 CEO — Rp6.000\n` +
        `𖡛 Developer — Rp10.000\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>𖡛 PANEL LEGAL</b>\n` +
        `𖡛 Reseller — Rp10.000\n` +
        `𖡛 Admin — Rp25.000\n` +
        `𖡛 Owner — Rp40.000\n` +
        `𖡛 Partner — Rp55.000\n` +
        `𖡛 Tangan Kanan — Rp70.000\n` +
        `𖡛 CEO — Rp85.000\n` +
        `𖡛 Developer — Rp100.000\n` +
        `━━━━━━━━━━━━━━━━━━━━`;

    await bot.sendMessage(q.message.chat.id, caption, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [
            [{ text: "𖡛 Panel Ilegal", callback_data: "order_type:illegal", style: "primary" }],
            [{ text: "𖡛 Panel Legal", callback_data: "order_type:legal", style: "danger" }],
            [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
        ] }
    });
});

router.registerCallback("order_type", async (bot, q, data, user, ctx) => {
    const type = data.split(":")[1];
    const harga = cfg.HARGA_ROLE[type];
    const label = type === "illegal" ? "𖡛 ILEGAL" : "𖡛 LEGAL";

    const buttons = Object.keys(harga).map(role => [
        { text: `${ROLE_LABEL[role]} — Rp${harga[role].toLocaleString("id-ID")}`, callback_data: `order_role:${type}:${role}` }
    ]);
    buttons.push([{ text: "✕ Kembali", callback_data: "menu_order", style: "danger" }]);

    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 ORDER ROLE — ${label}</b>\n\n━━━━━━━━━━━━━━━━━━━━\nPilih role:`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } });
});

router.registerCallback("order_role", async (bot, q, data, user, ctx) => {
    const parts = data.split(":");
    const type = parts[1];
    const role = parts[2];
    const harga = cfg.HARGA_ROLE[type][role];
    const benefit = cfg.ROLE_BENEFIT[role];
    const label = type === "illegal" ? "𖡛 ILEGAL" : "𖡛 LEGAL";

    const orderId = makeOrderId();
    const orders = readOrders();
    orders[orderId] = {
        id: orderId, userId: user.id, username: user.username || "-",
        firstName: user.first_name || "User", type, role, harga,
        status: "pending", createdAt: Date.now()
    };
    writeOrders(orders);

    const caption =
        `<b>𖡛 PEMBAYARAN ROLE</b>\n\n━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Order ID</b>: <code>${orderId}</code>\n` +
        `𖡛 <b>Role</b>: ${ROLE_LABEL[role]}\n` +
        `𖡛 <b>Tipe Panel</b>: ${label}\n` +
        `𖡛 <b>Harga</b>: <b>Rp${harga.toLocaleString("id-ID")}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>𖡛 Benefit:</b>\n${benefit}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Scan QRIS, kirim bukti transfer ke bot ini.</i>`;

    try {
        await bot.sendPhoto(q.message.chat.id, cfg.FOTO.QRIS, { caption, parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
    } catch {
        await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
    }

    ctx.setState(user.id, "order_proof", { orderId });
});

router.registerMessage("order_proof", async (bot, msg, state, ctx) => {
    if (!msg.photo) {
        return bot.sendMessage(msg.chat.id, "<b>✕ Kirim foto bukti transfer!</b>", { parse_mode: "HTML" });
    }

    const orders = readOrders();
    const order = orders[state.orderId];
    if (!order) {
        ctx.clearState(msg.from.id);
        return bot.sendMessage(msg.chat.id, "<b>✕ Order expired.</b>", { parse_mode: "HTML" });
    }

    order.proofFileId = msg.photo[msg.photo.length - 1].file_id;
    order.status = "pending";
    order.proofSentAt = Date.now();
    writeOrders(orders);
    ctx.clearState(msg.from.id);

    const caption =
        `<b>𖡛 ORDER BARU</b>\n\n━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Order ID</b>: <code>${order.id}</code>\n` +
        `𖡛 <b>User</b>: <a href="tg://user?id=${order.userId}">${order.firstName}</a>\n` +
        `𖡛 <b>Role</b>: ${ROLE_LABEL[order.role]}\n` +
        `𖡛 <b>Harga</b>: <b>Rp${order.harga.toLocaleString("id-ID")}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;

    const kb = { inline_keyboard: [[
        { text: "✓ ACC", callback_data: `order_acc:${order.id}`, style: "success" },
        { text: "✕ TOLAK", callback_data: `order_rej:${order.id}`, style: "danger" }
    ]] };

    try {
        await bot.sendPhoto(cfg.OWNER_ID, order.proofFileId, { caption, parse_mode: "HTML", reply_markup: kb });
    } catch {
        await bot.sendMessage(cfg.OWNER_ID, caption, { parse_mode: "HTML", reply_markup: kb });
    }

    await bot.sendMessage(msg.chat.id, `<b>✅ Bukti terkirim ke owner.</b>`, { parse_mode: "HTML" });

    await notify.notifyInfo(bot, "ORDER BARU — PENDING", [
        { label: "𖡛 Order ID", value: order.id },
        { label: "𖡛 User", value: order.firstName },
        { label: "𖡛 User ID", value: String(order.userId) },
        { label: "𖡛 Role", value: ROLE_LABEL[order.role] },
        { label: "𖡛 Tipe", value: order.type === "illegal" ? "ILEGAL" : "LEGAL" },
        { label: "𖡛 Harga", value: "Rp" + order.harga.toLocaleString("id-ID") }
    ], `<b>𖡛 ORDER BARU</b>\n\nUser: ${order.firstName}\nRole: ${ROLE_LABEL[order.role]}\nHarga: <b>Rp${order.harga.toLocaleString("id-ID")}</b>`);
});

router.registerCallback("order_acc", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "✖️ Owner only!", show_alert: true });

    const orderId = data.split(":")[1];
    const orders = readOrders();
    const order = orders[orderId];
    if (!order) return bot.answerCallbackQuery(q.id, { text: "✕ Order ga ada", show_alert: true });

    order.status = "success";
    order.approvedAt = Date.now();
    order.approvedBy = q.from.id;
    writeOrders(orders);

    await bot.answerCallbackQuery(q.id, { text: "✓ Order di-ACC", show_alert: true });

    const panel = order.type === "illegal" ? cfg.PANEL_ILLEGAL : cfg.PANEL_LEGAL;
    const label = order.type === "illegal" ? "𖡛 ILEGAL" : "𖡛 LEGAL";
    const benefit = cfg.ROLE_BENEFIT[order.role];

    const userCaption =
        `<b>✓ ORDER SUCCESS</b>\n\n━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Order ID</b>: <code>${orderId}</code>\n` +
        `𖡛 <b>Role</b>: ${ROLE_LABEL[order.role]}\n` +
        `𖡛 <b>Tipe Panel</b>: ${label}\n` +
        `𖡛 <b>Harga</b>: Rp${order.harga.toLocaleString("id-ID")}\n` +
        `𖡛 <b>Tanggal</b>: ${new Date(order.approvedAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>𖡛 Benefit:</b>\n${benefit}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<b>⚠️ LANGKAH SELANJUTNYA:</b>\n` +
        `<b>1.</b> Join group di bawah\n` +
        `<b>2.</b> Tunggu admin add role lu\n` +
        `<b>3.</b> Setelah di-add, baru bisa Create Panel`;

    try {
        await bot.sendMessage(order.userId, userCaption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "𖡛 JOIN GROUP DULU", url: panel.GROUP_LINK }]] }
        });
    } catch {}

    await bot.sendMessage(q.message.chat.id,
        `<b>✓ Order ${orderId} di-ACC.</b>`,
        { parse_mode: "HTML" });

    await notify.notifySuccess(bot, "ORDER SUCCESS", [
        { label: "𖡛 Order ID", value: order.id },
        { label: "𖡛 User", value: order.firstName },
        { label: "𖡛 Role", value: ROLE_LABEL[order.role] },
        { label: "𖡛 Harga", value: "Rp" + order.harga.toLocaleString("id-ID") },
        { label: "𖡛 Waktu", value: new Date(order.approvedAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) }
    ], `<b>✓ ORDER SUCCESS</b>\n\nUser: ${order.firstName}\nRole: ${ROLE_LABEL[order.role]}\nHarga: <b>Rp${order.harga.toLocaleString("id-ID")}</b>`);
});

router.registerCallback("order_rej", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true });

    const orderId = data.split(":")[1];
    const orders = readOrders();
    const order = orders[orderId];
    if (!order) return bot.answerCallbackQuery(q.id, { text: "✕ Order ga ada", show_alert: true });

    order.status = "failed";
    order.rejectedAt = Date.now();
    writeOrders(orders);

    await bot.answerCallbackQuery(q.id, { text: "✕ Order ditolak", show_alert: true });

    await bot.sendMessage(order.userId,
        `<b>✕ ORDER FAILED</b>\n\nOrder ID: <code>${orderId}</code>`,
        { parse_mode: "HTML" }).catch(() => {});

    await bot.sendMessage(q.message.chat.id, `<b>✕ Order ${orderId} ditolak.</b>`, { parse_mode: "HTML" });

    await notify.notifyFailed(bot, "ORDER REJECTED", [
        { label: "𖡛 Order ID", value: order.id },
        { label: "𖡛 User", value: order.firstName },
        { label: "𖡛 Role", value: ROLE_LABEL[order.role] },
        { label: "𖡛 Harga", value: "Rp" + order.harga.toLocaleString("id-ID") }
    ], `<b>✕ ORDER REJECTED</b>\n\nUser: ${order.firstName}\nRole: ${ROLE_LABEL[order.role]}`);
});

module.exports = { readOrders, writeOrders, ROLE_LABEL };