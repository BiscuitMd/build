const router = require("./router");
const cfg = require("../config");

// ═══════════════════════════════════════════
// MENU USER PREMIUM
// ═══════════════════════════════════════════
router.registerCallback("menu_userpremium", async (bot, q, data, user, ctx) => {
    try {
        console.log("[USER PREMIUM] user:", user.id);

        if (!ctx || !ctx.db) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Internal error.</b>`, { parse_mode: "HTML" });
        }

        // ⚠️ Cek premium
        const isPremium = ctx.db.isPremium(user.id) || ctx.db.isOwner(user.id);
        if (!isPremium) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Menu ini cuma untuk PREMIUM!</b>\n\nBeli premium dulu di menu utama.`,
                { parse_mode: "HTML" });
        }

        const caption =
            `<b>▸ MENU PREMIUM</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Selamat datang, Premium User!\n` +
            `Pilih menu:\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        const kb = [
            [{ text: "▸ Add Credit", callback_data: "prem_addcredit", style: "success" }],
            [{ text: "▸ Create Redeem", callback_data: "prem_createredeem", style: "success" }],
            [{ text: "✕ Tutup", callback_data: "menu_close", style: "danger" }]
        ];

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) {
        console.log("[USER PREMIUM ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// ADD CREDIT via KIRIM ID
// ═══════════════════════════════════════════
router.registerCallback("prem_addcredit", async (bot, q, data, user, ctx) => {
    try {
        const isPremium = ctx.db.isPremium(user.id) || ctx.db.isOwner(user.id);
        if (!isPremium) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Premium only!</b>`, { parse_mode: "HTML" });
        }

        ctx.setState(user.id, "prem_addcredit_await", {});

        await bot.sendMessage(q.message.chat.id,
            `<b>▸ ADD CREDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>ID_TELEGRAM|JUMLAH_CREDIT</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>8938118595|50</code>\n\n` +
            `<i>Max credit per add: 500</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_userpremium" }]] } });
    } catch (e) {
        console.log("[PREM ADDCREDIT ERR]", e.message);
    }
});

router.registerMessage("prem_addcredit_await", async (bot, msg, state, ctx) => {
    try {
        const input = msg.text?.trim();
        if (!input) return;

        // Parse: ID|AMOUNT
        const parts = input.split("|").map(s => s.trim());
        if (parts.length < 2) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Format salah.</b>\n\nKirim: <code>ID_TELEGRAM|JUMLAH_CREDIT</code>`,
                { parse_mode: "HTML" });
        }

        const targetId = parts[0].replace(/[^0-9]/g, "");
        const amount = Math.min(parseInt(parts[1]) || 0, 500);

        if (!targetId || amount < 1) {
            return bot.sendMessage(msg.chat.id, `<b>✕ ID / jumlah tidak valid.</b>`, { parse_mode: "HTML" });
        }

        // Ambil credit user premium
        const premUser = ctx.db.getUser(msg.from.id);
        if (premUser.credit < amount) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Credit lu ga cukup!</b>\n\n` +
                `▸ Credit lu: <code>${premUser.credit}</code>\n` +
                `▸ Mau kirim: <code>${amount}</code>`,
                { parse_mode: "HTML" });
        }

        // Transfer credit
        ctx.db.saveUser(msg.from.id, { credit: premUser.credit - amount });
        ctx.db.addCredit(targetId, amount);

        ctx.clearState(msg.from.id);

        await bot.sendMessage(msg.chat.id,
            `<b>✓ CREDIT BERHASIL DIKIRIM</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Ke ID: <code>${targetId}</code>\n` +
            `▸ Jumlah: <code>${amount}</code> credit\n` +
            `▸ Sisa credit lu: <code>${ctx.db.getUser(msg.from.id).credit}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "▸ Kirim Lagi", callback_data: "prem_addcredit", style: "success" }],
                        [{ text: "✕ Tutup", callback_data: "menu_close", style: "danger" }]
                    ]
                }
            });

        // Notif ke target
        try {
            await bot.sendMessage(targetId,
                `<b>▸ CREDIT MASUK</b>\n\n▸ +<code>${amount}</code> credit dari premium user!`,
                { parse_mode: "HTML" }).catch(() => {});
        } catch {}

        console.log("[PREM ADDCREDIT] sent", amount, "to", targetId);
    } catch (e) {
        console.log("[PREM ADDCREDIT AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// CREATE REDEEM (premium)
// ═══════════════════════════════════════════
router.registerCallback("prem_createredeem", async (bot, q, data, user, ctx) => {
    try {
        const isPremium = ctx.db.isPremium(user.id) || ctx.db.isOwner(user.id);
        if (!isPremium) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Premium only!</b>`, { parse_mode: "HTML" });
        }

        ctx.setState(user.id, "prem_redeem_name", {});

        await bot.sendMessage(q.message.chat.id,
            `<b>▸ CREATE REDEEM</b>\n\nKirim nama code redeem:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_userpremium", style: "danger" }]] } });
    } catch (e) {
        console.log("[PREM REDEEM ERR]", e.message);
    }
});

router.registerMessage("prem_redeem_name", async (bot, msg, state, ctx) => {
    const name = msg.text?.trim().toUpperCase();
    if (!name) return;

    ctx.setState(msg.from.id, "prem_redeem_credit", { name });
    await bot.sendMessage(msg.chat.id, `<b>Berapa credit? (max 500)</b>`, { parse_mode: "HTML" });
});

router.registerMessage("prem_redeem_credit", async (bot, msg, state, ctx) => {
    const credit = Math.min(parseInt(msg.text) || 0, 500);
    if (credit < 1) return bot.sendMessage(msg.chat.id, `<b>✕ Credit invalid.</b>`, { parse_mode: "HTML" });

    ctx.setState(msg.from.id, "prem_redeem_limit", { name: state.name, credit });
    await bot.sendMessage(msg.chat.id, `<b>Berapa orang yang bisa claim?</b>`, { parse_mode: "HTML" });
});

router.registerMessage("prem_redeem_limit", async (bot, msg, state, ctx) => {
    const limit = parseInt(msg.text) || 1;

    const redeems = ctx.db.read("redeem");
    redeems[state.name] = {
        name: state.name,
        credit: state.credit,
        limit,
        claimed: [],
        createdAt: Date.now(),
        active: true,
        creator: msg.from.id
    };
    ctx.db.write("redeem", redeems);

    ctx.clearState(msg.from.id);

    const users = ctx.db.allUsers();
    let sent = 0;
    for (const uid in users) {
        try {
            await bot.sendMessage(uid,
                `<b>▸ CODE REDEEM BARU</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Code: <code>${state.name}</code>\n` +
                `▸ Credit: <code>${state.credit}</code>\n` +
                `▸ Limit: ${limit} orang\n` +
                `━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "▸ Claim", callback_data: `redeem_claim:${state.name}` }]] } });
            sent++;
        } catch {}
    }

    await bot.sendMessage(msg.chat.id,
        `<b>✓ Redeem dibuat & dikirim ke ${sent} user.</b>`,
        { parse_mode: "HTML" });
});