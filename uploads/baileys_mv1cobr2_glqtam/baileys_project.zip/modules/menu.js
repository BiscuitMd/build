const router = require("./router");
const cfg = require("../config");

// ═══════════════════════════════════════════
// SAFE EDIT / SEND HELPER
// ═══════════════════════════════════════════
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msgId,
            parse_mode: "HTML",
            ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch (e2) {
                console.log("[SAFE EDIT] send fail:", e2.message.slice(0, 100));
                return null;
            }
        }
        console.log("[SAFE EDIT] fail:", msg.slice(0, 120));
        return null;
    }
}

async function sendPhoto(bot, chatId, url, caption, keyboard, q = null) {
    const replyMarkup = { inline_keyboard: keyboard };

    if (q && q.message) {
        const msgId = q.message.message_id;
        const hasPhoto = !!q.message.photo;

        if (hasPhoto) {
            try {
                await bot.editMessageCaption(caption, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    reply_markup: replyMarkup
                });
                return { ok: true, method: "editCaption" };
            } catch (e) {
                const m = e.message || "";
                if (m.includes("message is not modified")) return { ok: true, method: "noChange" };
                try {
                    await bot.editMessageReplyMarkup(replyMarkup, {
                        chat_id: chatId,
                        message_id: msgId
                    });
                    return { ok: true, method: "editMarkup" };
                } catch (e2) {
                    console.log("[SEND PHOTO] editCaption fail:", m.slice(0, 100));
                }
            }
        } else {
            try {
                await bot.editMessageMedia({
                    type: "photo",
                    media: url,
                    caption: caption,
                    parse_mode: "HTML"
                }, {
                    chat_id: chatId,
                    message_id: msgId,
                    reply_markup: replyMarkup
                });
                return { ok: true, method: "editMedia" };
            } catch (e) {
                console.log("[SEND PHOTO] editMedia fail:", e.message.slice(0, 100));
                await safeEdit(bot, chatId, msgId, caption, { reply_markup: replyMarkup });
                return { ok: true, method: "editText" };
            }
        }
    }

    try {
        await bot.sendPhoto(chatId, url, {
            caption,
            parse_mode: "HTML",
            reply_markup: replyMarkup
        });
        return { ok: true, method: "sendPhoto" };
    } catch {
        try {
            await bot.sendMessage(chatId, caption, {
                parse_mode: "HTML",
                reply_markup: replyMarkup
            });
            return { ok: true, method: "sendMessage" };
        } catch (e) {
            console.log("[SEND PHOTO] fail total:", e.message.slice(0, 100));
            return { ok: false, error: e.message };
        }
    }
}

// ═══════════════════════════════════════════
// MENU: THANKS TO
// ═══════════════════════════════════════════
router.registerCallback("menu_tqto", async (bot, q) => {
    const caption = `<b>𖡛 THANKS TO</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Developer</b>: <a href="https://t.me/biscuitMD">@biscuitMD</a>\n` +
        `𖡛 <b>Bot</b>: 𖡛 MULTI FUNGSI BOT 𖡛\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Klik username di atas untuk chat developer.</i>`;
    const keyboard = [
        [{ text: "𖡛 Chat Developer", url: "https://t.me/biscuitMD?text=Halow%20kak%20saya%20mau%20tanya%20tentang%20fitur%20bot%20nya%20kak", style: "success"  }],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger"  }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.TQTO, caption, keyboard, q);
});

// ═══════════════════════════════════════════
// MENU: CEK ERROR
// ═══════════════════════════════════════════
router.registerCallback("menu_cekerror", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 CEK SYNTAX ERROR</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Kirim file .txt / .js berisi function yang mau di-cek.</i>\n` +
        `Atau ketik langsung di chat.\n\n` +
        `🪙 Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
    ctx.setState(user.id, "syntax_await", {});
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.CEKERROR, caption, [[
        { text: "✕ Batal", callback_data: "menu_back", style: "danger" }
    ]], q);
});

// ═══════════════════════════════════════════
// MENU: DEPLOY
// ═══════════════════════════════════════════
router.registerCallback("menu_deploy", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 DEPLOY HTML</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Kirim file .html / .zip yang mau di-deploy.</i>\n\n` +
        `Setelah terkirim, lu bakal pilih platform:\n` +
        `• <b>Vercel</b> — hosting publik\n` +
        `• <b>Netflix</b> — hosting privat\n\n` +
        `🪙 Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
    ctx.setState(user.id, "deploy_await", {});
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.DEPLOY, caption, [[
        { text: "✕ Batal", callback_data: "menu_back", style: "danger" }
    ]], q);
});

// ═══════════════════════════════════════════
// MENU: TOOLS — ADA TEXT STYLER
// ═══════════════════════════════════════════
router.registerCallback("menu_tools", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 MENU TOOLS</b>\n\n━━━━━━━━━━━━━━━━━━━━\nPilih tool yang mau lu pakai:\n𖡛 <b>GRATIS</b> — no credit\n━━━━━━━━━━━━━━━━━━━━`;
    const keyboard = [
        [
            { text: "𖡛 Cek Cuaca", callback_data: "tool_cuaca", style: "success" },
            { text: "𖡛 Jam Sholat", callback_data: "tool_sholat", style: "success" }
        ],
        [
            { text: "𖡛 Downloader", callback_data: "tool_downloader", style: "primary" },
            { text: "𖡛 Brat Sticker", callback_data: "tool_brat", style: "success" }
        ],
        [
            { text: "𖡛 HD Upscale", callback_data: "tool_hd", style: "success" },
            { text: "𖡛 Cek Ping Web", callback_data: "tool_ping", style: "success" }
        ],
        [
            { text: "𖡛 Spam NGL", callback_data: "tool_ngl", style: "success" },
            { text: "𖡛 Anime AI", callback_data: "tool_anime", style: "success" }
        ],
        [
            { text: "𖡛 Image To Link", callback_data: "menu_filetolink", style: "success" },
            { text: "▸ Text Styler", callback_data: "tool_textstyler", style: "success" }
        ],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.TOOLS || cfg.FOTO.MENU, caption, keyboard, q);
});

// ═══════════════════════════════════════════
// MENU: MUSIC
// ═══════════════════════════════════════════
router.registerCallback("menu_music", async (bot, q, data, user, ctx) => {
    const caption = `<b>𖡛 MUSIC SPOTIFY</b>\n\n━━━━━━━━━━━━━━━━━━━━\nCari lagu & lirik dari Spotify.\n\n𖡛 <b>GRATIS</b> — no credit\n━━━━━━━━━━━━━━━━━━━━`;
    const keyboard = [
        [{ text: "𖡛 Search Lagu", callback_data: "music_search", style: "success" }],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.MUSIC || cfg.FOTO.MENU, caption, keyboard, q);
});

// ═══════════════════════════════════════════
// MENU: GUARD (delegasi)
// ═══════════════════════════════════════════
router.registerCallback("menu_guard", async (bot, q, data, user, ctx) => {
    const handlers = require("./router.js").handlers;
    if (handlers["menu_guard_internal"]) return handlers["menu_guard_internal"](bot, q, data, user, ctx);
    if (handlers["menu_guard"]) return handlers["menu_guard"](bot, q, data, user, ctx);
});

// ═══════════════════════════════════════════
// MENU: PANEL (delegasi)
// ═══════════════════════════════════════════
router.registerCallback("menu_panel", async (bot, q, data, user, ctx) => {
    const handlers = require("./router.js").handlers;
    if (handlers["menu_panel_internal"]) return handlers["menu_panel_internal"](bot, q, data, user, ctx);
    if (handlers["menu_panel"]) return handlers["menu_panel"](bot, q, data, user, ctx);
});

// ═══════════════════════════════════════════
// MENU: DEVELOPER (owner only)
// ═══════════════════════════════════════════
router.registerCallback("menu_developer", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Lu bukan owner bot!", show_alert: true });
    }
    const caption = `<b>𖡛 MENU DEVELOPER</b>\n\n━━━━━━━━━━━━━━━━━━━━\nSelamat datang owner 𖡛\nPilih command di bawah ini.\n━━━━━━━━━━━━━━━━━━━━`;
    const keyboard = [
        [{ text: "𖡛 Add Credit", callback_data: "dev_addcredit", style: "success" }, { text: "𖡛 Add Premium", callback_data: "dev_addpremium", style: "success" }],
        [{ text: "𖡛 Add Bot", callback_data: "dev_addbot", style: "primary" }, { text: "𖡛 Create Redeem", callback_data: "dev_createredeem", style: "success" }],
        [{ text: "𖡛 Ban User", callback_data: "dev_banuser", style: "primary" }, { text: "𖡛 Unban User", callback_data: "dev_unbanuser", style: "success" }],
        [{ text: "𖡛 Add Fitur", callback_data: "dev_addfitur", style: "primary" }, { text: "𖡛 Del Fitur", callback_data: "dev_delfitur", style: "success" }],
        [{ text: "𖡛 Del Credit", callback_data: "dev_delcredit", style: "primary" }, { text: "𖡛 Del Premium", callback_data: "dev_delpremium", style: "success" }],
        [{ text: "𖡛 Del Redeem", callback_data: "dev_delredeem", style: "primary" }, { text: "𖡛 Del Bot", callback_data: "dev_delbot", style: "success" }],
        [{ text: "𖡛 Broadcast", callback_data: "dev_broadcast", style: "primary" }],
        [{ text: "𖡛 Add Script", callback_data: "dev_addscript", style: "success" }],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.DEVELOPER, caption, keyboard, q);
});

// ═══════════════════════════════════════════
// MENU: PREMIUM
// ═══════════════════════════════════════════
router.registerCallback("menu_premium", async (bot, q, data, user, ctx) => {
    if (!user.premium && !ctx.db.isOwner(user.id)) {
        return bot.answerCallbackQuery(q.id, { text: "✕ Menu ini hanya untuk PREMIUM!", show_alert: true });
    }
    const caption = `<b>𖡛 MENU PREMIUM</b>\n\n━━━━━━━━━━━━━━━━━━━━\nSelamat datang premium user 𖡛\n━━━━━━━━━━━━━━━━━━━━`;
    const keyboard = [
        [{ text: "𖡛 Add Credit (max 500)", callback_data: "prem_addcredit" }, { text: "𖡛 Create Redeem", callback_data: "prem_createredeem" }],
        [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
    ];
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.PREMIUM_MENU, caption, keyboard, q);
});

console.log("[MENU] module loaded");