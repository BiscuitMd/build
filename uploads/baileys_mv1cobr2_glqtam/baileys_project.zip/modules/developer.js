const router = require("./router");
const cfg = require("../config");

function isOwner(ctx, id) { return ctx.db.isOwner(id); }

router.registerCallback("dev_addcredit", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_addcredit_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 ADD CREDIT</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_addcredit_id", async (bot, msg, state, ctx) => {
    ctx.setState(msg.from.id, "dev_addcredit_amount", { uid: msg.text.trim() });
    await bot.sendMessage(msg.chat.id, `<b>Berapa credit? (max 500)</b>`, { parse_mode: "HTML" });
});
router.registerMessage("dev_addcredit_amount", async (bot, msg, state, ctx) => {
    const amt = Math.min(parseInt(msg.text) || 0, 500);
    ctx.db.addCredit(state.uid, amt);
    await bot.sendMessage(msg.chat.id, `<b>✅ +${amt} credit → ${state.uid}</b>`, { parse_mode: "HTML" });
    await bot.sendMessage(state.uid, `<b>🪙 Credit +${amt} dari owner!</b>`, { parse_mode: "HTML" }).catch(() => {});
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_addscript", async (bot, q, data, user, ctx) => {
    if (!ctx.db.isOwner(q.from.id)) return;
    ctx.setState(q.from.id, "dev_addscript_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 ADD SCRIPT</b>\n\nKirim file <b>.zip</b> script:\n\n` +
        `<i>Setelah file dikirim, lu bakal diminta nama + harga.</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back" }]] } });
});

router.registerMessage("dev_addscript_await", async (bot, msg, state, ctx) => {
    if (!ctx.db.isOwner(msg.from.id)) return;

    if (!msg.document) {
        return bot.sendMessage(msg.chat.id, `<b>✕ Kirim file .zip</b>`, { parse_mode: "HTML" });
    }

    const fname = msg.document.file_name || "script.zip";
    if (!fname.endsWith(".zip")) {
        return bot.sendMessage(msg.chat.id, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
    }

    ctx.setState(msg.from.id, "dev_addscript_name", {
        fileId: msg.document.file_id,
        fileName: fname,
        fileSize: msg.document.file_size
    });

    await bot.sendMessage(msg.chat.id,
        `<b>✓ FILE DITERIMA</b>\n\n𖡛 <code>${fname}</code>\n\n<b>Kirim nama script:</b>`,
        { parse_mode: "HTML" });
});

router.registerMessage("dev_addscript_name", async (bot, msg, state, ctx) => {
    if (!ctx.db.isOwner(msg.from.id)) return;
    const name = msg.text?.trim();
    if (!name) return;

    ctx.setState(msg.from.id, "dev_addscript_price", { ...state, name });
    await bot.sendMessage(msg.chat.id, `<b>Kirim harga script (angka):</b>`, { parse_mode: "HTML" });
});

router.registerMessage("dev_addscript_price", async (bot, msg, state, ctx) => {
    if (!ctx.db.isOwner(msg.from.id)) return;
    const harga = parseInt(msg.text.replace(/[^0-9]/g, ""));
    if (!harga || harga < 1) return bot.sendMessage(msg.chat.id, `<b>✕ Harga invalid.</b>`, { parse_mode: "HTML" });

    const store = ctx.db.read("scripts");
    const id = "SCR" + Date.now().toString(36).toUpperCase();
    store[id] = {
        id, name: state.name, harga,
        fileId: state.fileId, fileName: state.fileName, fileSize: state.fileSize,
        createdAt: Date.now(), createdBy: msg.from.id, sold: 0
    };
    ctx.db.write("scripts", store);
    ctx.clearState(msg.from.id);

    await bot.sendMessage(msg.chat.id,
        `<b>✓ SCRIPT DITAMBAHKAN</b>\n\n` +
        `𖡛 <code>${id}</code>\n` +
        `𖡛 ${state.name}\n` +
        `𖡛 Rp${harga.toLocaleString("id-ID")}`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[
            { text: "𖡛 Lihat Store", callback_data: "menu_scriptstore" }
        ]] } });
});

router.registerCallback("dev_delcredit", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_delcredit_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 DEL CREDIT</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_delcredit_id", async (bot, msg, state, ctx) => {
    ctx.db.delCredit(msg.text.trim());
    await bot.sendMessage(msg.chat.id, `<b>✅ Credit ${msg.text.trim()} → 0</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_addpremium", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_addpremium_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 ADD PREMIUM</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_addpremium_id", async (bot, msg, state, ctx) => {
    const uid = msg.text.trim();
    ctx.db.setPremium(uid, true);
    await bot.sendMessage(msg.chat.id, `<b>✅ ${uid} → PREMIUM</b>`, { parse_mode: "HTML" });
    await bot.sendMessage(uid, `<b>𖡛 Lu sekarang PREMIUM!</b>`, { parse_mode: "HTML" }).catch(() => {});
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_delpremium", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_delpremium_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 DEL PREMIUM</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_delpremium_id", async (bot, msg, state, ctx) => {
    const uid = msg.text.trim();
    ctx.db.setPremium(uid, false);
    await bot.sendMessage(msg.chat.id, `<b>✓ ${uid} 𖡛 FREE</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_banuser", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_ban_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>✕ BAN USER</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_ban_id", async (bot, msg, state, ctx) => {
    ctx.setState(msg.from.id, "dev_ban_durasi", { uid: msg.text.trim() });
    await bot.sendMessage(msg.chat.id, `<b>Pilih durasi ban:</b>`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [
            [{ text: "𖡛 1 Jam", callback_data: "dev_ban_set:1jam" }, { text: "𖡛 1 Hari", callback_data: "dev_ban_set:1hari" }],
            [{ text: "𖡛 1 Bulan", callback_data: "dev_ban_set:1bulan" }, { text: "𖡛 1 Tahun", callback_data: "dev_ban_set:1tahun" }]
        ] }
    });
});
router.registerCallback("dev_ban_set", async (bot, q, data, user, ctx) => {
    const st = ctx.getState(q.from.id);
    if (!st || !st.uid) return bot.sendMessage(q.message.chat.id, "✕ Sesi habis.", { parse_mode: "HTML" });
    const key = data.split(":")[1];
    ctx.db.banUser(st.uid, cfg.BAN_DURASI[key]);
    await bot.sendMessage(q.message.chat.id, `<b>✅ ${st.uid} dibanned (${key})</b>`, { parse_mode: "HTML" });
    await bot.sendMessage(st.uid, `<b>✕ LU DI BANNED ${key.toUpperCase()}</b>`, { parse_mode: "HTML" }).catch(() => {});
    ctx.clearState(q.from.id);
});

router.registerCallback("dev_unbanuser", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_unban_id", {});
    await bot.sendMessage(q.message.chat.id, `<b>✓ UNBAN USER</b>\n\nKirim ID user:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_unban_id", async (bot, msg, state, ctx) => {
    const uid = msg.text.trim();
    ctx.db.unbanUser(uid);
    await bot.sendMessage(msg.chat.id, `<b>✓ ${uid} di-unban</b>`, { parse_mode: "HTML" });
    await bot.sendMessage(uid, `<b>✓ Lu udah di-unban.</b>`, { parse_mode: "HTML" }).catch(() => {});
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_addbot", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_addbot_token", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 ADD BOT</b>\n\nKirim token bot Telegram baru:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_addbot_token", async (bot, msg, state, ctx) => {
    const token = msg.text.trim();
    const TelegramBot = require("node-telegram-bot-api");
    try {
        const nb = new TelegramBot(token, { polling: true });
        const info = await nb.getMe();
        const settings = ctx.db.read("settings");
        settings.bots = settings.bots || {};
        settings.bots[info.id] = { token, username: info.username, addedAt: Date.now() };
        ctx.db.write("settings", settings);
        nb.on("message", async (m) => {
            if (m.text === "/start") nb.sendMessage(m.chat.id, `<b>𖡛 Bot aktif. Gunakan bot utama untuk fitur lengkap.</b>`, { parse_mode: "HTML" });
        });
        await bot.sendMessage(msg.chat.id, `<b>✓ Bot @${info.username} aktif!</b>`, { parse_mode: "HTML" });
    } catch (e) {
        await bot.sendMessage(msg.chat.id, `<b>✕ Token invalid: <code>${e.message}</code></b>`, { parse_mode: "HTML" });
    }
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_delbot", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_delbot_token", {});
    await bot.sendMessage(q.message.chat.id, `<b>✕ DEL BOT</b>\n\nKirim token bot yang mau dihapus:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_delbot_token", async (bot, msg, state, ctx) => {
    const token = msg.text.trim();
    const settings = ctx.db.read("settings");
    const bots = settings.bots || {};
    for (const id in bots) {
        if (bots[id].token === token) {
            delete bots[id];
            ctx.db.write("settings", settings);
            await bot.sendMessage(msg.chat.id, `<b>✓ Bot dihapus dari list.</b>`, { parse_mode: "HTML" });
            ctx.clearState(msg.from.id);
            return;
        }
    }
    await bot.sendMessage(msg.chat.id, `<b>✖️ Token tidak ditemukan.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_createredeem", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_redeem_name", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 CREATE REDEEM</b>\n\nKirim nama code redeem:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_redeem_name", async (bot, msg, state, ctx) => {
    ctx.setState(msg.from.id, "dev_redeem_credit", { name: msg.text.trim().toUpperCase() });
    await bot.sendMessage(msg.chat.id, `<b>Berapa credit? (max 500)</b>`, { parse_mode: "HTML" });
});
router.registerMessage("dev_redeem_credit", async (bot, msg, state, ctx) => {
    const credit = Math.min(parseInt(msg.text) || 0, 500);
    ctx.setState(msg.from.id, "dev_redeem_limit", { name: state.name, credit });
    await bot.sendMessage(msg.chat.id, `<b>Berapa orang yang bisa claim?</b>`, { parse_mode: "HTML" });
});
router.registerMessage("dev_redeem_limit", async (bot, msg, state, ctx) => {
    const limit = parseInt(msg.text) || 1;
    const redeems = ctx.db.read("redeem");
    redeems[state.name] = { name: state.name, credit: state.credit, limit, claimed: [], createdAt: Date.now(), active: true };
    ctx.db.write("redeem", redeems);
    const users = ctx.db.allUsers();
    let sent = 0;
    for (const uid in users) {
        try {
            await bot.sendMessage(uid,
                `<b>𖡛 CODE REDEEM BARU!</b>\n\n━━━━━━━━━━━━━━━━━━━━\n𖡛 Code: <code>${state.name}</code>\n🪙 Credit: ${state.credit}\n𖡛 Limit: ${limit} orang\n━━━━━━━━━━━━━━━━━━━━`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Claim", callback_data: `redeem_claim:${state.name}` }]] } });
            sent++;
        } catch {}
    }
    await bot.sendMessage(msg.chat.id, `<b>✓ Redeem dibuat & di-broadcast ke ${sent} user.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("redeem_claim", async (bot, q, data, user, ctx) => {
    const name = data.split(":")[1];
    const redeems = ctx.db.read("redeem");
    const r = redeems[name];
    if (!r || !r.active) return bot.answerCallbackQuery(q.id, { text: "✕ Redeem expired!", show_alert: true });
    if (r.claimed.includes(q.from.id)) return bot.answerCallbackQuery(q.id, { text: "✕ Lu udah claim!", show_alert: true });
    if (r.claimed.length >= r.limit) {
        r.active = false;
        ctx.db.write("redeem", redeems);
        return bot.answerCallbackQuery(q.id, { text: "✕ Redeem udah expired!", show_alert: true });
    }
    r.claimed.push(q.from.id);
    if (r.claimed.length >= r.limit) r.active = false;
    ctx.db.write("redeem", redeems);
    ctx.db.addCredit(q.from.id, r.credit);
    await bot.answerCallbackQuery(q.id, { text: `✓ +${r.credit} credit masuk!`, show_alert: true });
});

router.registerCallback("dev_delredeem", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_delredeem_name", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 DEL REDEEM</b>\n\nKirim nama code:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_delredeem_name", async (bot, msg, state, ctx) => {
    const redeems = ctx.db.read("redeem");
    const name = msg.text.trim().toUpperCase();
    if (redeems[name]) { redeems[name].active = false; ctx.db.write("redeem", redeems); }
    await bot.sendMessage(msg.chat.id, `<b>✓ Redeem ${name} di-expired-kan.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_broadcast", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_broadcast_msg", {});
    await bot.sendPhoto(q.message.chat.id, cfg.FOTO.BROADCAST, {
        caption: `<b>𖡛 BROADCAST</b>\n\nKirim pesan yang mau di-broadcast:`,
        parse_mode: "HTML"
    });
});
router.registerMessage("dev_broadcast_msg", async (bot, msg, state, ctx) => {
    const users = ctx.db.allUsers();
    let sent = 0;
    for (const uid in users) {
        try {
            if (msg.photo) {
                await bot.sendPhoto(uid, msg.photo[msg.photo.length - 1].file_id, { caption: msg.caption || "", parse_mode: "HTML" });
            } else {
                await bot.sendMessage(uid, `<b>𖡛 BROADCAST</b>\n\n${msg.text}`, { parse_mode: "HTML" });
            }
            sent++;
        } catch {}
    }
    await bot.sendMessage(msg.chat.id, `<b>✅ Broadcast terkirim ke ${sent} user.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_addfitur", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_addfitur_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 ADD FITUR</b>\n\nMau tambahin fitur bos? Kirim aja file/txt/code nya nanti saya akan otomatis add.\n\nKirim nama menu dulu ya:`,
        { parse_mode: "HTML" });
});
router.registerMessage("dev_addfitur_await", async (bot, msg, state, ctx) => {
    const settings = ctx.db.read("settings");
    settings.custom_features = settings.custom_features || {};
    const nama = msg.text.trim();
    settings.custom_features[nama] = { name: nama, addedAt: Date.now() };
    ctx.db.write("settings", settings);
    await bot.sendMessage(msg.chat.id, `<b>✓ Fitur "${nama}" ditambahkan ke list.</b>`, { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);
});

router.registerCallback("dev_delfitur", async (bot, q, data, user, ctx) => {
    if (!isOwner(ctx, q.from.id)) return;
    ctx.setState(q.from.id, "dev_delfitur_await", {});
    await bot.sendMessage(q.message.chat.id, `<b>𖡛 DEL FITUR</b>\n\nKirim nama fitur yang mau dihapus:`, { parse_mode: "HTML" });
});
router.registerMessage("dev_delfitur_await", async (bot, msg, state, ctx) => {
    const settings = ctx.db.read("settings");
    const nama = msg.text.trim();
    if (settings.custom_features && settings.custom_features[nama]) {
        delete settings.custom_features[nama];
        ctx.db.write("settings", settings);
        await bot.sendMessage(msg.chat.id, `<b>✓ Fitur "${nama}" dihapus permanen.</b>`, { parse_mode: "HTML" });
    } else {
        await bot.sendMessage(msg.chat.id, `<b>✕ Fitur tidak ditemukan.</b>`, { parse_mode: "HTML" });
    }
    ctx.clearState(msg.from.id);
});