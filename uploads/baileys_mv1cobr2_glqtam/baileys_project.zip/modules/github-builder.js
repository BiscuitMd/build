// ═══════════════════════════════════════════
// GITHUB BUILDER — Helper (Fixed & Robust)
// ═══════════════════════════════════════════

const axios = require("axios");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const cfg = require("../config");

const GH = cfg.GITHUB || {};
const API = "https://api.github.com";
const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

const JOBS_FILE = path.join(__dirname, "..", "database", "buildjobs.json");
if (!fs.existsSync(JOBS_FILE)) fs.writeFileSync(JOBS_FILE, "{}", "utf8");

function readJobs() {
    try { return JSON.parse(fs.readFileSync(JOBS_FILE, "utf8")); }
    catch { return {}; }
}
function writeJobs(d) {
    fs.writeFileSync(JOBS_FILE, JSON.stringify(d, null, 2), "utf8");
}

function newJobId(prefix = "job") {
    return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(3).toString("hex")}`;
}

function ghHeaders(extra = {}) {
    return {
        Authorization: `token ${GH.TOKEN}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "SpartaX-Bot",
        ...extra
    };
}

function validateConfig() {
    if (!GH.TOKEN || GH.TOKEN.startsWith("ISI_")) throw new Error("GITHUB.TOKEN belum di-set di config.js");
    if (!GH.USERNAME || GH.USERNAME.startsWith("ISI_")) throw new Error("GITHUB.USERNAME belum di-set di config.js");
    if (!GH.REPO || GH.REPO.startsWith("ISI_")) throw new Error("GITHUB.REPO belum di-set di config.js");
}

// ═══════════════════════════════════════════
// UPLOAD FILE KE REPO (create/update)
// ═══════════════════════════════════════════
async function putFile(repoPath, contentBase64, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${repoPath}`;

    console.log("[GH putFile] path:", repoPath, "size(b64):", contentBase64.length);

    let sha = null;
    try {
        const cur = await axios.get(url, {
            headers: ghHeaders(),
            params: { ref: b },
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (cur.status === 200 && cur.data && cur.data.sha) {
            sha = cur.data.sha;
            console.log("[GH putFile] existing sha:", sha);
        }
    } catch (e) {
        console.log("[GH putFile] sha check skip:", e.message);
    }

    const body = {
        message: message || `upload ${repoPath}`,
        content: contentBase64,
        branch: b
    };
    if (sha) body.sha = sha;

    const res = await axios.put(url, body, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });

    console.log("[GH putFile] uploaded, status:", res.status);
    return res.data;
}

// ═══════════════════════════════════════════
// UPLOAD VIA GIT BLOBS API (buat file gede >20MB)
// ═══════════════════════════════════════════
async function uploadFile(repoPath, buffer, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";

    // Step 1: create blob
    const blobUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/blobs`;
    const blobRes = await axios.post(blobUrl, {
        content: buffer.toString("base64"),
        encoding: "base64"
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });

    const blobSha = blobRes.data.sha;
    console.log("[GH uploadFile] blob sha:", blobSha);

    // Step 2: get ref
    const refUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/ref/heads/${b}`;
    const refRes = await axios.get(refUrl, { headers: ghHeaders(), timeout: 30000 });
    const parentSha = refRes.data.object.sha;

    // Step 3: get commit
    const commitUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/commits/${parentSha}`;
    const commitRes = await axios.get(commitUrl, { headers: ghHeaders(), timeout: 30000 });
    const baseTreeSha = commitRes.data.tree.sha;

    // Step 4: create tree
    const treeUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/trees`;
    const treeRes = await axios.post(treeUrl, {
        base_tree: baseTreeSha,
        tree: [{
            path: repoPath,
            mode: "100644",
            type: "blob",
            sha: blobSha
        }]
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        timeout: 60000
    });

    // Step 5: create commit
    const newCommitUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/commits`;
    const newCommitRes = await axios.post(newCommitUrl, {
        message: message || `upload ${repoPath}`,
        tree: treeRes.data.sha,
        parents: [parentSha]
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        timeout: 60000
    });

    // Step 6: update ref
    const updateRefUrl = `${API}/repos/${GH.USERNAME}/${GH.REPO}/git/refs/heads/${b}`;
    await axios.patch(updateRefUrl, {
        sha: newCommitRes.data.sha
    }, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        timeout: 60000
    });

    console.log("[GH uploadFile] done, commit:", newCommitRes.data.sha);
    return newCommitRes.data;
}

// ═══════════════════════════════════════════
// HAPUS FILE DARI REPO
// ═══════════════════════════════════════════
async function deleteFile(repoPath, message, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${repoPath}`;

    let sha;
    try {
        const cur = await axios.get(url, {
            headers: ghHeaders(),
            params: { ref: b },
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (cur.status !== 200 || !cur.data || !cur.data.sha) return null;
        sha = cur.data.sha;
    } catch {
        return null;
    }

    const res = await axios.delete(url, {
        headers: ghHeaders({ "Content-Type": "application/json" }),
        data: { message: message || `delete ${repoPath}`, sha, branch: b },
        timeout: 60000
    });
    return res.data;
}

// ═══════════════════════════════════════════
// LIST FILES DALAM FOLDER
// ═══════════════════════════════════════════
async function listFiles(folderPath, branch = null) {
    validateConfig();
    const b = branch || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/contents/${folderPath ? folderPath : ""}`;
    try {
        const res = await axios.get(url, {
            headers: ghHeaders(),
            params: { ref: b },
            timeout: 30000
        });
        return res.data;
    } catch {
        return [];
    }
}

// ═══════════════════════════════════════════
// TRIGGER WORKFLOW DISPATCH
// ═══════════════════════════════════════════
async function triggerWorkflow(workflowFile, inputs = {}, ref = null) {
    validateConfig();
    const r = ref || GH.BRANCH || "main";
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/workflows/${workflowFile}/dispatches`;

    console.log("[GH triggerWorkflow]", workflowFile, "inputs:", JSON.stringify(inputs));

    try {
        const res = await axios.post(url, { ref: r, inputs }, {
            headers: ghHeaders({ "Content-Type": "application/json" }),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 204) {
            return { ok: true };
        }

        return {
            ok: false,
            error: `HTTP ${res.status}: ${JSON.stringify(res.data).slice(0, 200)}`
        };
    } catch (e) {
        const msg = e.response?.data?.message || e.message;
        const details = e.response?.data?.errors ? JSON.stringify(e.response.data.errors) : "";
        console.log("[GH triggerWorkflow] fail:", msg, details);
        return { ok: false, error: `${msg} ${details}`.trim() };
    }
}

// ═══════════════════════════════════════════
// DAPETIN RUN ID TERBARU
// ═══════════════════════════════════════════
async function getLatestRun(workflowFile, afterTimestamp = 0) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/workflows/${workflowFile}/runs`;
    try {
        const res = await axios.get(url, {
            headers: ghHeaders(),
            params: { per_page: 10 },
            timeout: 30000
        });
        const runs = res.data.workflow_runs || [];
        console.log("[GH getLatestRun] total runs:", runs.length, "after:", afterTimestamp);

        for (const r of runs) {
            const created = new Date(r.created_at).getTime();
            if (created >= afterTimestamp - 10000) {
                console.log("[GH getLatestRun] found run:", r.id, "created:", r.created_at);
                return r;
            }
        }
        return null;
    } catch (e) {
        console.log("[GH getLatestRun] err:", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// DAPETIN STATUS RUN
// ═══════════════════════════════════════════
async function getRunStatus(runId) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}`;
    try {
        const res = await axios.get(url, { headers: ghHeaders(), timeout: 30000 });
        return res.data;
    } catch {
        return null;
    }
}

// ═══════════════════════════════════════════
// DAPETIN JOBS DARI RUN
// ═══════════════════════════════════════════
async function getRunJobs(runId) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/jobs`;
    try {
        const res = await axios.get(url, { headers: ghHeaders(), timeout: 30000 });
        return res.data.jobs || [];
    } catch {
        return [];
    }
}

// ═══════════════════════════════════════════
// DAPETIN ARTIFACT DARI RUN
// ═══════════════════════════════════════════
async function getRunArtifacts(runId) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/artifacts`;
    try {
        const res = await axios.get(url, { headers: ghHeaders(), timeout: 30000 });
        const arts = res.data.artifacts || [];
        console.log("[GH getRunArtifacts]", arts.map(a => a.name));
        return arts;
    } catch {
        return [];
    }
}

// ═══════════════════════════════════════════
// DOWNLOAD ARTIFACT
// ═══════════════════════════════════════════
async function downloadArtifact(artifactId, destPath) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/artifacts/${artifactId}/zip`;
    const res = await axios.get(url, {
        headers: ghHeaders(),
        responseType: "arraybuffer",
        maxRedirects: 10,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });
    fs.writeFileSync(destPath, Buffer.from(res.data));
    console.log("[GH downloadArtifact] saved:", destPath, "size:", res.data.length);
    return destPath;
}

// ═══════════════════════════════════════════
// DAPETIN RAW FILE
// ═══════════════════════════════════════════
async function getRawFile(repoPath, ref = null) {
    validateConfig();
    const r = ref || GH.BRANCH || "main";
    const url = `https://raw.githubusercontent.com/${GH.USERNAME}/${GH.REPO}/${r}/${repoPath}`;
    try {
        const res = await axios.get(url, { responseType: "text", timeout: 15000 });
        return res.data;
    } catch {
        return null;
    }
}

// ═══════════════════════════════════════════
// DAPETIN LOG DARI RUN
// ═══════════════════════════════════════════
async function getRunLogs(runId) {
    validateConfig();
    const url = `${API}/repos/${GH.USERNAME}/${GH.REPO}/actions/runs/${runId}/logs`;
    try {
        const res = await axios.get(url, {
            headers: ghHeaders(),
            responseType: "arraybuffer",
            maxRedirects: 10,
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            timeout: 120000
        });
        return Buffer.from(res.data);
    } catch (e) {
        console.log("[GH getRunLogs] err:", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// POLL STATUS SAMPE SELESAI
// ═══════════════════════════════════════════
async function pollRunUntilDone(runId, onProgress, maxWaitMs = null) {
    const maxWait = maxWaitMs || cfg.BUILD_MAX_WAIT_MS || 1800000;
    const interval = cfg.BUILD_POLL_INTERVAL || 15000;
    const start = Date.now();

    while (Date.now() - start < maxWait) {
        const run = await getRunStatus(runId);
        if (run) {
            const status = run.status;
            const conclusion = run.conclusion;

            if (typeof onProgress === "function") {
                onProgress({ status, conclusion, run });
            }

            if (status === "completed") {
                return { status, conclusion, run };
            }
        }
        await new Promise(r => setTimeout(r, interval));
    }

    return { status: "timeout", conclusion: null, run: null };
}

// ═══════════════════════════════════════════
// GENERATE BUILD NOTIF IMAGE
// ═══════════════════════════════════════════
async function generateBuildNotifImage({
    title = "BUILD",
    subtitle = "",
    status = "info",
    fields = [],
    footer = ""
}) {
    const sharp = require("sharp");

    const COLORS = {
        success: { g1: "#10B981", g2: "#059669", label: "SUCCESS", icon: "OK", color: "#10B981" },
        failed: { g1: "#EF4444", g2: "#DC2626", label: "FAILED", icon: "X", color: "#EF4444" },
        info: { g1: "#3B82F6", g2: "#2563EB", label: "INFO", icon: "i", color: "#3B82F6" },
        building: { g1: "#F59E0B", g2: "#D97706", label: "BUILDING", icon: "~", color: "#F59E0B" }
    };
    const c = COLORS[status] || COLORS.info;

    const escXml = (s) => String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");

    const W = 1000;
    const H = 520;

    const fieldRows = fields.slice(0, 6).map((f, i) => {
        const y = 250 + i * 40;
        return `
  <text x="80" y="${y}" font-family="Arial" font-size="16" fill="#94A3B8">${escXml(f.label)}</text>
  <text x="${W - 80}" y="${y}" font-family="Arial" font-size="16" font-weight="bold" fill="#FFFFFF" text-anchor="end">${escXml(String(f.value).slice(0, 45))}</text>
  <line x1="80" y1="${y + 12}" x2="${W - 80}" y2="${y + 12}" stroke="#334155" stroke-width="1" opacity="0.4"/>
        `;
    }).join("");

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0F172A"/>
      <stop offset="50%" stop-color="#1E293B"/>
      <stop offset="100%" stop-color="#0F172A"/>
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${c.g1}"/>
      <stop offset="100%" stop-color="${c.g2}"/>
    </linearGradient>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <circle cx="80" cy="80" r="200" fill="${c.color}" opacity="0.08"/>
  <circle cx="${W - 80}" cy="${H - 80}" r="220" fill="${c.color}" opacity="0.06"/>

  <rect x="30" y="30" width="${W - 60}" height="${H - 60}" rx="22" fill="#FFFFFF" fill-opacity="0.04" stroke="${c.color}" stroke-width="2" stroke-opacity="0.4"/>
  <rect x="30" y="30" width="${W - 60}" height="8" rx="4" fill="url(#accent)"/>

  <text x="${W / 2}" y="90" font-family="Arial" font-size="20" font-weight="bold" fill="#94A3B8" text-anchor="middle" letter-spacing="4">SPARTAX BUILD SYSTEM</text>

  <rect x="${W / 2 - 140}" y="120" width="280" height="55" rx="27" fill="${c.color}" opacity="0.15" stroke="${c.color}" stroke-width="2"/>
  <text x="${W / 2}" y="155" font-family="Arial" font-size="22" font-weight="bold" fill="${c.color}" text-anchor="middle" letter-spacing="2">${escXml(c.label)}</text>

  <text x="${W / 2}" y="215" font-family="Arial" font-size="32" font-weight="bold" fill="#FFFFFF" text-anchor="middle" letter-spacing="1">${escXml(title).slice(0, 45)}</text>

  ${subtitle ? `<text x="${W / 2}" y="240" font-family="Arial" font-size="14" fill="#94A3B8" text-anchor="middle">${escXml(subtitle).slice(0, 60)}</text>` : ""}

  ${fieldRows}

  ${footer ? `<text x="${W / 2}" y="${H - 40}" font-family="Arial" font-size="13" fill="#64748B" text-anchor="middle">${escXml(footer).slice(0, 80)}</text>` : ""}
</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
}

// ═══════════════════════════════════════════
// SEND BUILD NOTIF KE CHANNEL
// ═══════════════════════════════════════════
async function sendBuildNotif(bot, {
    title,
    subtitle = "",
    status = "info",
    fields = [],
    footer = "",
    caption = ""
}) {
    if (!cfg.BUILD_LOG_CHANNEL || cfg.BUILD_LOG_CHANNEL === "-1001234567890") return;

    const finalCaption = caption || `<b>▸ ${title}</b>`;

    try {
        const img = await generateBuildNotifImage({ title, subtitle, status, fields, footer });
        await bot.sendPhoto(cfg.BUILD_LOG_CHANNEL, img, {
            caption: finalCaption,
            parse_mode: "HTML"
        });
    } catch (e) {
        console.log("[BUILD NOTIF ERR]", e.message);
        try {
            await bot.sendMessage(cfg.BUILD_LOG_CHANNEL, finalCaption, { parse_mode: "HTML" });
        } catch {}
    }
}

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports = {
    API,
    TMP_DIR,
    readJobs,
    writeJobs,
    newJobId,
    validateConfig,
    putFile,
    uploadFile,
    deleteFile,
    listFiles,
    triggerWorkflow,
    getLatestRun,
    getRunStatus,
    getRunJobs,
    getRunArtifacts,
    downloadArtifact,
    getRawFile,
    getRunLogs,
    pollRunUntilDone
};

console.log("[GITHUB BUILDER] helper loaded");