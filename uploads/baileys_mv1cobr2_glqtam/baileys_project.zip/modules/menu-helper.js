// ═══════════════════════════════════════════
// MENU HELPER — Edit pesan yang ada, bukan bikin baru
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

/**
 * Kirim ATAU edit message menu.
 * Kalau dari callback query (q), edit message yang diklik.
 * Kalau dari command (msg), kirim baru.
 * 
 * @param {TelegramBot} bot
 * @param {Object} q - callback_query object (atau null kalau dari command)
 * @param {Object} msg - message object (kalau dari command)
 * @param {Object} content - { text, photo, caption, keyboard, parseMode }
 */
async function showMenu(bot, q, msg, content) {
    const {
        text = "",
        photo = null,
        caption = "",
        keyboard = null,
        parseMode = "HTML"
    } = content;

    const replyMarkup = keyboard ? { reply_markup: keyboard } : {};

    // ⚠️ Kalau dari callback query → edit message yang ada
    if (q && q.message) {
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;
        const hasPhoto = !!q.message.photo;
        const hasCaption = !!q.message.caption;

        // ─── CASE 1: mau kirim PHOTO, dan message lama juga PHOTO → edit caption + keyboard ───
        if (photo && hasPhoto) {
            try {
                // Edit caption + keyboard (kalau ada text baru)
                if (caption || text) {
                    await bot.editMessageCaption(caption || text, {
                        chat_id: chatId,
                        message_id: msgId,
                        parse_mode: parseMode,
                        ...replyMarkup
                    });
                } else {
                    await bot.editMessageReplyMarkup(replyMarkup.reply_markup, {
                        chat_id: chatId,
                        message_id: msgId
                    });
                }
                return { ok: true, method: "editCaption" };
            } catch (e) {
                console.log("[MENU] editCaption fail:", e.message.slice(0, 100));
            }
        }

        // ─── CASE 2: mau kirim PHOTO, message lama TEXT → edit media ───
        if (photo && !hasPhoto) {
            try {
                await bot.editMessageMedia({
                    type: "photo",
                    media: photo,
                    caption: caption || text,
                    parse_mode: parseMode
                }, {
                    chat_id: chatId,
                    message_id: msgId,
                    ...replyMarkup
                });
                return { ok: true, method: "editMedia" };
            } catch (e) {
                console.log("[MENU] editMedia fail:", e.message.slice(0, 100));
            }
        }

        // ─── CASE 3: mau kirim TEXT, message lama TEXT → edit text ───
        if (!photo && !hasPhoto) {
            try {
                await bot.editMessageText(text || caption, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: parseMode,
                    ...replyMarkup
                });
                return { ok: true, method: "editText" };
            } catch (e) {
                const m = e.message || "";
                if (m.includes("message is not modified")) {
                    return { ok: true, method: "noChange" };
                }
                console.log("[MENU] editText fail:", m.slice(0, 100));

                // Fallback: hapus + kirim baru
                try { await bot.deleteMessage(chatId, msgId); } catch {}
            }
        }

        // ─── CASE 4: mau kirim TEXT, message lama PHOTO → edit caption ───
        if (!photo && hasPhoto) {
            try {
                await bot.editMessageCaption(text || caption, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: parseMode,
                    ...replyMarkup
                });
                return { ok: true, method: "editCaption" };
            } catch (e) {
                console.log("[MENU] editCaption fail:", e.message.slice(0, 100));
                try { await bot.deleteMessage(chatId, msgId); } catch {}
            }
        }
    }

    // ⚠️ Fallback: kirim baru (kalau bukan dari callback atau edit gagal)
    const targetChatId = q ? q.message.chat.id : msg.chat.id;

    try {
        if (photo) {
            await bot.sendPhoto(targetChatId, photo, {
                caption: caption || text,
                parse_mode: parseMode,
                ...replyMarkup
            });
            return { ok: true, method: "sendPhoto" };
        } else {
            await bot.sendMessage(targetChatId, text || caption, {
                parse_mode: parseMode,
                ...replyMarkup
            });
            return { ok: true, method: "sendText" };
        }
    } catch (e) {
        console.log("[MENU] send fail:", e.message.slice(0, 100));
        return { ok: false, error: e.message };
    }
}

module.exports = { showMenu };
console.log("[MENU HELPER] module loaded");