// ═══════════════════════════════════════════
// MUSIC — Download full audio (Spotify/YouTube)
// v6 — Cobalt API + yt-dlp npx fallback
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const notify = require("./notify");
const { exec } = require("child_process");
const util = require("util");
const execAsync = util.promisify(exec);

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

const MAX_AUDIO_MB = 45;
const MAX_AUDIO_BYTES = MAX_AUDIO_MB * 1024 * 1024;
const MIN_AUDIO_BYTES = 100 * 1024; // 100 KB minimum

function tmpPath(ext = "mp3") {
    return path.join(TMP_DIR, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);
}

async function sendPhoto(bot, chatId, url, caption, keyboard) {
    try {
        return await bot.sendPhoto(chatId, url, {
            caption, parse_mode: "HTML",
            reply_markup: keyboard ? { inline_keyboard: keyboard } : undefined
        });
    } catch {
        return bot.sendMessage(chatId, caption, {
            parse_mode: "HTML",
            reply_markup: keyboard ? { inline_keyboard: keyboard } : undefined
        });
    }
}

// ═══════════════════════════════════════════
// HTTP CLIENT
// ═══════════════════════════════════════════
const httpClient = axios.create({
    timeout: 120000,
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
    headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9"
    }
});

// ═══ VERIFY AUDIO BUFFER ═══
function isValidAudio(buf) {
    if (!buf || buf.length < MIN_AUDIO_BYTES) return false;
    // Cek header: MP3 (ID3 / FF), M4A (ftyp), OGG (OggS), WAV (RIFF)
    const h = buf;
    if (h[0] === 0x49 && h[1] === 0x44 && h[2] === 0x33) return true; // ID3
    if (h[0] === 0xff && (h[1] & 0xe0) === 0xe0) return true;         // MP3 frame
    if (h[4] === 0x66 && h[5] === 0x74 && h[6] === 0x79 && h[7] === 0x70) return true; // ftyp (m4a/mp4)
    if (h[0] === 0x4f && h[1] === 0x67 && h[2] === 0x67 && h[3] === 0x53) return true; // OggS
    if (h[0] === 0x52 && h[1] === 0x49 && h[2] === 0x46 && h[3] === 0x46) return true; // RIFF
    return false;
}

async function downloadFromUrl(url, label) {
    try {
        console.log(`[MUSIC] download from ${label}: ${url.slice(0, 80)}`);
        const res = await httpClient.get(url, {
            responseType: "arraybuffer",
            timeout: 120000
        });
        const buf = Buffer.from(res.data);
        console.log(`[MUSIC] ${label} → ${buf.length} bytes`);

        if (!isValidAudio(buf)) {
            console.log(`[MUSIC] ${label} not valid audio, skip`);
            return null;
        }

        const filePath = tmpPath("mp3");
        fs.writeFileSync(filePath, buf);
        return { path: filePath, source: label, size: buf.length };
    } catch (e) {
        console.log(`[MUSIC] ${label} fail:`, e.message.slice(0, 100));
        return null;
    }
}

// ═══════════════════════════════════════════
// YT-DLP CHECK & AUTO-INSTALL
// ═══════════════════════════════════════════
let ytDlpChecked = false;
let ytDlpAvailable = false;
let ytDlpCmd = null;

async function ensureYtDlp() {
    if (ytDlpChecked) return ytDlpAvailable;
    ytDlpChecked = true;

    // Cek binary langsung
    try {
        await execAsync("which yt-dlp");
        ytDlpAvailable = true;
        ytDlpCmd = "yt-dlp";
        console.log("[MUSIC] ✅ yt-dlp found");
        return true;
    } catch {}

    // Cek pip user install
    try {
        const { stdout } = await execAsync("ls $HOME/.local/bin/yt-dlp 2>/dev/null || echo NONE");
        if (stdout.trim() !== "NONE") {
            ytDlpAvailable = true;
            ytDlpCmd = "$HOME/.local/bin/yt-dlp";
            console.log("[MUSIC] ✅ yt-dlp found at $HOME/.local/bin");
            return true;
        }
    } catch {}

    // Cek npx yt-dlp
    try {
        await execAsync("npx --yes yt-dlp --version", { timeout: 60000 });
        ytDlpAvailable = true;
        ytDlpCmd = "npx --yes yt-dlp";
        console.log("[MUSIC] ✅ yt-dlp via npx works");
        return true;
    } catch {}

    // Coba auto-install pake pip
    console.log("[MUSIC] yt-dlp belum ada, coba install...");
    try {
        await execAsync("pip3 install --quiet --user --upgrade yt-dlp 2>/dev/null || pip install --quiet --user --upgrade yt-dlp 2>/dev/null || python3 -m pip install --quiet --user --upgrade yt-dlp 2>/dev/null", { timeout: 180000 });
        try {
            await execAsync("ls $HOME/.local/bin/yt-dlp");
            ytDlpAvailable = true;
            ytDlpCmd = "$HOME/.local/bin/yt-dlp";
            console.log("[MUSIC] ✅ yt-dlp installed via pip");
            return true;
        } catch {}
    } catch (e) {
        console.log("[MUSIC] pip install fail:", e.message.slice(0, 100));
    }

    // Coba install via npm (ga butuh root)
    try {
        console.log("[MUSIC] coba install via npm...");
        await execAsync("npm install -g yt-dlp-exec 2>/dev/null || npm install yt-dlp-exec 2>/dev/null", { timeout: 120000 });
        // yt-dlp-exec punya binary terpisah
        try {
            await execAsync("./node_modules/.bin/yt-dlp --version");
            ytDlpAvailable = true;
            ytDlpCmd = "./node_modules/.bin/yt-dlp";
            console.log("[MUSIC] ✅ yt-dlp via npm");
            return true;
        } catch {}
    } catch (e) {
        console.log("[MUSIC] npm install fail:", e.message.slice(0, 100));
    }

    console.log("[MUSIC] ❌ yt-dlp ga bisa di-install otomatis");
    ytDlpAvailable = false;
    return false;
}

// ═══════════════════════════════════════════
// DOWNLOAD VIA YT-DLP
// ═══════════════════════════════════════════
async function downloadViaYtDlp(track) {
    const available = await ensureYtDlp();
    if (!available) return null;

    const query = `${track.title} ${track.artist?.name || ""} audio`;
    const outputTemplate = path.join(TMP_DIR, `ytdlp_${Date.now()}_%(id)s.%(ext)s`);

    const cmd = `${ytDlpCmd} -x --audio-format mp3 --audio-quality 0 --no-playlist --no-warnings -o "${outputTemplate}" "ytsearch1:${query.replace(/"/g, "")}"`;

    console.log("[MUSIC] yt-dlp cmd:", cmd.slice(0, 180));

    try {
        await execAsync(cmd, { timeout: 180000, maxBuffer: 20 * 1024 * 1024 });

        // Cari file hasil
        const dir = TMP_DIR;
        const files = fs.readdirSync(dir)
            .filter(f => f.startsWith("ytdlp_") && (f.endsWith(".mp3") || f.endsWith(".m4a") || f.endsWith(".webm") || f.endsWith(".opus")))
            .map(f => ({ name: f, path: path.join(dir, f), mtime: fs.statSync(path.join(dir, f)).mtime.getTime() }))
            .sort((a, b) => b.mtime - a.mtime);

        if (files.length === 0) {
            console.log("[MUSIC] yt-dlp: no output file");
            return null;
        }

        const latest = files[0];
        const stat = fs.statSync(latest.path);

        if (stat.size < MIN_AUDIO_BYTES) {
            console.log(`[MUSIC] yt-dlp: file too small (${stat.size})`);
            try { fs.unlinkSync(latest.path); } catch {}
            return null;
        }

        console.log(`[MUSIC] ✅ yt-dlp sukses: ${stat.size} bytes`);
        return { path: latest.path, source: "yt-dlp", size: stat.size };
    } catch (e) {
        console.log("[MUSIC] yt-dlp fail:", e.message.slice(0, 200));
        return null;
    }
}

// ═══════════════════════════════════════════
// DOWNLOAD FULL AUDIO — MULTI API + YT-DLP
// ═══════════════════════════════════════════
async function downloadFullAudio(track) {
    const title = track.title || "";
    const artist = track.artist?.name || "";
    const fullQuery = `${title} ${artist}`.trim();
    const q = encodeURIComponent(fullQuery);
    const spotifyUrl = track.link || "";

    const APIs = [
        // ─── API 1: Cobalt.tools (paling reliable 2024-2025) ───
        async () => {
            try {
                console.log("[MUSIC] trying cobalt...");
                const r = await httpClient.post("https://api.cobalt.tools/api/json", {
                    url: spotifyUrl,
                    isAudioOnly: true,
                    aFormat: "mp3",
                    audioBitrate: "320",
                    filenamePattern: "basic"
                }, {
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    timeout: 45000
                });
                let url = r.data?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "cobalt");
            } catch (e) {
                // Coba cobalt instance lain
                try {
                    const r2 = await httpClient.post("https://co.wuk.sh/api/json", {
                        url: spotifyUrl,
                        isAudioOnly: true,
                        aFormat: "mp3"
                    }, { headers: { "Content-Type": "application/json" }, timeout: 45000 });
                    let url = r2.data?.url;
                    if (url) return await downloadFromUrl(url, "cobalt-2");
                } catch {}
                return null;
            }
        },

        // ─── API 2: y2mate (search YouTube) ───
        async () => {
            try {
                console.log("[MUSIC] trying y2mate...");
                const r = await httpClient.get(`https://api.vevioz.com/api/button/mp3/${q}`, { timeout: 30000 });
                // vevioz balikin HTML, skip
                return null;
            } catch { return null; }
        },

        // ─── API 3: siputzx spotify ───
        async () => {
            try {
                console.log("[MUSIC] trying siputzx-spotify...");
                const r = await httpClient.get(`https://api.siputzx.my.id/api/d/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 45000 });
                const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.download;
                if (!url) return null;
                return await downloadFromUrl(url, "siputzx-spotify");
            } catch { return null; }
        },

        // ─── API 4: siputzx ytplay ───
        async () => {
            try {
                console.log("[MUSIC] trying siputzx-ytplay...");
                const r = await httpClient.get(`https://api.siputzx.my.id/api/d/ytplaymp3?query=${q}`, { timeout: 45000 });
                const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.download;
                if (!url) return null;
                return await downloadFromUrl(url, "siputzx-yt");
            } catch { return null; }
        },

        // ─── API 5: nexoracle ───
        async () => {
            try {
                console.log("[MUSIC] trying nexoracle...");
                const r = await httpClient.get(`https://api.nexoracle.com/downloader/spotify?apikey=free&url=${encodeURIComponent(spotifyUrl)}`, { timeout: 45000 });
                const url = r.data?.result?.url || r.data?.result?.download || r.data?.data?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "nexoracle");
            } catch { return null; }
        },

        // ─── API 6: betabotz ───
        async () => {
            try {
                console.log("[MUSIC] trying betabotz...");
                const key = cfg.API_KEYS?.BETABOTZ || "";
                if (!key) return null;
                const r = await httpClient.get(`https://api.betabotz.eu.org/api/download/spotify?url=${encodeURIComponent(spotifyUrl)}&apikey=${key}`, { timeout: 45000 });
                const url = r.data?.result?.url || r.data?.result?.download || r.data?.data?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "betabotz");
            } catch { return null; }
        },

        // ─── API 7: vreden yt ───
        async () => {
            try {
                console.log("[MUSIC] trying vreden-yt...");
                const r = await httpClient.get(`https://api.vreden.my.id/api/ytplaymp3?query=${q}`, { timeout: 45000 });
                const url = r.data?.result?.download?.url || r.data?.result?.download || r.data?.result?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "vreden-yt");
            } catch { return null; }
        },

        // ─── API 8: alyachan ───
        async () => {
            try {
                console.log("[MUSIC] trying alyachan...");
                const r = await httpClient.get(`https://api.alyachan.dev/api/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 45000 });
                const url = r.data?.data?.url || r.data?.data?.download || r.data?.result?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "alyachan");
            } catch { return null; }
        },

        // ─── API 9: itzpire ───
        async () => {
            try {
                console.log("[MUSIC] trying itzpire...");
                const r = await httpClient.get(`https://itzpire.com/download/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 45000 });
                const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.url;
                if (!url) return null;
                return await downloadFromUrl(url, "itzpire");
            } catch { return null; }
        },

        // ─── API 10: YT-DLP ───
        async () => {
            console.log("[MUSIC] trying yt-dlp...");
            return await downloadViaYtDlp(track);
        }
    ];

    for (let i = 0; i < APIs.length; i++) {
        try {
            console.log(`[MUSIC] API ${i + 1}/${APIs.length}`);
            const result = await APIs[i]();
            if (result && result.path) {
                console.log(`[MUSIC] ✅ API ${i + 1} success — ${result.source} (${result.size} bytes)`);
                return result;
            }
        } catch (e) {
            console.log(`[MUSIC] API ${i + 1} exception:`, e.message.slice(0, 100));
        }
    }

    return null;
}

// ═══════════════════════════════════════════
// MENU MUSIC
// ═══════════════════════════════════════════
router.registerCallback("menu_music", async (bot, q, data, user, ctx) => {
    const caption =
        `<b>𖡛 MUSIC</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Cari lagu & dapet file audio <b>FULL DURASI</b>.\n\n` +
        `𖡛 <b>GRATIS</b>\n` +
        `𖡛 Support: <b>6+ menit durasi</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.MUSIC || cfg.FOTO.MENU, caption, [
        [{ text: "𖡛 Search Lagu", callback_data: "music_search", style: "success" }],
        [{ text: "⬅️ Kembali", callback_data: "menu_back", style: "danger" }]
    ]);
});

router.registerCallback("music_search", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "music_search_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 SEARCH LAGU</b>\n\nKirim judul / artist:\nContoh: <code>Bruno Mars</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("music_search_await", async (bot, msg, state, ctx) => {
    const query = msg.text?.trim();
    if (!query) return;
    ctx.clearState(String(msg.from.id));

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cari "${query}"...</b>`, { parse_mode: "HTML" });

    try {
        const sr = await httpClient.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=5`, { timeout: 15000 });

        if (!sr.data || !sr.data.data || sr.data.data.length === 0) {
            return bot.editMessageText(`<b>❌ Lagu "${query}" ga ditemukan.</b>`,
                { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        }

        const list = sr.data.data.map((t, i) => `${i + 1}. <b>${t.title}</b> — ${t.artist.name}`).join("\n");
        ctx.setState(String(msg.from.id), "music_pick", { results: sr.data.data });

        await bot.editMessageText(
            `<b>𖡛 HASIL PENCARIAN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Query: <code>${query}</code>\n\n${list}\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            {
                chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML",
                reply_markup: { inline_keyboard: sr.data.data.map((t, i) => [{ text: `${i + 1}. ${t.title.slice(0, 30)}`, callback_data: `music_pick:${i}` }]) }
            });
    } catch (e) {
        await bot.editMessageText(`<b>❌ Error:</b> <code>${e.message.slice(0, 150)}</code>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    }
});

router.registerCallback("music_pick", async (bot, q, data, user, ctx) => {
    const idx = parseInt(data.split(":")[1]);
    const st = ctx.getState(String(user.id));
    if (!st || !st.results || !st.results[idx]) {
        return bot.answerCallbackQuery(q.id, { text: "❌ Sesi habis", show_alert: true });
    }

    const track = st.results[idx];
    ctx.clearState(String(user.id));
    await bot.answerCallbackQuery(q.id, { text: "𖡛 Download audio full..." });

    const loading = await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 Download audio</b>\n\n` +
        `<b>${track.title}</b>\n` +
        `<i>${track.artist.name}</i>\n\n` +
        `▸ Mencari sumber full durasi...`,
        { parse_mode: "HTML" });

    let audio = await downloadFullAudio(track);

    await bot.deleteMessage(q.message.chat.id, loading.message_id).catch(() => {});

    // ═══ KIRIM HASIL ═══
    if (audio && fs.existsSync(audio.path)) {
        try {
            const stat = fs.statSync(audio.path);

            if (stat.size > MAX_AUDIO_BYTES) {
                await bot.sendMessage(q.message.chat.id,
                    `<b>⚠️ File terlalu besar (${(stat.size / 1024 / 1024).toFixed(1)} MB)</b>\n\n` +
                    `<i>Max yang bisa dikirim Telegram via bot = 45 MB.</i>`,
                    { parse_mode: "HTML" });
                try { fs.unlinkSync(audio.path); } catch {}
                return;
            }

            const caption =
                `<b>𖡛 ${track.title}</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `𖡛 <b>Artist</b>: ${track.artist.name}\n` +
                `𖡛 <b>Album</b>: ${track.album?.title || "-"}\n` +
                `𖡛 <b>Source</b>: ${audio.source}\n` +
                `𖡛 <b>Size</b>: ${(stat.size / 1024 / 1024).toFixed(2)} MB\n` +
                `━━━━━━━━━━━━━━━━━━━━`;

            await bot.sendAudio(q.message.chat.id, audio.path, {
                caption,
                parse_mode: "HTML",
                title: track.title,
                performer: track.artist.name,
                reply_markup: { inline_keyboard: [[{ text: "𖡛 Buka di Spotify", url: track.link }]] }
            });

            await notify.notifySuccess(bot, "MUSIC DOWNLOAD", [
                { label: "𖡛 User", value: q.from.first_name || "User" },
                { label: "𖡛 Lagu", value: track.title.slice(0, 30) },
                { label: "𖡛 Source", value: audio.source },
                { label: "𖡛 Size", value: (stat.size / 1024 / 1024).toFixed(2) + " MB" }
            ]).catch(() => {});

            try { fs.unlinkSync(audio.path); } catch {}
        } catch (e) {
            console.log("[MUSIC] sendAudio FAIL:", e.message);
            await bot.sendMessage(q.message.chat.id,
                `<b>❌ Gagal kirim audio:</b> <code>${e.message.slice(0, 200)}</code>`,
                { parse_mode: "HTML" });
            try { fs.unlinkSync(audio.path); } catch {}
        }
    } else {
        // Total gagal — kirim cover + link + saran
        const ytSearch = `https://www.youtube.com/results?search_query=${encodeURIComponent(track.title + " " + track.artist.name)}`;
        const spotifySearch = `https://open.spotify.com/search/${encodeURIComponent(track.title + " " + track.artist.name)}`;

        try {
            await bot.sendPhoto(q.message.chat.id, track.album?.cover_xl || track.album?.cover_big, {
                caption:
                    `<b>𖡛 ${track.title}</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `𖡛 <b>Artist</b>: ${track.artist.name}\n` +
                    `𖡛 <b>Album</b>: ${track.album?.title || "-"}\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<b>⚠️ Semua API download gagal.</b>\n` +
                    `<i>Ini karena server API eksternal sedang down atau lu belum install yt-dlp di server.</i>\n\n` +
                    `<b>💡 Solusi:</b>\n` +
                    `▸ Install yt-dlp + ffmpeg di server\n` +
                    `▸ Atau coba lagu lain\n` +
                    `▸ Atau buka manual di YouTube/Spotify`,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [
                    [{ text: "🎵 Cari di YouTube", url: ytSearch }],
                    [{ text: "𖡛 Buka di Spotify", url: spotifySearch }]
                ]}
            });
        } catch {
            await bot.sendMessage(q.message.chat.id,
                `<b>𖡛 ${track.title}</b> — ${track.artist.name}\n𖡛 ${track.link}`,
                { parse_mode: "HTML" });
        }

        await notify.notifyFailed(bot, "MUSIC DOWNLOAD", [
            { label: "𖡛 User", value: q.from.first_name || "User" },
            { label: "𖡛 Lagu", value: track.title.slice(0, 30) },
            { label: "❌ Error", value: "semua API gagal — cek yt-dlp" }
        ]).catch(() => {});
    }
});

module.exports = {
    downloadFullAudio,
    downloadViaYtDlp,
    ensureYtDlp
};
console.log("[MUSIC] module loaded (v6 — cobalt + yt-dlp)");