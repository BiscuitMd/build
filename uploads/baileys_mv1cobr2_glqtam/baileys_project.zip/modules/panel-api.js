// ═══════════════════════════════════════════
// PANEL API — Pterodactyl Application API Helper
// v1 — Bikin user + server di Pterodactyl asli
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const axios = require("axios");
const cfg = require("../config");

// ═══ CONFIG PTERODACTYL ═══
// Format di config.js:
// PTERODACTYL: {
//   PLTA: { URL, API_KEY, NEST_ID, EGG_DEFAULT },
//   PLTC: { URL, API_KEY, NEST_ID },
//   DOMAIN: "..."
// }

function getPanelConfig(scope) {
    const c = cfg.PTERODACTYL || {};

    if (scope === "legal") {
        return c.PLTC || c.PLTA || null;
    }
    return c.PLTA || null;
}

function buildHeaders(apiKey) {
    return {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        "User-Agent": "SpartaX-Bot/1.0"
    };
}

// ═══════════════════════════════════════════
// GET USER BY EMAIL
// ═══════════════════════════════════════════
async function getUserByEmail(scope, email) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.get(`${pc.URL}/api/application/users?filter[email]=${encodeURIComponent(email)}`, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200 && res.data?.data?.length > 0) {
            return { ok: true, user: res.data.data[0], raw: res.data };
        }
        return { ok: false, error: "User tidak ditemukan" };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// CREATE USER
// ═══════════════════════════════════════════
async function createUser(scope, { email, username, firstName, lastName, password }) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.post(`${pc.URL}/api/application/users`, {
            email,
            username,
            first_name: firstName || username,
            last_name: lastName || "User",
            password,
            root_admin: false,
            language: "en"
        }, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200 || res.status === 201) {
            return { ok: true, user: res.data.attributes, raw: res.data };
        }

        // Error dari panel
        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 200);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// GET ALLOCATIONS (port kosong)
// ═══════════════════════════════════════════
async function getAllocations(scope, nodeId = 1) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.get(`${pc.URL}/api/application/nodes/${nodeId}/allocations?per_page=100`, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200) {
            const allocs = (res.data.data || []).filter(a => !a.attributes.assigned);
            return { ok: true, allocations: allocs };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// GET EGG DETAIL
// ═══════════════════════════════════════════
async function getEggDetail(scope, nestId, eggId) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.get(`${pc.URL}/api/application/nests/${nestId}/eggs/${eggId}?include=variables`, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200) {
            return { ok: true, egg: res.data.attributes, variables: res.data.attributes.relationships?.variables?.data || [] };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// CREATE SERVER
// ═══════════════════════════════════════════
async function createServer(scope, {
    name, userId, nestId, eggId,
    dockerImage, startup,
    environment = {},
    memory, disk, cpu,
    allocationId,
    databases = 0,
    backups = 0,
    allocations = 0,
    locationId = 1
}) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.post(`${pc.URL}/api/application/servers`, {
            name,
            user: userId,
            egg: eggId,
            docker_image: dockerImage,
            startup,
            environment,
            limits: {
                memory: parseInt(memory) || 512,
                swap: 0,
                disk: parseInt(disk) || 1024,
                io: 500,
                cpu: parseInt(cpu) || 100
            },
            feature_limits: {
                databases: parseInt(databases) || 0,
                backups: parseInt(backups) || 0,
                allocations: parseInt(allocations) || 0
            },
            deploy: {
                locations: [locationId],
                dedicated_ip: false,
                port_range: []
            },
            start_on_completion: true,
            allocation: {
                default: allocationId
            }
        }, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 60000,
            validateStatus: s => s < 500
        });

        if (res.status === 200 || res.status === 201) {
            return { ok: true, server: res.data.attributes, raw: res.data };
        }

        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 200);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// LIST NESTS (buat list egg di panel)
// ═══════════════════════════════════════════
async function listNests(scope) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.get(`${pc.URL}/api/application/nests`, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200) {
            return { ok: true, nests: res.data.data || [] };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// LIST EGGS FROM NEST
// ═══════════════════════════════════════════
async function listEggs(scope, nestId) {
    const pc = getPanelConfig(scope);
    if (!pc || !pc.URL || !pc.API_KEY) {
        return { ok: false, error: "Panel config belum di-set" };
    }

    try {
        const res = await axios.get(`${pc.URL}/api/application/nests/${nestId}/eggs`, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200) {
            return { ok: true, eggs: res.data.data || [] };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// GENERATE EMAIL
// ═══════════════════════════════════════════
function generateEmail(username, domain) {
    return `${username}@${domain || "panel.local"}`;
}

// ═══════════════════════════════════════════
// GENERATE PASSWORD
// ═══════════════════════════════════════════
function generatePassword(len = 12) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
    let out = "";
    for (let i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

module.exports = {
    getPanelConfig,
    getUserByEmail,
    createUser,
    getAllocations,
    getEggDetail,
    createServer,
    listNests,
    listEggs,
    generateEmail,
    generatePassword
};

console.log("[PANEL API] helper loaded");