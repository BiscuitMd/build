const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const { Worker } = require("worker_threads");

const PAIRING_WORKER = path.join(__dirname, "wa-worker.js");
const activeWorkers = new Map();

// ═══════════════════════════════════════════
// MENU: ADD SENDER
// ═══════════════════════════════════════════
router.registerCallback("menu_addsender", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>𖡛 ADD SENDER</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Kirim nomor WhatsApp dengan format:</i>\n` +
            `<code>628xxxxxxxxxx</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Nomor harus aktif WhatsApp!</b>`;

        ctx.setState(user.id, "addsender_await_number", {});
        await bot.sendPhoto(q.message.chat.id, cfg.FOTO.ADD_SENDER, {
            caption,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back" }]] }
        });
    } catch (e) {
        console.log("[ADD SENDER MENU ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// HANDLE NOMOR → START WORKER
// ═══════════════════════════════════════════
router.registerMessage("addsender_await_number", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    let number = msg.text?.replace(/[^0-9]/g, "");
    if (!number) return;
    if (number.startsWith("0")) number = "62" + number.slice(1);
    if (!number.startsWith("62")) number = "62" + number;

    ctx.clearState(userId);

    const loading = await bot.sendMessage(chatId,
        `<b>𖡛 Menyiapkan koneksi...</b>\n\n𖡛 <code>+${number}</code>`,
        { parse_mode: "HTML" });

    const authDir = path.join(__dirname, "..", "pairing", number);

    // Hapus session lama biar fresh
    if (fs.existsSync(authDir)) {
        try { fs.rmSync(authDir, { recursive: true, force: true }); } catch {}
    }

    try {
        const worker = new Worker(PAIRING_WORKER, {
            workerData: { number, authDir, action: "pairing" }
        });

        activeWorkers.set(number, worker);

        let pairingDone = false;
        let connectedDone = false;
        let failedDone = false;

        worker.on("message", async (msg2) => {
            console.log(`[PAIRING ${number}]`, msg2);

            // Phase: pairing code keluar
            if (msg2.ok && msg2.phase === "pairing" && !pairingDone) {
                pairingDone = true;

                try {
                    await bot.editMessageText(
                        `<b>𖡛 PAIRING CODE</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `𖡛 Nomor: <code>+${number}</code>\n` +
                        `𖡛 Code: <code>${msg2.code}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n\n` +
                        `<b>Cara pakai:</b>\n` +
                        `1. Buka WhatsApp lu\n` +
                        `2. Settings → Linked Devices\n` +
                        `3. Link a Device → Link with phone number\n` +
                        `4. Masukkan code di atas\n\n` +
                        `<i>Tunggu sampai berhasil connect...</i>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch (e) {
                    console.log("[SENDER EDIT PAIRING ERR]", e.message);
                }
            }

            // Phase: connect berhasil
            if (msg2.ok && msg2.phase === "connected" && !connectedDone) {
                connectedDone = true;

                // Simpan sender ke DB
                try {
                    const senders = ctx.db.read("senders");
                    senders[number] = { number, addedAt: Date.now(), addedBy: userId };
                    ctx.db.write("senders", senders);
                } catch (e) {
                    console.log("[SENDER SAVE ERR]", e.message);
                }

                try {
                    await bot.sendPhoto(chatId, cfg.FOTO.ADD_SENDER, {
                        caption:
                            `<b>✓ SENDER BERHASIL DI-ADD</b>\n\n` +
                            `━━━━━━━━━━━━━━━━━━━━\n` +
                            `𖡛 Nomor: <code>+${number}</code>\n` +
                            `𖡛 Status: Connected\n` +
                            `━━━━━━━━━━━━━━━━━━━━`,
                        parse_mode: "HTML",
                        reply_markup: { inline_keyboard: [[{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]] }
                    });
                } catch (e) {
                    console.log("[SENDER SEND SUCCESS ERR]", e.message);
                }

                // Notif channel
                try {
                    const notify = require("./notify");
                    await notify.notifySuccess(bot, "SENDER CONNECTED", [
                        { label: "User", value: userId },
                        { label: "Nomor", value: "+" + number }
                    ]).catch(() => {});
                } catch {}
            }

            // Phase: connect final
            if (msg2.ok && msg2.phase === "success" && !connectedDone) {
                connectedDone = true;

                try {
                    const senders = ctx.db.read("senders");
                    senders[number] = { number, addedAt: Date.now(), addedBy: userId };
                    ctx.db.write("senders", senders);
                } catch {}

                try {
                    await bot.sendPhoto(chatId, cfg.FOTO.ADD_SENDER, {
                        caption:
                            `<b>✓ SENDER BERHASIL DI-ADD</b>\n\n` +
                            `━━━━━━━━━━━━━━━━━━━━\n` +
                            `𖡛 Nomor: <code>+${number}</code>\n` +
                            `𖡛 Status: Connected\n` +
                            `━━━━━━━━━━━━━━━━━━━━`,
                        parse_mode: "HTML",
                        reply_markup: { inline_keyboard: [[{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]] }
                    });
                } catch {}
            }

            // Phase: failed
            if (!msg2.ok && !failedDone) {
                failedDone = true;
                console.log(`[SENDER ${number}] FAIL:`, msg2.error);

                try {
                    await bot.editMessageText(
                        `<b>✕ GAGAL ADD SENDER</b>\n\n` +
                        `<code>${msg2.error}</code>\n\n` +
                        `<i>✕ Coba lagi atau pastikan nomor WA aktif.</i>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch {}
            }

            // Phase: restart (515)
            if (msg2.ok && msg2.phase === "restart") {
                console.log(`[SENDER ${number}] restart 515...`);
            }
        });

        worker.on("error", (err) => {
            console.log(`[SENDER ${number}] WORKER ERR:`, err.message);
            if (!failedDone) {
                failedDone = true;
                bot.sendMessage(chatId, `<b>✕ Worker error:</b>\n<code>${err.message}</code>`, { parse_mode: "HTML" }).catch(() => {});
            }
        });

        worker.on("exit", (code) => {
            console.log(`[SENDER ${number}] worker exit code:`, code);
            activeWorkers.delete(number);
        });

        // Timeout safety 15 menit
        setTimeout(() => {
            if (activeWorkers.has(number)) {
                try { activeWorkers.get(number).terminate(); } catch {}
                activeWorkers.delete(number);
            }
        }, 15 * 60 * 1000);
    } catch (e) {
        console.log("[SENDER START ERR]", e.message);
        try {
            await bot.editMessageText(
                `<b>✕ Gagal start worker:</b>\n<code>${e.message}</code>`,
                { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
        } catch {}
    }
});

// ═══════════════════════════════════════════
// MENU: CLEAR SENDER
// ═══════════════════════════════════════════
router.registerCallback("menu_clearsender", async (bot, q, data, user, ctx) => {
    try {
        const senders = ctx.db.read("senders");
        const list = Object.keys(senders);
        if (list.length === 0) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Belum ada sender.</b>`, { parse_mode: "HTML" });
        }
        const keyboard = list.map((n) => [{ text: `𖡛 +${n}`, callback_data: `clearsender_pick:${n}` }]);
        keyboard.push([{ text: "✕ Kembali", callback_data: "menu_back" }]);

        await bot.sendPhoto(q.message.chat.id, cfg.FOTO.CLEAR_SENDER, {
            caption: `<b>𖡛 CLEAR SENDER</b>\n\nPilih nomor yang mau dihapus:`,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: keyboard }
        });
    } catch (e) {
        console.log("[CLEAR SENDER MENU ERR]", e.message);
    }
});

router.registerCallback("clearsender_pick", async (bot, q, data, user, ctx) => {
    try {
        const number = data.split(":")[1];
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 Konfirmasi Hapus</b>\n\nYakin hapus sender <code>+${number}</code>?`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "𖡛 Hapus", callback_data: `clearsender_do:${number}`, style: "danger" },
                            { text: "✕ Batal", callback_data: "menu_back", style: "danger" }
                        ]
                    ]
                }
            });
    } catch (e) {
        console.log("[CLEAR SENDER PICK ERR]", e.message);
    }
});

router.registerCallback("clearsender_do", async (bot, q, data, user, ctx) => {
    try {
        const number = data.split(":")[1];
        const senders = ctx.db.read("senders");
        if (senders[number]) {
            delete senders[number];
            ctx.db.write("senders", senders);

            const authDir = path.join(__dirname, "..", "pairing", number);
            try { fs.rmSync(authDir, { recursive: true, force: true }); } catch {}

            if (activeWorkers.has(number)) {
                try { activeWorkers.get(number).terminate(); } catch {}
                activeWorkers.delete(number);
            }

            await bot.sendMessage(q.message.chat.id,
                `<b>✓ Sender +${number} berhasil dihapus.</b>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Menu", callback_data: "menu_back" }]] } });
        }
    } catch (e) {
        console.log("[CLEAR SENDER DO ERR]", e.message);
    }
});