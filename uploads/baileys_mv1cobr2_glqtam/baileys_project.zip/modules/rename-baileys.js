const router = require("./router");
const cfg = require("../config");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch { return null; }
        }
        if (msg.includes("message is not modified")) return null;
        return null;
    }
}

// ═══ DAFTAR BAILEYS VERSIONS YANG TERSEDIA ═══
const BAILEYS_VERSIONS = [
    { label: "Latest (Stable)", value: "latest" },
    { label: "6.7.18", value: "^6.7.18" },
    { label: "6.7.17", value: "^6.7.17" },
    { label: "6.7.16", value: "^6.7.16" },
    { label: "6.7.15", value: "^6.7.15" },
    { label: "6.7.14", value: "^6.7.14" },
    { label: "6.7.13", value: "^6.7.13" },
    { label: "6.7.12", value: "^6.7.12" },
    { label: "6.7.11", value: "^6.7.11" },
    { label: "6.7.10", value: "^6.7.10" },
    { label: "6.7.9", value: "^6.7.9" },
    { label: "6.7.8", value: "^6.7.8" },
    { label: "6.7.7", value: "^6.7.7" },
    { label: "6.7.6", value: "^6.7.6" },
    { label: "6.7.5", value: "^6.7.5" },
    { label: "6.6.0", value: "^6.6.0" },
    { label: "6.5.0", value: "^6.5.0" },
    { label: "Github: NtedBitch/bail", value: "github:NtedBitch/bail" },
    { label: "Github: WhiskeySockets/Baileys", value: "github:WhiskeySockets/Baileys" }
];

// ═══ SCAN package.json UNTUK VERSI BAILEYS LAMA ═══
function scanBaileysVersion(extractDir) {
    const results = [];
    const pkgFiles = [];

    function walk(dir) {
        let items;
        try { items = fs.readdirSync(dir, { withFileTypes: true }); }
        catch { return; }

        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                if (["node_modules", ".git", "build", "dist"].includes(item.name)) continue;
                walk(full);
            } else if (item.name === "package.json") {
                pkgFiles.push(full);
            }
        }
    }
    walk(extractDir);

    for (const pkgPath of pkgFiles) {
        if (!fs.existsSync(pkgPath)) continue;
        try {
            const content = fs.readFileSync(pkgPath, "utf8");
            const pkg = JSON.parse(content);
            const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };

            const baileysKeys = [
                "@whiskeysockets/baileys",
                "baileys",
                "@adiwajshing/baileys"
            ];

            for (const key of baileysKeys) {
                if (deps[key]) {
                    results.push({
                        package: key,
                        version: deps[key],
                        path: path.relative(extractDir, pkgPath),
                        fullPath: pkgPath,
                        depType: pkg.dependencies && pkg.dependencies[key] ? "dependencies" : "devDependencies"
                    });
                }
            }
        } catch (e) {
            console.log("[BAILEYS SCAN] skip:", pkgPath, e.message);
        }
    }

    return results;
}

// ═══ REPLACE VERSI BAILEYS DI SEMUA package.json ═══
function replaceBaileysVersion(extractDir, newVersion) {
    const results = [];
    const pkgFiles = [];

    function walk(dir) {
        let items;
        try { items = fs.readdirSync(dir, { withFileTypes: true }); }
        catch { return; }

        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                if (["node_modules", ".git", "build", "dist"].includes(item.name)) continue;
                walk(full);
            } else if (item.name === "package.json") {
                pkgFiles.push(full);
            }
        }
    }
    walk(extractDir);

    const baileysKeys = [
        "@whiskeysockets/baileys",
        "baileys",
        "@adiwajshing/baileys"
    ];

    for (const pkgPath of pkgFiles) {
        if (!fs.existsSync(pkgPath)) continue;
        try {
            const content = fs.readFileSync(pkgPath, "utf8");
            const pkg = JSON.parse(content);
            let changed = false;
            const changes = [];

            for (const key of baileysKeys) {
                if (pkg.dependencies && pkg.dependencies[key]) {
                    const oldVer = pkg.dependencies[key];
                    pkg.dependencies[key] = newVersion;
                    changes.push(`${key}: ${oldVer} → ${newVersion}`);
                    changed = true;
                }
                if (pkg.devDependencies && pkg.devDependencies[key]) {
                    const oldVer = pkg.devDependencies[key];
                    pkg.devDependencies[key] = newVersion;
                    changes.push(`${key} (dev): ${oldVer} → ${newVersion}`);
                    changed = true;
                }
            }

            if (changed) {
                fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2), "utf8");
                results.push({
                    path: path.relative(extractDir, pkgPath),
                    changes
                });
                console.log("[BAILEYS REPLACE]", pkgPath, changes.join(", "));
            }
        } catch (e) {
            console.log("[BAILEYS REPLACE] skip:", pkgPath, e.message);
        }
    }

    return results;
}

// ═══ ZIP ULANG FOLDER ═══
function rezipFolder(sourceDir, destZipPath) {
    return new Promise((resolve, reject) => {
        try {
            const zip = new AdmZip();
            zip.addLocalFolder(sourceDir);
            zip.writeZip(destZipPath);
            resolve(destZipPath);
        } catch (e) {
            reject(e);
        }
    });
}

// ═══ UPLOAD ZIP KE GITHUB ═══
async function uploadZipToGitHub(jobId, zipPath, repoZipPath) {
    const gh = require("./github-builder");
    const zipBuf = fs.readFileSync(zipPath);
    console.log("[RENAME BAILEYS] zip size:", zipBuf.length, "bytes");

    if (typeof gh.putFile === "function") {
        try {
            const b64 = zipBuf.toString("base64");
            await gh.putFile(repoZipPath, b64, `[${jobId}] upload baileys project`);
            return { ok: true, method: "gh.putFile" };
        } catch (e) { console.log("[UPLOAD] gh.putFile fail:", e.message); }
    }

    if (typeof gh.uploadFile === "function") {
        try {
            await gh.uploadFile(repoZipPath, zipBuf, `[${jobId}] upload baileys project`);
            return { ok: true, method: "gh.uploadFile" };
        } catch (e) { console.log("[UPLOAD] gh.uploadFile fail:", e.message); }
    }

    try {
        const token = cfg.GITHUB.TOKEN;
        const user = cfg.GITHUB.USERNAME;
        const repo = cfg.GITHUB.REPO;
        const branch = cfg.GITHUB.BRANCH || "main";
        const apiUrl = `https://api.github.com/repos/${user}/${repo}/contents/${repoZipPath}`;

        let sha = null;
        try {
            const check = await axios.get(apiUrl, {
                headers: { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot" },
                params: { ref: branch },
                validateStatus: s => s < 500
            });
            if (check.status === 200 && check.data && check.data.sha) sha = check.data.sha;
        } catch {}

        const payload = { message: `[${jobId}] upload baileys project`, content: zipBuf.toString("base64"), branch };
        if (sha) payload.sha = sha;

        const res = await axios.put(apiUrl, payload, {
            headers: {
                Authorization: `token ${token}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json"
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            timeout: 120000
        });

        if (res.status === 200 || res.status === 201) return { ok: true, method: "axios" };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        const msg = e.response ? `HTTP ${e.response.status}: ${JSON.stringify(e.response.data).slice(0, 200)}` : e.message;
        return { ok: false, error: msg };
    }
}

// ═══ HAPUS FILE DARI GITHUB ═══
async function deleteFromGitHub(repoPath) {
    try {
        const token = cfg.GITHUB.TOKEN;
        const user = cfg.GITHUB.USERNAME;
        const repo = cfg.GITHUB.REPO;
        const branch = cfg.GITHUB.BRANCH || "main";
        const apiUrl = `https://api.github.com/repos/${user}/${repo}/contents/${repoPath}`;

        const check = await axios.get(apiUrl, {
            headers: { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot" },
            params: { ref: branch },
            validateStatus: s => s < 500
        });

        if (check.status !== 200 || !check.data || !check.data.sha) return false;

        await axios.delete(apiUrl, {
            headers: {
                Authorization: `token ${token}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json"
            },
            data: { message: `cleanup ${repoPath}`, sha: check.data.sha, branch },
            timeout: 60000
        });
        return true;
    } catch (e) {
        console.log("[CLEANUP] fail:", e.message);
        return false;
    }
}

// ═══ BUILD CALLBACK DARI MENU ═══
router.registerCallback("menu_renamebaileys", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < cfg.CREDIT_PER_USE) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Ganti versi <code>@whiskeysockets/baileys</code>\n` +
            `▸ Kirim: <b>file .zip</b> project lu\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `▸ Hasil: File .zip baru dengan versi baileys yang lu pilih\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Versi Baileys yang tersedia:</b>\n` +
            BAILEYS_VERSIONS.slice(0, 8).map(v => `• <code>${v.label}</code>`).join("\n") +
            `\n• ...dan ${BAILEYS_VERSIONS.length - 8} lainnya\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        ctx.setState(user.id, "renamebaileys_await_zip", {});
        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
        });
    } catch (e) { console.log("[RENAME BAILEYS MENU ERR]", e.message); }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("renamebaileys_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip project lu.</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "project.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        if (msg.document.file_size > 20 * 1024 * 1024) {
            return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 20MB.</b>`, { parse_mode: "HTML" });
        }

        const creditCheck = checkAndDeductCredit(ctx, { id: userId }, cfg.CREDIT_PER_USE);
        if (!creditCheck.ok) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ ${creditCheck.error}</b>`, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "▶️ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
            });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(5)}]</code> <b>5%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Download file dari Telegram\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        const jobId = `baileys_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        let zipPath;
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const res = await axios.get(fileLink, {
                responseType: "arraybuffer",
                timeout: 60000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            zipPath = path.join(workDir, fname);
            fs.writeFileSync(zipPath, Buffer.from(res.data));
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download file:</b>\n<code>${e.message}</code>`);
        }

        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(20)}]</code> <b>20%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Extract & scan package.json\n` +
            `<i>Mohon tunggu...</i>`);

        const extractDir = path.join(workDir, "extracted");
        fs.mkdirSync(extractDir, { recursive: true });

        try {
            const zip = new AdmZip(zipPath);
            zip.extractAllTo(extractDir, true);
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal extract zip:</b>\n<code>${e.message}</code>`);
        }

        const found = scanBaileysVersion(extractDir);
        console.log("[RENAME BAILEYS] found:", JSON.stringify(found));

        if (found.length === 0) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Baileys tidak ditemukan di package.json</b>\n\n` +
                `Cek: <code>@whiskeysockets/baileys</code>, <code>baileys</code>, atau <code>@adiwajshing/baileys</code>`);
        }

        ctx.setState(userId, "renamebaileys_pick_version", {
            jobId, zipPath, fname, extractDir, workDir,
            loadingMsgId: loading.message_id,
            found
        });

        const foundText = found.map(f =>
            `• <code>${f.package}</code>: <b>${f.version}</b>\n  <i>${f.path} (${f.depType})</i>`
        ).join("\n");

        const versionButtons = [];
        for (let i = 0; i < BAILEYS_VERSIONS.length; i += 2) {
            const row = [];
            for (let j = 0; j < 2; j++) {
                if (i + j < BAILEYS_VERSIONS.length) {
                    const v = BAILEYS_VERSIONS[i + j];
                    row.push({
                        text: `▸ ${v.label}`,
                        callback_data: `renamebaileys_pick:${i + j}`,
                        style: "primary"
                    });
                }
            }
            versionButtons.push(row);
        }
        versionButtons.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 PILIH VERSI BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Job ID: <code>${jobId}</code>\n` +
            `▸ File: <code>${fname}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Versi Baileys yang ketemu:</b>\n${foundText}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Pilih versi baru:</b>`,
            { reply_markup: { inline_keyboard: versionButtons } });
    } catch (e) {
        console.log("[RENAME BAILEYS AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ CALLBACK: PILIH VERSI ═══
router.registerCallback("renamebaileys_pick", async (bot, q, data, user, ctx) => {
    let workDir = null;
    try {
        const idx = parseInt(data.split(":")[1], 10);
        const picked = BAILEYS_VERSIONS[idx];
        if (!picked) {
            return bot.answerCallbackQuery(q.id, { text: "Versi tidak valid", show_alert: true });
        }

        const prev = ctx.getState(user.id) || {};
        const { jobId, zipPath, fname, extractDir } = prev;
        workDir = prev.workDir;

        if (!jobId || !zipPath || !extractDir) {
            ctx.clearState(user.id);
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis. Kirim zip ulang.", show_alert: true });
        }

        const chatId = q.message.chat.id;
        const loadingMsgId = prev.loadingMsgId || q.message.message_id;

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(40)}]</code> <b>40%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Replace versi di package.json\n` +
            `▸ <b>Versi baru</b>: <code>${picked.label}</code>\n` +
            `▸ <b>Value</b>: <code>${picked.value}</code>\n` +
            `<i>Mohon tunggu...</i>`);

        const changes = replaceBaileysVersion(extractDir, picked.value);
        console.log("[RENAME BAILEYS] changes:", JSON.stringify(changes));

        if (changes.length === 0) {
            ctx.clearState(user.id);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Tidak ada package.json yang diubah</b>`);
        }

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(60)}]</code> <b>60%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Re-zip project\n` +
            `<i>Mohon tunggu...</i>`);

        const newZipPath = path.join(workDir, `baileys_${picked.value.replace(/[^a-z0-9]/gi, "_")}_${fname}`);
        try {
            await rezipFolder(extractDir, newZipPath);
        } catch (e) {
            ctx.clearState(user.id);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal re-zip:</b>\n<code>${e.message}</code>`);
        }

        const newSize = fs.statSync(newZipPath).size;
        console.log("[RENAME BAILEYS] new zip:", newZipPath, newSize, "bytes");

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(80)}]</code> <b>80%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Upload ke GitHub\n` +
            `<i>Mohon tunggu...</i>`);

        const repoZipPath = `uploads/${jobId}/baileys_project.zip`;
        const uploadResult = await uploadZipToGitHub(jobId, newZipPath, repoZipPath);

        if (!uploadResult.ok) {
            ctx.clearState(user.id);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal upload ke GitHub</b>\n\n<code>${String(uploadResult.error).slice(0, 200)}</code>`);
        }

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(95)}]</code> <b>95%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Trigger build workflow\n` +
            `<i>Mohon tunggu...</i>`);

        const gh = require("./github-builder");
        const workflow = cfg.GITHUB.WORKFLOW_NATIVE || "native-build.yml";
        const triggerTime = Date.now();

        let trigger;
        try {
            trigger = await gh.triggerWorkflow(workflow, {
                target_dir: `uploads/${jobId}`,
                zip_file: "baileys_project.zip",
                build_task: "assembleRelease",
                build_flavor: "",
                java_version: "17"
            });
        } catch (e) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            ctx.clearState(user.id);
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal trigger workflow:</b>\n<code>${e.message}</code>`);
        }

        if (!trigger || !trigger.ok) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            ctx.clearState(user.id);
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal trigger workflow:</b>\n<code>${trigger ? trigger.error : "unknown"}</code>`);
        }

        buildNotifier.sendBuildNotif(bot, {
            status: "processing",
            feature: `Rename Baileys — ${picked.label}`,
            baseName: fname,
            user: user,
            subtitle: `Job: ${jobId}`,
            fields: [
                { label: "Versi Baru", value: picked.label },
                { label: "Value", value: picked.value },
                { label: "File", value: fname },
                { label: "Changes", value: String(changes.length) },
                { label: "Status", value: "Uploaded to GitHub" }
            ]
        }).catch(e => console.log("[NOTIF RENAME BAILEYS ERR]", e.message));

        let run = null;
        for (let i = 0; i < 12; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await gh.getLatestRun(workflow, triggerTime); } catch {}
            if (run) break;
        }

        if (!run) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            ctx.clearState(user.id);
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Build timeout — GitHub ga response</b>`);
        }

        const runId = run.id;
        console.log("[RENAME BAILEYS] run id:", runId);

        const startTime = Date.now();
        const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;

        while (Date.now() - startTime < maxWait) {
            let status = null;
            try { status = await gh.getRunStatus(runId); } catch {}

            if (!status) {
                await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
                continue;
            }

            const jobStatus = status.status;
            const conclusion = status.conclusion;
            const elapsed = Date.now() - startTime;

            let pct = 95 + Math.min(Math.floor((elapsed / 300000) * 4), 4);
            if (jobStatus === "completed") pct = 100;

            await safeEdit(bot, chatId, loadingMsgId,
                `<b>𖡛 RENAME BAILEYS</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `<code>[${progressBar(pct)}]</code> <b>${pct}%</b>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ <b>Status</b>: ${jobStatus === "in_progress" ? "Building di GitHub" : jobStatus}\n` +
                `▸ <b>Versi</b>: <code>${picked.label}</code>\n` +
                `▸ <b>Job ID</b>: <code>${jobId}</code>\n` +
                `▸ <b>Waktu</b>: <code>${(elapsed / 1000).toFixed(0)}s</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `<i>${jobStatus === "completed" ? "Selesai." : "Mohon tunggu..."}</i>`);

            if (jobStatus === "completed") {
                try { await deleteFromGitHub(repoZipPath); } catch {}
                ctx.clearState(user.id);

                if (conclusion === "success") {
                    const actionsUrl = `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`;
                    const artifactsUrl = `${actionsUrl}#artifacts`;
                    const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);

                    let artifacts = [];
                    try { artifacts = await gh.getRunArtifacts(runId); } catch {}

                    await safeEdit(bot, chatId, loadingMsgId,
                        `<b>✓ RENAME BAILEYS SUCCESS</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▸ <b>File</b>: <code>${fname}</code>\n` +
                        `▸ <b>Versi Baru</b>: <code>${picked.label}</code>\n` +
                        `▸ <b>Value</b>: <code>${picked.value}</code>\n` +
                        `▸ <b>Changes</b>: <code>${changes.length}</code>\n` +
                        `▸ <b>Artifacts</b>: <code>${artifacts.length}</code>\n` +
                        `▸ <b>Waktu</b>: ${elapsedSec}s\n` +
                        `▸ <b>Job ID</b>: <code>${jobId}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n\n` +
                        `<b>▸ Download Link:</b>\n` +
                        `<i>Klik tombol di bawah</i>`,
                        {
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: "𖡛 Download APK / AAB", url: artifactsUrl, style: "success" }],
                                    [{ text: "𖡛 Lihat Actions", url: actionsUrl, style: "primary" }],
                                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                                ]
                            }
                        });

                    buildNotifier.sendBuildNotif(bot, {
                        status: "success",
                        feature: `Rename Baileys — ${picked.label}`,
                        baseName: fname,
                        user: user,
                        subtitle: `${artifacts.length} artifact siap`,
                        fields: [
                            { label: "Versi Baru", value: picked.label },
                            { label: "Value", value: picked.value },
                            { label: "Changes", value: String(changes.length) },
                            { label: "Artifacts", value: String(artifacts.length) },
                            { label: "Waktu", value: elapsedSec + "s" },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(e => console.log("[NOTIF RENAME BAILEYS SUCCESS ERR]", e.message));
                } else {
                    let errorLog = "";
                    try {
                        const logs = await gh.getRunLogs(runId);
                        if (logs && logs.length > 0) errorLog = logs.toString("utf8").slice(-3000);
                    } catch {}

                    const errorPath = path.join(TMP_DIR, `${jobId}_error.txt`);
                    fs.writeFileSync(errorPath,
                        `=== ✕ RENAME BAILEYS FAILED ===\n` +
                        `File: ${fname}\n` +
                        `Versi Baru: ${picked.label}\n` +
                        `Job ID: ${jobId}\nRun ID: ${runId}\nConclusion: ${conclusion}\n` +
                        `Time: ${new Date().toISOString()}\n` +
                        `\n=== LOG ===\n${errorLog}\n\n=== LINK ===\n` +
                        `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`,
                        "utf8");

                    await safeEdit(bot, chatId, loadingMsgId,
                        `<b>✕ RENAME BAILEYS FAILED</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▸ File: <code>${fname}</code>\n` +
                        `▸ Versi Baru: <code>${picked.label}</code>\n` +
                        `▸ Job ID: <code>${jobId}</code>\n` +
                        `▸ Conclusion: <code>${conclusion}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━`);

                    try {
                        await bot.sendDocument(chatId, errorPath, {
                            caption: `<b>✕ RENAME BAILEYS FAILED</b>\n\n𖡛 File: <code>${fname}</code>\n𖡛 Job ID: <code>${jobId}</code>`,
                            parse_mode: "HTML"
                        }, { filename: `${jobId}_error.txt`, contentType: "text/plain" });
                    } catch (e) {
                        console.log("[SEND ERROR LOG FAIL]", e.message);
                    }

                    buildNotifier.sendBuildNotif(bot, {
                        status: "failed",
                        feature: `Rename Baileys — ${picked.label}`,
                        baseName: fname,
                        user: user,
                        subtitle: `Conclusion: ${conclusion}`,
                        fields: [
                            { label: "File", value: fname },
                            { label: "Versi Baru", value: picked.label },
                            { label: "Conclusion", value: conclusion },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(e => console.log("[NOTIF RENAME BAILEYS FAILED ERR]", e.message));

                    try { fs.unlinkSync(errorPath); } catch {}
                }

                try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
                return;
            }

            await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
        }

        // TIMEOUT
        try { await deleteFromGitHub(repoZipPath); } catch {}
        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        ctx.clearState(user.id);

        buildNotifier.sendBuildNotif(bot, {
            status: "failed",
            feature: `Rename Baileys — ${picked.label}`,
            baseName: fname,
            user: user,
            subtitle: "Build timeout > 60 menit",
            fields: [
                { label: "File", value: fname },
                { label: "Job ID", value: jobId },
                { label: "Reason", value: "Timeout" }
            ]
        }).catch(() => {});

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>⏱ Build timeout (>60 menit)</b>\n\n▸ File: <code>${fname}</code>\n▸ Cek: https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`);
    } catch (e) {
        console.log("[RENAME BAILEYS PICK ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        try { ctx.clearState(user.id); } catch {}
    }
});

module.exports = { checkAndDeductCredit, progressBar, BAILEYS_VERSIONS, scanBaileysVersion, replaceBaileysVersion };
console.log("[RENAME BAILEYS] module loaded");