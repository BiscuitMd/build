const router = require("./router");
const cfg = require("../config");
const vm = require("vm");
const notify = require("./notify");
const fs = require("fs");
const path = require("path");

// ═══════════════════════════════════════════
// PENDING FIX — FILE BASED
// ═══════════════════════════════════════════
const PENDING_FILE = path.join(__dirname, "..", "database", "pending_fix.json");

function readPending() {
    try { return JSON.parse(fs.readFileSync(PENDING_FILE, "utf8")); } catch { return {}; }
}

function writePending(data) {
    fs.writeFileSync(PENDING_FILE, JSON.stringify(data, null, 2), "utf8");
}

function setPending(userId, payload) {
    const data = readPending();
    data[String(userId)] = { ...payload, savedAt: Date.now() };
    writePending(data);
}

function getPending(userId) {
    const data = readPending();
    return data[String(userId)] || null;
}

function deletePending(userId) {
    const data = readPending();
    delete data[String(userId)];
    writePending(data);
}

setInterval(() => {
    try {
        const data = readPending();
        const now = Date.now();
        let changed = false;
        for (const uid in data) {
            if (now - (data[uid].savedAt || 0) > 30 * 60 * 1000) {
                delete data[uid];
                changed = true;
            }
        }
        if (changed) writePending(data);
    } catch {}
}, 5 * 60 * 1000);

// ═══════════════════════════════════════════
// HELPER: ESCAPE HTML
// ═══════════════════════════════════════════
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══════════════════════════════════════════
// CHECK SYNTAX — robust
// ═══════════════════════════════════════════
function checkSyntax(code) {
    const errors = [];

    // ─── 1. Parse via vm sebagai SCRIPT ───
    try {
        new vm.Script(code, { filename: "user_input.js" });
    } catch (e) {
        errors.push({
            type: "SyntaxError",
            message: e.message,
            line: e.lineNumber || 0,
            raw: e
        });
    }

    // ─── 2. Cek brace balance GLOBAL (bukan per-line) ───
    const braceBalance = countBalance(code);
    if (braceBalance.curly !== 0) {
        errors.push({
            type: "CurlyBrace",
            message: `Curly brace tidak seimbang (${braceBalance.curly > 0 ? "+" : ""}${braceBalance.curly}). Cek pembuka/penutup { }`
        });
    }
    if (braceBalance.paren !== 0) {
        errors.push({
            type: "Parenthesis",
            message: `Tanda kurung tidak seimbang (${braceBalance.paren > 0 ? "+" : ""}${braceBalance.paren}). Cek ( )`
        });
    }
    if (braceBalance.bracket !== 0) {
        errors.push({
            type: "Bracket",
            message: `Square bracket tidak seimbang (${braceBalance.bracket > 0 ? "+" : ""}${braceBalance.bracket}). Cek [ ]`
        });
    }

    // ─── 3. Cek try tanpa catch/finally ───
    const tryErrors = checkTryWithoutCatch(code);
    errors.push(...tryErrors);

    return errors;
}

// Hitung brace/paren/bracket balance GLOBAL (strip string & komentar dulu)
function countBalance(code) {
    const stripped = stripStringsAndComments(code);
    let curly = 0, paren = 0, bracket = 0;
    for (const ch of stripped) {
        if (ch === "{") curly++;
        else if (ch === "}") curly--;
        else if (ch === "(") paren++;
        else if (ch === ")") paren--;
        else if (ch === "[") bracket++;
        else if (ch === "]") bracket--;
    }
    return { curly, paren, bracket };
}

// Strip string literal & komentar biar brace di dalam string ga kehitung
function stripStringsAndComments(code) {
    let out = "";
    let i = 0;
    const n = code.length;
    while (i < n) {
        const c = code[i];

        // Line comment
        if (c === "/" && code[i + 1] === "/") {
            while (i < n && code[i] !== "\n") i++;
            continue;
        }

        // Block comment
        if (c === "/" && code[i + 1] === "*") {
            i += 2;
            while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
            i += 2;
            continue;
        }

        // String ' atau "
        if (c === "'" || c === '"') {
            const q = c;
            i++;
            while (i < n && code[i] !== q) {
                if (code[i] === "\\") i++;
                i++;
            }
            i++;
            continue;
        }

        // Template literal
        if (c === "`") {
            i++;
            while (i < n && code[i] !== "`") {
                if (code[i] === "\\") i++;
                i++;
            }
            i++;
            continue;
        }

        out += c;
        i++;
    }
    return out;
}

// Cek try { ... } tanpa catch/finally
function checkTryWithoutCatch(code) {
    const errors = [];
    const lines = code.split("\n");

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const tryMatch = line.match(/\btry\s*\{/);
        if (!tryMatch) continue;

        // Scan dari posisi try, cari } penutup try
        const startIdx = line.indexOf("try");
        const braceStart = line.indexOf("{", startIdx);
        if (braceStart === -1) continue;

        // Gabung sisa code dari sini
        const restLines = lines.slice(i);
        const restCode = restLines.join("\n");

        // Cari pasangan brace try
        let depth = 0;
        let endIdx = -1;
        let inString = false;
        let stringChar = "";
        for (let j = braceStart; j < restCode.length; j++) {
            const ch = restCode[j];

            if (inString) {
                if (ch === "\\") { j++; continue; }
                if (ch === stringChar) inString = false;
                continue;
            }

            if (ch === "'" || ch === '"' || ch === "`") {
                inString = true;
                stringChar = ch;
                continue;
            }

            if (ch === "{") depth++;
            else if (ch === "}") {
                depth--;
                if (depth === 0) { endIdx = j; break; }
            }
        }

        if (endIdx === -1) continue; // try belum ketutup — bakal ke-detect di brace balance

        // Cek setelah } try: apakah ada catch/finally?
        const after = restCode.slice(endIdx + 1).trimStart();
        const afterFirst = after.slice(0, 50);

        if (!/^catch\b/.test(after) && !/^finally\b/.test(after)) {
            errors.push({
                type: "TryWithoutCatch",
                message: `try { } di line ${i + 1} tidak punya catch/finally.`,
                line: i + 1
            });
        }
    }

    return errors;
}

// ═══════════════════════════════════════════
// AUTO FIX — beneran fix
// ═══════════════════════════════════════════
function autoFix(code) {
    let fixed = code;

    // 1. Normalisasi quote
    fixed = fixed.replace(/[""]/g, '"').replace(/['']/g, "'");

    // 2. Normalisasi tanda baca full-width
    fixed = fixed.replace(/；/g, ";").replace(/，/g, ",");
    fixed = fixed.replace(/（/g, "(").replace(/）/g, ")");
    fixed = fixed.replace(/｛/g, "{").replace(/｝/g, "}");
    fixed = fixed.replace(/：/g, ":");

    // 3. Fix try tanpa catch → tambah catch kosong
    fixed = fixTryWithoutCatch(fixed);

    // 4. Fix brace kurang → tambah } di akhir
    const bal = countBalance(fixed);
    if (bal.curly > 0) {
        fixed += "\n" + "}".repeat(bal.curly);
    }
    if (bal.paren > 0) {
        // Cari posisi terakhir yang cocok — paling aman tambah di akhir
        fixed = fixed.replace(/([^\n])\s*$/, "$1" + ")".repeat(bal.paren));
    }

    return fixed;
}

function fixTryWithoutCatch(code) {
    const lines = code.split("\n");
    const out = [];

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        out.push(line);

        const tryMatch = line.match(/\btry\s*\{/);
        if (!tryMatch) continue;

        // Gabung dari sini buat scan
        const restLines = lines.slice(i);
        const restCode = restLines.join("\n");
        const braceStart = line.indexOf("{", line.indexOf("try"));
        if (braceStart === -1) continue;

        // Cari } penutup try
        let depth = 0;
        let endIdx = -1;
        let inString = false;
        let stringChar = "";
        for (let j = braceStart; j < restCode.length; j++) {
            const ch = restCode[j];
            if (inString) {
                if (ch === "\\") { j++; continue; }
                if (ch === stringChar) inString = false;
                continue;
            }
            if (ch === "'" || ch === '"' || ch === "`") {
                inString = true;
                stringChar = ch;
                continue;
            }
            if (ch === "{") depth++;
            else if (ch === "}") {
                depth--;
                if (depth === 0) { endIdx = j; break; }
            }
        }

        if (endIdx === -1) continue;

        const after = restCode.slice(endIdx + 1).trimStart();
        if (/^catch\b/.test(after) || /^finally\b/.test(after)) continue;

        // try tanpa catch — sisipkan `catch (e) { console.error(e); }` setelah } try
        const endLineIdx = i + restCode.slice(0, endIdx).split("\n").length - 1;
        const endLineText = restLines[restCode.slice(0, endIdx).split("\n").length - 1];
        const beforeBrace = endLineText.slice(0, endLineText.lastIndexOf("}"));

        // Update baris terakhir try biar ditambahin catch setelahnya
        if (endLineIdx >= i) {
            // Sisa baris yg udah di-push oleh loop — pop dulu, ganti
            const idxInOut = out.length - 1;
            // Simple: tambah line baru setelah baris try terakhir
            // Cari index baris terakhir yg di-push
            while (out.length > i + 1 + (endLineIdx - i)) {
                out.pop();
            }
            out.push(endLineText + " catch (e) { console.error(e); }");
        }
    }

    return out.join("\n");
}

// ═══════════════════════════════════════════
// MENU: CEK SYNTAX ERROR
// ═══════════════════════════════════════════
router.registerCallback("menu_cekerror", async (bot, q, data, user, ctx) => {
    try {
        console.log("[SYNTAX] menu_cekerror clicked by", user.id);

        const caption =
            `<b>𖡛 CEK SYNTAX ERROR</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Kirim file .txt / .js atau ketik langsung.</i>\n\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        ctx.setState(user.id, "syntax_await", {});
        console.log("[SYNTAX] state set → syntax_await");

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
        });
    } catch (e) {
        console.log("[SYNTAX MENU ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// HANDLE INPUT
// ═══════════════════════════════════════════
router.registerMessage("syntax_await", async (bot, msg, state, ctx) => {
    try {
        console.log("[SYNTAX] === syntax_await TRIGGERED ===");
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        let loading;
        try {
            loading = await bot.sendMessage(chatId, `<b>𖡛 Menerima input...</b>`, { parse_mode: "HTML" });
        } catch (e) {
            console.log("[SYNTAX] loading send fail:", e.message);
        }

        let code = "";

        if (msg.document) {
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const axios = require("axios");
                const res = await axios.get(fileLink, { responseType: "text", timeout: 15000 });
                code = res.data;
                console.log("[SYNTAX] code length:", code.length);
            } catch (e) {
                console.log("[SYNTAX] getFileLink fail:", e.message);
                ctx.clearState(userId);
                if (loading) {
                    try {
                        return bot.editMessageText(
                            `<b>✕ Gagal baca file:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                            { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                    } catch {}
                }
                return;
            }
        } else if (msg.text && msg.text.toLowerCase() !== "batal") {
            code = msg.text;
            console.log("[SYNTAX] text input, length:", code.length);
        } else {
            return;
        }

        if (code.length < 10) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    return bot.editMessageText(
                        `<b>✕ Code terlalu pendek.</b>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch {}
            }
            return;
        }

        const user = ctx.db.getUser(userId);
        if (user.credit < 1) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    return bot.editMessageText(
                        `<b>✕ Credit habis!</b>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch {}
            }
            return;
        }

        ctx.db.saveUser(userId, { credit: user.credit - 1 });

        const errors = checkSyntax(code);
        const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

        // ═══ KALAU GA ADA ERROR ═══
        if (errors.length === 0) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    await bot.editMessageText(
                        `<b>✓ SYNTAX VALID</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `𖡛 Baris: <code>${code.split("\n").length}</code>\n` +
                        `𖡛 Sisa Credit: <code>${ctx.db.getUser(userId).credit}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━`,
                        {
                            chat_id: chatId,
                            message_id: loading.message_id,
                            parse_mode: "HTML",
                            reply_markup: { inline_keyboard: [[{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]] }
                        });
                } catch {}
            }

            try {
                await notify.notifySuccess(bot, "SYNTAX VALID", [
                    { label: "User", value: msg.from.first_name || "User" },
                    { label: "Baris", value: String(code.split("\n").length) },
                    { label: "Waktu", value: waktu }
                ]).catch(() => {});
            } catch {}
            return;
        }

        // ═══ KALAU ADA ERROR ═══
        const errList = errors.map((e, i) =>
            `<b>${i + 1}. ${escHtml(e.type)}</b>\n` +
            `<code>${escHtml(e.message.slice(0, 150))}</code>` +
            (e.line ? `\n▸ Line: <b>${e.line}</b>` : "")
        ).join("\n\n");

        setPending(userId, { code, errors });
        ctx.clearState(userId);

        if (loading) {
            try {
                await bot.editMessageText(
                    `<b>✕ ${errors.length} ERROR DITEMUKAN</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `${errList}\n` +
                    `━━━━━━━━━━━━━━━━━━━━`,
                    {
                        chat_id: chatId,
                        message_id: loading.message_id,
                        parse_mode: "HTML",
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "𖡛 AUTO FIX", callback_data: "syntax_fix", style: "success" }],
                                [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
                            ]
                        }
                    });
            } catch {}
        }

        try {
            await notify.notifyFailed(bot, "SYNTAX ERROR", [
                { label: "User", value: msg.from.first_name || "User" },
                { label: "Error", value: errors.length + " error" },
                { label: "Waktu", value: waktu }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[SYNTAX AWAIT ERR]", e.message);
        console.log("[SYNTAX AWAIT STACK]", e.stack);
    }
});

// ═══════════════════════════════════════════
// AUTO FIX
// ═══════════════════════════════════════════
router.registerCallback("syntax_fix", async (bot, q, data, user, ctx) => {
    try {
        console.log("[SYNTAX FIX] === clicked by", user.id, "===");
        await bot.answerCallbackQuery(q.id, { text: "Memproses..." }).catch(() => {});

        const pend = getPending(user.id);

        if (!pend) {
            console.log("[SYNTAX FIX] pending NOT FOUND for", user.id);
            return bot.answerCallbackQuery(q.id, {
                text: "Sesi expired. Cek ulang syntax lu.",
                show_alert: true
            }).catch(() => {});
        }

        console.log("[SYNTAX FIX] processing", pend.errors ? pend.errors.length : 0, "errors");

        // ═══ MULTI-PASS AUTO FIX ═══
        let fixed = pend.code;
        let iteration = 0;
        const maxIter = 5;
        let finalErrors = [];

        while (iteration < maxIter) {
            iteration++;
            fixed = autoFix(fixed);
            finalErrors = checkSyntax(fixed);
            console.log(`[SYNTAX FIX] iteration ${iteration}: ${finalErrors.length} errors remaining`);
            if (finalErrors.length === 0) break;
        }

        const status = finalErrors.length === 0
            ? `<b>✓ FIXED — NO ERROR</b>`
            : `<b>⚠️ MASIH ${finalErrors.length} ERROR</b>\n\n<i>Auto fix ga bisa handle error ini. Manual fix dulu.</i>`;

        // ═══ KIRIM FILE HASIL FIX ═══
        const buf = Buffer.from(fixed, "utf8");

        try {
            await bot.sendDocument(q.message.chat.id, buf, {
                caption:
                    `${status}\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `𖡛 File: <code>fixed_function.js</code>\n` +
                    `𖡛 Size: ${buf.length} bytes\n` +
                    `𖡛 Baris: ${fixed.split("\n").length}\n` +
                    `𖡛 Iterasi: ${iteration}x\n` +
                    `━━━━━━━━━━━━━━━━━━━━`,
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Cek Ulang", callback_data: "menu_cekerror", style: "success" }],
                        [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            }, { filename: "fixed_function.js", contentType: "text/javascript" });
        } catch (e) {
            console.log("[SYNTAX FIX] sendDocument FAIL:", e.message);
            try {
                const preview = escHtml(fixed.slice(0, 3500));
                await bot.sendMessage(q.message.chat.id,
                    `<b>${status}</b>\n\n<pre>${preview}</pre>`,
                    { parse_mode: "HTML" });
            } catch (e2) {
                console.log("[SYNTAX FIX] fallback fail:", e2.message);
            }
        }

        deletePending(user.id);

        try {
            await notify.notifySuccess(bot, "SYNTAX FIXED", [
                { label: "User", value: q.from.first_name || "User" },
                { label: "File", value: "fixed_function.js" },
                { label: "Iterasi", value: iteration + "x" }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[SYNTAX FIX ERR]", e.message);
        console.log("[SYNTAX FIX STACK]", e.stack);

        try {
            await bot.sendMessage(q.message.chat.id,
                `<b>✕ Gagal:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" }).catch(() => {});
        } catch {}

        await bot.answerCallbackQuery(q.id, {
            text: "Error: " + e.message.slice(0, 100),
            show_alert: true
        }).catch(() => {});
    }
});

module.exports = { checkSyntax, autoFix };
console.log("[SYNTAX] module loaded");