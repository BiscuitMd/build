// ═══════════════════════════════════════════
// GATE — Cek join channel
// v2 — Cache permanent kalau user udah join
// ═══════════════════════════════════════════

const cfg = require("../config");

const _joinCache = new Map();
const CACHE_TTL = 5 * 60 * 1000;

async function checkJoin(bot, userId) {
    if (!cfg.CHANNELS || cfg.CHANNELS.length === 0) return { ok: true, missing: [] };

    const uid = String(userId);
    const cached = _joinCache.get(uid);

    if (cached && cached.result.ok && Date.now() - cached.at < CACHE_TTL) {
        return cached.result;
    }

    const missing = [];
    for (const ch of cfg.CHANNELS) {
        try {
            const chatId = ch.url.replace("https://t.me/", "@");
            const memberPromise = bot.getChatMember(chatId, userId);
            const timeoutPromise = new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 4000));
            const member = await Promise.race([memberPromise, timeoutPromise]);
            const valid = ["creator", "administrator", "member", "restricted"].includes(member.status);
            if (!valid) missing.push(ch);
        } catch {
            missing.push(ch);
        }
    }

    const result = { ok: missing.length === 0, missing };

    if (result.ok) {
        _joinCache.set(uid, { result, at: Date.now() });
    } else {
        _joinCache.delete(uid);
    }

    return result;
}

function joinKeyboard() {
    const kb = cfg.CHANNELS.map(ch => [{ text: `𖡛 Join ${ch.name}`, url: ch.url }]);
    kb.push([{ text: "✓ Saya Sudah Join", callback_data: "check_join", style: "danger" }]);
    return { inline_keyboard: kb };
}

async function sendNotif(bot, type, text) {
    if (!cfg.NOTIF_CHANNEL || cfg.NOTIF_CHANNEL === "-1001234567890") return;
    try {
        await bot.sendMessage(cfg.NOTIF_CHANNEL, `<b>${type}</b>\n\n${text}`, { parse_mode: "HTML" });
    } catch {}
}

module.exports = { checkJoin, joinKeyboard, sendNotif };