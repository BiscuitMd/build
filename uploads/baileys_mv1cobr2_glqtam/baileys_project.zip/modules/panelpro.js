// ═══════════════════════════════════════════
// PANEL PRO — Create Panel via Pterodactyl API
// v3 — Flow /create + /setconfig lengkap
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const panelApi = require("./panel-api");

// ═══ ICON SET ═══
const I = {
    bullet: "▸",
    bulletOut: "▪",
    dot: "●",
    circle: "◉",
    check: "✓",
    cross: "✕",
    star: "✦",
    arrow: "→",
    line: "─",
    pipe: "│",
    cornerTL: "╭",
    cornerTR: "╮",
    cornerBL: "╰",
    cornerBR: "╯",
    teeL: "├",
    doubleH: "═",
    diamond: "◆",
    square: "■",
    squareOut: "□",
};

// ═══ PANEL FILE ═══
const PANEL_FILE = path.join(__dirname, "..", "database", "panel.json");

function readPanel() {
    try {
        const raw = JSON.parse(fs.readFileSync(PANEL_FILE, "utf8"));
        if (!raw.users) raw.users = {};
        if (!raw.groups) raw.groups = [];
        if (!raw.servers) raw.servers = {};
        if (!raw.adp) raw.adp = { "1": {}, "2": {} };
        if (!raw.config) raw.config = {};
        return raw;
    } catch {
        return { users: {}, groups: [], servers: {}, adp: { "1": {}, "2": {} }, config: {} };
    }
}

function writePanel(d) {
    if (!d.users) d.users = {};
    if (!d.groups) d.groups = [];
    if (!d.servers) d.servers = {};
    if (!d.adp) d.adp = { "1": {}, "2": {} };
    if (!d.config) d.config = {};
    fs.writeFileSync(PANEL_FILE, JSON.stringify(d, null, 2), "utf8");
}

function isGroupAllowed(chatId) {
    const p = readPanel();
    if (String(chatId) === String(cfg.MAIN_GROUP_ID)) return true;
    return (p.groups || []).some(g => String(g) === String(chatId));
}

function canUsePanel(ctx, userId) {
    const p = readPanel();
    const uid = String(userId);
    const rec = p.users[uid];
    if (!rec) return { ok: false, error: "Belum di-add admin" };
    if (rec.credit < 1) return { ok: false, error: "Credit habis" };
    return { ok: true, record: rec };
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══════════════════════════════════════════
// FETCH EGGS (dari API, fallback ke EGG_15)
// ═══════════════════════════════════════════
async function fetchEggs(scope, nestId = 1) {
    console.log(`[PANELPRO] fetching eggs for ${scope} (nest ${nestId})`);

    const apiRes = await panelApi.listEggs(scope, nestId);

    if (apiRes.ok && apiRes.eggs && apiRes.eggs.length > 0) {
        console.log(`[PANELPRO] ✅ got ${apiRes.eggs.length} eggs from API`);
        return {
            ok: true,
            eggs: apiRes.eggs.map(e => ({
                id: e.attributes.id,
                name: e.attributes.name,
                docker_image: e.attributes.docker_image,
                startup: e.attributes.startup,
                source: "api"
            })),
            source: "api"
        };
    }

    console.log(`[PANELPRO] ⚠️ API fail (${apiRes.error}), fallback ke EGG_15`);

    // Fallback ke EGG_15
    const fallbackEggs = (cfg.EGG_15 || []).map(e => ({
        id: e.egg_id,
        name: e.name,
        docker_image: e.docker_image,
        startup: e.startup,
        source: "fallback",
        category: e.category
    }));

    return { ok: true, eggs: fallbackEggs, source: "fallback" };
}

// ═══════════════════════════════════════════
// COMMAND /create
// ═══════════════════════════════════════════
module.exports.handleCreate = async function (bot, msg, ctx) {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const chatType = msg.chat.type;

        // ═══ Cek group ═══
        if (chatType === "private") {
            return bot.sendMessage(chatId,
                `${I.cornerTL}${I.line.repeat(18)}${I.cornerTR}\n` +
                `${I.pipe} ${I.cross} HARUS DI GROUP\n` +
                `${I.cornerBL}${I.line.repeat(18)}${I.cornerBR}\n\n` +
                `Command <code>/create</code> cuma bisa di group yang udah di-add owner.`,
                { parse_mode: "HTML" });
        }

        if (!isGroupAllowed(chatId)) {
            return bot.sendMessage(chatId,
                `${I.cross} Group belum terdaftar\n\n` +
                `Owner kirim <code>/addgroup</code> dulu di group ini.`,
                { parse_mode: "HTML" });
        }

        // ═══ Cek akses ═══
        const isOwner = ctx.db.isOwner(msg.from.id);
        let actor = null;

        if (!isOwner) {
            const acc = canUsePanel(ctx, msg.from.id);
            if (!acc.ok) {
                return bot.sendMessage(chatId,
                    `${I.cross} ${acc.error}\n\n` +
                    `Hubungi owner buat add lu jadi admin panel.`,
                    { parse_mode: "HTML" });
            }
            actor = acc.record;
        }

        // ═══ Cek join channel ═══
        if (!isOwner) {
            try {
                const gate = require("./gate");
                const join = await gate.checkJoin(bot, msg.from.id);
                if (!join.ok) {
                    return bot.sendMessage(chatId,
                        `${I.cross} Join channel dulu!\n\n` +
                        `Ketik /start buat cek channel yang harus di-join.`,
                        { parse_mode: "HTML" });
                }
            } catch {}
        }

        // ═══ Pilih server ═══
        const scope = actor?.scope || (isOwner ? "both" : "illegal");
        const kb = [];

        kb.push([{ text: `${I.bullet} Server 1 (Ilegal)`, callback_data: "createpanel_srv:plta", style: "success" }]);

        if (scope === "legal" || scope === "both" || isOwner) {
            kb.push([{ text: `${I.bullet} Server 2 (Legal)`, callback_data: "createpanel_srv:pltc", style: "success" }]);
        }

        kb.push([{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]);

        await bot.sendMessage(chatId,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.star} CREATE PANEL ${I.star}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} PILIH SERVER\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server 1 = Ilegal\n` +
            `${I.pipe} ${I.bullet} Server 2 = Legal\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[CREATEPANEL ERR]", e.message);
        await bot.sendMessage(msg.chat.id, `${I.cross} Error: ${e.message.slice(0, 150)}`, { parse_mode: "HTML" });
    }
};

// ═══════════════════════════════════════════
// CALLBACK: PILIH SERVER
// ═══════════════════════════════════════════
router.registerCallback("createpanel_srv", async (bot, q, data, user, ctx) => {
    try {
        const scope = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        await bot.answerCallbackQuery(q.id, { text: "Loading eggs...", show_alert: false }).catch(() => {});

        // ═══ Cek config panel ═══
        const pc = panelApi.getPanelConfig(scope);
        if (!pc || !pc.URL || !pc.API_KEY || pc.API_KEY.startsWith("ptla_GANTI") || pc.API_KEY.startsWith("ptlc_GANTI")) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${I.cross} Panel config belum di-set\n\n` +
                `${I.bulletOut} Cek <code>config.js</code> → <code>PTERODACTYL.${scope.toUpperCase()}</code>\n` +
                `${I.bulletOut} Isi URL + API_KEY`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }

        // ═══ Fetch eggs ═══
        const nestId = pc.NEST_ID || 1;
        const res = await fetchEggs(scope, nestId);

        if (!res.ok || res.eggs.length === 0) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${I.cross} Gaada egg\n\n` +
                `${I.bulletOut} Cek panel lu punya egg atau engga`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }

        // ═══ Simpen state ═══
        ctx.setState(userId, "createpanel_pick_egg", {
            scope,
            eggs: res.eggs,
            source: res.source
        });

        // ═══ Bikin button per egg ═══
        const kb = [];
        const maxEggs = Math.min(res.eggs.length, 20);

        for (let i = 0; i < maxEggs; i += 2) {
            const row = [];
            const e1 = res.eggs[i];
            row.push({
                text: `${I.bullet} ${e1.name.slice(0, 20)}`,
                callback_data: `createpanel_egg:${e1.id}`,
                style: "primary"
            });
            if (i + 1 < maxEggs) {
                const e2 = res.eggs[i + 1];
                row.push({
                    text: `${I.bullet} ${e2.name.slice(0, 20)}`,
                    callback_data: `createpanel_egg:${e2.id}`,
                    style: "primary"
                });
            }
            kb.push(row);
        }
        kb.push([{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]);

        const scopeLabel = scope === "pltc" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";
        const sourceLabel = res.source === "api" ? "Panel API" : "Fallback";

        await safeEdit(bot, chatId, q.message.message_id,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.star} PILIH EGG ${I.star}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} INFO\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server  ${I.arrow}  <b>${scopeLabel}</b>\n` +
            `${I.pipe} ${I.bullet} Source  ${I.arrow}  <code>${sourceLabel}</code>\n` +
            `${I.pipe} ${I.bullet} Eggs    ${I.arrow}  <code>${res.eggs.length}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            { reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[CREATEPANEL SRV ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// CALLBACK: PILIH EGG → Minta username
// ═══════════════════════════════════════════
router.registerCallback("createpanel_egg", async (bot, q, data, user, ctx) => {
    try {
        const eggId = parseInt(data.split(":")[1]);
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        await bot.answerCallbackQuery(q.id, { text: "OK", show_alert: false }).catch(() => {});

        const st = ctx.getState(userId);
        if (!st || !st.eggs) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${I.cross} Sesi habis, ulangi /create`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }

        const egg = st.eggs.find(e => e.id === eggId);
        if (!egg) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${I.cross} Egg tidak valid`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }

        ctx.setState(userId, "createpanel_await_username", {
            scope: st.scope,
            egg,
            eggs: st.eggs
        });

        await safeEdit(bot, chatId, q.message.message_id,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.star} INPUT USERNAME ${I.star}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} EGG DIPILIH\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Egg  ${I.arrow}  <b>${egg.name}</b>\n` +
            `${I.pipe} ${I.bullet} ID   ${I.arrow}  <code>${egg.id}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} <b>Kirim username panel lu</b>\n` +
            `${I.bulletOut} 3-20 karakter\n` +
            `${I.bulletOut} Huruf kecil / angka / underscore\n` +
            `${I.bulletOut} Contoh: <code>admin01</code>`,
            { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
    } catch (e) {
        console.log("[CREATEPANEL EGG ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// MESSAGE: TERIMA USERNAME → CREATE PANEL
// ═══════════════════════════════════════════
router.registerMessage("createpanel_await_username", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const username = (msg.text || "").trim();

        if (!username) return;
        if (username.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        // ═══ Validasi ═══
        if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
            return bot.sendMessage(chatId,
                `${I.cross} Username invalid\n\n` +
                `${I.bulletOut} 3-20 karakter\n` +
                `${I.bulletOut} Huruf / angka / underscore`,
                { parse_mode: "HTML" });
        }

        const scope = state.scope;
        const egg = state.egg;

        ctx.clearState(userId);

        // ═══ Loading ═══
        const loading = await bot.sendMessage(chatId,
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} CREATING PANEL\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Username  ${I.arrow}  <code>${username}</code>\n` +
            `${I.pipe} ${I.bullet} Egg       ${I.arrow}  <b>${egg.name}</b>\n` +
            `${I.pipe} ${I.bullet} Status    ${I.arrow}  Processing...\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            { parse_mode: "HTML" });

        const updateProgress = async (status) => {
            try {
                await safeEdit(bot, chatId, loading.message_id,
                    `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.circle} CREATING PANEL\n` +
                    `${I.teeL}${I.line.repeat(20)}\n` +
                    `${I.pipe} ${I.bullet} Username  ${I.arrow}  <code>${username}</code>\n` +
                    `${I.pipe} ${I.bullet} Egg       ${I.arrow}  <b>${egg.name}</b>\n` +
                    `${I.pipe} ${I.bullet} Status    ${I.arrow}  ${status}\n` +
                    `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`);
            } catch {}
        };

        try {
            // ═══ STEP 1: Generate credential ═══
            await updateProgress("Generate credential");

            const pc = panelApi.getPanelConfig(scope);
            const domain = pc?.DOMAIN || "panel.local";
            const email = panelApi.generateEmail(username, domain);
            const password = panelApi.generatePassword(14);

            console.log(`[CREATEPANEL] email: ${email} | scope: ${scope}`);

            // ═══ STEP 2: Cek user udah ada? ═══
            await updateProgress("Cek user existing");

            const existing = await panelApi.getUserByEmail(scope, email);
            let userIdPanel = null;

            if (existing.ok && existing.user) {
                userIdPanel = existing.user.attributes.id;
                console.log(`[CREATEPANEL] user ${email} udah ada, id: ${userIdPanel}`);
            } else {
                // ═══ STEP 3: Create user ═══
                await updateProgress("Create user di panel");

                const newUser = await panelApi.createUser(scope, {
                    email,
                    username,
                    firstName: username,
                    lastName: "User",
                    password
                });

                if (!newUser.ok) {
                    throw new Error(`Create user gagal: ${newUser.error}`);
                }

                userIdPanel = newUser.user.id;
                console.log(`[CREATEPANEL] user created: ${userIdPanel}`);
            }

            // ═══ STEP 4: Cari allocation kosong ═══
            await updateProgress("Cari allocation kosong");

            const locationId = pc.DEFAULT_LOCATION || 1;
            const allocRes = await panelApi.getAllocations(scope, locationId);

            if (!allocRes.ok || !allocRes.allocations || allocRes.allocations.length === 0) {
                throw new Error(`Gaada allocation kosong di node ${locationId}`);
            }

            const allocation = allocRes.allocations[0].attributes;
            console.log(`[CREATEPANEL] allocation: ${allocation.id}`);

            // ═══ STEP 5: Create server ═══
            await updateProgress("Create server");

            const serverName = `${username}-server`;

            const serverRes = await panelApi.createServer(scope, {
                name: serverName,
                userId: userIdPanel,
                nestId: pc.NEST_ID || 1,
                eggId: egg.id,
                dockerImage: egg.docker_image,
                startup: egg.startup,
                environment: {},
                memory: pc.DEFAULT_MEMORY || 1024,
                disk: pc.DEFAULT_DISK || 2048,
                cpu: pc.DEFAULT_CPU || 50,
                allocationId: allocation.id,
                locationId,
                databases: pc.DEFAULT_DATABASES || 1,
                backups: pc.DEFAULT_BACKUPS || 1,
                allocations: pc.DEFAULT_ALLOCATIONS || 0
            });

            if (!serverRes.ok) {
                throw new Error(`Create server gagal: ${serverRes.error}`);
            }

            console.log(`[CREATEPANEL] server created: ${serverRes.server.id}`);

            // ═══ STEP 6: Kurangin credit ═══
            if (!ctx.db.isOwner(userId)) {
                const p = readPanel();
                if (p.users && p.users[userId]) {
                    p.users[userId].credit = Math.max(0, (p.users[userId].credit || 0) - 1);
                    writePanel(p);
                }
            }

            // ═══ STEP 7: Simpen server di DB ═══
            try {
                const p = readPanel();
                if (!p.servers) p.servers = {};
                p.servers[username] = {
                    username,
                    password,
                    email,
                    scope,
                    egg: egg.name,
                    eggId: egg.id,
                    serverId: serverRes.server.id,
                    userId: userIdPanel,
                    domain: pc.URL,
                    createdAt: Date.now(),
                    createdBy: userId
                };
                writePanel(p);
            } catch {}

            // ═══ STEP 8: Kirim ke DM ═══
            await updateProgress("Kirim credential ke DM");

            const scopeLabel = scope === "pltc" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";
            const loginUrl = pc.URL;

            const credentialMsg =
                `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
                `${I.pipe}  ${I.check} PANEL CREATED  ${I.pipe}\n` +
                `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
                `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} CREDENTIAL\n` +
                `${I.teeL}${I.line.repeat(22)}\n` +
                `${I.pipe} ${I.bullet} Username  ${I.arrow}  <code>${username}</code>\n` +
                `${I.pipe} ${I.bullet} Password  ${I.arrow}  <code>${password}</code>\n` +
                `${I.pipe} ${I.bullet} Email     ${I.arrow}  <code>${email}</code>\n` +
                `${I.pipe} ${I.bullet} Login URL ${I.arrow}  ${loginUrl}\n` +
                `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} SERVER INFO\n` +
                `${I.teeL}${I.line.repeat(22)}\n` +
                `${I.pipe} ${I.bullet} Server    ${I.arrow}  ${scopeLabel}\n` +
                `${I.pipe} ${I.bullet} Egg       ${I.arrow}  ${egg.name}\n` +
                `${I.pipe} ${I.bullet} Memory    ${I.arrow}  ${pc.DEFAULT_MEMORY || 1024} MB\n` +
                `${I.pipe} ${I.bullet} Disk      ${I.arrow}  ${pc.DEFAULT_DISK || 2048} MB\n` +
                `${I.pipe} ${I.bullet} CPU       ${I.arrow}  ${pc.DEFAULT_CPU || 50}%\n` +
                `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                `${I.arrow} <b>Login:</b>\n` +
                `${I.bulletOut} Buka ${loginUrl}\n` +
                `${I.bulletOut} Masukkan username + password\n\n` +
                `${I.star} <i>Simpan credential ini baik-baik</i>`;

            let sentToDM = false;
            try {
                await bot.sendMessage(userId, credentialMsg, { parse_mode: "HTML" });
                sentToDM = true;
                console.log(`[CREATEPANEL] sent to DM ${userId}`);
            } catch (e) {
                console.log("[CREATEPANEL] DM fail:", e.message);
            }

            // ═══ STEP 9: Update pesan di group ═══
            await safeEdit(bot, chatId, loading.message_id,
                `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                `${I.pipe} ${I.check} PANEL CREATED\n` +
                `${I.teeL}${I.line.repeat(22)}\n` +
                `${I.pipe} ${I.bullet} User  ${I.arrow}  <a href="tg://user?id=${userId}">${msg.from.first_name}</a>\n` +
                `${I.pipe} ${I.bullet} Panel ${I.arrow}  <code>${username}</code>\n` +
                `${I.pipe} ${I.bullet} Egg   ${I.arrow}  ${egg.name}\n` +
                `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                `${I.arrow} ${sentToDM ? "Credential dikirim ke DM" : "⚠️ Gagal kirim DM — buka DM bot & /start"}`);
        } catch (e) {
            console.log("[CREATEPANEL PROCESS ERR]", e.message);
            await safeEdit(bot, chatId, loading.message_id,
                `${I.cross} Gagal create panel\n\n` +
                `${I.bulletOut} ${e.message.slice(0, 200)}`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }
    } catch (e) {
        console.log("[CREATEPANEL USERNAME ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// COMMAND /setconfig — Set config panel (owner only)
// Flow: pilih server → pilih field → input value
// ═══════════════════════════════════════════
module.exports.handleSetConfig = async function (bot, msg, ctx) {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        if (!ctx.db.isOwner(userId)) {
            return bot.sendMessage(chatId, `${I.cross} Owner only`, { parse_mode: "HTML" });
        }

        const kb = [
            [{ text: `${I.bullet} Server 1 (Ilegal)`, callback_data: "setcfg_srv:plta", style: "success" }],
            [{ text: `${I.bullet} Server 2 (Legal)`, callback_data: "setcfg_srv:pltc", style: "success" }],
            [{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]
        ];

        await bot.sendMessage(chatId,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} SET CONFIG ${I.square}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} PILIH SERVER\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server 1 = Ilegal\n` +
            `${I.pipe} ${I.bullet} Server 2 = Legal\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} Pilih server yang mau di-set config:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[SETCONFIG ERR]", e.message);
    }
};

// ═══ CALLBACK: PILIH SERVER (setconfig) ═══
router.registerCallback("setcfg_srv", async (bot, q, data, user, ctx) => {
    try {
        const scope = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        await bot.answerCallbackQuery(q.id, { text: "OK", show_alert: false }).catch(() => {});

        ctx.setState(userId, "setcfg_pick_field", { scope });

        const scopeLabel = scope === "pltc" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

        const kb = [
            [{ text: `${I.bullet} Set URL Panel`, callback_data: "setcfg_field:url", style: "primary" }],
            [{ text: `${I.bullet} Set API Key`, callback_data: "setcfg_field:apiKey", style: "primary" }],
            [{ text: `${I.bullet} Set Domain`, callback_data: "setcfg_field:domain", style: "primary" }],
            [{ text: `${I.bullet} Set Nest ID`, callback_data: "setcfg_field:nestId", style: "primary" }],
            [{ text: `${I.bullet} Set Location ID`, callback_data: "setcfg_field:location", style: "primary" }],
            [{ text: `${I.bullet} Set Memory`, callback_data: "setcfg_field:memory", style: "primary" }],
            [{ text: `${I.bullet} Set Disk`, callback_data: "setcfg_field:disk", style: "primary" }],
            [{ text: `${I.bullet} Set CPU`, callback_data: "setcfg_field:cpu", style: "primary" }],
            [{ text: `${I.bullet} Lihat Config Sekarang`, callback_data: "setcfg_view", style: "success" }],
            [{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]
        ];

        await safeEdit(bot, chatId, q.message.message_id,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} SET CONFIG ${I.square}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} SERVER DIPILIH\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server  ${I.arrow}  <b>${scopeLabel}</b>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} Pilih field yang mau di-set:`,
            { reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[SETCFG SRV ERR]", e.message);
    }
});

// ═══ CALLBACK: PILIH FIELD ═══
router.registerCallback("setcfg_field", async (bot, q, data, user, ctx) => {
    try {
        const field = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        await bot.answerCallbackQuery(q.id, { text: "OK", show_alert: false }).catch(() => {});

        const st = ctx.getState(userId);
        if (!st || !st.scope) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${I.cross} Sesi habis, ulangi /setconfig`,
                { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
        }

        const fieldNames = {
            url: "URL Panel (contoh: https://panel.domain.com)",
            apiKey: "API Key (contoh: ptla_xxx atau ptlc_xxx)",
            domain: "Domain (contoh: panel.domain.com)",
            nestId: "Nest ID (angka)",
            location: "Location ID (angka)",
            memory: "Memory MB (angka)",
            disk: "Disk MB (angka)",
            cpu: "CPU % (angka)"
        };

        ctx.setState(userId, "setcfg_await_value", {
            scope: st.scope,
            field
        });

        await safeEdit(bot, chatId, q.message.message_id,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} INPUT VALUE ${I.square}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} SETTING\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server  ${I.arrow}  <b>${st.scope.toUpperCase()}</b>\n` +
            `${I.pipe} ${I.bullet} Field   ${I.arrow}  <b>${field}</b>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} <b>Kirim value untuk ${field}:</b>\n` +
            `${I.bulletOut} ${fieldNames[field] || field}\n\n` +
            `${I.bulletOut} Ketik <code>cancel</code> buat batal`,
            { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
    } catch (e) {
        console.log("[SETCFG FIELD ERR]", e.message);
    }
});

// ═══ MESSAGE: TERIMA VALUE ═══
router.registerMessage("setcfg_await_value", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const value = (msg.text || "").trim();

        if (!value) return;
        if (value.toLowerCase() === "cancel" || value.startsWith("/")) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `${I.check} Dibatalkan`, { parse_mode: "HTML" });
        }

        const scope = state.scope;
        const field = state.field;

        // ═══ Validasi ═══
        if (field === "url" && !value.startsWith("http")) {
            return bot.sendMessage(chatId, `${I.cross} URL harus mulai dengan http:// atau https://`, { parse_mode: "HTML" });
        }
        if ((field === "nestId" || field === "location" || field === "memory" || field === "disk" || field === "cpu") && isNaN(parseInt(value))) {
            return bot.sendMessage(chatId, `${I.cross} Field ${field} harus angka`, { parse_mode: "HTML" });
        }
        if (field === "apiKey" && !value.startsWith("ptla_") && !value.startsWith("ptlc_")) {
            return bot.sendMessage(chatId, `${I.cross} API Key harus mulai dengan <code>ptla_</code> atau <code>ptlc_</code>`, { parse_mode: "HTML" });
        }

        // ═══ Simpen ke panel.json ═══
        const saved = panelApi.saveConfigToPanel(scope, field, value);

        ctx.clearState(userId);

        if (!saved) {
            return bot.sendMessage(chatId, `${I.cross} Gagal simpen config`, { parse_mode: "HTML" });
        }

        const scopeLabel = scope === "pltc" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

        await bot.sendMessage(chatId,
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.check} CONFIG SAVED  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} SAVED\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Server  ${I.arrow}  <b>${scopeLabel}</b>\n` +
            `${I.pipe} ${I.bullet} Field   ${I.arrow}  <b>${field}</b>\n` +
            `${I.pipe} ${I.bullet} Value   ${I.arrow}  <code>${value.slice(0, 60)}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} Config udah disimpen di <code>panel.json</code>`,
            { parse_mode: "HTML" });
    } catch (e) {
        console.log("[SETCFG VALUE ERR]", e.message);
    }
});

// ═══ CALLBACK: VIEW CONFIG ═══
router.registerCallback("setcfg_view", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        await bot.answerCallbackQuery(q.id, { text: "OK", show_alert: false }).catch(() => {});

        const p = readPanel();
        const conf = p.config || {};

        const plta = conf.plta || {};
        const pltc = conf.pltc || {};

        const text =
            `${I.cornerTL}${I.doubleH.repeat(15)}${I.cornerTR}\n` +
            `${I.pipe}  ${I.square} CONFIG NOW ${I.square}  ${I.pipe}\n` +
            `${I.cornerBL}${I.doubleH.repeat(15)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.diamond} SERVER 1\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} URL       ${I.arrow}  <code>${plta.url || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} API Key   ${I.arrow}  <code>${plta.apiKey ? plta.apiKey.slice(0, 20) + "..." : "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Domain    ${I.arrow}  <code>${plta.domain || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Nest      ${I.arrow}  <code>${plta.nestId || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Location  ${I.arrow}  <code>${plta.location || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Memory    ${I.arrow}  <code>${plta.memory || "-"}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.diamond} SERVER 2\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} URL       ${I.arrow}  <code>${pltc.url || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} API Key   ${I.arrow}  <code>${pltc.apiKey ? pltc.apiKey.slice(0, 20) + "..." : "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Domain    ${I.arrow}  <code>${pltc.domain || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Nest      ${I.arrow}  <code>${pltc.nestId || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Location  ${I.arrow}  <code>${pltc.location || "-"}</code>\n` +
            `${I.pipe} ${I.bullet} Memory    ${I.arrow}  <code>${pltc.memory || "-"}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`;

        await safeEdit(bot, chatId, q.message.message_id, text,
            { reply_markup: { inline_keyboard: [[{ text: `${I.cross} Batal`, callback_data: "menu_back", style: "danger" }]] } });
    } catch (e) {
        console.log("[SETCFG VIEW ERR]", e.message);
    }
});

console.log("[PANEL PRO] module loaded (v3 — create + setconfig)");