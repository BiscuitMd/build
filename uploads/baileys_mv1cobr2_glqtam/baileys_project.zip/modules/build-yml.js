// ═══════════════════════════════════════════
// BUILD YAML — Native Base Builder via GitHub
// v5 — Kirim Link Download (no upload to Telegram)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const gh = require("./github-builder");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function canUse(ctx, user) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < cfg.CREDIT_PER_USE) {
        return { ok: false, error: `Credit habis! Butuh ${cfg.CREDIT_PER_USE} credit.` };
    }
    return { ok: true };
}

function checkAndDeductCredit(ctx, user) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < cfg.CREDIT_PER_USE) {
        return { ok: false, error: "Credit habis! Butuh " + cfg.CREDIT_PER_USE + " credit." };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - cfg.CREDIT_PER_USE });
    return { ok: true, credit: u.credit - cfg.CREDIT_PER_USE };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId,
            message_id: msgId,
            parse_mode: "HTML",
            ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("EFATAL") || msg.includes("AggregateError")) {
            await new Promise(r => setTimeout(r, 3000));
            try {
                return await bot.editMessageText(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch (e2) {
                console.log("[SAFE EDIT] retry fail:", e2.message.slice(0, 100));
                return null;
            }
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch (e2) {
                console.log("[SAFE EDIT] send new fail:", e2.message.slice(0, 100));
                return null;
            }
        }
        if (msg.includes("message is not modified")) return null;
        console.log("[SAFE EDIT] fail:", msg.slice(0, 120));
        return null;
    }
}

async function safeDelete(bot, chatId, msgId) {
    if (!msgId) return;
    try { await bot.deleteMessage(chatId, msgId); } catch {}
}

function makeProgressUpdater(bot, chatId, msgId, title = "BUILD YAML") {
    let lastPct = -1;
    let lastEditAt = 0;
    return async function update(pct, status, extra = {}) {
        pct = Math.max(0, Math.min(100, Math.round(pct)));
        const now = Date.now();
        if (pct === lastPct && now - lastEditAt < 1200) return;
        if (now - lastEditAt < 800 && pct !== 100) return;
        lastPct = pct;
        lastEditAt = now;

        const bar = progressBar(pct);
        let text =
            `<b>𖡛 ${title}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${bar}]</code> <b>${pct}%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▶️ <b>Status</b>: ${status}\n`;
        if (extra.baseName) text += `▶️ <b>Base</b>: <code>${extra.baseName}</code>\n`;
        if (extra.jobId) text += `▸ <b>Job ID</b>: <code>${extra.jobId}</code>\n`;
        if (extra.task) text += `▶️ <b>Task</b>: <code>${extra.task}</code>\n`;
        if (extra.info) text += `▶️ <b>Info</b>: ${extra.info}\n`;
        text += `━━━━━━━━━━━━━━━━━━━━\n`;
        text += `<i>${pct < 100 ? "Mohon tunggu..." : "Selesai."}</i>`;

        await safeEdit(bot, chatId, msgId, text, extra.replyMarkup ? { reply_markup: extra.replyMarkup } : {});
    };
}

function extractBaseName(zipPath) {
    try {
        const AdmZip = require("adm-zip");
        const zip = new AdmZip(zipPath);
        const entries = zip.getEntries();

        for (const entry of entries) {
            if (entry.entryName.endsWith("settings.gradle") || entry.entryName.endsWith("settings.gradle.kts")) {
                const content = entry.getData().toString("utf8");
                const match = content.match(/rootProject\.name\s*=\s*['"]([^'"]+)['"]/);
                if (match) return match[1];
            }
        }

        for (const entry of entries) {
            if (entry.entryName.endsWith("app/build.gradle") || entry.entryName.endsWith("app/build.gradle.kts")) {
                const content = entry.getData().toString("utf8");
                const match = content.match(/applicationId\s+['"]([^'"]+)['"]/);
                if (match) return match[1];
            }
        }
    } catch (e) {
        console.log("[EXTRACT BASE NAME YML] fail:", e.message);
    }
    return "unknown";
}

async function uploadZipToGitHub(jobId, zipPath, repoZipPath) {
    const zipBuf = fs.readFileSync(zipPath);
    console.log("[UPLOAD YML] zip size:", zipBuf.length, "bytes");

    if (typeof gh.putFile === "function") {
        try {
            const b64 = zipBuf.toString("base64");
            await gh.putFile(repoZipPath, b64, `[${jobId}] upload native base`);
            return { ok: true, method: "gh.putFile" };
        } catch (e) { console.log("[UPLOAD YML] gh.putFile fail:", e.message); }
    }

    if (typeof gh.uploadFile === "function") {
        try {
            await gh.uploadFile(repoZipPath, zipBuf, `[${jobId}] upload native base`);
            return { ok: true, method: "gh.uploadFile" };
        } catch (e) { console.log("[UPLOAD YML] gh.uploadFile fail:", e.message); }
    }

    try {
        const token = cfg.GITHUB.TOKEN;
        const user = cfg.GITHUB.USERNAME;
        const repo = cfg.GITHUB.REPO;
        const branch = cfg.GITHUB.BRANCH || "main";
        const apiUrl = `https://api.github.com/repos/${user}/${repo}/contents/${repoZipPath}`;

        let sha = null;
        try {
            const check = await axios.get(apiUrl, {
                headers: { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot" },
                params: { ref: branch },
                validateStatus: s => s < 500
            });
            if (check.status === 200 && check.data && check.data.sha) sha = check.data.sha;
        } catch {}

        const payload = { message: `[${jobId}] upload native base`, content: zipBuf.toString("base64"), branch };
        if (sha) payload.sha = sha;

        const res = await axios.put(apiUrl, payload, {
            headers: {
                Authorization: `token ${token}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json"
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            timeout: 120000
        });

        if (res.status === 200 || res.status === 201) return { ok: true, method: "axios" };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        const msg = e.response ? `HTTP ${e.response.status}: ${JSON.stringify(e.response.data).slice(0, 200)}` : e.message;
        return { ok: false, error: msg };
    }
}

async function deleteFromGitHub(repoPath) {
    try {
        const token = cfg.GITHUB.TOKEN;
        const user = cfg.GITHUB.USERNAME;
        const repo = cfg.GITHUB.REPO;
        const branch = cfg.GITHUB.BRANCH || "main";
        const apiUrl = `https://api.github.com/repos/${user}/${repo}/contents/${repoPath}`;

        const check = await axios.get(apiUrl, {
            headers: { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot" },
            params: { ref: branch },
            validateStatus: s => s < 500
        });

        if (check.status !== 200 || !check.data || !check.data.sha) return false;

        await axios.delete(apiUrl, {
            headers: {
                Authorization: `token ${token}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json"
            },
            data: { message: `cleanup ${repoPath}`, sha: check.data.sha, branch },
            timeout: 60000
        });
        return true;
    } catch (e) {
        console.log("[CLEANUP YML] fail:", e.message);
        return false;
    }
}

// ═══════════════════════════════════════════
// MENU
// ═══════════════════════════════════════════
router.registerCallback("menu_buildyml", async (bot, q, data, user, ctx) => {
    try {
        const check = canUse(ctx, user);
        if (!check.ok) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ ${check.error}</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 BUILD YAML (NATIVE)</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▶️ Fitur: Build Native APK (Gradle)\n` +
            `▶️ Via: GitHub Actions\n` +
            `▶️ Support: Java / Kotlin native project\n` +
            `▶️ Kirim: <b>file .zip</b> project native lu\n` +
            `▶️ Hasil: <b>Link Download</b> (langsung dari GitHub)\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Struktur .zip:</b>\n` +
            `<code>project/</code>\n` +
            `<code>  ├── build.gradle</code>\n` +
            `<code>  ├── settings.gradle</code>\n` +
            `<code>  ├── gradlew</code>\n` +
            `<code>  ├── app/</code>\n` +
            `<code>  └── gradle/</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        ctx.setState(user.id, "buildyml_await_zip", {});
        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
        });
    } catch (e) { console.log("[BUILD YML MENU ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA ZIP
// ═══════════════════════════════════════════
router.registerMessage("buildyml_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip project native lu.</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "project.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        if (msg.document.file_size > 20 * 1024 * 1024) {
            return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 20MB.</b>`, { parse_mode: "HTML" });
        }

        const creditCheck = checkAndDeductCredit(ctx, { id: userId });
        if (!creditCheck.ok) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ ${creditCheck.error}</b>`, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "▶️ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
            });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 BUILD YAML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(5)}]</code> <b>5%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▶️ <b>Status</b>: Download file dari Telegram\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        const jobId = gh.newJobId("yml");
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        let zipPath;
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const res = await axios.get(fileLink, {
                responseType: "arraybuffer",
                timeout: 60000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            zipPath = path.join(workDir, fname);
            fs.writeFileSync(zipPath, Buffer.from(res.data));
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download file:</b>\n<code>${e.message}</code>`);
        }

        const baseName = extractBaseName(zipPath);
        console.log("[BUILD YML] base name:", baseName);

        ctx.setState(userId, "buildyml_pick_build", {
            jobId, zipPath, fname, baseName,
            loadingMsgId: loading.message_id
        });

        const kb = [
            [
                { text: "𖡛 APK Release", callback_data: "buildyml_build:assembleRelease:", style: "success" },
                { text: "𖡛 APK Debug", callback_data: "buildyml_build:assembleDebug:", style: "primary" }
            ],
            [
                { text: "𖡛 AAB Release", callback_data: "buildyml_build:bundleRelease:", style: "success" },
                { text: "𖡛 AAB Debug", callback_data: "buildyml_build:bundleDebug:", style: "primary" }
            ],
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ];

        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 PILIH MODE BUILD (NATIVE)</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▶️ Base: <code>${baseName}</code>\n` +
            `▶️ File: <code>${fname}</code>\n` +
            `▶️ Size: ${(msg.document.file_size / 1024).toFixed(1)} KB\n` +
            `▶️ Job ID: <code>${jobId}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih tipe build:</b>`,
            { reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[BUILD YML AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══════════════════════════════════════════
// CALLBACK: PILIH MODE BUILD
// ═══════════════════════════════════════════
router.registerCallback("buildyml_build", async (bot, q, data, user, ctx) => {
    let workDir = null;
    let repoZipPath = null;
    let baseName = "unknown";

    try {
        const parts = data.split(":");
        const buildTask = parts[1];
        const buildFlavor = parts[2] || "";

        const prev = ctx.getState(user.id) || {};
        const { jobId, zipPath } = prev;
        baseName = prev.baseName || "unknown";

        if (!jobId || !zipPath) {
            ctx.clearState(user.id);
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis. Kirim zip ulang.", show_alert: true });
        }

        ctx.clearState(user.id);

        const chatId = q.message.chat.id;
        const loadingMsgId = prev.loadingMsgId || q.message.message_id;
        const updateProgress = makeProgressUpdater(bot, chatId, loadingMsgId);

        await updateProgress(10, "Upload zip ke GitHub", { jobId, baseName, task: buildTask });

        workDir = path.join(TMP_DIR, jobId);
        repoZipPath = `uploads/${jobId}/project.zip`;

        await updateProgress(20, "Uploading zip...", { jobId, baseName, task: buildTask });

        let uploadResult;
        try { uploadResult = await uploadZipToGitHub(jobId, zipPath, repoZipPath); }
        catch (e) { uploadResult = { ok: false, error: e.message }; }

        if (!uploadResult.ok) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal upload ke GitHub</b>\n\n<code>${String(uploadResult.error).slice(0, 200)}</code>`);
        }

        await updateProgress(30, "Trigger workflow...", { jobId, baseName, task: buildTask });

        const workflow = cfg.GITHUB.WORKFLOW_NATIVE || "native-build.yml";
        const triggerTime = Date.now();

        let trigger;
        try {
            trigger = await gh.triggerWorkflow(workflow, {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_task: buildTask,
                build_flavor: buildFlavor,
                java_version: "17"
            });
        } catch (e) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId, `<b>✕ Gagal trigger workflow:</b>\n<code>${e.message}</code>`);
        }

        if (!trigger || !trigger.ok) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal trigger workflow:</b>\n<code>${trigger ? trigger.error : "unknown"}</code>`);
        }

        await updateProgress(40, "Workflow triggered, waiting GitHub...", { jobId, baseName, task: buildTask });

        // 📸 NOTIF PROCESSING
        buildNotifier.sendBuildNotif(bot, {
            status: "processing",
            feature: `Build YAML — ${buildTask}`,
            baseName: baseName,
            user: user,
            subtitle: `Job: ${jobId}`,
            fields: [
                { label: "Base", value: baseName },
                { label: "Task", value: buildTask },
                { label: "Flavor", value: buildFlavor || "-" },
                { label: "Java Version", value: "17" },
                { label: "Status", value: "Uploaded to GitHub" }
            ]
        }).catch(e => console.log("[NOTIF YML PROCESSING ERR]", e.message));

        let run = null;
        for (let i = 0; i < 12; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await gh.getLatestRun(workflow, triggerTime); } catch {}
            if (run) break;
            await updateProgress(40 + i, `Waiting GitHub run... (${i + 1}/12)`, { jobId, baseName, task: buildTask });
        }

        if (!run) {
            try { await deleteFromGitHub(repoZipPath); } catch {}
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}

            buildNotifier.sendBuildNotif(bot, {
                status: "failed",
                feature: `Build YAML — ${buildTask}`,
                baseName: baseName,
                user: user,
                subtitle: "GitHub tidak response",
                fields: [
                    { label: "Base", value: baseName },
                    { label: "Job ID", value: jobId },
                    { label: "Reason", value: "No run detected" }
                ]
            }).catch(() => {});

            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Build timeout — GitHub ga response</b>`);
        }

        const runId = run.id;
        console.log("[BUILD YML] run id:", runId);

        let lastPct = 40;
        const startTime = Date.now();
        const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;

        while (Date.now() - startTime < maxWait) {
            let status = null;
            try { status = await gh.getRunStatus(runId); } catch {}

            if (!status) {
                await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
                continue;
            }

            const jobStatus = status.status;
            const conclusion = status.conclusion;

            const elapsed = Date.now() - startTime;
            let pct = 50 + Math.min(Math.floor((elapsed / 300000) * 45), 44);
            if (jobStatus === "completed") pct = 95;

            if (pct !== lastPct) {
                lastPct = pct;
                const jobStatusLabel = jobStatus === "in_progress" ? "Building di GitHub" : jobStatus;
                await updateProgress(pct, jobStatusLabel, {
                    jobId, baseName, task: buildTask,
                    info: `<code>${(elapsed / 1000).toFixed(0)}s</code>`
                });
            }

            if (jobStatus === "completed") {
                try { await deleteFromGitHub(repoZipPath); } catch {}

                // ═══ BUILD SUKSES ═══
                if (conclusion === "success") {
                    await updateProgress(100, "Build selesai!", {
                        jobId, baseName, task: buildTask,
                        info: "Kirim link download..."
                    });

                    const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);

                    let artifacts = [];
                    try { artifacts = await gh.getRunArtifacts(runId); } catch {}

                    const apkArtifacts = artifacts.filter(a =>
                        a.name.includes("apk") || a.name.includes("appbundle") || a.name.includes("release") || a.name.includes("app")
                    );

                    const actionsUrl = `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`;
                    const artifactsUrl = `${actionsUrl}#artifacts`;

                    const resultCaption =
                        `<b>✓ BUILD SUCCESS</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▶️ <b>Base</b>: <code>${baseName}</code>\n` +
                        `▶️ <b>Task</b>: ${buildTask}\n` +
                        `▶️ <b>Flavor</b>: ${buildFlavor || "-"}\n` +
                        `▶️ <b>Artifacts</b>: <code>${apkArtifacts.length}</code>\n` +
                        `▶️ <b>Waktu</b>: ${elapsedSec}s\n` +
                        `▶️ <b>Job ID</b>: <code>${jobId}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n\n` +
                        `<b>▶️ Download Link:</b>\n` +
                        `<i>Klik tombol di bawah buat download file</i>`;

                    const resultKb = [
                        [{ text: "𖡛 Download APK / AAB", url: artifactsUrl, style: "success" }],
                        [{ text: "𖡛 Lihat Actions", url: actionsUrl, style: "primary" }],
                        [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                    ];

                    await safeEdit(bot, chatId, loadingMsgId, resultCaption, {
                        reply_markup: { inline_keyboard: resultKb }
                    });

                    // 📸 NOTIF SUCCESS
                    buildNotifier.sendBuildNotif(bot, {
                        status: "success",
                        feature: `Build YAML — ${buildTask}`,
                        baseName: baseName,
                        user: user,
                        subtitle: `${apkArtifacts.length} artifact siap`,
                        fields: [
                            { label: "Base", value: baseName },
                            { label: "Task", value: buildTask },
                            { label: "Artifacts", value: String(apkArtifacts.length) },
                            { label: "Waktu", value: elapsedSec + "s" },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(e => console.log("[NOTIF YML SUCCESS ERR]", e.message));

                    try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
                    return;
                } else {
                    // ═══ BUILD GAGAL ═══
                    let errorLog = "";
                    try {
                        const logs = await gh.getRunLogs(runId);
                        if (logs && logs.length > 0) errorLog = logs.toString("utf8").slice(-3000);
                    } catch {}

                    const errorPath = path.join(TMP_DIR, `${jobId}_error.txt`);
                    fs.writeFileSync(errorPath,
                        `=== ✕ BUILD YAML FAILED ===\n` +
                        `Base: ${baseName}\n` +
                        `Job ID: ${jobId}\nRun ID: ${runId}\nConclusion: ${conclusion}\n` +
                        `Task: ${buildTask}\nFlavor: ${buildFlavor || "-"}\n` +
                        `Time: ${new Date().toISOString()}\n` +
                        `\n=== LOG ===\n${errorLog}\n\n=== LINK ===\n` +
                        `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`,
                        "utf8");

                    await safeEdit(bot, chatId, loadingMsgId,
                        `<b>✕ BUILD FAILED</b>\n\n━━━━━━━━━━━━━━━━━━━━\n` +
                        `▶️ Base: <code>${baseName}</code>\n` +
                        `▶️ Job ID: <code>${jobId}</code>\n` +
                        `▶️ Conclusion: <code>${conclusion}</code>\n` +
                        `▶️ Cek detail: https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}\n` +
                        `━━━━━━━━━━━━━━━━━━━━`);

                    try {
                        await bot.sendDocument(chatId, errorPath, {
                            caption: `<b>✕ BUILD FAILED</b>\n\n𖡛 Base: <code>${baseName}</code>\n𖡛 Job ID: <code>${jobId}</code>`,
                            parse_mode: "HTML"
                        }, { filename: `${jobId}_error.txt`, contentType: "text/plain" });
                    } catch (e) {
                        console.log("[SEND ERROR LOG FAIL]", e.message);
                    }

                    // 📸 NOTIF FAILED
                    buildNotifier.sendBuildNotif(bot, {
                        status: "failed",
                        feature: `Build YAML — ${buildTask}`,
                        baseName: baseName,
                        user: user,
                        subtitle: `Conclusion: ${conclusion}`,
                        fields: [
                            { label: "Base", value: baseName },
                            { label: "Task", value: buildTask },
                            { label: "Conclusion", value: conclusion },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(e => console.log("[NOTIF YML FAILED ERR]", e.message));

                    try { fs.unlinkSync(errorPath); } catch {}
                    try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
                    return;
                }
            }

            await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
        }

        // TIMEOUT
        try { await deleteFromGitHub(repoZipPath); } catch {}
        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}

        buildNotifier.sendBuildNotif(bot, {
            status: "failed",
            feature: `Build YAML — ${buildTask}`,
            baseName: baseName,
            user: user,
            subtitle: "Build timeout > 60 menit",
            fields: [
                { label: "Base", value: baseName },
                { label: "Job ID", value: jobId },
                { label: "Reason", value: "Timeout" }
            ]
        }).catch(() => {});

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>⏱ Build timeout (>60 menit)</b>\n\n▸ Base: <code>${baseName}</code>\n▸ Cek: https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`);
    } catch (e) {
        console.log("[BUILD YML BUILD ERR]", e.message);
        try { if (repoZipPath) await deleteFromGitHub(repoZipPath); } catch {}
        try { if (workDir) fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

module.exports = { canUse, progressBar };
console.log("[BUILD YML] module loaded");