// ═══════════════════════════════════════════
// SPARTAX BOT — Main Entry
// v7 — TMP cleanup + userbot + auto-backup
// ═══════════════════════════════════════════

// ═══════════════════════════════════════════
// ERROR HANDLER — Filter anti-spam
// ═══════════════════════════════════════════
let lastErrorMsg = "";
let lastErrorTime = 0;
const ERROR_SPAM_GUARD_MS = 5000;

function shouldLogError(msg) {
    const now = Date.now();
    if (msg === lastErrorMsg && now - lastErrorTime < ERROR_SPAM_GUARD_MS) {
        return false;
    }
    lastErrorMsg = msg;
    lastErrorTime = now;
    return true;
}

process.on("uncaughtException", (e) => {
    const msg = e.message || "";
    if (msg.includes("EFATAL") || msg.includes("AggregateError")) return;
    if (msg.includes("instanceof")) return;
    if (!shouldLogError(msg)) return;
    console.log("[UNCAUGHT]", msg);
});

process.on("unhandledRejection", (e) => {
    const msg = (e && e.message) ? e.message : String(e);
    if (msg.includes("EFATAL") || msg.includes("AggregateError")) return;
    if (msg.includes("instanceof")) return;
    if (!shouldLogError(msg)) return;
    console.log("[UNHANDLED]", msg);
});

const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const DB_DIR = path.join(ROOT, "database");

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const FILES = {
    users: path.join(DB_DIR, "users.json"),
    senders: path.join(DB_DIR, "senders.json"),
    redeem: path.join(DB_DIR, "redeem.json"),
    reports: path.join(DB_DIR, "reports.json"),
    settings: path.join(DB_DIR, "settings.json"),
    guard: path.join(DB_DIR, "guard.json"),
    panel: path.join(DB_DIR, "panel.json"),
    orders: path.join(DB_DIR, "orders.json"),
    groupgate: path.join(DB_DIR, "groupgate.json"),
    scripts: path.join(DB_DIR, "scripts.json"),
    script_orders: path.join(DB_DIR, "script_orders.json"),
    pending_fix: path.join(DB_DIR, "pending_fix.json"),
    ai_memory: path.join(DB_DIR, "ai_memory.json"),
    user_state: path.join(DB_DIR, "user_state.json")
};

for (const key in FILES) {
    if (!fs.existsSync(FILES[key])) fs.writeFileSync(FILES[key], "{}", "utf8");
}

function readDB(key) {
    try { return JSON.parse(fs.readFileSync(FILES[key], "utf8")); } catch { return {}; }
}

function writeDB(key, data) {
    fs.writeFileSync(FILES[key], JSON.stringify(data, null, 2), "utf8");
}

const cfg = require(path.join(ROOT, "config.js"));

const db = {
    getUser(id) {
        const users = readDB("users");
        const uid = String(id);
        if (!users[uid]) {
            users[uid] = {
                id: uid,
                role: "free",
                credit: 20,
                premium: false,
                banned: false,
                banUntil: 0,
                createdAt: Date.now()
            };
            writeDB("users", users);
        }
        return users[uid];
    },
    saveUser(id, data) {
        const users = readDB("users");
        users[String(id)] = { ...users[String(id)], ...data };
        writeDB("users", users);
    },
    allUsers() { return readDB("users"); },
    isBanned(id) {
        const u = this.getUser(id);
        if (!u.banned) return false;
        if (u.banUntil && Date.now() > u.banUntil) {
            this.saveUser(id, { banned: false, banUntil: 0 });
            return false;
        }
        return true;
    },
    isPremium(id) { return !!this.getUser(id).premium; },
    isOwner(id) { return String(id) === String(cfg.OWNER_ID); },
    addCredit(id, amount) {
        const u = this.getUser(id);
        const total = Math.min(u.credit + amount, 500);
        this.saveUser(id, { credit: total });
        return total;
    },
    delCredit(id) { this.saveUser(id, { credit: 0 }); },
    setPremium(id, status) {
        this.saveUser(id, { premium: !!status, role: status ? "premium" : "free" });
    },
    banUser(id, duration) { this.saveUser(id, { banned: true, banUntil: Date.now() + duration }); },
    unbanUser(id) { this.saveUser(id, { banned: false, banUntil: 0 }); },
    deductCredit(id, amount = 1) {
        const u = this.getUser(id);
        if (u.credit < amount) return false;
        this.saveUser(id, { credit: u.credit - amount });
        return true;
    },
    read: readDB,
    write: writeDB,
    FILES
};

global.db = db;
global.readDB = readDB;
global.writeDB = writeDB;

const TelegramBot = require("node-telegram-bot-api");
const bot = new TelegramBot(cfg.BOT_TOKEN, { polling: true });

const gate = require(path.join(ROOT, "modules", "gate.js"));
const guard = require(path.join(ROOT, "modules", "guard.js"));
const panel = require(path.join(ROOT, "modules", "panel.js"));
const notify = require(path.join(ROOT, "modules", "notify.js"));
const groupgate = require(path.join(ROOT, "modules", "groupgate.js"));
const panelpro = require(path.join(ROOT, "modules", "panelpro.js"));
const router = require(path.join(ROOT, "modules", "router.js"));

// ═══════════════════════════════════════════
// TMP FOLDER AUTO-CLEANUP — Setiap 1 jam
// ═══════════════════════════════════════════
const TMP_DIR = path.join(ROOT, "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

setInterval(() => {
    try {
        const files = fs.readdirSync(TMP_DIR);
        const now = Date.now();
        let deleted = 0;
        for (const f of files) {
            const p = path.join(TMP_DIR, f);
            try {
                const stat = fs.statSync(p);
                if (now - stat.mtimeMs > 60 * 60 * 1000) { // 1 jam
                    fs.unlinkSync(p);
                    deleted++;
                }
            } catch {}
        }
        if (deleted > 0) console.log(`[TMP CLEANUP] Deleted ${deleted} files`);
    } catch (e) {}
}, 60 * 60 * 1000);

console.log("[TMP CLEANUP] Timer aktif — cleanup tiap 1 jam");

// ═══════════════════════════════════════════
// TMP_BUILD FOLDER AUTO-CLEANUP — Setiap 2 jam
// ═══════════════════════════════════════════
const TMP_BUILD_DIR = path.join(ROOT, "tmp_build");
if (!fs.existsSync(TMP_BUILD_DIR)) fs.mkdirSync(TMP_BUILD_DIR, { recursive: true });

setInterval(() => {
    try {
        const files = fs.readdirSync(TMP_BUILD_DIR);
        const now = Date.now();
        let deleted = 0;
        for (const f of files) {
            const p = path.join(TMP_BUILD_DIR, f);
            try {
                const stat = fs.statSync(p);
                if (now - stat.mtimeMs > 2 * 60 * 60 * 1000) { // 2 jam
                    if (stat.isDirectory()) {
                        fs.rmSync(p, { recursive: true, force: true });
                    } else {
                        fs.unlinkSync(p);
                    }
                    deleted++;
                }
            } catch {}
        }
        if (deleted > 0) console.log(`[TMP_BUILD CLEANUP] Deleted ${deleted} items`);
    } catch (e) {}
}, 2 * 60 * 60 * 1000);

console.log("[TMP_BUILD CLEANUP] Timer aktif — cleanup tiap 2 jam");

// ═══════════════════════════════════════════
// PANEL MONITORING LOOP
// ═══════════════════════════════════════════
try { panel.startMonitoringLoop(bot); } catch (e) { console.log("[MONITOR START ERR]", e.message); }

// ═══════════════════════════════════════════
// USERBOT — Load & Restore
// ═══════════════════════════════════════════
try {
    const userbotLogin = require(path.join(ROOT, "handlers", "userbot", "login.js"));
    setTimeout(() => {
        userbotLogin.restoreAllSessions(bot).catch(e => console.log("[USERBOT RESTORE ERR]", e.message));
    }, 5000);
    console.log("[USERBOT] restore scheduled");
} catch (e) {
    console.log("[USERBOT LOAD ERR]", e.message);
}

// ═══════════════════════════════════════════
// AUTO BACKUP
// ═══════════════════════════════════════════
let autoBackup = null;
try {
    autoBackup = require(path.join(ROOT, "modules", "auto-backup.js"));
    autoBackup.registerCommands(bot, cfg);
    autoBackup.startAutoBackup(bot, cfg);
    console.log("[AUTO BACKUP] service started");
} catch (e) {
    console.log("[AUTO BACKUP LOAD ERR]", e.message);
}

// ═══════════════════════════════════════════
// USER STATE — FILE-BASED PERSISTENT
// ═══════════════════════════════════════════
const STATE_FILE = FILES.user_state;

function readAllState() {
    try { return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")); } catch { return {}; }
}

function writeAllState(d) {
    fs.writeFileSync(STATE_FILE, JSON.stringify(d, null, 2), "utf8");
}

function setState(id, state, data = {}) {
    const all = readAllState();
    const key = String(id);
    all[key] = { state, ...data, _updatedAt: Date.now() };
    writeAllState(all);
    console.log("[STATE] set:", key, "→", state);
}

function getState(id) {
    const all = readAllState();
    const key = String(id);
    const s = all[key] || null;
    if (s) console.log("[STATE] get:", key, "→", s.state);
    return s;
}

function clearState(id) {
    const all = readAllState();
    const key = String(id);
    if (all[key]) {
        delete all[key];
        writeAllState(all);
        console.log("[STATE] clear:", key);
    }
}

setInterval(() => {
    try {
        const all = readAllState();
        const now = Date.now();
        let changed = false;
        for (const uid in all) {
            if (all[uid]._updatedAt && now - all[uid]._updatedAt > 10 * 60 * 1000) {
                console.log("[STATE] auto-cleanup expired:", uid);
                delete all[uid];
                changed = true;
            }
        }
        if (changed) writeAllState(all);
    } catch (e) {}
}, 60 * 1000);

function buildPanelCtx() {
    return {
        db, gate, panel, panelpro, notify, groupgate,
        setState, getState, clearState, sendMenu
    };
}

// ═══════════════════════════════════════════
// MENU TEXT
// ═══════════════════════════════════════════
function menuText(user) {
    const role = user.premium ? "❰ PREMIUM ❱" : "❰ FREE ❱";
    return `<b>𖡛 𝐁𝐎𝐓 𝐌𝐔𝐋𝐓𝐈 𝐅𝐔𝐍𝐆𝐒𝐈 𖡛</b>\n\n` +
        `<b>Halo</b> <a href="tg://user?id=${user.id}">${user.id}</a>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>ID</b>: <code>${user.id}</code>\n` +
        `▸ <b>Role</b>: ${role}\n` +
        `▸ <b>Credit</b>: <code>${user.credit}</code>\n` +
        `▸ <b>Status</b>: ${user.banned ? "BANNED" : "AKTIF"}\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
}

// ═══════════════════════════════════════════
// MAIN KEYBOARD
// ═══════════════════════════════════════════
function getMainKeyboard(userId) {
    const isOwnerUser = String(userId) === String(cfg.OWNER_ID);
    const user = db.getUser(userId);
    const isPremiumUser = !!user.premium;

    const kb = [
        [
            { text: "𖡛 AI Sakura", callback_data: "menu_ai", style: "success" },
            { text: "𖡛 File to Link", callback_data: "menu_filetolink", style: "success" }
        ],
        [
            { text: "𖡛 Script Store", callback_data: "menu_scriptstore", style: "success" },
            { text: "𖡛 Auto Order Role", callback_data: "menu_order", style: "success" }
        ],
        [
            { text: "𖡛 Tes Function", callback_data: "menu_tesfunc", style: "primary" },
            { text: "𖡛 Cek Syntax Error", callback_data: "menu_cekerror", style: "primary" }
        ],
        [
            { text: "𖡛 Add Sender", callback_data: "menu_addsender", style: "success" },
            { text: "𖡛 Clear Sender", callback_data: "menu_clearsender", style: "success" }
        ],
        [
            { text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "primary" },
            { text: "𖡛 Buy Premium", callback_data: "menu_buypremium", style: "primary" }
        ],
        [
            { text: "𖡛 Menu Tools", callback_data: "menu_tools", style: "success" },
            { text: "𖡛 Music", callback_data: "menu_music", style: "success" }
        ],
        [{ text: "𖡛 Group Guard", callback_data: "menu_guard", style: "danger" }],
        [
            { text: "𖡛 Create Panel", callback_data: "menu_panelpro", style: "primary" },
            { text: "𖡛 Push Channel", callback_data: "menu_pushchannel", style: "primary" }
        ],
        [{ text: "𖡛 BUILD MENU", callback_data: "menu_buildmenu", style: "danger" }],
        [{ text: "𖡛 USERBOT TELEGRAM", callback_data: "menu_userbot", style: "success" }]
    ];

    if (isPremiumUser) kb.push([{ text: "𖡛 MENU PREMIUM", callback_data: "menu_userpremium", style: "success" }]);
    if (isOwnerUser) kb.push([{ text: "𖡛 MENU OWNER", callback_data: "menu_owner", style: "primary" }]);

    return { inline_keyboard: kb };
}

// ═══════════════════════════════════════════
// SEND MENU
// ═══════════════════════════════════════════
async function sendMenu(chatId, user, q = null, msg = null) {
    const keyboard = getMainKeyboard(user.id);

    if (q && q.message) {
        const msgId = q.message.message_id;
        const hasPhoto = !!q.message.photo;

        if (hasPhoto) {
            try {
                await bot.editMessageCaption(menuText(user), {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: "HTML",
                    reply_markup: keyboard
                });
                return;
            } catch (e) {
                const m = e.message || "";
                if (m.includes("message is not modified")) return;
                try {
                    await bot.editMessageReplyMarkup(keyboard, {
                        chat_id: chatId,
                        message_id: msgId
                    });
                    return;
                } catch {}
            }
        } else {
            try {
                await bot.editMessageMedia({
                    type: "photo",
                    media: cfg.FOTO.MENU,
                    caption: menuText(user),
                    parse_mode: "HTML"
                }, {
                    chat_id: chatId,
                    message_id: msgId,
                    reply_markup: keyboard
                });
                return;
            } catch {}
        }
    }

    try {
        const timeout = new Promise((_, reject) =>
            setTimeout(() => reject(new Error("sendPhoto timeout")), 15000)
        );
        await Promise.race([
            bot.sendPhoto(chatId, cfg.FOTO.MENU, {
                caption: menuText(user),
                parse_mode: "HTML",
                reply_markup: keyboard
            }),
            timeout
        ]);
    } catch (e) {
        console.log("[SEND MENU] photo fail, fallback:", e.message.slice(0, 80));
        try {
            await bot.sendMessage(chatId, menuText(user), {
                parse_mode: "HTML",
                reply_markup: keyboard
            });
        } catch (e2) {
            console.log("[SEND MENU] text fail:", e2.message);
        }
    }
}

async function requireJoin(msgOrQ, isCallback = false) {
    const id = msgOrQ.from.id;
    if (String(id) === String(cfg.OWNER_ID)) return true;

    try {
        const join = await gate.checkJoin(bot, id);
        if (join.ok) return true;

        const chatId = isCallback ? msgOrQ.message.chat.id : msgOrQ.chat.id;
        const text = `<b>WAJIB JOIN CHANNEL</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Lu harus join ${cfg.CHANNELS.length} channel dulu:\n\n` +
            cfg.CHANNELS.map((c, i) => `▸ ${c.name}`).join("\n") +
            `\n━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Setelah join semua, klik tombol di bawah.</i>`;

        await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: gate.joinKeyboard() });
        return false;
    } catch (e) {
        console.log("[REQUIRE JOIN ERR]", e.message);
        return true;
    }
}

// ═══════════════════════════════════════════
// LOADING SCREEN
// ═══════════════════════════════════════════
const loadingLocks = new Set();

const LOADING_STEPS = [
    { pct: 20, text: "Initializing bot core" },
    { pct: 45, text: "Verifying credentials" },
    { pct: 70, text: "Loading plugins" },
    { pct: 90, text: "Almost ready" },
    { pct: 100, text: "Complete" }
];

function makeProgressBar(pct) {
    const total = 14;
    const filled = Math.floor((pct / 100) * total);
    const empty = total - filled;
    return "■".repeat(filled) + "□".repeat(empty);
}

function loadingText(username, userId, pct, status) {
    return `<b>𖡛 𝐁𝐎𝐓 𝐌𝐔𝐋𝐓𝐈 𝐅𝐔𝐍𝐆𝐒𝐈 𖡛</b>\n\n` +
        `<b>Halo</b> <a href="tg://user?id=${userId}">${username}</a>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Status</b>: ${status}\n` +
        `<code>[${makeProgressBar(pct)}]</code> <b>${pct}%</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Mohon tunggu sebentar...</i>`;
}

async function showLoading(bot, chatId, user) {
    const key = String(user.id);
    if (loadingLocks.has(key)) return;
    loadingLocks.add(key);

    const username = user.first_name || "User";
    let msgId = null;

    try {
        const msg = await bot.sendMessage(chatId,
            loadingText(username, user.id, 0, "Initializing..."),
            { parse_mode: "HTML" });
        msgId = msg.message_id;
    } catch (e) {
        console.log("[LOADING] send fail:", e.message);
        loadingLocks.delete(key);
        return;
    }

    for (const step of LOADING_STEPS) {
        await new Promise(r => setTimeout(r, 90));
        try {
            await bot.editMessageText(
                loadingText(username, user.id, step.pct, step.text),
                { chat_id: chatId, message_id: msgId, parse_mode: "HTML" });
        } catch {}
    }

    await new Promise(r => setTimeout(r, 250));

    if (msgId) {
        for (let i = 0; i < 3; i++) {
            try {
                await bot.deleteMessage(chatId, msgId);
                break;
            } catch (e) {
                if (i === 2) {
                    try {
                        await bot.editMessageText("​", { chat_id: chatId, message_id: msgId });
                        await bot.deleteMessage(chatId, msgId);
                    } catch {}
                }
                await new Promise(r => setTimeout(r, 500));
            }
        }
    }

    loadingLocks.delete(key);
}

// ═══════════════════════════════════════════
// /start
// ═══════════════════════════════════════════
bot.onText(/^\/start$/, async (msg) => {
    const id = msg.from.id;
    const userBefore = db.getUser(id);
    const isNewUser = userBefore.createdAt && Date.now() - userBefore.createdAt < 5000;

    if (isNewUser) {
        try {
            await notify.notifyUser(bot, msg.from, {
                fields: [{ label: "Status", value: userBefore.banned ? "BANNED" : "AKTIF" }],
                footer: "User baru pakai /start"
            });
        } catch (e) { console.log("[NOTIFY USER ERR]", e.message); }
    }

    if (db.isBanned(id)) {
        return bot.sendMessage(msg.chat.id,
            `<b>MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!</b>`,
            { parse_mode: "HTML" });
    }

    const ok = await requireJoin(msg, false);
    if (!ok) return;

    await showLoading(bot, msg.chat.id, msg.from);
    await sendMenu(msg.chat.id, db.getUser(id));
});

// ═══════════════════════════════════════════
// /menu
// ═══════════════════════════════════════════
bot.onText(/^\/menu$/, async (msg) => {
    const id = msg.from.id;
    if (db.isBanned(id)) {
        return bot.sendMessage(msg.chat.id,
            `<b>MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!</b>`,
            { parse_mode: "HTML" });
    }
    const ok = await requireJoin(msg, false);
    if (!ok) return;
    await sendMenu(msg.chat.id, db.getUser(id));
});

// ═══════════════════════════════════════════
// WELCOME / LEAVE
// ═══════════════════════════════════════════
bot.on("new_chat_members", async (msg) => {
    try {
        await guard.handleNewMembers(bot, msg, { db, gate });
    } catch (e) {
        console.log("[NEW MEMBERS ERR]", e.message);
    }
});

bot.on("left_chat_member", async (msg) => {
    try {
        await guard.handleLeftMembers(bot, msg, { db, gate });
    } catch (e) {
        console.log("[LEFT MEMBER ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// REGISTER GROUP TOOLS
// ═══════════════════════════════════════════
try {
    const grouptools = require(path.join(ROOT, "modules", "grouptools.js"));
    grouptools.register(bot, { db, gate });
} catch (e) {
    console.log("[GROUPTOOLS REGISTER ERR]", e.message);
}

// ═══════════════════════════════════════════
// /reset
// ═══════════════════════════════════════════
bot.onText(/^\/reset$/, async (msg) => {
    const id = msg.from.id;
    try {
        const ai = require(path.join(ROOT, "modules", "ai-engine.js"));
        ai.clearMemory(id);
        await bot.sendMessage(msg.chat.id,
            `<b>🧹 Memory di-reset!</b>\n\n<i>Sakura lupa chat sebelumnya. Mulai fresh lagi~ UwU</i>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[RESET ERR]", e.message); }
});

// ═══════════════════════════════════════════
// /accubot
// ═══════════════════════════════════════════
bot.onText(/^\/accubot(?:\s+(.+))?$/, async (msg) => {
    if (String(msg.from.id) !== String(cfg.OWNER_ID)) {
        return bot.sendMessage(msg.chat.id, `<b>✕ Owner only.</b>`, { parse_mode: "HTML" });
    }
    const args = (msg.text || "").split(/\s+/).slice(1);
    const targetId = args[0];
    const role = args[1];
    if (!targetId || !role) {
        return bot.sendMessage(msg.chat.id,
            `<b>Format:</b> <code>/accubot [user_id] [role]</code>\n\n` +
            `<b>Role:</b> permanent, reseller, admin, owner`,
            { parse_mode: "HTML" });
    }
    try {
        const store = require(path.join(ROOT, "handlers", "userbot", "session-store.js"));
        store.setUserRole(targetId, role, 0);
        await bot.sendMessage(msg.chat.id,
            `<b>✓ ROLE USERBOT DI-ACC</b>\n\n` +
            `▸ User: <code>${targetId}</code>\n` +
            `▸ Role: <b>${role.toUpperCase()}</b>\n` +
            `▸ Status: Permanen`,
            { parse_mode: "HTML" });
        await bot.sendMessage(targetId,
            `<b>𖡛 ROLE USERBOT DI-ACC</b>\n\n` +
            `▸ Role: <b>${role.toUpperCase()}</b>\n` +
            `▸ Status: Permanen\n\n` +
            `<i>Ketik /menu → Userbot Telegram → Login</i>`,
            { parse_mode: "HTML" }).catch(() => {});
    } catch (e) {
        await bot.sendMessage(msg.chat.id, `<b>✕ Error:</b> ${e.message.slice(0, 150)}`, { parse_mode: "HTML" });
    }
});

// ═══════════════════════════════════════════
// COMMANDS — PANEL
// ═══════════════════════════════════════════
bot.onText(/^\/add(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAdd(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADD ERR]", e.message); }
});

bot.onText(/^\/addgroup(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddGroup(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDGROUP ERR]", e.message); }
});

bot.onText(/^\/addall(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddAll(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDALL ERR]", e.message); }
});

bot.onText(/^\/addrole(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddRole(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDROLE ERR]", e.message); }
});

bot.onText(/^\/cadp(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleCadp(bot, msg, buildPanelCtx(), 1); } catch (e) { console.log("[CADP ERR]", e.message); }
});

bot.onText(/^\/cadp2(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleCadp(bot, msg, buildPanelCtx(), 2); } catch (e) { console.log("[CADP2 ERR]", e.message); }
});

bot.onText(/^\/info(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleInfoGroup(bot, msg, buildPanelCtx()); } catch (e) { console.log("[INFO ERR]", e.message); }
});

bot.onText(/^\/unmuteall(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        const gg = require(path.join(ROOT, "modules", "groupgate.js"));
        if (typeof gg.unmuteAll !== "function") return;
        const result = await gg.unmuteAll(bot, msg.chat.id);
        await bot.sendMessage(msg.chat.id,
            `<b>✓ UNMUTE ALL</b>\n\n▸ Total: ${result.total}\n▸ Berhasil: ${result.success}`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[UNMUTEALL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// CALLBACK QUERY
// ═══════════════════════════════════════════
bot.on("callback_query", async (q) => {
    if (!q || !q.from || !q.message || !q.data) {
        console.log("[CB] invalid query");
        return bot.answerCallbackQuery(q?.id || "").catch(() => {});
    }

    const id = q.from.id;
    const data = q.data;
    const user = db.getUser(id);

    console.log("[CB] user:", id, "data:", data);

    if (data === "menu_close") {
        try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
        return bot.answerCallbackQuery(q.id).catch(() => {});
    }

    if (data === "menu_back") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        return sendMenu(q.message.chat.id, user, q);
    }

    if (data === "check_join") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        const join = await gate.checkJoin(bot, id);
        if (!join.ok) {
            return bot.answerCallbackQuery(q.id, { text: "Lu belum join semua channel!", show_alert: true }).catch(() => {});
        }
        return sendMenu(q.message.chat.id, user, q);
    }

    if (data.startsWith("gategroup_check:")) {
        return router(bot, q, data, user, buildPanelCtx());
    }

    if (db.isBanned(id) && !data.startsWith("dev_") && !data.startsWith("redeem_claim") && !data.startsWith("guard_")) {
        return bot.answerCallbackQuery(q.id, {
            text: "MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!",
            show_alert: true
        }).catch(() => {});
    }

    if (String(id) !== String(cfg.OWNER_ID)) {
        try {
            const join = await gate.checkJoin(bot, id);
            if (!join.ok) {
                await bot.answerCallbackQuery(q.id, { text: "Join channel dulu!", show_alert: true }).catch(() => {});
                return bot.sendMessage(q.message.chat.id,
                    `<b>WAJIB JOIN CHANNEL</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `Join ${cfg.CHANNELS.length} channel dulu:\n\n` +
                    cfg.CHANNELS.map((c, i) => `▸ ${c.name}`).join("\n") +
                    `\n━━━━━━━━━━━━━━━━━━━━`,
                    { parse_mode: "HTML", reply_markup: gate.joinKeyboard() });
            }
        } catch {}
    }

    try {
        return await router(bot, q, data, user, buildPanelCtx());
    } catch (e) {
        console.log("[ROUTER CALL ERR]", e.message);
        return bot.answerCallbackQuery(q.id, {
            text: "Error: " + e.message.slice(0, 100),
            show_alert: true
        }).catch(() => {});
    }
});

// ═══════════════════════════════════════════
// MESSAGE
// ═══════════════════════════════════════════
bot.on("message", async (msg) => {
    if (!msg.text && !msg.photo && !msg.video && !msg.document && !msg.audio && !msg.voice) return;

    const id = msg.from.id;

    if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
        try { await groupgate.handleMessage(bot, msg, { db, gate }); }
        catch (e) { console.log("[GROUPGATE ERR]", e.message); }

        try { await guard.handleMessage(bot, msg, { db, gate }); }
        catch (e) { console.log("[GUARD ERR]", e.message); }
    }

    if (msg.text && msg.text.startsWith("/")) {
        return;
    }

    const state = getState(id);
    if (!state) return;

    if (String(id) !== String(cfg.OWNER_ID)) {
        try {
            const join = await gate.checkJoin(bot, id);
            if (!join.ok) return;
        } catch {}
    }

    try {
        return await router.message(bot, msg, state, buildPanelCtx());
    } catch (e) {
        console.log("[ROUTER MSG ERR]", e.message);
        return bot.sendMessage(msg.chat.id, "Error: " + e.message.slice(0, 200), { parse_mode: "HTML" }).catch(() => {});
    }
});

bot.on("polling_error", (e) => {
    if (!e.message.includes("EFATAL")) console.log("[POLLING]", e.message);
});

// ═══════════════════════════════════════════
// GRACEFUL SHUTDOWN
// ═══════════════════════════════════════════
process.on("SIGINT", () => {
    console.log("[SHUTDOWN] SIGINT received");
    if (autoBackup) autoBackup.stopAutoBackup();
    process.exit(0);
});

process.on("SIGTERM", () => {
    console.log("[SHUTDOWN] SIGTERM received");
    if (autoBackup) autoBackup.stopAutoBackup();
    process.exit(0);
});

console.log("𖡛 𝘀𝗽𝗮𝗿𝘁𝗮𝗫 𝗕𝗢𝗧 aktif...");
console.log("[DB]", DB_DIR);
console.log("[CH]", cfg.CHANNELS.length);
console.log("[OWNER]", cfg.OWNER_ID);