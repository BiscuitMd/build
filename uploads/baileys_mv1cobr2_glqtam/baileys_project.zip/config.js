module.exports = {
    // ═══════════════════════════════════════════
    // BOT CONFIG
    // ═══════════════════════════════════════════
    BOT_TOKEN: "8851814221:AAE1sbDpicb5nyGtOvJ0YquCv2y9IGm3xJQ",
    OWNER_ID: "8938118595",
    OWNER_USERNAME: "@biscuitMD",
    GROUP_UPDATE: "https://t.me/biscuitMD",

    MAIN_GROUP_ID: "-1003963880893",

    APP_MODE: process.env.NODE_ENV || "production",
    MAX_PAIRING: 5,
    TIMEOUT_PAIRING: 30000,

    CREDIT_PER_USE: 1,

    CHANNELS: [
        { name: "Channel 1", url: "https://t.me/Aboutlyd", style: "success" },
        { name: "Channel 2", url: "https://t.me/testilyd", style: "success" },
        { name: "Channel 3", url: "https://t.me/monitortesfuncexoid", style: "success" }
    ],

    NOTIF_CHANNEL: "-1004389804220",
   
   BUY_ROLE_NOTIF_CHANNEL: "-1004389804220",

    // ═══════════════════════════════════════════
    // PANEL — Legacy config (dipake panel.js lama)
    // ═══════════════════════════════════════════
    PANEL: {
        PLTA: "https://plta.domain-lu.com",
        PLTC: "https://pltc.domain-lu.com",
        DOMAIN: "panel.domain-lu.com",
        DEFAULT_DAYS: 30,
        DEFAULT_CREDIT: 10,
        ROLE_DEFAULT: "reseller",
        MONITOR_INTERVAL: 5 * 60 * 1000
    },

    // ═══════════════════════════════════════════
    // PANEL_ILLEGAL — Server 1 (Ilegal)
    // Info yang ditampilin ke user (link login, grup)
    // ═══════════════════════════════════════════
    PANEL_ILLEGAL: {
        PLTA: "https://panel1.domain-lu.com",
        PLTC: "https://pltc1.domain-lu.com",
        DOMAIN: "panel1.domain-lu.com",
        GROUP_LINK: "https://t.me/biscuitMD",
        TYPE: "illegal"
    },

    // ═══════════════════════════════════════════
    // PANEL_LEGAL — Server 2 (Legal)
    // ═══════════════════════════════════════════
    PANEL_LEGAL: {
        PLTA: "https://panel2.domain-lu.com",
        PLTC: "https://pltc2.domain-lu.com",
        DOMAIN: "panel2.domain-lu.com",
        GROUP_LINK: "https://t.me/biscuitMD",
        TYPE: "legal"
    },

    // ═══════════════════════════════════════════
    // PTERODACTYL — API Config (buat /create + /cadp)
    // ═══════════════════════════════════════════
    // Cara dapetin API Key:
    // 1. Login Pterodactyl sebagai ADMIN
    // 2. Klik user icon (kanan atas) → API Credentials
    // 3. Klik "Create API Key"
    // 4. Kasih nama "SpartaX Bot"
    // 5. Centang ALL permissions (Application + Client)
    // 6. Copy key yang mulai "ptla_..."
    // ═══════════════════════════════════════════
    PTERODACTYL: {
        // ═══ SERVER 1 (ILEGAL) ═══
        PLTA: {
            URL: "https://panel1.domain-lu.com",              // ← GANTI: URL panel Pterodactyl server 1
            API_KEY: "ptla_GANTI_DENGAN_API_KEY_PANEL_1",      // ← GANTI: Application API Key panel 1
            NEST_ID: 1,                                         // ← Nest ID default
            DEFAULT_LOCATION: 1,                                // ← Location / Node ID
            DEFAULT_MEMORY: 1024,                               // ← RAM (MB)
            DEFAULT_DISK: 2048,                                 // ← Disk (MB)
            DEFAULT_CPU: 50,                                    // ← CPU (%)
            DEFAULT_DATABASES: 1,                               // ← Jumlah database
            DEFAULT_BACKUPS: 1,                                 // ← Jumlah backup
            DEFAULT_ALLOCATIONS: 0                              // ← Extra allocations
        },

        // ═══ SERVER 2 (LEGAL) ═══
        PLTC: {
            URL: "https://panel2.domain-lu.com",              // ← GANTI: URL panel Pterodactyl server 2
            API_KEY: "ptlc_GANTI_DENGAN_API_KEY_PANEL_2",      // ← GANTI: Application API Key panel 2
            NEST_ID: 1,
            DEFAULT_LOCATION: 1,
            DEFAULT_MEMORY: 1024,
            DEFAULT_DISK: 2048,
            DEFAULT_CPU: 50,
            DEFAULT_DATABASES: 1,
            DEFAULT_BACKUPS: 1,
            DEFAULT_ALLOCATIONS: 0
        },

        // ═══ DOMAIN (buat email username@domain) ═══
        DOMAIN: "panel.domain-lu.com"                           // ← GANTI: domain panel
    },

    // ═══════════════════════════════════════════
    // ROLE SYSTEM
    // ═══════════════════════════════════════════
    HARGA_ROLE: {
        illegal: {
            reseller: 1000,
            admin: 2000,
            owner: 3000,
            partner: 4000,
            tangankanann: 5000,
            ceo: 6000,
            developer: 10000
        },
        legal: {
            reseller: 10000,
            admin: 25000,
            owner: 40000,
            partner: 55000,
            tangankanann: 70000,
            ceo: 85000,
            developer: 100000
        }
    },

    ROLE_BENEFIT: {
        reseller: "Buat panel + akses menu dasar",
        admin: "Semua benefit Reseller + add reseller + CADP",
        owner: "Semua benefit Admin + add admin",
        partner: "Semua benefit Owner + add owner",
        tangankanann: "Semua benefit Partner + add partner",
        ceo: "Semua benefit Tangan Kanan + add tangan kanan + delete offline server",
        developer: "SEMUA AKSES + add semua role + delete offline + monitoring"
    },

    // ═══════════════════════════════════════════
    // EGGS — Fallback list (kalo API panel error)
    // ═══════════════════════════════════════════
    EGG_15: [
        { id: "nodejs_18", name: "Node.js 18", egg_id: 1, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_18", startup: "npm start", category: "nodejs" },
        { id: "nodejs_20", name: "Node.js 20", egg_id: 2, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_20", startup: "node index.js", category: "nodejs" },
        { id: "nodejs_22", name: "Node.js 22", egg_id: 3, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_22", startup: "node index.js", category: "nodejs" },
        { id: "python_310", name: "Python 3.10", egg_id: 4, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.10", startup: "python main.py", category: "python" },
        { id: "python_311", name: "Python 3.11", egg_id: 5, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.11", startup: "python main.py", category: "python" },
        { id: "python_312", name: "Python 3.12", egg_id: 6, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.12", startup: "python main.py", category: "python" },
        { id: "minecraft_java", name: "Minecraft Java", egg_id: 7, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}", category: "minecraft" },
        { id: "minecraft_paper", name: "Minecraft PaperMC", egg_id: 8, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}", category: "minecraft" },
        { id: "minecraft_bedrock", name: "Minecraft Bedrock", egg_id: 9, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:debian", startup: "./bedrock_server", category: "minecraft" },
        { id: "ubuntu_2204", name: "Ubuntu 22.04", egg_id: 10, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:ubuntu", startup: "bash", category: "os" },
        { id: "debian_12", name: "Debian 12", egg_id: 11, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:debian", startup: "bash", category: "os" },
        { id: "alpine", name: "Alpine", egg_id: 12, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:alpine", startup: "sh", category: "os" },
        { id: "java_17", name: "Java 17", egg_id: 13, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -jar {{SERVER_JARFILE}}", category: "java" },
        { id: "golang", name: "Golang", egg_id: 14, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:go", startup: "./main", category: "golang" },
        { id: "nginx", name: "Nginx", egg_id: 15, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nginx", startup: "nginx -g 'daemon off;'", category: "web" }
    ],

    // ═══════════════════════════════════════════
    // ALLOCATION & RAM OPTIONS
    // ═══════════════════════════════════════════
    ALLOCATION_1: {
        location_id: 1,
        default_ip: "0.0.0.0",
        default_port: 25565,
        additional_ports: 5,
        memory_min: 512,
        memory_max: 10240,
        disk_min: 1024,
        disk_max: 51200,
        cpu_min: 10,
        cpu_max: 100,
        databases: 1,
        backups: 3,
        allocations: 3
    },

    RAM_OPTIONS: {
        nodejs: ["512MB", "1GB", "2GB", "3GB", "4GB", "5GB", "8GB", "Unli"],
        python: ["512MB", "1GB", "2GB", "3GB", "4GB", "5GB", "8GB", "Unli"],
        minecraft: ["2GB", "4GB", "6GB", "8GB", "12GB", "16GB", "Unli"],
        os: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        java: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        golang: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        web: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"]
    },

    // ═══════════════════════════════════════════
    // API KEYS
    // ═══════════════════════════════════════════
    API_KEYS: {
        SPOTIFY_CLIENT_ID: "ISI_SPOTIFY_CLIENT_ID",
        SPOTIFY_CLIENT_SECRET: "ISI_SPOTIFY_CLIENT_SECRET",
        SPOTIFY_ACCESS_TOKEN: "",
        DEEZER: "",
        YOUTUBE: "ISI_YOUTUBE_API_KEY",
        OPENWEATHER: "",
        OPENAI: "ISI_OPENAI_API_KEY",
        GEMINI: "ISI_GEMINI_API_KEY",
        REPLICATE: "ISI_REPLICATE_API_KEY",
        ANIME_AI: "",
        NGL: "",
        VERCEL_TOKEN: "ISI_VERCEL_TOKEN_LU",
        NETFLIX_TOKEN: "ISI_NETFLIX_TOKEN_LU",
        BETABOTZ: "Btz-Xx9CJ"
    },

    VERCEL: {
        TOKEN: "ISI_VERCEL_TOKEN_LU",
        TEAM_ID: "",
        PROJECT_NAME_PREFIX: "spartax-deploy"
    },

    NETFLIX: {
        TOKEN: "ISI_NETFLIX_TOKEN_LU",
        API_URL: "https://api.netflix-deploy.example.com",
        TEAM_ID: "",
        PROJECT_NAME_PREFIX: "spartax-nf"
    },

    API_ENDPOINTS: {
        WEATHER: "https://api.open-meteo.com/v1/forecast",
        GEO: "https://geocoding-api.open-meteo.com/v1/search",
        PRAYER: "https://api.aladhan.com/v1/timingsByCity",
        DEEZER: "https://api.deezer.com/search",
        LYRICS: "https://api.lyrics.ovh/v1",
        TIKTOK: "https://tikwm.com/api/",
        BRAT: "https://api.siputzx.my.id/api/m/brat",
        ANIME: "https://api.siputzx.my.id/api/ai/animediffusion",
        NGL: "https://ngl.link/api/submit",
        INSTAGRAM: "https://api.instagram.com/oembed/",
        YOUTUBE_OEMBED: "https://www.youtube.com/oembed"
    },

    // ═══════════════════════════════════════════
    // FOTO / IMAGE URLs
    // ═══════════════════════════════════════════
    FOTO: {
        MENU: "https://files.catbox.moe/3hj0vu.png",
        TQTO: "https://files.catbox.moe/3hj0vu.png",
        ADD_SENDER: "https://files.catbox.moe/3hj0vu.png",
        CLEAR_SENDER: "https://files.catbox.moe/3hj0vu.png",
        TESFUNC: "https://files.catbox.moe/3hj0vu.png",
        BUY_CREDIT: "https://files.catbox.moe/3hj0vu.png",
        BUY_PREMIUM: "https://files.catbox.moe/3hj0vu.png",
        REPORT: "https://files.catbox.moe/3hj0vu.png",
        CHATDEV: "https://files.catbox.moe/3hj0vu.png",
        BUY_SCRIPT: "https://files.catbox.moe/3hj0vu.png",
        DEVELOPER: "https://files.catbox.moe/3hj0vu.png",
        PREMIUM_MENU: "https://files.catbox.moe/3hj0vu.png",
        BROADCAST: "https://files.catbox.moe/3hj0vu.png",
        QRIS: "https://files.catbox.moe/d272b6.jpeg",
        CEKERROR: "https://files.catbox.moe/3hj0vu.png",
        DEPLOY: "https://files.catbox.moe/3hj0vu.png",
        TOOLS: "https://files.catbox.moe/3hj0vu.png",
        MUSIC: "https://files.catbox.moe/3hj0vu.png",
        GUARD: "https://files.catbox.moe/3hj0vu.png",
        PANEL: "https://files.catbox.moe/3hj0vu.png",
        MONITOR: "https://files.catbox.moe/3hj0vu.png"
    },

    // ═══════════════════════════════════════════
    // HARGA
    // ═══════════════════════════════════════════
    HARGA: {
        CREDIT_PER_1: 100,
        MAX_CREDIT: 500,
        PREMIUM: 10000,
        SCRIPT_NO_UP: 10000,
        SCRIPT_FULL_UP: 25000
    },

    BAN_DURASI: {
        "1jam": 60 * 60 * 1000,
        "1hari": 24 * 60 * 60 * 1000,
        "1bulan": 30 * 24 * 60 * 60 * 1000,
        "1tahun": 365 * 24 * 60 * 60 * 1000
    },

    REDEEM_MAX_CREDIT: 500,
    DEFAULT_CREDIT: 5,
    DEFAULT_ROLE: "free",

    // ═══════════════════════════════════════════
    // GITHUB — WAJIB buat build APK
    // JANGAN HAPUS!
    // ═══════════════════════════════════════════
    GITHUB: {
        TOKEN: "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",
        USERNAME: "BiscuitMd",
        REPO: "build",
        BRANCH: "main",
        WORKFLOW_FLUTTER: "flutter-build.yml",
        WORKFLOW_NATIVE: "native-build.yml",
        WORKFLOW_WEB2APP: "web-to-app.yml"
    },

    // ═══════════════════════════════════════════
    // BUILD CONFIG
    // ═══════════════════════════════════════════
    BUILD_LOG_CHANNEL: "-1004389804220",
    BUILD_POLL_INTERVAL: 15000,
    BUILD_MAX_WAIT_MS: 1800000,
    BUILD_TMP_DIR: "tmp_build",

    // ═══════════════════════════════════════════
    // AI — Multi Provider
    // Priority: 1. Groq → 2. Gemini → 3. Cerebras
    // 4. OpenRouter → 5. DeepInfra → 6. HF
    // 7. Pollinations → 8. DuckDuckGo
    // ═══════════════════════════════════════════
    AI: {
        GROQ_KEY: "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",
        GEMINI_KEY: "ISI_GEMINI_KEY_DARI_aistudio.google.com",
        CEREBRAS_KEY: "",
        OPENROUTER_KEY: "",
        MAX_MEMORY: 15,
        TEMPERATURE: 0.85
    }
};