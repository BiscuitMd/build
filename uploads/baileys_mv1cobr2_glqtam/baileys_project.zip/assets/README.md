# Exoid Engine — Assets

Taruh semua foto di sini, atau pakai URL langsung di config.js:

- menu.jpg          → FOTO.MENU
- addsender.jpg     → FOTO.ADD_SENDER
- clearsender.jpg   → FOTO.CLEAR_SENDER
- tesfunc.jpg       → FOTO.TESFUNC
- buycredit.jpg     → FOTO.BUY_CREDIT
- buypremium.jpg    → FOTO.BUY_PREMIUM
- report.jpg        → FOTO.REPORT
- chatdev.jpg       → FOTO.CHATDEV
- buyscript.jpg     → FOTO.BUY_SCRIPT
- developer.jpg     → FOTO.DEVELOPER
- premiummenu.jpg   → FOTO.PREMIUM_MENU
- broadcast.jpg     → FOTO.BROADCAST
- qris.jpg          → FOTO.QRIS