const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_autorespon.json");
if (!fs.existsSync(path.dirname(DB))) fs.mkdirSync(path.dirname(DB), { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

function read() {
    try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; }
}

function write(d) {
    try {
        const tmp = DB + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(d, null, 2), "utf8");
        fs.renameSync(tmp, DB);
    } catch (e) {
        console.log("[AUTORESPOON] gagal simpan:", e.message);
    }
}

function defaultData() {
    return {
        enabled: false,
        mode: "all",
        reply: "Halo! Pesan lu udah masuk, nanti dibalas ya.",
        custom: {},
        cooldown: 60000,
        blacklist: [],
        whitelist: [],
        lastReply: {},
        stats: { totalReplied: 0, totalSkipped: 0, totalCooldown: 0 }
    };
}

function getData(db, userId) {
    db[userId] = db[userId] || defaultData();
    const d = db[userId];
    // lengkapi field yang mungkin belum ada di file lama
    const def = defaultData();
    for (const k of Object.keys(def)) if (d[k] === undefined) d[k] = def[k];
    return d;
}

// ═══ COMMAND: .autorespon ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    const data = getData(db, userId);

    if (cmd === "on") {
        data.enabled = true;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-respon ON\n▸ Mode: " + data.mode.toUpperCase() });
    }

    if (cmd === "off") {
        data.enabled = false;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-respon OFF" });
    }

    if (cmd === "set") {
        const text = args.slice(1).join(" ").trim();
        if (!text) return client.sendMessage(chatId, { message: "▸ .autorespon set [teks balasan]" });
        data.reply = text;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Balasan global diset:\n\n\"" + text + "\"" });
    }

    if (cmd === "setuser") {
        const target = normTarget(args[1]);
        const text = args.slice(2).join(" ").trim();
        if (!target || !text) return client.sendMessage(chatId, { message: "▸ .autorespon setuser [@user/ID] [teks]" });
        data.custom[target] = text;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Balasan custom untuk " + target + ":\n\n\"" + text + "\"" });
    }

    if (cmd === "deluser") {
        const target = normTarget(args[1]);
        if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon deluser [@user/ID]" });
        delete data.custom[target];
        write(db);
        return client.sendMessage(chatId, { message: "✓ Custom balasan dihapus untuk: " + target });
    }

    if (cmd === "listuser") {
        const keys = Object.keys(data.custom);
        if (!keys.length) return client.sendMessage(chatId, { message: "▸ Gaada balasan custom" });
        let list = "";
        keys.forEach((k, i) => { list += "│ " + (i + 1) + ". " + k + " → " + data.custom[k].slice(0, 30) + "\n"; });
        return client.sendMessage(chatId, { message: "◆ Custom Balasan\n\n" + list });
    }

    if (cmd === "mode") {
        const m = args[1]?.toLowerCase();
        if (!["all", "dm", "gc"].includes(m)) return client.sendMessage(chatId, { message: "▸ .autorespon mode all/dm/gc" });
        data.mode = m;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Mode: " + m.toUpperCase() });
    }

    if (cmd === "cooldown") {
        const sec = parseInt(args[1]);
        if (isNaN(sec) || sec < 5) return client.sendMessage(chatId, { message: "▸ .autorespon cooldown [detik min 5]" });
        data.cooldown = sec * 1000;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Cooldown: " + sec + "s" });
    }

    if (cmd === "bl" || cmd === "wl") {
        const sub = args[1]?.toLowerCase();
        const target = normTarget(args[2]);
        const key = cmd === "bl" ? "blacklist" : "whitelist";

        if (sub === "add") {
            if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon " + cmd + " add [@user/ID]" });
            if (!data[key].includes(target)) data[key].push(target);
            write(db);
            return client.sendMessage(chatId, { message: "✓ " + cmd.toUpperCase() + " ditambah: " + target });
        }

        if (sub === "del") {
            if (!target) return client.sendMessage(chatId, { message: "▸ .autorespon " + cmd + " del [@user/ID]" });
            data[key] = data[key].filter(x => x !== target);
            write(db);
            return client.sendMessage(chatId, { message: "✓ Dihapus: " + target });
        }

        if (sub === "list" || !sub) {
            if (!data[key].length) return client.sendMessage(chatId, { message: "▸ " + key + " kosong" });
            let list = "";
            data[key].forEach((x, i) => { list += "│ " + (i + 1) + ". " + x + "\n"; });
            return client.sendMessage(chatId, { message: "◆ " + cmd.toUpperCase() + "\n\n" + list });
        }

        return client.sendMessage(chatId, { message: "▸ .autorespon " + cmd + " add/del/list" });
    }

    if (cmd === "reset") {
        db[userId] = defaultData();
        write(db);
        return client.sendMessage(chatId, { message: "✓ Config direset" });
    }

    if (!cmd || cmd === "status") {
        const t =
            "╭───────────────────╮\n" +
            "│   ◇  AUTORESPON    │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ◆ STATUS\n" +
            "├───────────────────\n" +
            "│ ▪ Enabled   → " + (data.enabled ? "ON" : "OFF") + "\n" +
            "│ ▪ Mode      → " + data.mode.toUpperCase() + "\n" +
            "│ ▪ Cooldown  → " + (data.cooldown / 1000) + "s\n" +
            "│ ▪ Custom    → " + Object.keys(data.custom).length + " user\n" +
            "│ ▪ Bl/Wl     → " + data.blacklist.length + "/" + data.whitelist.length + "\n" +
            "│ ▪ Dibalas   → " + data.stats.totalReplied + "x\n" +
            "├───────────────────\n" +
            "│ ◆ BALASAN GLOBAL\n" +
            "├───────────────────\n" +
            "│ " + data.reply.slice(0, 60) + "\n" +
            "├───────────────────\n" +
            "│ ◆ COMMANDS\n" +
            "├───────────────────\n" +
            "│ ▪ .autorespon on/off\n" +
            "│ ▪ .autorespon set [teks]\n" +
            "│ ▪ .autorespon setuser [@user] [teks]\n" +
            "│ ▪ .autorespon deluser [@user]\n" +
            "│ ▪ .autorespon listuser\n" +
            "│ ▪ .autorespon mode all/dm/gc\n" +
            "│ ▪ .autorespon cooldown [detik]\n" +
            "│ ▪ .autorespon bl/wl add/del/list\n" +
            "│ ▪ .autorespon reset\n" +
            "╰───────────────────";
        return client.sendMessage(chatId, { message: t });
    }

    return client.sendMessage(chatId, {
        message: "▸ .autorespon on/off/set/setuser/deluser/listuser/mode/cooldown/bl/wl/reset/status"
    });
}

// normalisasi target: "@User" → "@user", "123" → "123"
function normTarget(t) {
    if (!t) return null;
    t = String(t).trim();
    if (t.startsWith("@")) return t.toLowerCase();
    return t;
}

// ═══ AUTO-RESPON PESAN MASUK ═══
// Dipanggil dari event handler NewMessage (incoming: true) dengan event-nya.
async function handleIncoming(userId, client, event) {
    try {
        const m = event.message;
        if (!m) return;

        const db = read();
        const data = getData(db, userId);
        if (!data.enabled) return;

        if (m.out) return;                                   // pesan dari akun sendiri
        const text = m.message || m.text || "";
        if (!text) return;

        // filter tipe chat sesuai mode
        const isDM = m.isPrivate;
        const isGC = m.isGroup || m.isChannel;
        if (data.mode === "dm" && !isDM) return;
        if (data.mode === "gc" && !isGC) return;

        const sender = await m.getSender().catch(() => null);
        if (!sender) return;
        if (sender.bot) return;                               // jangan balas bot

        const senderId = String(sender.id);
        if (senderId === String(userId)) return;

        const username = sender.username ? "@" + sender.username.toLowerCase() : null;

        // blacklist
        if (data.blacklist.includes(senderId) || (username && data.blacklist.includes(username))) {
            data.stats.totalSkipped++; write(db); return;
        }

        // whitelist (kalau diisi, hanya yang ada di whitelist yang dibalas)
        if (data.whitelist.length > 0) {
            const inWL = data.whitelist.includes(senderId) || (username && data.whitelist.includes(username));
            if (!inWL) { data.stats.totalSkipped++; write(db); return; }
        }

        // cooldown per pengirim
        const last = data.lastReply[senderId] || 0;
        if (Date.now() - last < data.cooldown) {
            data.stats.totalCooldown++; write(db); return;
        }

        // pilih balasan: custom per user (ID atau @username) lalu balasan global
        let replyText = data.reply;
        if (data.custom[senderId]) replyText = data.custom[senderId];
        else if (username && data.custom[username]) replyText = data.custom[username];

        // jeda acak supaya tidak terlihat seperti bot
        await new Promise(r => setTimeout(r, Math.floor(Math.random() * 2000) + 1000));

        try {
            await m.reply({ message: replyText });
        } catch {
            const chat = await m.getInputChat();
            await client.sendMessage(chat, { message: replyText, replyTo: m.id });
        }

        data.lastReply[senderId] = Date.now();
        data.stats.totalReplied++;
        write(db);

        console.log("[AUTORESPOON] replied to " + senderId);
    } catch (e) {
        console.log("[AUTORESPOON] err: " + (e.message || String(e)).slice(0, 100));
    }
}

module.exports = {
    command: "autorespon",
    handler,
    handleIncoming,
    description: "Auto-balas pesan masuk (teks global + custom per user)",
    category: "tools",
    commands: ["ar"]
};