const fs = require("fs");
const path = require("path");

const DB = path.join(__dirname, "..", "..", "..", "database", "userbot_afk.json");
if (!fs.existsSync(path.dirname(DB))) fs.mkdirSync(path.dirname(DB), { recursive: true });
if (!fs.existsSync(DB)) fs.writeFileSync(DB, "{}", "utf8");

const DEFAULT_TEMPLATE =
    "◇ AFK — {alasan}\n\n" +
    "▪ Sejak: {durasi} lalu\n" +
    "▪ Nanti dibalas kalau udah online";

const REPLY_COOLDOWN_MS = 5 * 60 * 1000; // 1 balasan per pengirim tiap 5 menit
const lastReplied = new Map();           // key: `${userId}:${senderId}` → timestamp

function read() {
    try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {}; }
}

function write(d) {
    try {
        const tmp = DB + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(d, null, 2), "utf8");
        fs.renameSync(tmp, DB);
    } catch (e) {
        console.log("[AFK] gagal simpan:", e.message);
    }
}

function getUserData(db, userId) {
    db[userId] = db[userId] || {
        afk: false,
        reason: "",
        since: 0,
        autoReply: true,
        template: DEFAULT_TEMPLATE
    };
    if (!db[userId].template) db[userId].template = DEFAULT_TEMPLATE;
    return db[userId];
}

function formatDuration(ms) {
    const s = Math.floor(ms / 1000);
    if (s < 60) return s + " detik";
    const m = Math.floor(s / 60);
    if (m < 60) return m + " menit";
    const h = Math.floor(m / 60);
    if (h < 24) return h + " jam " + (m % 60) + " menit";
    return Math.floor(h / 24) + " hari";
}

function buildReply(data) {
    const dur = data.since ? formatDuration(Date.now() - data.since) : "-";
    return (data.template || DEFAULT_TEMPLATE)
        .replace(/\{alasan\}/g, data.reason || "sedang tidak tersedia")
        .replace(/\{durasi\}/g, dur);
}

// ═══ COMMAND: .afk ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();
    const db = read();
    const d = getUserData(db, userId);

    // .afk  → tampilkan status
    if (!cmd || cmd === "status") {
        const dur = d.afk && d.since ? formatDuration(Date.now() - d.since) : "-";
        const t =
            "╭───────────────────╮\n" +
            "│   ◇  AFK MODE      │\n" +
            "╰───────────────────╯\n\n" +
            "├───────────────────\n" +
            "│ ▪ Status    → " + (d.afk ? "ON" : "OFF") + "\n" +
            "│ ▪ Alasan    → " + (d.reason || "-") + "\n" +
            "│ ▪ Sejak     → " + (d.afk ? dur + " lalu" : "-") + "\n" +
            "│ ▪ AutoRP    → " + (d.autoReply ? "ON" : "OFF") + "\n" +
            "├───────────────────\n" +
            "│ ◆ COMMANDS\n" +
            "├───────────────────\n" +
            "│ ▪ .afk on [alasan]\n" +
            "│ ▪ .afk off\n" +
            "│ ▪ .afk set [alasan]\n" +
            "│ ▪ .afk pesan [teks balasan]\n" +
            "│ ▪ .afk autoreply on/off\n" +
            "│ ▪ .afk reset\n" +
            "│ ▪ .afk status\n" +
            "╰───────────────────\n\n" +
            "Placeholder pesan: {alasan} {durasi}";
        return client.sendMessage(chatId, { message: t });
    }

    // .afk on [alasan]
    if (cmd === "on") {
        const reason = args.slice(1).join(" ").trim() || "AFK";
        d.afk = true;
        d.reason = reason;
        d.since = Date.now();
        write(db);
        return client.sendMessage(chatId, {
            message:
                "✓ AFK MODE ON\n\n" +
                "├─────────────────\n" +
                "│ ▪ Alasan   → " + reason + "\n" +
                "│ ▪ Sejak    → " + new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + "\n" +
                "│ ▪ AutoRP   → " + (d.autoReply ? "ON" : "OFF") + "\n" +
                "╰─────────────────"
        });
    }

    // .afk off
    if (cmd === "off") {
        d.afk = false;
        d.since = 0;
        write(db);
        return client.sendMessage(chatId, { message: "✓ AFK OFF — Welcome back!" });
    }

    // .afk set [alasan]  → ubah alasan tanpa mematikan AFK
    if (cmd === "set") {
        const reason = args.slice(1).join(" ").trim();
        if (!reason) return client.sendMessage(chatId, { message: "▸ .afk set [alasan]" });
        d.reason = reason;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Alasan AFK: " + reason });
    }

    // .afk pesan [teks]  → ubah isi pesan auto-reply
    if (cmd === "pesan") {
        const text = args.slice(1).join(" ").trim();
        if (!text) {
            return client.sendMessage(chatId, {
                message: "▸ .afk pesan [teks balasan]\n▸ Placeholder: {alasan} {durasi}\n▸ Kosongkan dengan .afk pesan reset"
            });
        }
        if (text.toLowerCase() === "reset") {
            d.template = DEFAULT_TEMPLATE;
            write(db);
            return client.sendMessage(chatId, { message: "✓ Pesan balasan dikembalikan ke default" });
        }
        d.template = text;
        write(db);
        return client.sendMessage(chatId, { message: "✓ Pesan auto-reply diubah:\n\n" + buildReply(d) });
    }

    // .afk autoreply on/off
    if (cmd === "autoreply") {
        const v = args[1]?.toLowerCase();
        if (!["on", "off"].includes(v)) {
            return client.sendMessage(chatId, { message: "▸ .afk autoreply on/off" });
        }
        d.autoReply = v === "on";
        write(db);
        return client.sendMessage(chatId, { message: "✓ Auto-reply: " + v.toUpperCase() });
    }

    // .afk reset  → kembalikan semua setting default
    if (cmd === "reset") {
        db[userId] = {
            afk: false, reason: "", since: 0, autoReply: true, template: DEFAULT_TEMPLATE
        };
        write(db);
        return client.sendMessage(chatId, { message: "✓ Setting AFK direset ke default" });
    }

    return client.sendMessage(chatId, {
        message: "▸ .afk on/off/set/pesan/autoreply/reset/status"
    });
}

// ═══ AUTO-REPLY PESAN MASUK ═══
// Dipanggil dari event handler (NewMessage, incoming: true) dengan event-nya.
async function handleIncoming(userId, client, event) {
    try {
        const m = event.message;
        if (!m) return;

        const db = read();
        const data = db[userId];
        if (!data || !data.afk || !data.autoReply) return;

        if (m.out) return;                       // pesan dari akun sendiri
        if (!m.isPrivate) return;                // hanya chat pribadi (ubah jika mau grup)

        const text = m.message || m.text || "";
        if (!text) return;

        const senderId = m.senderId?.toString() || "";
        if (!senderId || senderId === String(userId)) return;

        const sender = m.sender || (typeof m.getSender === "function" ? await m.getSender().catch(() => null) : null);
        if (sender?.bot) return;                 // jangan balas bot

        // cooldown per pengirim
        const key = `${userId}:${senderId}`;
        const last = lastReplied.get(key) || 0;
        if (Date.now() - last < REPLY_COOLDOWN_MS) return;
        lastReplied.set(key, Date.now());

        const reply = buildReply(data);

        // jeda acak supaya tidak terlihat seperti bot
        await new Promise(r => setTimeout(r, Math.floor(Math.random() * 1500) + 800));

        try {
            if (typeof m.reply === "function") {
                await m.reply({ message: reply });
            } else {
                await client.sendMessage(m.peerId, { message: reply, replyTo: m.id });
            }
        } catch {
            await client.sendMessage(m.peerId, { message: reply }).catch(() => {});
        }

        console.log("[AFK] replied to " + senderId);
    } catch (e) {
        console.log("[AFK] err: " + (e.message || String(e)).slice(0, 100));
    }
}

module.exports = {
    command: "afk",
    handler,
    handleIncoming,
    description: "Mode AFK — auto-respon saat tidak online",
    category: "tools"
};