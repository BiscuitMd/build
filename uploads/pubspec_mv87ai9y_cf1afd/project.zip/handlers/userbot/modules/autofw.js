const fs = require("fs");
const path = require("path");

const FW_FILE = path.join(__dirname, "..", "..", "..", "database", "userbot_autofw.json");
if (!fs.existsSync(path.dirname(FW_FILE))) fs.mkdirSync(path.dirname(FW_FILE), { recursive: true });
if (!fs.existsSync(FW_FILE)) fs.writeFileSync(FW_FILE, "{}", "utf8");

const DEFAULT_INTERVAL_MS = 5 * 60 * 1000;   // jeda antar putaran: 5 menit
const MAX_AUTO_WAIT_MS = 6 * 60 * 60 * 1000; // FLOOD_WAIT di atas 6 jam dianggap limit berat

// Runtime state (per userId)
const RUNNING_JOBS = new Map();

const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
};

// ═══ FILE HELPERS ═══
function readFw() {
    try { return JSON.parse(fs.readFileSync(FW_FILE, "utf8")); } catch { return {}; }
}

function writeFw(data) {
    try {
        const tmp = FW_FILE + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
        fs.renameSync(tmp, FW_FILE);
    } catch (e) {
        console.log("[AUTOFW] gagal simpan:", e.message);
    }
}

function defaultConfig() {
    return {
        enabled: false,
        mode: "both",              // "user" | "group" | "channel" | "both"
        intervalMs: DEFAULT_INTERVAL_MS,
        blacklist: [],             // [ { id, name, addedAt } ]
        limit: null,               // { type, at, until, note } kalau kena limit
        lastRun: 0,
        totalSent: 0,
        totalFailed: 0,
        totalRounds: 0
    };
}

function getConfig(userId) {
    const fw = readFw();
    const uid = String(userId);
    if (!fw[uid]) {
        fw[uid] = defaultConfig();
        writeFw(fw);
    }
    const c = { ...defaultConfig(), ...fw[uid] };
    if (!c.mode) c.mode = "both";
    if (!c.intervalMs) c.intervalMs = DEFAULT_INTERVAL_MS;
    if (!Array.isArray(c.blacklist)) c.blacklist = [];
    return c;
}

function setConfig(userId, patch) {
    const fw = readFw();
    const uid = String(userId);
    fw[uid] = { ...defaultConfig(), ...(fw[uid] || {}), ...patch };
    writeFw(fw);
    return fw[uid];
}

// ═══ HELPERS ═══
// Normalisasi ID supaya "-100123", "-123", dan "123" dianggap sama
function normId(id) {
    return String(id).replace(/^-100/, "").replace(/^-/, "");
}

function parseIntervalInput(input) {
    if (!input) return null;
    const m = String(input).toLowerCase().trim();
    let match = m.match(/^(\d+)\s*(ms|s|m|h)$/);
    if (match) {
        const num = parseInt(match[1], 10);
        const unit = match[2];
        if (unit === "ms") return num;
        if (unit === "s") return num * 1000;
        if (unit === "m") return num * 60 * 1000;
        if (unit === "h") return num * 60 * 60 * 1000;
    }
    match = m.match(/^(\d+)$/);
    if (match) return parseInt(match[1], 10) * 1000;
    return null;
}

function formatInterval(ms) {
    if (ms < 1000) return `${ms}ms`;
    if (ms < 60000) return `${(ms / 1000).toFixed(1)} detik`;
    if (ms < 3600000) return `${(ms / 60000).toFixed(1)} menit`;
    return `${(ms / 3600000).toFixed(1)} jam`;
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// Tidur yang bisa diputus: cek status tiap 1 detik
async function sleepInterruptible(ms, userId, job) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
        if (shouldStop(userId, job)) return false;
        await sleep(Math.min(1000, end - Date.now()));
    }
    return !shouldStop(userId, job);
}

function shouldStop(userId, job) {
    if (!job || job.stopped || job.halt) return true;
    if (RUNNING_JOBS.get(String(userId)) !== job) return true;
    return !getConfig(userId).enabled;
}

// ═══ DETEKSI ERROR / LIMIT TELEGRAM ═══
function classifyError(e) {
    const raw = String(e?.errorMessage || e?.message || "");

    if (typeof e?.seconds === "number" || /FLOOD_WAIT/i.test(raw)) {
        const sec = typeof e?.seconds === "number"
            ? e.seconds
            : parseInt((raw.match(/FLOOD_WAIT_(\d+)/i) || [])[1] || "0", 10);
        return { kind: "flood", seconds: sec };
    }
    if (/PEER_FLOOD/i.test(raw)) return { kind: "peerflood" };
    if (/PHONE_NUMBER_BANNED|USER_DEACTIVATED|AUTH_KEY_UNREGISTERED|SESSION_REVOKED|USER_DEACTIVATED_BAN/i.test(raw)) {
        return { kind: "banned" };
    }
    if (/USER_RESTRICTED|SPAM_RESTRICTED|SPAMBOT/i.test(raw)) return { kind: "restricted" };
    return { kind: "target", raw };
}

// Cek status akun lewat @SpamBot (dipanggil saat kena limit)
async function checkSpamBot(client) {
    try {
        await client.sendMessage("SpamBot", { message: "/start" });
        await sleep(5000);
        const msgs = await client.getMessages("SpamBot", { limit: 1 });
        return msgs[0]?.message || "(tidak ada balasan dari @SpamBot)";
    } catch (e) {
        return "gagal cek @SpamBot: " + (e.message || "").slice(0, 80);
    }
}

async function notifyMe(client, text) {
    try {
        await client.sendMessage("me", { message: text, parseMode: "html" });
    } catch (e) {
        console.log("[AUTOFW] notif gagal:", e.message);
    }
}

// ═══════════════════════════════════════════
// HANDLE COMMAND .autofw / .addbl / .delbl / .listbl
// ═══════════════════════════════════════════
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const uid = String(userId);
    const cfg = getConfig(userId);
    const text = msg.message?.message || msg.message?.text || "";
    const cmd = text.slice(1).trim().split(/\s+/)[0].toLowerCase();

    const isGroupChat = () => {
        const cn = msg.message?.peerId?.className || "";
        return cn === "PeerChannel" || cn === "PeerChat" || !!msg.message?.isGroup;
    };

    // ═══════════════════════════════════
    // .addbl — Blacklist group ini (HARUS DI GROUP)
    // ═══════════════════════════════════
    if (cmd === "addbl") {
        if (!isGroupChat()) {
            return client.sendMessage(chatId, {
                message:
                    `${I.cross} <b>Harus di GROUP</b>\n\n` +
                    `${I.bulletOut} Command <code>.addbl</code> cuma bisa dipake di dalam group`,
                parseMode: "html"
            });
        }

        let groupName = "Unknown Group";
        let groupId = normId(chatId);
        try {
            const entity = await client.getEntity(chatId);
            groupName = entity.title || entity.username || "Unknown Group";
            groupId = normId(entity.id);
        } catch (e) {
            console.log("[AUTOFW addbl] getEntity fail:", e.message);
        }

        const fw = readFw();
        const userCfg = { ...defaultConfig(), ...(fw[uid] || {}) };
        const existing = userCfg.blacklist.find(b => normId(b.id) === groupId);
        if (existing) {
            return client.sendMessage(chatId, {
                message:
                    `${I.squareOut} <b>Group udah di blacklist</b>\n\n` +
                    `${I.bulletOut} Nama: <b>${existing.name}</b>\n` +
                    `${I.bulletOut} ID: <code>${existing.id}</code>`,
                parseMode: "html"
            });
        }

        userCfg.blacklist.push({ id: groupId, name: groupName, addedAt: Date.now() });
        fw[uid] = userCfg;
        writeFw(fw);

        return client.sendMessage(chatId, {
            message:
                `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                `${I.pipe}  ${I.check} SUCCESS ADDBL  ${I.pipe}\n` +
                `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} GROUP INFO\n` +
                `${I.teeL}${I.line.repeat(22)}\n` +
                `${I.pipe} ${I.bullet} Nama  ${I.arrow}  <b>${groupName.slice(0, 30)}</b>\n` +
                `${I.pipe} ${I.bullet} ID    ${I.arrow}  <code>${groupId}</code>\n` +
                `${I.pipe} ${I.bullet} Total ${I.arrow}  <code>${userCfg.blacklist.length}</code> groups\n` +
                `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                `${I.arrow} <i>Group ini gaakan dikirim pesan autofw</i>`,
            parseMode: "html"
        });
    }

    // ═══════════════════════════════════
    // .delbl — Hapus group ini dari blacklist (DI GROUP)
    // ═══════════════════════════════════
    if (cmd === "delbl") {
        if (!isGroupChat()) {
            return client.sendMessage(chatId, {
                message: `${I.cross} Command <code>.delbl</code> cuma bisa di group`,
                parseMode: "html"
            });
        }

        let groupId = normId(chatId);
        try {
            const entity = await client.getEntity(chatId);
            groupId = normId(entity.id);
        } catch {}

        const fw = readFw();
        const userCfg = { ...defaultConfig(), ...(fw[uid] || {}) };
        const before = userCfg.blacklist.length;
        userCfg.blacklist = userCfg.blacklist.filter(b => normId(b.id) !== groupId);

        if (before === userCfg.blacklist.length) {
            return client.sendMessage(chatId, {
                message: `${I.squareOut} Group ini gaada di blacklist`,
                parseMode: "html"
            });
        }

        fw[uid] = userCfg;
        writeFw(fw);

        return client.sendMessage(chatId, {
            message:
                `${I.check} <b>Group dihapus dari blacklist</b>\n\n` +
                `${I.bulletOut} ID: <code>${groupId}</code>\n` +
                `${I.bulletOut} Total: <code>${userCfg.blacklist.length}</code> groups`,
            parseMode: "html"
        });
    }

    // ═══════════════════════════════════
    // .listbl — Lihat blacklist
    // ═══════════════════════════════════
    if (cmd === "listbl") {
        const bl = getConfig(userId).blacklist;
        if (bl.length === 0) {
            return client.sendMessage(chatId, { message: `${I.squareOut} Blacklist kosong`, parseMode: "html" });
        }

        let list = "";
        bl.forEach((b, i) => {
            list += `${i + 1}. <b>${String(b.name || "Unknown").slice(0, 30)}</b>\n`;
            list += `   ${I.bulletOut} <code>${b.id}</code>\n`;
        });

        return client.sendMessage(chatId, {
            message:
                `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                `${I.pipe}  ${I.square} BLACKLIST ${I.square}  ${I.pipe}\n` +
                `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                `${list}\n` +
                `${I.bulletOut} Total: <code>${bl.length}</code> groups`,
            parseMode: "html"
        });
    }

    // ═══════════════════════════════════
    // .autofw — Menu utama
    // ═══════════════════════════════════
    if (cmd === "autofw") {
        const sub = args[0]?.toLowerCase();
        const val = args[1];
        const rest = args.slice(1).join(" ");
        const job = RUNNING_JOBS.get(uid);

        const modeText =
            cfg.mode === "both" ? "User + Group + Channel" :
            cfg.mode === "user" ? "Cuma User DM" :
            cfg.mode === "group" ? "Cuma Group" :
            cfg.mode === "channel" ? "Cuma Channel" : cfg.mode;

        const limitText = cfg.limit
            ? `${cfg.limit.type.toUpperCase()} (${new Date(cfg.limit.at).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })})`
            : "Aman";

        // ─── MENU / STATUS ───
        if (!sub || sub === "status") {
            return client.sendMessage(chatId, {
                message:
                    `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
                    `${I.pipe}  ${I.square} AUTOFW  ${I.pipe}\n` +
                    `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +
                    `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.circle} STATUS\n` +
                    `${I.teeL}${I.line.repeat(22)}\n` +
                    `${I.pipe} ${I.bullet} Status     ${I.arrow}  <b>${cfg.enabled ? "ON" : "OFF"}</b>\n` +
                    `${I.pipe} ${I.bullet} Running    ${I.arrow}  <b>${job ? "YA — putaran " + job.round : "TIDAK"}</b>\n` +
                    `${I.pipe} ${I.bullet} Mode       ${I.arrow}  <b>${modeText}</b>\n` +
                    `${I.pipe} ${I.bullet} Jeda       ${I.arrow}  <b>${formatInterval(cfg.intervalMs)}</b>\n` +
                    `${I.pipe} ${I.bullet} Limit      ${I.arrow}  <b>${limitText}</b>\n` +
                    `${I.pipe} ${I.bullet} Blacklist  ${I.arrow}  <code>${cfg.blacklist.length}</code>\n` +
                    `${I.pipe} ${I.bullet} Sent       ${I.arrow}  <code>${cfg.totalSent || 0}</code>\n` +
                    `${I.pipe} ${I.bullet} Putaran    ${I.arrow}  <code>${cfg.totalRounds || 0}</code>\n` +
                    `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}\n\n` +
                    `${I.cornerTL}${I.line.repeat(22)}${I.cornerTR}\n` +
                    `${I.pipe} ${I.diamond} COMMANDS\n` +
                    `${I.teeL}${I.line.repeat(22)}\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw on</code>        Aktifin\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw off</code>       Matiin (stop putaran)\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw stop</code>      Stop putaran sekarang\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw send [text]</code>  Mulai putaran\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw mode user/group/channel/both</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw jeda 30s</code> / <code>5m</code> / <code>1h</code>\n` +
                    `${I.pipe} ${I.bullet} <code>.autofw cek</code>       Cek status akun @SpamBot\n` +
                    `${I.pipe} ${I.bullet} <code>.addbl</code> / <code>.delbl</code> / <code>.listbl</code>\n` +
                    `${I.cornerBL}${I.line.repeat(22)}${I.cornerBR}`,
                parseMode: "html"
            });
        }

        // ─── ON ───
        if (sub === "on") {
            const newCfg = setConfig(userId, { enabled: true, limit: null });
            return client.sendMessage(chatId, {
                message:
                    `${I.check} <b>AUTOFW ON</b>\n\n` +
                    `${I.bulletOut} Mode: ${newCfg.mode}\n` +
                    `${I.bulletOut} Jeda antar putaran: ${formatInterval(newCfg.intervalMs)}\n\n` +
                    `${I.arrow} Kirim <code>.autofw send [text]</code> buat mulai`,
                parseMode: "html"
            });
        }

        // ─── OFF (hentikan total) ───
        if (sub === "off") {
            setConfig(userId, { enabled: false });
            const j = RUNNING_JOBS.get(uid);
            if (j) {
                j.stopped = true;
                RUNNING_JOBS.delete(uid);
            }
            return client.sendMessage(chatId, {
                message: `${I.cross} <b>AUTOFW OFF</b>\n\n<i>Putaran dihentikan.</i>`,
                parseMode: "html"
            });
        }

        // ─── STOP (hentikan putaran, autofw tetap ON) ───
        if (sub === "stop") {
            if (job) {
                job.stopped = true;
                RUNNING_JOBS.delete(uid);
                return client.sendMessage(chatId, { message: `${I.squareOut} <b>STOPPED</b>`, parseMode: "html" });
            }
            return client.sendMessage(chatId, { message: `${I.squareOut} Gaada putaran yang jalan` });
        }

        // ─── CEK LIMIT (@SpamBot) ───
        if (sub === "cek") {
            await client.sendMessage(chatId, { message: `${I.circle} Ngecek status akun ke @SpamBot...` });
            const reply = await checkSpamBot(client);
            return client.sendMessage(chatId, {
                message: `${I.diamond} <b>Balasan @SpamBot</b>\n\n<i>${reply.slice(0, 1000)}</i>`,
                parseMode: "html"
            });
        }

        // ─── MODE ───
        if (sub === "mode") {
            if (!["user", "group", "channel", "both"].includes(val)) {
                return client.sendMessage(chatId, {
                    message: `${I.cross} Mode: <code>user</code> | <code>group</code> | <code>channel</code> | <code>both</code>`,
                    parseMode: "html"
                });
            }
            setConfig(userId, { mode: val });
            return client.sendMessage(chatId, { message: `${I.check} Mode: <b>${val.toUpperCase()}</b>`, parseMode: "html" });
        }

        // ─── JEDA ───
        if (sub === "jeda" || sub === "interval") {
            const ms = parseIntervalInput(val);
            if (!ms) {
                return client.sendMessage(chatId, {
                    message:
                        `${I.cross} Format jeda salah\n\n` +
                        `${I.bulletOut} <code>.autofw jeda 30s</code>\n` +
                        `${I.bulletOut} <code>.autofw jeda 5m</code>\n` +
                        `${I.bulletOut} <code>.autofw jeda 1h</code>`,
                    parseMode: "html"
                });
            }
            if (ms < 5000) return client.sendMessage(chatId, { message: `${I.cross} Jeda minimal 5 detik` });
            if (ms > 24 * 60 * 60 * 1000) return client.sendMessage(chatId, { message: `${I.cross} Jeda max 24 jam` });

            setConfig(userId, { intervalMs: ms });
            return client.sendMessage(chatId, {
                message: `${I.check} Jeda antar putaran: <b>${formatInterval(ms)}</b>\n<i>Berlaku dari putaran berikutnya.</i>`,
                parseMode: "html"
            });
        }

        // ─── SEND (mulai putaran) ───
        if (sub === "send") {
            if (!rest) return client.sendMessage(chatId, { message: `${I.bullet} <code>.autofw send [text]</code>`, parseMode: "html" });

            const c = getConfig(userId);
            if (!c.enabled) return client.sendMessage(chatId, { message: `${I.cross} Autofw OFF. Ketik <code>.autofw on</code> dulu` });
            if (RUNNING_JOBS.has(uid)) return client.sendMessage(chatId, { message: `${I.squareOut} Putaran udah jalan. Stop dulu pakai <code>.autofw stop</code>`, parseMode: "html" });

            await client.sendMessage(chatId, {
                message:
                    `${I.circle} <b>MULAI PUTARAN</b>\n\n` +
                    `${I.bulletOut} Mode: ${c.mode}\n` +
                    `${I.bulletOut} Jeda antar putaran: ${formatInterval(c.intervalMs)}\n` +
                    `${I.bulletOut} Text: <i>${rest.slice(0, 100)}</i>\n\n` +
                    `${I.arrow} Putaran jalan terus sampai <code>.autofw off</code>`,
                parseMode: "html"
            });

            runForward(userId, client, rest).catch(e => console.log("[AUTOFW BG ERR]", e.message));
            return;
        }

        return client.sendMessage(chatId, { message: `${I.cross} Command ga dikenal` });
    }
}

// ═══════════════════════════════════════════
// AMBIL TARGET (dialog) SESUAI MODE + BLACKLIST
// ═══════════════════════════════════════════
async function scanTargets(userId, client, cfg) {
    const blacklistIds = cfg.blacklist.map(b => normId(b.id));
    const out = { users: [], groups: [], channels: [] };

    const dialogs = await client.getDialogs({ limit: 500 });
    for (const d of dialogs) {
        const rawId = d.id;
        if (rawId === undefined || rawId === null) continue;
        const nid = normId(rawId);
        if (blacklistIds.includes(nid)) continue;

        const ref = d.inputEntity || d.entity;
        if (!ref) continue;

        if (d.isUser && !d.entity?.bot && !d.entity?.self) {
            out.users.push({ ref, id: nid, name: d.title || d.name || "User" });
        } else if (d.isGroup) {
            out.groups.push({ ref, id: nid, name: d.title || "Group" });
        } else if (d.isChannel && !d.isGroup) {
            out.channels.push({ ref, id: nid, name: d.title || "Channel" });
        }
    }

    const list = [];
    if (cfg.mode === "user" || cfg.mode === "both") list.push(...out.users.map(t => ({ ...t, type: "user" })));
    if (cfg.mode === "group" || cfg.mode === "both") list.push(...out.groups.map(t => ({ ...t, type: "group" })));
    if (cfg.mode === "channel" || cfg.mode === "both") list.push(...out.channels.map(t => ({ ...t, type: "channel" })));
    return list;
}

// ═══════════════════════════════════════════
// PUTARAN TERUS-MENERUS: putaran 1 → jeda → putaran 2 → jeda → ...
// Berhenti hanya saat .autofw off / stop, atau saat akun kena limit berat.
// ═══════════════════════════════════════════
async function runForward(userId, client, text) {
    const uid = String(userId);
    const job = { stopped: false, halt: null, round: 0, startedAt: Date.now() };
    RUNNING_JOBS.set(uid, job);

    let totalSent = 0;
    let totalFailed = 0;

    console.log("[AUTOFW] start");

    try {
        while (!shouldStop(userId, job)) {
            job.round++;
            const cfg = getConfig(userId);

            const list = await scanTargets(userId, client, cfg).catch(e => {
                console.log("[AUTOFW] scan err:", e.message);
                return [];
            });

            console.log(`[AUTOFW] putaran ${job.round} — target ${list.length}`);

            if (list.length === 0) {
                await notifyMe(client, `${I.cross} Gaada target buat dikirim. Cek mode / blacklist.`);
                // tetap nunggu jeda lalu coba lagi, supaya kalau ada chat baru bisa ikut
            }

            let roundSent = 0;
            let roundFailed = 0;

            for (let i = 0; i < list.length; i++) {
                if (shouldStop(userId, job)) break;
                const t = list[i];

                // jeda kecil antar target supaya tidak kayak spam
                const gap = Math.floor(Math.random() * 2000) + 1500;
                if (!(await sleepInterruptible(gap, userId, job))) break;

                let done = false;
                for (let attempt = 1; attempt <= 2 && !done; attempt++) {
                    try {
                        await client.sendMessage(t.ref, { message: text });
                        roundSent++;
                        done = true;
                        console.log(`[AUTOFW] ✓ [${i + 1}/${list.length}] ${t.type} ${t.name}`);
                    } catch (e) {
                        const err = classifyError(e);

                        // ── kena FLOOD_WAIT: tunggu sesuai perintah Telegram lalu coba lagi ──
                        if (err.kind === "flood") {
                            const waitMs = (err.seconds || 0) * 1000 + 3000;
                            const limitState = {
                                type: "flood",
                                at: Date.now(),
                                until: Date.now() + waitMs,
                                note: `FLOOD_WAIT ${err.seconds}s`
                            };
                            setConfig(userId, { limit: limitState });
                            console.log(`[AUTOFW] FLOOD_WAIT ${err.seconds}s — tunggu`);

                            if (waitMs > MAX_AUTO_WAIT_MS) {
                                job.halt = "flood-berat";
                                setConfig(userId, { enabled: false });
                                await notifyMe(client,
                                    `${I.cross} <b>AUTOFW DIHENTIKAN — LIMIT BERAT</b>\n\n` +
                                    `${I.bulletOut} Telegram minta tunggu <b>${err.seconds} detik</b>\n` +
                                    `${I.bulletOut} Autofw dimatikan otomatis. Nyalakan lagi dengan <code>.autofw on</code> setelah limit selesai.`);
                                break;
                            }

                            if (!(await sleepInterruptible(waitMs, userId, job))) break;
                            setConfig(userId, { limit: null });
                            continue; // coba target yang sama lagi
                        }

                        // ── kena PEER_FLOOD / restricted / banned: akun dihentikan ──
                        if (err.kind === "peerflood" || err.kind === "restricted" || err.kind === "banned") {
                            job.halt = err.kind;
                            setConfig(userId, {
                                enabled: false,
                                limit: {
                                    type: err.kind,
                                    at: Date.now(),
                                    until: null,
                                    note: (e.errorMessage || e.message || "").slice(0, 120)
                                }
                            });
                            console.log(`[AUTOFW] LIMIT ${err.kind} — autofw dihentikan`);

                            const spamReply = err.kind === "banned" ? "(skip cek)" : await checkSpamBot(client);
                            await notifyMe(client,
                                `${I.cross} <b>AKUN KENA LIMIT TELEGRAM</b>\n\n` +
                                `${I.bulletOut} Jenis: <b>${err.kind.toUpperCase()}</b>\n` +
                                `${I.bulletOut} Autofw otomatis dimatikan biar akun aman.\n\n` +
                                `${I.diamond} <b>Balasan @SpamBot:</b>\n<i>${String(spamReply).slice(0, 600)}</i>\n\n` +
                                `${I.arrow} Nyalakan lagi dengan <code>.autofw on</code> setelah limit selesai.`);
                            break;
                        }

                        // ── error per target (CHAT_WRITE_FORBIDDEN, dll): skip saja ──
                        roundFailed++;
                        console.log(`[AUTOFW] ✕ [${i + 1}/${list.length}] ${t.type} ${t.name}: ${(e.message || "").slice(0, 60)}`);
                        done = true;
                    }
                }

                if (job.halt) break;
            }

            totalSent += roundSent;
            totalFailed += roundFailed;

            const cfgNow = getConfig(userId);
            setConfig(userId, {
                totalSent: (cfgNow.totalSent || 0) + roundSent,
                totalFailed: (cfgNow.totalFailed || 0) + roundFailed,
                totalRounds: (cfgNow.totalRounds || 0) + 1,
                lastRun: Date.now()
            });

            if (shouldStop(userId, job)) break;

            // ── JEDA antar putaran ──
            const nextMs = getConfig(userId).intervalMs || DEFAULT_INTERVAL_MS;
            const nextAt = new Date(Date.now() + nextMs).toLocaleTimeString("id-ID", { timeZone: "Asia/Jakarta" });
            await notifyMe(client,
                `${I.check} <b>PUTARAN ${job.round} SELESAI</b>\n\n` +
                `${I.bulletOut} Sent: <code>${roundSent}</code> | Failed: <code>${roundFailed}</code>\n` +
                `${I.bulletOut} Jeda: <b>${formatInterval(nextMs)}</b>\n` +
                `${I.arrow} Putaran ${job.round + 1} mulai sekitar ${nextAt} WIB`);

            if (!(await sleepInterruptible(nextMs, userId, job))) break;
        }
    } catch (e) {
        console.log("[AUTOFW] loop err:", e.message);
    } finally {
        if (RUNNING_JOBS.get(uid) === job) RUNNING_JOBS.delete(uid);

        const reason = job.halt ? `dihentikan (${job.halt})` : "dihentikan manual";
        await notifyMe(client,
            `${I.squareOut} <b>AUTOFW ${reason.toUpperCase()}</b>\n\n` +
            `${I.bulletOut} Putaran: <code>${job.round}</code>\n` +
            `${I.bulletOut} Sent: <code>${totalSent}</code> | Failed: <code>${totalFailed}</code>\n` +
            `${I.bulletOut} Durasi: ${((Date.now() - job.startedAt) / 60000).toFixed(1)} menit`);
    }
}

// ═══ FORWARD PESAN MASUK (opsional, belum dipakai) ═══
async function handleForward(userId, client, msg) {
    const cfg = getConfig(userId);
    if (!cfg.enabled) return;
    if (cfg.mode === "user") return;

    const chatId = normId(msg.message.chatId);
    const blacklisted = cfg.blacklist.some(b => normId(b.id) === chatId);
    if (blacklisted) return;
}

module.exports = {
    command: "autofw",
    handler,
    handleForward,
    runForward,
    getConfig,
    setConfig,
    commands: ["autofw", "addbl", "delbl", "listbl"],
    description: "Auto forward putaran terus-menerus + jeda + deteksi limit",
    category: "forward"
};

console.log("[AUTOFW] module loaded (v5 — putaran terus + jeda + deteksi limit)");