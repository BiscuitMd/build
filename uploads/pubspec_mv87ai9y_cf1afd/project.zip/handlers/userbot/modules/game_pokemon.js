const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const sharp = require("sharp");
const { Api } = require("telegram");
const core = require("./gamecore");

const W = 800, H = 500, FPS = 6, FRAMES = 8;
const TMP = path.join(__dirname, "..", "..", "..", "tmp_game");
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

// Karakter buatan sendiri (bukan merek dagang orang lain)
const MONSTERS = [
    { name: "Voltfox", color: "#fbbf24", hp: 100, atk: 25, element: "Listrik" },
    { name: "Emberpup", color: "#f97316", hp: 110, atk: 22, element: "Api" },
    { name: "Aquashell", color: "#3b82f6", hp: 120, atk: 18, element: "Air" },
    { name: "Leafling", color: "#22c55e", hp: 115, atk: 20, element: "Tanaman" },
    { name: "Shadowmoth", color: "#7c3aed", hp: 95, atk: 28, element: "Bayangan" },
    { name: "Stonebear", color: "#78716c", hp: 140, atk: 15, element: "Batu" },
    { name: "Skydrake", color: "#0891b2", hp: 130, atk: 26, element: "Angin" },
    { name: "Glimmerbun", color: "#ec4899", hp: 105, atk: 21, element: "Cahaya" }
];

function pickRandom() {
    return MONSTERS[Math.floor(Math.random() * MONSTERS.length)];
}

// Gambar monster buatan sendiri (lingkaran + mata + bayangan)
function monsterSvg(m, cx, cy, bob, hit) {
    const flash = hit ? `<circle cx="${cx}" cy="${cy}" r="120" fill="#fff" opacity="0.35"/>` : "";
    return `${flash}
<ellipse cx="${cx}" cy="${cy + 110}" rx="90" ry="16" fill="#000" opacity="0.45"/>
<g transform="translate(0,${bob})">
  <circle cx="${cx}" cy="${cy}" r="90" fill="${m.color}" stroke="#000" stroke-width="4"/>
  <circle cx="${cx - 30}" cy="${cy - 10}" r="14" fill="#fff"/>
  <circle cx="${cx + 30}" cy="${cy - 10}" r="14" fill="#fff"/>
  <circle cx="${cx - 28}" cy="${cy - 8}" r="6" fill="#000"/>
  <circle cx="${cx + 32}" cy="${cy - 8}" r="6" fill="#000"/>
  <path d="M${cx - 25} ${cy + 30} Q${cx} ${cy + 48} ${cx + 25} ${cy + 30}" stroke="#000" stroke-width="5" fill="none"/>
</g>`;
}

function hpBar(x, y, hp, maxHp, color) {
    const w = Math.max(0, (hp / maxHp) * 260);
    const fill = hp > maxHp * 0.3 ? color : "#ef4444";
    return `<rect x="${x}" y="${y}" width="260" height="20" rx="10" fill="#333"/>` +
           `<rect x="${x}" y="${y}" width="${w}" height="20" rx="10" fill="${fill}"/>`;
}

// ═══ SCENE ═══
function sceneSvg(room, t, hitSide, caption) {
    const p1 = room.state.p1, p2 = room.state.p2;
    const bob = Math.sin(t * Math.PI * 2) * 6;
    const lunge = hitSide === 0 ? t * 40 : hitSide === 1 ? -t * 40 : 0;

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e293b"/><stop offset="1" stop-color="#0f172a"/></linearGradient>
</defs>
<rect width="${W}" height="${H}" fill="url(#bg)"/>
<rect y="380" width="${W}" height="120" fill="#14532d"/>

<text x="200" y="50" font-family="Arial" font-size="20" fill="#fff" text-anchor="middle">${core.escapeXml(p1.name)} · ${core.escapeXml(p1.element)}</text>
${hpBar(70, 70, p1.hp, p1.maxHp, "#22c55e")}
<text x="200" y="110" font-family="Arial" font-size="14" fill="#fff" text-anchor="middle">HP ${p1.hp}/${p1.maxHp}</text>

<text x="600" y="50" font-family="Arial" font-size="20" fill="#fff" text-anchor="middle">${core.escapeXml(p2.name)} · ${core.escapeXml(p2.element)}</text>
${hpBar(470, 70, p2.hp, p2.maxHp, "#3b82f6")}
<text x="600" y="110" font-family="Arial" font-size="14" fill="#fff" text-anchor="middle">HP ${p2.hp}/${p2.maxHp}</text>

<g transform="translate(${lunge},0)">${monsterSvg(p1, 200, 260, bob, hitSide === 1)}</g>
<g transform="translate(${-lunge},0)">${monsterSvg(p2, 600, 260, -bob, hitSide === 0)}</g>

<text x="400" y="${H - 30}" font-family="Arial" font-size="18" fill="#fde047" text-anchor="middle">${core.escapeXml(caption || "")}</text>
</svg>`;
}

// ═══ VIDEO ═══
async function renderVideo(room, outPath, hitSide, caption) {
    const ff = spawn("ffmpeg", [
        "-y", "-f", "image2pipe", "-framerate", String(FPS), "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", outPath
    ]);
    ff.stderr.on("data", () => {});
    ff.stdin.on("error", () => {});

    for (let i = 0; i < FRAMES; i++) {
        const t = i / (FRAMES - 1);
        const png = await sharp(Buffer.from(sceneSvg(room, t, hitSide, caption))).png().toBuffer();
        ff.stdin.write(png);
    }
    ff.stdin.end();

    await new Promise((resolve, reject) => {
        ff.on("close", code => code === 0 ? resolve() : reject(new Error("ffmpeg exit " + code)));
        ff.on("error", reject);
    });
    return outPath;
}

async function sendGame(client, chatId, room, hitSide = null, caption = "") {
    const outPath = path.join(TMP, `monster_${Date.now()}.mp4`);
    try {
        await renderVideo(room, outPath, hitSide, caption);
        await client.sendFile(chatId, {
            file: outPath,
            caption: `🎮 <b>MONSTER BATTLE</b>\n${caption}`,
            parseMode: "html",
            forceDocument: false,
            attributes: [new Api.DocumentAttributeVideo({
                duration: FRAMES / FPS, w: W, h: H, supportsStreaming: true
            })]
        });
    } catch (e) {
        console.log("[MONSTER VIDEO ERR]", e.message);
        await client.sendMessage(chatId, {
            message: `🎮 <b>MONSTER BATTLE</b>\n${caption}\n\n<i>(video gagal dibuat, cek ffmpeg)</i>`,
            parseMode: "html"
        }).catch(() => {});
    } finally {
        try { fs.unlinkSync(outPath); } catch {}
    }
}

// ═══ COMMAND ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const m = pickRandom();
        const room = core.createRoom("monster", userId, myName, me?.username || null, {
            state: { p1: { ...m, maxHp: m.hp }, p2: null },
            maxPlayers: 2,
            chatId: String(chatId)
        });
        return sendGame(client, chatId, room, null,
            `Room <code>${room.id}</code> · ${m.name} (${m.element})\nLawan join: <code>.monster join ${room.id}</code>`);
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .monster join [KODE]" });
        const r = core.joinRoom(roomId, userId, myName, me?.username || null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });

        const m2 = pickRandom();
        r.room.state.p2 = { ...m2, maxHp: m2.hp };
        core.saveRoom(r.room);

        return sendGame(client, chatId, r.room, null,
            `Battle dimulai! Giliran: ${r.room.players[0].name}. Ketik <code>.monster attack</code>`);
    }

    if (cmd === "attack") {
        const room = Object.values(core.ROOMS).find(r =>
            r.gameType === "monster" && r.status === "playing" && r.players.some(p => String(p.id) === String(userId)));
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });

        const currentPlayer = room.players[room.turn % 2];
        if (String(currentPlayer.id) !== String(userId)) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

        const myIdx = room.turn % 2;
        const myMon = myIdx === 0 ? room.state.p1 : room.state.p2;
        const enemyMon = myIdx === 0 ? room.state.p2 : room.state.p1;

        const dmg = Math.floor(myMon.atk * (0.7 + Math.random() * 0.6));
        enemyMon.hp = Math.max(0, enemyMon.hp - dmg);

        const hitSide = myIdx === 0 ? 1 : 0;
        const caption = `${myMon.name} menyerang! -${dmg} HP ke ${enemyMon.name}`;

        if (enemyMon.hp <= 0) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, hitSide, `💀 ${enemyMon.name} kalah! ${myMon.name} menang!`);
            return core.checkWinAndReward(room, currentPlayer.id, currentPlayer.name, client, chatId);
        }

        room.turn++;
        core.saveRoom(room);
        return sendGame(client, chatId, room, hitSide,
            `${caption}. Giliran: ${room.players[room.turn % 2].name}`);
    }

    return client.sendMessage(chatId, {
        message:
            "🎮 <b>MONSTER BATTLE</b> 🎮\n\n├─────────────────\n" +
            "│ ▪ <code>.monster start</code>\n│ ▪ <code>.monster join [KODE]</code>\n" +
            "│ ▪ <code>.monster attack</code>\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "monster",
    handler,
    description: "Monster card battle PVP (video otomatis)",
    category: "game",
    commands: ["battle"]
};