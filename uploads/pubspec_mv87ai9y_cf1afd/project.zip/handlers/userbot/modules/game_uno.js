const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const sharp = require("sharp");
const { Api } = require("telegram");
const core = require("./gamecore");

const COLORS = ["red", "blue", "green", "yellow"];
const NUMBERS = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const W = 800, H = 500, FPS = 6, FRAMES = 8;

const COLOR_HEX = {
    red: "#e53935", blue: "#1e88e5", green: "#43a047", yellow: "#fdd835", wild: "#212121"
};
const TMP = path.join(__dirname, "..", "..", "..", "tmp_game");
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

// ═══ DECK ═══
function makeDeck() {
    const deck = [];
    for (const c of COLORS) {
        for (const n of NUMBERS) {
            deck.push({ color: c, value: String(n) });
            deck.push({ color: c, value: String(n) });
        }
        deck.push({ color: c, value: "Skip" });
        deck.push({ color: c, value: "+2" });
    }
    for (let i = 0; i < 4; i++) {
        deck.push({ color: "wild", value: "Wild" });
        deck.push({ color: "wild", value: "+4" });
    }
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

// ═══ KARTU MIRIP UNO (SVG) ═══
function cardSvg(card, x, y, scale = 1) {
    const w = 120 * scale, h = 180 * scale;
    const color = COLOR_HEX[card.color] || COLOR_HEX.wild;
    const label = card.value === "Skip" ? "⊘" : card.value;
    const cx = x + w / 2, cy = y + h / 2;

    let inner = "";
    if (card.color === "wild") {
        const q = 0.22 * w;
        inner =
            `<rect x="${cx - q}" y="${cy - q}" width="${q}" height="${q}" fill="${COLOR_HEX.red}"/>` +
            `<rect x="${cx}" y="${cy - q}" width="${q}" height="${q}" fill="${COLOR_HEX.blue}"/>` +
            `<rect x="${cx - q}" y="${cy}" width="${q}" height="${q}" fill="${COLOR_HEX.yellow}"/>` +
            `<rect x="${cx}" y="${cy}" width="${q}" height="${q}" fill="${COLOR_HEX.green}"/>`;
    }

    return (
        `<g>` +
        `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${14 * scale}" fill="#111" />` +
        `<rect x="${x + 6}" y="${y + 6}" width="${w - 12}" height="${h - 12}" rx="${12 * scale}" fill="${color}"/>` +
        `<ellipse cx="${cx}" cy="${cy}" rx="${w * 0.36}" ry="${h * 0.32}" fill="#fff" transform="rotate(-20 ${cx} ${cy})"/>` +
        inner +
        (card.color !== "wild"
            ? `<text x="${cx}" y="${cy + 18 * scale}" font-family="Arial Black,Arial" font-size="${48 * scale}" font-weight="900" fill="${color}" text-anchor="middle">${core.escapeXml(label)}</text>`
            : `<text x="${cx}" y="${cy + 14 * scale}" font-family="Arial Black,Arial" font-size="${30 * scale}" font-weight="900" fill="#fff" text-anchor="middle" stroke="#000" stroke-width="2">${core.escapeXml(card.value)}</text>`) +
        `<text x="${x + 14 * scale}" y="${y + 30 * scale}" font-family="Arial Black,Arial" font-size="${18 * scale}" font-weight="900" fill="#fff">${core.escapeXml(label)}</text>` +
        `<text x="${x + w - 14 * scale}" y="${y + h - 14 * scale}" font-family="Arial Black,Arial" font-size="${18 * scale}" font-weight="900" fill="#fff" text-anchor="end">${core.escapeXml(label)}</text>` +
        `</g>`
    );
}

// ═══ SCENE (meja + tumpukan + tangan) ═══
function sceneSvg(room, s, t, caption) {
    const top = s.discard[s.discard.length - 1];
    const hand = s.hands[room.turn % 2];
    const hx = W / 2 - (hand.length * 70) / 2;
    const glow = COLOR_HEX[s.currentColor] || "#fff";
    const bob = Math.sin(t * Math.PI * 2) * 4;
    const handShow = hand.slice(0, 7);

    let handSvg = "";
    handShow.forEach((c, i) => { handSvg += cardSvg(c, hx + i * 70, 300 + bob, 0.45); });

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <radialGradient id="table" cx="50%" cy="40%" r="70%"><stop offset="0" stop-color="#166534"/><stop offset="1" stop-color="#052e16"/></radialGradient>
  <radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${glow}" stop-opacity="0.6"/><stop offset="1" stop-color="${glow}" stop-opacity="0"/></radialGradient>
</defs>
<rect width="${W}" height="${H}" fill="url(#table)"/>
<circle cx="400" cy="150" r="170" fill="url(#glow)"/>
<text x="400" y="45" font-family="Arial Black,Arial" font-size="32" font-weight="900" fill="#fde047" text-anchor="middle">UNO</text>
<text x="170" y="150" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">DECK ${s.deck.length}</text>
<rect x="100" y="90" width="80" height="120" rx="10" fill="#111" stroke="#fff" stroke-width="2"/>
<text x="140" y="160" font-family="Arial Black,Arial" font-size="22" fill="#fff" text-anchor="middle">UNO</text>
${cardSvg(top, 340, 80, 0.85)}
<text x="400" y="${285}" font-family="Arial" font-size="16" fill="#fff" text-anchor="middle">Warna aktif: ${String(s.currentColor).toUpperCase()}</text>
${handSvg}
<rect x="0" y="${H - 50}" width="${W}" height="50" fill="rgba(0,0,0,0.6)"/>
<text x="400" y="${H - 18}" font-family="Arial" font-size="18" fill="#fde047" text-anchor="middle">Giliran: ${core.escapeXml(room.players[room.turn % 2].name)} · ${caption || ""}</text>
</svg>`;
}

// ═══ VIDEO ═══
async function renderVideo(room, outPath, caption) {
    const ff = spawn("ffmpeg", [
        "-y", "-f", "image2pipe", "-framerate", String(FPS), "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", outPath
    ]);
    ff.stderr.on("data", () => {});
    ff.stdin.on("error", () => {});

    for (let i = 0; i < FRAMES; i++) {
        const t = i / (FRAMES - 1);
        const png = await sharp(Buffer.from(sceneSvg(room, room.state, t, caption))).png().toBuffer();
        ff.stdin.write(png);
    }
    ff.stdin.end();

    await new Promise((resolve, reject) => {
        ff.on("close", code => code === 0 ? resolve() : reject(new Error("ffmpeg exit " + code)));
        ff.on("error", reject);
    });
    return outPath;
}

async function sendGame(client, chatId, room, caption = "") {
    const outPath = path.join(TMP, `uno_${Date.now()}.mp4`);
    try {
        await renderVideo(room, outPath, caption);
        await client.sendFile(chatId, {
            file: outPath,
            caption: `🃏 <b>UNO</b>\n${caption}`,
            parseMode: "html",
            forceDocument: false,
            attributes: [new Api.DocumentAttributeVideo({
                duration: FRAMES / FPS, w: W, h: H, supportsStreaming: true
            })]
        });
    } catch (e) {
        console.log("[UNO VIDEO ERR]", e.message);
        await client.sendMessage(chatId, {
            message: `🃏 <b>UNO</b>\n${caption}\n\n<i>(video gagal dibuat, cek ffmpeg)</i>`,
            parseMode: "html"
        }).catch(() => {});
    } finally {
        try { fs.unlinkSync(outPath); } catch {}
    }
}

// ═══ COMMAND ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";
    const myUsername = me?.username || null;

    if (cmd === "start") {
        const deck = makeDeck();
        const hands = [[], []];
        for (let i = 0; i < 7; i++) {
            hands[0].push(deck.pop());
            hands[1].push(deck.pop());
        }
        let first = deck.pop();
        while (first.color === "wild") {
            deck.unshift(first);
            first = deck.pop();
        }
        const room = core.createRoom("uno", userId, myName, myUsername, {
            state: { deck, hands, discard: [first], currentColor: first.color },
            maxPlayers: 2,
            chatId: String(chatId)
        });
        return sendGame(client, chatId, room,
            `Room <code>${room.id}</code> dibuat. Lawan join: <code>.uno join ${room.id}</code>`);
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .uno join [KODE]" });
        const r = core.joinRoom(roomId, userId, myName, myUsername);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });
        return sendGame(client, chatId, r.room,
            `Game dimulai! Main: <code>.uno play [nomor]</code> atau <code>.uno draw</code>`);
    }

    const room = Object.values(core.ROOMS).find(r =>
        r.gameType === "uno" && r.status === "playing" && r.players.some(p => String(p.id) === String(userId)));
    if (!room) return client.sendMessage(chatId, { message: "✕ Lu ga di game UNO aktif. Ketik .uno start / .uno join [KODE]" });

    const currentPlayer = room.players[room.turn % 2];
    if (String(currentPlayer.id) !== String(userId)) return client.sendMessage(chatId, { message: "✕ Bukan turn lu" });

    const myIdx = room.turn % 2;
    const otherIdx = 1 - myIdx;

    if (cmd === "draw") {
        if (room.state.deck.length === 0) return client.sendMessage(chatId, { message: "✕ Deck kosong" });
        const card = room.state.deck.pop();
        room.state.hands[myIdx].push(card);
        room.turn++;
        core.saveRoom(room);
        return sendGame(client, chatId, room,
            `${currentPlayer.name} ambil kartu.`);
    }

    if (cmd === "play") {
        const idx = parseInt(args[1]);
        const hand = room.state.hands[myIdx];
        if (isNaN(idx) || idx < 1 || idx > hand.length) {
            return client.sendMessage(chatId, { message: "✕ Index invalid (1-" + hand.length + ")" });
        }
        const card = hand[idx - 1];
        const top = room.state.discard[room.state.discard.length - 1];
        const ok = card.color === "wild" || card.color === room.state.currentColor || card.value === top.value;
        if (!ok) {
            return client.sendMessage(chatId, { message: "✕ Kartu ga cocok. Top: " + room.state.currentColor + " " + top.value });
        }

        hand.splice(idx - 1, 1);
        room.state.discard.push(card);
        if (card.color !== "wild") room.state.currentColor = card.color;

        if (card.value === "Skip") room.turn += 2;
        else if (card.value === "+2") {
            for (let i = 0; i < 2 && room.state.deck.length; i++) room.state.hands[otherIdx].push(room.state.deck.pop());
            room.turn += 2;
        } else if (card.value === "+4") {
            for (let i = 0; i < 4 && room.state.deck.length; i++) room.state.hands[otherIdx].push(room.state.deck.pop());
            room.turn += 2;
        } else room.turn++;

        if (hand.length === 0) {
            core.saveRoom(room);
            await sendGame(client, chatId, room, `🏆 ${currentPlayer.name} menang!`);
            return core.checkWinAndReward(room, currentPlayer.id, currentPlayer.name, client, chatId);
        }

        core.saveRoom(room);
        return sendGame(client, chatId, room,
            `${currentPlayer.name} main ${card.color} ${card.value}. Sisa ${hand.length} kartu.`);
    }

    return client.sendMessage(chatId, {
        message:
            "🃏 <b>UNO</b> 🃏\n\n├─────────────────\n" +
            "│ ▪ <code>.uno start</code>\n│ ▪ <code>.uno join [KODE]</code>\n" +
            "│ ▪ <code>.uno play [nomor]</code>\n│ ▪ <code>.uno draw</code>\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "uno",
    handler,
    description: "UNO card game PVP (video otomatis)",
    category: "game"
};