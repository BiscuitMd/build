// ═══════════════════════════════════════════
// UBOT BUILD — v10
// FIX: GitHub upload pakai /git/blobs (support 100 MB)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const path = require("path");
const fs = require("fs");
const axios = require("axios");
const AdmZip = require("adm-zip");

// ⚡ LIMIT ZIP
const MAX_ZIP_SIZE = 70 * 1024 * 1024;

// ⚡ ICON SET
const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
    triangle: "▲", triangleDown: "▼", triangleRight: "►",
};

// ⚡ ROOT
const ROOT = path.join(__dirname, "..", "..", "..");
const cfg = require(path.join(ROOT, "config.js"));

// ⚡ GITHUB BUILDER
const GH_PATH = path.join(__dirname, "..", "github-builder.js");

let gh;
try {
    gh = require(GH_PATH);
    console.log("[UBOT BUILD] ✅ github-builder loaded");
} catch (e) {
    console.log("[UBOT BUILD] ❌ gagal load github-builder:", e.message);
    gh = {
        putFile: async () => { throw new Error("github-builder gaada"); },
        uploadFile: async () => { throw new Error("github-builder gaada"); },
        deleteFile: async () => null,
        triggerWorkflow: async () => ({ ok: false, error: "github-builder gaada" }),
        getLatestRun: async () => null,
        getRunStatus: async () => null,
        getRunArtifacts: async () => [],
        downloadArtifact: async () => { throw new Error("github-builder gaada"); },
        getRunLogs: async () => null,
        newJobId: (prefix = "job") => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
    };
}

const TMP_DIR = path.join(ROOT, "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ STATE ═══
const PENDING_ZIPS = new Map();
const ACTIVE_BUILDS = new Map();
const KEEP_ALIVE_INTERVALS = new Map();

// ═══════════════════════════════════════════
// 🔥 GITHUB API CLIENT — FIRM + TIMEOUT + RETRY
// ═══════════════════════════════════════════
const GITHUB_API = "https://api.github.com";

function ghHeaders() {
    return {
        Authorization: `token ${cfg.GITHUB.TOKEN}`,
        "User-Agent": "SpartaX-Bot/1.0",
        "Content-Type": "application/json",
        Accept: "application/vnd.github+json"
    };
}

// ⚡ RETRY WRAPPER
async function ghRetry(fn, label, maxRetry = 3) {
    let lastErr = null;
    for (let i = 1; i <= maxRetry; i++) {
        try {
            return await fn();
        } catch (e) {
            lastErr = e;
            const msg = e.message || "";
            const status = e.response?.status;

            console.log(`[GH RETRY] ${label} attempt ${i}/${maxRetry}: ${msg.slice(0, 100)}`);

            // Kalau error 4xx yang bukan 429 — ga perlu retry
            if (status && status >= 400 && status < 500 && status !== 429 && status !== 408) {
                throw e;
            }

            if (i < maxRetry) await new Promise(r => setTimeout(r, 2000 * i));
        }
    }
    throw lastErr;
}

// ⚡ GET LATEST COMMIT SHA (BRANCH)
async function ghGetBranchSha() {
    return ghRetry(async () => {
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/git/ref/heads/${cfg.GITHUB.BRANCH}`;
        const res = await axios.get(url, { headers: ghHeaders(), timeout: 30000 });
        return res.data?.object?.sha;
    }, "getBranchSha");
}

// ⚡ CREATE BLOB (support s/d 100 MB)
async function ghCreateBlob(content, isBase64 = true) {
    return ghRetry(async () => {
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/git/blobs`;
        const payload = {
            content,
            encoding: isBase64 ? "base64" : "utf-8"
        };
        const res = await axios.post(url, payload, {
            headers: ghHeaders(),
            timeout: 180000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });
        return res.data?.sha;
    }, "createBlob");
}

// ⚡ CREATE TREE
async function ghCreateTree(baseSha, files) {
    return ghRetry(async () => {
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/git/trees`;
        const payload = {
            base_tree: baseSha,
            tree: files.map(f => ({
                path: f.path,
                mode: "100644",
                type: "blob",
                sha: f.sha
            }))
        };
        const res = await axios.post(url, payload, {
            headers: ghHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity
        });
        return res.data?.sha;
    }, "createTree");
}

// ⚡ CREATE COMMIT
async function ghCreateCommit(treeSha, parentSha, message) {
    return ghRetry(async () => {
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/git/commits`;
        const payload = {
            message,
            tree: treeSha,
            parents: [parentSha]
        };
        const res = await axios.post(url, payload, {
            headers: ghHeaders(),
            timeout: 60000
        });
        return res.data?.sha;
    }, "createCommit");
}

// ⚡ UPDATE REF (BRANCH POINTER)
async function ghUpdateRef(commitSha) {
    return ghRetry(async () => {
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/git/refs/heads/${cfg.GITHUB.BRANCH}`;
        const payload = {
            sha: commitSha,
            force: false
        };
        const res = await axios.patch(url, payload, {
            headers: ghHeaders(),
            timeout: 60000
        });
        return res.data?.object?.sha;
    }, "updateRef");
}

// ⚡ DELETE FILE (via git tree — gabungin ke commit kosong)
async function ghDeleteFile(repoPath, message = "cleanup") {
    try {
        const branchSha = await ghGetBranchSha();
        const url = `${GITHUB_API}/repos/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/contents/${repoPath}`;

        // Cek apakah file ada
        let fileSha = null;
        try {
            const check = await axios.get(url, {
                headers: ghHeaders(),
                params: { ref: cfg.GITHUB.BRANCH },
                timeout: 30000,
                validateStatus: s => s < 500
            });
            if (check.status === 200 && check.data?.sha) fileSha = check.data.sha;
        } catch {}

        if (!fileSha) return null; // udah ga ada

        const delRes = await axios.delete(url, {
            headers: ghHeaders(),
            data: {
                message,
                sha: fileSha,
                branch: cfg.GITHUB.BRANCH
            },
            timeout: 60000
        });

        return delRes.data?.commit?.sha || null;
    } catch (e) {
        console.log("[GH DELETE FILE ERR]", e.message.slice(0, 150));
        return null;
    }
}

// ═══════════════════════════════════════════
// 🔥 UPLOAD ZIP VIA /git/blobs (SUPPORT 100 MB)
// ═══════════════════════════════════════════
async function uploadZipViaBlob(jobId, zipPath) {
    const repoPath = `uploads/${jobId}/project.zip`;
    const buf = fs.readFileSync(zipPath);
    const sizeMB = buf.length / 1024 / 1024;

    console.log(`[UPLOAD] ${sizeMB.toFixed(2)} MB → ${repoPath}`);

    // ⚡ CEK LIMIT (blobs = 100 MB)
    if (sizeMB > 95) {
        return { ok: false, error: `File terlalu besar: ${sizeMB.toFixed(2)} MB (max 95 MB)` };
    }

    try {
        // STEP 1: Branch SHA
        console.log("[UPLOAD] 1/5 get branch sha...");
        const branchSha = await ghGetBranchSha();
        if (!branchSha) throw new Error("Ga dapet branch sha");

        // STEP 2: Create blob (base64)
        console.log("[UPLOAD] 2/5 create blob...");
        const b64 = buf.toString("base64");
        const blobSha = await ghCreateBlob(b64, true);
        if (!blobSha) throw new Error("Ga dapet blob sha");

        // STEP 3: Create tree
        console.log("[UPLOAD] 3/5 create tree...");
        const treeSha = await ghCreateTree(branchSha, [{ path: repoPath, sha: blobSha }]);
        if (!treeSha) throw new Error("Ga dapet tree sha");

        // STEP 4: Create commit
        console.log("[UPLOAD] 4/5 create commit...");
        const commitSha = await ghCreateCommit(treeSha, branchSha, `[${jobId}] upload project.zip`);
        if (!commitSha) throw new Error("Ga dapet commit sha");

        // STEP 5: Update ref
        console.log("[UPLOAD] 5/5 update ref...");
        await ghUpdateRef(commitSha);

        console.log(`[UPLOAD] ✅ sukses: ${repoPath}`);
        return { ok: true, path: repoPath, method: "blob" };
    } catch (e) {
        console.log("[UPLOAD] ❌ gagal:", e.message.slice(0, 200));
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// KEEP ALIVE
// ═══════════════════════════════════════════
function startKeepAlive(userId, client) {
    stopKeepAlive(userId);
    const intervalId = setInterval(async () => {
        try {
            if (client && typeof client.getMe === "function") {
                await client.getMe();
            }
        } catch (e) {
            if (e.message && (
                e.message.includes("disconnect") ||
                e.message.includes("ECONNRESET") ||
                e.message.includes("Not connected")
            )) {
                try { await client.connect(); } catch {}
            }
        }
    }, 30000);
    KEEP_ALIVE_INTERVALS.set(String(userId), intervalId);
}

function stopKeepAlive(userId) {
    const id = KEEP_ALIVE_INTERVALS.get(String(userId));
    if (id) {
        clearInterval(id);
        KEEP_ALIVE_INTERVALS.delete(String(userId));
    }
}

// ═══ SAFE SEND ═══
async function safeSend(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try {
            return await client.sendMessage(peer, options);
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try {
                    await client.connect();
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                } catch {}
            }
            if (attempt === retry) throw e;
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

async function safeEdit(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try {
            return await client.editMessage(peer, options);
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("message is not modified")) return null;
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try { await client.connect(); await new Promise(r => setTimeout(r, 2000)); continue; } catch {}
            }
            if (attempt === retry) {
                try {
                    return await client.sendMessage(peer, { message: options.text || options.message, parseMode: options.parseMode });
                } catch { return null; }
            }
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

async function safeDelete(client, peer, msgIds, retry = 2) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try { return await client.deleteMessages(peer, msgIds, { revoke: true }); }
        catch (e) { if (attempt === retry) return null; await new Promise(r => setTimeout(r, 1000)); }
    }
}

async function safeSendFile(client, peer, options, retry = 3) {
    for (let attempt = 1; attempt <= retry; attempt++) {
        try { return await client.sendFile(peer, options); }
        catch (e) {
            const msg = e.message || "";
            if (msg.includes("disconnect") || msg.includes("Not connected") || msg.includes("ECONNRESET")) {
                try { await client.connect(); await new Promise(r => setTimeout(r, 2000)); continue; } catch {}
            }
            if (attempt === retry) throw e;
            await new Promise(r => setTimeout(r, 2000));
        }
    }
}

// ═══ HELPERS ═══
function tmpFile(ext = "zip") {
    return path.join(TMP_DIR, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);
}

function isZipBuffer(buf) {
    return buf.length > 4 && buf[0] === 0x50 && buf[1] === 0x4b;
}

function detectProjectType(zipPath) {
    try {
        const zip = new AdmZip(zipPath);
        const entries = zip.getEntries();
        let hasPubspec = false;
        let hasBuildGradle = false;
        for (const entry of entries) {
            const name = entry.entryName.toLowerCase();
            if (name.endsWith("pubspec.yaml")) hasPubspec = true;
            if (name.endsWith("build.gradle") || name.endsWith("build.gradle.kts")) hasBuildGradle = true;
        }
        if (hasPubspec) return "flutter";
        if (hasBuildGradle) return "native";
        return "unknown";
    } catch { return "error"; }
}

async function downloadFromMessage(client, msg) {
    const buf = await client.downloadMedia(msg);
    if (!buf) throw new Error("Gagal download media");
    return Buffer.from(buf);
}

// ═══ CLEANUP ═══
async function cleanupGitHub(repoPath) {
    try {
        await ghDeleteFile(repoPath, `cleanup ${repoPath}`);
    } catch {}
}

function buildProgressBar(pct) {
    const total = 12;
    const filled = Math.round((pct / 100) * total);
    return "▰".repeat(filled) + "▱".repeat(total - filled);
}

function shortJobId(jobId) {
    if (!jobId) return "-";
    const parts = String(jobId).split("_");
    if (parts.length >= 2) return parts[0] + "_" + parts[1];
    return jobId.slice(0, 16);
}

// ═══════════════════════════════════════════
// BUILD MENU (6 command)
// ═══════════════════════════════════════════
function buildMenuText() {
    const box = (title, lines) =>
        `${I.cornerTL}${I.line.repeat(24)}${I.cornerTR}\n` +
        `${I.pipe} ${I.diamond} ${title}\n` +
        `${I.teeL}${I.line.repeat(24)}\n` +
        lines.map(l => `${I.pipe} ${l}`).join("\n") + "\n" +
        `${I.cornerBL}${I.line.repeat(24)}${I.cornerBR}\n\n`;

    return (
        `${I.cornerTL}${I.doubleH.repeat(13)}${I.cornerTR}\n` +
        `${I.pipe}  ${I.square} BUILD MENU  ${I.pipe}\n` +
        `${I.cornerBL}${I.doubleH.repeat(13)}${I.cornerBR}\n\n` +

        box("FLUTTER", [
            `${I.bullet} <code>.build_flutter_release</code>`,
            `${I.bulletOut}   Flutter APK Release`,
            `${I.bullet} <code>.build_flutter_debug</code>`,
            `${I.bulletOut}   Flutter APK Debug`
        ]) +
        box("NATIVE ANDROID", [
            `${I.bullet} <code>.build_native_release</code>`,
            `${I.bulletOut}   Native APK Release`,
            `${I.bullet} <code>.build_native_debug</code>`,
            `${I.bulletOut}   Native APK Debug`
        ]) +
        box("WEB TO APP (dari link)", [
            `${I.bullet} <code>.web_to_app [url] [nama] [icon|-] [release|debug]</code>`,
            `${I.bulletOut}   Contoh: <code>.web_to_app https://tokoku.com TokoKu - release</code>`
        ]) +
        box("WEB TO APP (dari zip)", [
            `${I.bullet} <code>.build_web_to_app_release</code>`,
            `${I.bulletOut}   Reply file zip, lalu ketik command`,
            `${I.bullet} <code>.build_web_to_app_debug</code>`,
            `${I.bulletOut}   Reply file zip, lalu ketik command`
        ]) +
        box("INFO", [
            `${I.bullet} Max zip  ${I.arrow}  <b>70 MB</b>`,
            `${I.bullet} Format   ${I.arrow}  .apk / .aab`,
            `${I.bullet} Tempat   ${I.arrow}  private / group / channel`
        ]).trimEnd()
    );
}

// ═══════════════════════════════════════════
// HANDLER UTAMA
// ═══════════════════════════════════════════
async function handler(userId, client, msg, args) {
    const peerId = msg.message.peerId;
    const text = msg.message?.message || msg.message?.text || "";
    const cmd = text.slice(1).trim().split(/\s+/)[0].toLowerCase();
    
        // ═══ MENU & WEB TO APP DARI LINK ═══
    if (cmd === "build_menu" || cmd === "menu_build") {
        return safeSend(client, peerId, { message: buildMenuText(), parseMode: "html" });
    }
    if (cmd === "web_to_app" || cmd === "web2app") {
        return handleWebToApp(userId, client, msg, text);
    }

    // ═══ Parse command ═══
    let buildType = null;
    let buildMode = null;

    // NATIVE
    if (cmd === "build_native_release") { buildType = "native"; buildMode = "release"; }
    else if (cmd === "build_native_debug") { buildType = "native"; buildMode = "debug"; }
    // FLUTTER
    else if (cmd === "build_flutter_release") { buildType = "pubspec"; buildMode = "release"; }
    else if (cmd === "build_flutter_debug") { buildType = "pubspec"; buildMode = "debug"; }
    // WEB TO APP
    else if (cmd === "build_web_to_app_release" || cmd === "build_wep_to_app_release") { buildType = "web2app"; buildMode = "release"; }
    else if (cmd === "build_web_to_app_debug" || cmd === "build_wep_to_app_debug") { buildType = "web2app"; buildMode = "debug"; }
    // MENU
    else if (cmd === "build") {
        return safeSend(client, peerId, {
            message: buildMenuText(),
            parseMode: "html"
        });
    } else {
        return;
    }

    console.log(`[UBOT BUILD] cmd: ${cmd} | type: ${buildType} | mode: ${buildMode}`);

    // ═══ Cek build aktif ═══
    const activeBuild = ACTIVE_BUILDS.get(String(userId));
    if (activeBuild) {
        return safeSend(client, peerId, {
            message:
                `${I.cross} <b>Lu masih punya build aktif</b>\n\n` +
                `${I.bulletOut} Job: <code>${shortJobId(activeBuild.jobId)}</code>\n` +
                `${I.bulletOut} Status: ${activeBuild.status}\n` +
                `${I.bulletOut} Waktu: ${((Date.now() - activeBuild.startTime) / 1000).toFixed(0)}s\n\n` +
                `<i>Tunggu build sebelumnya selesai</i>`,
            parseMode: "html"
        });
    }

    // ═══ Cek reply ═══
    const replyTo = msg.message.replyTo?.replyToMsgId;
    if (!replyTo) {
        return safeSend(client, peerId, {
            message:
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.cross} REPLY FILE .ZIP\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
                `${I.arrow} <b>Langkah:</b>\n` +
                `${I.bulletOut} Kirim file <code>.zip</code> base project\n` +
                `${I.bulletOut} Reply file itu\n` +
                `${I.bulletOut} Ketik <code>.${cmd}</code>\n\n` +
                `${I.bulletOut} Max size: <b>70 MB</b>`,
            parseMode: "html"
        });
    }

    const msgs = await client.getMessages(msg.message.chatId, { ids: [replyTo] });
    const target = msgs[0];
    if (!target || !target.media || !target.document) {
        return safeSend(client, peerId, {
            message: `${I.cross} Yang di-reply harus file <b>.zip</b>`,
            parseMode: "html"
        });
    }

    const fileName = target.document.attributes?.find(a => a.fileName)?.fileName || "project.zip";
    if (!fileName.toLowerCase().endsWith(".zip")) {
        return safeSend(client, peerId, {
            message: `${I.cross} File harus <b>.zip</b>`,
            parseMode: "html"
        });
    }

    const fileSize = Number(target.document.size) || 0;
    if (fileSize > MAX_ZIP_SIZE) {
        return safeSend(client, peerId, {
            message:
                `${I.cross} <b>File terlalu besar!</b>\n\n` +
                `${I.bulletOut} Size: ${(fileSize / 1024 / 1024).toFixed(2)} MB\n` +
                `${I.bulletOut} Max: <b>70 MB</b>`,
            parseMode: "html"
        });
    }

    // ═══ START KEEP ALIVE ═══
    startKeepAlive(userId, client);

    // ═══ Loading ═══
    const loading = await safeSend(client, peerId, {
        message:
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} DOWNLOADING\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} File  ${I.arrow}  <code>${fileName.slice(0, 30)}</code>\n` +
            `${I.pipe} ${I.bullet} Size  ${I.arrow}  ${(fileSize / 1024 / 1024).toFixed(2)} MB\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
        parseMode: "html"
    });

    try {
        const buf = await downloadFromMessage(client, target);

        if (!isZipBuffer(buf)) {
            stopKeepAlive(userId);
            try { await safeDelete(client, peerId, [loading.id]); } catch {}
            return safeSend(client, peerId, { message: `${I.cross} File bukan zip valid`, parseMode: "html" });
        }

        const zipPath = tmpFile("zip");
        fs.writeFileSync(zipPath, buf);

        const detectedType = detectProjectType(zipPath);
        const sizeMB = (buf.length / 1024 / 1024).toFixed(2);

        try { await safeDelete(client, peerId, [loading.id]); } catch {}

        const jobId = gh.newJobId("ubotbuild");
        console.log(`[UBOT BUILD] job: ${jobId} | size: ${sizeMB} MB | type: ${detectedType}`);

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "uploading" });

        const progressMsg = await safeSend(client, peerId, {
            message:
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} UPLOADING\n` +
                `${I.teeL}${I.line.repeat(20)}\n` +
                `${I.pipe} ${I.bullet} File    ${I.arrow}  <code>${fileName.slice(0, 24)}</code>\n` +
                `${I.pipe} ${I.bullet} Size    ${I.arrow}  ${sizeMB} MB\n` +
                `${I.pipe} ${I.bullet} Type    ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                `${I.pipe} ${I.bullet} Mode    ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                `${I.pipe} ${I.bullet} Job     ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                `${I.pipe} ${I.bullet} Step    ${I.arrow}  <i>0/5</i>\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            parseMode: "html"
        });

        // ═══════════════════════════════════════════
        // 🔥 UPLOAD ZIP VIA /git/blobs (fix)
        // ═══════════════════════════════════════════
        console.log("[UPLOAD] mulai upload via /git/blobs...");
        const upload = await uploadZipViaBlob(jobId, zipPath);

        if (!upload.ok) {
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message:
                    `${I.cross} <b>Upload gagal</b>\n\n` +
                    `${I.bulletOut} Reason: ${(upload.error || "unknown").slice(0, 200)}\n\n` +
                    `${I.arrow} <b>Coba:</b>\n` +
                    `${I.bulletOut} Kecilin file zip (< 90 MB)\n` +
                    `${I.bulletOut} Cek token GitHub masih valid\n` +
                    `${I.bulletOut} Cek quota GitHub API`,
                parseMode: "html"
            });
        }

        console.log(`[UBOT BUILD] ✅ uploaded via ${upload.method} → ${upload.path}`);

        try { await safeDelete(client, peerId, [progressMsg.id]); } catch {}

        // ═══ Progress message baru buat build ═══
        const buildMsg = await safeSend(client, peerId, {
            message:
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} TRIGGERING\n` +
                `${I.teeL}${I.line.repeat(20)}\n` +
                `${I.pipe} ${I.bullet} Job  ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
            parseMode: "html"
        });

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "triggering" });

        // ═══ Pilih workflow ═══
        let workflow, inputs;
        if (buildType === "pubspec") {
            workflow = cfg.GITHUB.WORKFLOW_FLUTTER || "flutter-build.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_type: "apk",
                build_mode: buildMode,
                split_per_abi: "false",
                flutter_version: "auto"
            };
        } else if (buildType === "web2app") {
            workflow = cfg.GITHUB.WORKFLOW_WEB2APP || "web-to-app.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_mode: buildMode
            };
        } else {
            workflow = cfg.GITHUB.WORKFLOW_NATIVE || "native-build.yml";
            inputs = {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_task: buildMode === "debug" ? "assembleDebug" : "assembleRelease",
                build_flavor: "",
                java_version: "17"
            };
        }

        let trigger;
        try {
            trigger = await gh.triggerWorkflow(workflow, inputs);
        } catch (e) {
            try { await cleanupGitHub(upload.path); } catch {}
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [buildMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message: `${I.cross} Trigger gagal\n\n${I.bulletOut} ${e.message.slice(0, 150)}`,
                parseMode: "html"
            });
        }

        if (!trigger?.ok) {
            try { await cleanupGitHub(upload.path); } catch {}
            try { fs.unlinkSync(zipPath); } catch {}
            try { await safeDelete(client, peerId, [buildMsg.id]); } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return safeSend(client, peerId, {
                message: `${I.cross} Trigger gagal\n\n${I.bulletOut} ${(trigger?.error || "unknown").slice(0, 150)}`,
                parseMode: "html"
            });
        }

        try { fs.unlinkSync(zipPath); } catch {}

        const triggerTime = Date.now();
        let run = null;
        for (let i = 0; i < 12; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await gh.getLatestRun(workflow, triggerTime); } catch {}
            if (run) break;
        }

        if (!run) {
            try { await cleanupGitHub(upload.path); } catch {}
            try {
                await safeEdit(client, peerId, {
                    message: buildMsg.id,
                    text: `${I.cross} GitHub ga response\n\n${I.bulletOut} Job: <code>${shortJobId(jobId)}</code>`,
                    parseMode: "html"
                });
            } catch {}
            ACTIVE_BUILDS.delete(String(userId));
            stopKeepAlive(userId);
            return;
        }

        const runId = run.id;
        console.log(`[UBOT BUILD] run id: ${runId}`);

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "building" });

        const startTime = Date.now();
        const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;
        const pollInterval = cfg.BUILD_POLL_INTERVAL || 20000;
        let lastEditAt = 0;

        while (Date.now() - startTime < maxWait) {
            let status = null;
            try { status = await gh.getRunStatus(runId); } catch {}

            if (!status) { await new Promise(r => setTimeout(r, pollInterval)); continue; }

            const jobStatus = status.status;
            const conclusion = status.conclusion;
            const elapsed = Date.now() - startTime;

            if (Date.now() - lastEditAt > 18000) {
                lastEditAt = Date.now();
                const pct = Math.min(Math.floor((elapsed / 900000) * 100), 95);
                const bar = buildProgressBar(pct);
                const statusLabel = jobStatus === "in_progress" ? "BUILDING" : jobStatus === "queued" ? "QUEUED" : jobStatus.toUpperCase();

                try {
                    await safeEdit(client, peerId, {
                        message: buildMsg.id,
                        text:
                            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                            `${I.pipe} ${I.circle} ${statusLabel}\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} ${I.bullet} Type    ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Mode    ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Job     ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                            `${I.pipe} ${I.bullet} Waktu   ${I.arrow}  ${(elapsed / 1000).toFixed(0)}s\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} <code>${bar}</code> ${pct}%\n` +
                            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
                        parseMode: "html"
                    });
                } catch {}
            }

            if (jobStatus === "completed") {
                try { await cleanupGitHub(upload.path); } catch {}

                if (conclusion === "success") {
                    let artifacts = [];
                    try { artifacts = await gh.getRunArtifacts(runId); } catch {}

                    const apkArtifacts = artifacts.filter(a =>
                        a.name.includes("apk") || a.name.includes("appbundle") ||
                        a.name.includes("release") || a.name.includes("app")
                    );

                    const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);
                    try { await safeDelete(client, peerId, [buildMsg.id]); } catch {}

                    await safeSend(client, peerId, {
                        message:
                            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                            `${I.pipe} ${I.check} BUILD SUCCESS\n` +
                            `${I.teeL}${I.line.repeat(20)}\n` +
                            `${I.pipe} ${I.bullet} Type       ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Mode       ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                            `${I.pipe} ${I.bullet} Artifacts  ${I.arrow}  <code>${apkArtifacts.length}</code>\n` +
                            `${I.pipe} ${I.bullet} Waktu      ${I.arrow}  ${elapsedSec}s\n` +
                            `${I.pipe} ${I.bullet} Job        ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
                            `${I.circle} <b>Mengirim file APK/AAB...</b>`,
                        parseMode: "html"
                    });

                    for (const art of apkArtifacts.slice(0, 5)) {
                        try {
                            const dest = tmpFile("zip");
                            await gh.downloadArtifact(art.id, dest);
                            const zip = new AdmZip(dest);
                            const entries = zip.getEntries().filter(e =>
                                e.entryName.endsWith(".apk") || e.entryName.endsWith(".aab")
                            );

                            for (const entry of entries.slice(0, 3)) {
                                const fileBuf = entry.getData();
                                const ext = entry.entryName.endsWith(".apk") ? "apk" : "aab";
                                const outPath = tmpFile(ext);
                                fs.writeFileSync(outPath, fileBuf);

                                const fname = entry.entryName.split("/").pop();

                                try {
                                    await safeSendFile(client, peerId, {
                                        file: outPath,
                                        caption:
                                            `${I.cornerTL}${I.line.repeat(18)}${I.cornerTR}\n` +
                                            `${I.pipe} ${I.star} BUILD ARTIFACT\n` +
                                            `${I.teeL}${I.line.repeat(18)}\n` +
                                            `${I.pipe} ${I.bullet} File  ${I.arrow}  <code>${fname}</code>\n` +
                                            `${I.pipe} ${I.bullet} Size  ${I.arrow}  ${(fileBuf.length / 1024 / 1024).toFixed(2)} MB\n` +
                                            `${I.pipe} ${I.bullet} Job   ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                                            `${I.cornerBL}${I.line.repeat(18)}${I.cornerBR}`,
                                        forceDocument: false
                                    });
                                } catch (e) {
                                    console.log("[UBOT BUILD] sendFile fail:", e.message.slice(0, 100));
                                }

                                try { fs.unlinkSync(outPath); } catch {}
                            }

                            try { fs.unlinkSync(dest); } catch {}
                        } catch (e) {
                            console.log("[UBOT BUILD] artifact fail:", e.message.slice(0, 100));
                        }
                    }

                    await safeSend(client, peerId, { message: `${I.check} <b>Build selesai</b>` });
                } else {
                    const actionsUrl = `https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${runId}`;
                    try {
                        await safeEdit(client, peerId, {
                            message: buildMsg.id,
                            text:
                                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                                `${I.pipe} ${I.cross} BUILD FAILED\n` +
                                `${I.teeL}${I.line.repeat(20)}\n` +
                                `${I.pipe} ${I.bullet} Type        ${I.arrow}  <b>${buildType.toUpperCase()}</b>\n` +
                                `${I.pipe} ${I.bullet} Mode        ${I.arrow}  <b>${buildMode.toUpperCase()}</b>\n` +
                                `${I.pipe} ${I.bullet} Conclusion  ${I.arrow}  <code>${conclusion}</code>\n` +
                                `${I.pipe} ${I.bullet} Job         ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                                `${I.teeL}${I.line.repeat(20)}\n` +
                                `${I.pipe} ${I.arrow} ${actionsUrl}\n` +
                                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`,
                            parseMode: "html"
                        });
                    } catch {}
                }

                ACTIVE_BUILDS.delete(String(userId));
                stopKeepAlive(userId);
                return;
            }

            await new Promise(r => setTimeout(r, pollInterval));
        }

        try { await cleanupGitHub(upload.path); } catch {}
        try {
            await safeEdit(client, peerId, {
                message: buildMsg.id,
                text: `${I.cross} Build timeout (>60 menit)\n\n${I.bulletOut} Job: <code>${shortJobId(jobId)}</code>`,
                parseMode: "html"
            });
        } catch {}
        ACTIVE_BUILDS.delete(String(userId));
        stopKeepAlive(userId);
    } catch (e) {
        console.log("[UBOT BUILD] ERR:", e.message);
        console.log(e.stack);
        ACTIVE_BUILDS.delete(String(userId));
        stopKeepAlive(userId);
        try {
            await safeSend(client, peerId, {
                message: `${I.cross} Error: ${e.message.slice(0, 200)}`,
                parseMode: "html"
            });
        } catch {}
    }
}

// ═══════════════════════════════════════════
// WEB TO APP DARI LINK — .web_to_app
// Format: .web_to_app <url> <nama> <icon|-> <release|debug>
// ═══════════════════════════════════════════
const WEB2APP_USAGE =
    `${I.cross} <b>Format salah</b>\n\n` +
    `${I.arrow} <code>.web_to_app [url] [nama] [icon|-] [release|debug]</code>\n\n` +
    `${I.bulletOut} url   : https://domain.com\n` +
    `${I.bulletOut} nama  : TokoKu (huruf/angka, max 30)\n` +
    `${I.bulletOut} icon  : link gambar .png/.jpg atau <code>-</code>\n` +
    `${I.bulletOut} mode  : release / debug`;

function parseWebToApp(tokens) {
    // tokens[0] = nama command
    const url = tokens[1] || "";
    const name = tokens[2] || "";
    const icon = tokens[3] && tokens[3] !== "-" ? tokens[3] : null;
    const mode = (tokens[4] || "release").toLowerCase();

    if (!/^https?:\/\/[^\s]+\.[^\s]+/i.test(url)) return { error: "URL harus diawali http:// atau https://" };
    if (!/^[A-Za-z0-9 ]{2,30}$/.test(name)) return { error: "Nama app 2-30 karakter, huruf/angka/spasi" };
    if (icon && !/^https?:\/\/[^\s]+\.(png|jpe?g|webp)(\?[^\s]*)?$/i.test(icon)) {
        return { error: "Link icon harus .png / .jpg / .webp, atau pakai -" };
    }
    if (!["release", "debug"].includes(mode)) return { error: "Mode harus release atau debug" };

    return { url, name, icon, mode };
}

async function handleWebToApp(userId, client, msg, text) {
    const peerId = msg.message.peerId;
    const tokens = text.slice(1).trim().split(/\s+/);
    const parsed = parseWebToApp(tokens);

    if (parsed.error) {
        return safeSend(client, peerId, {
            message: `${I.cross} <b>${parsed.error}</b>\n\n${WEB2APP_USAGE}`,
            parseMode: "html"
        });
    }

    if (ACTIVE_BUILDS.get(String(userId))) {
        return safeSend(client, peerId, {
            message: `${I.cross} Lu masih punya build aktif. Tunggu sampai selesai.`,
            parseMode: "html"
        });
    }

    const { url, name, icon, mode } = parsed;
    const jobId = gh.newJobId("web2app");
    const workflow = cfg.GITHUB.WORKFLOW_WEB2APP_URL || "web-to-app.yml";
    const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;
    const pollInterval = cfg.BUILD_POLL_INTERVAL || 20000;

    ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "triggering" });
    startKeepAlive(userId, client);

    const statusMsg = await safeSend(client, peerId, {
        message:
            `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
            `${I.pipe} ${I.circle} WEB TO APP\n` +
            `${I.teeL}${I.line.repeat(20)}\n` +
            `${I.pipe} ${I.bullet} Nama  ${I.arrow}  <b>${name}</b>\n` +
            `${I.pipe} ${I.bullet} URL   ${I.arrow}  <code>${url.slice(0, 40)}</code>\n` +
            `${I.pipe} ${I.bullet} Mode  ${I.arrow}  <b>${mode.toUpperCase()}</b>\n` +
            `${I.pipe} ${I.bullet} Job   ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
            `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}\n\n` +
            `${I.arrow} Sedang trigger build...`,
        parseMode: "html"
    });

    const editStatus = (body) => safeEdit(client, peerId, {
        message: statusMsg.id, text: body, parseMode: "html"
    }).catch(() => {});

    try {
        const triggerTime = Date.now();
        const trigger = await gh.triggerWorkflow(workflow, {
            web_url: url,
            app_name: name.replace(/\s+/g, ""),
            app_label: name,
            icon_url: icon || "",
            build_mode: mode,
            job_id: jobId
        });
        if (!trigger?.ok) throw new Error(trigger?.error || "trigger gagal");

        let run = null;
        for (let i = 0; i < 12 && !run; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await gh.getLatestRun(workflow, triggerTime); } catch {}
        }
        if (!run) throw new Error("GitHub tidak merespon setelah trigger");

        ACTIVE_BUILDS.set(String(userId), { jobId, startTime: Date.now(), status: "building" });

        const startTime = Date.now();
        let conclusion = null;
        while (Date.now() - startTime < maxWait) {
            let st = null;
            try { st = await gh.getRunStatus(run.id); } catch {}
            if (st?.status === "completed") { conclusion = st.conclusion; break; }
            await editStatus(
                `${I.cornerTL}${I.line.repeat(20)}${I.cornerTR}\n` +
                `${I.pipe} ${I.circle} BUILDING\n` +
                `${I.teeL}${I.line.repeat(20)}\n` +
                `${I.pipe} ${I.bullet} Nama  ${I.arrow}  <b>${name}</b>\n` +
                `${I.pipe} ${I.bullet} Job   ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                `${I.pipe} ${I.bullet} Waktu ${I.arrow}  ${Math.floor((Date.now() - startTime) / 1000)}s\n` +
                `${I.cornerBL}${I.line.repeat(20)}${I.cornerBR}`
            );
            await new Promise(r => setTimeout(r, pollInterval));
        }

        if (conclusion !== "success") {
            await editStatus(
                `${I.cross} <b>BUILD GAGAL</b>\n\n` +
                `${I.bulletOut} Nama: ${name}\n` +
                `${I.bulletOut} Conclusion: <code>${conclusion || "timeout"}</code>\n` +
                `${I.bulletOut} Job: <code>${shortJobId(jobId)}</code>\n` +
                `${I.bulletOut} Log: https://github.com/${cfg.GITHUB.USERNAME}/${cfg.GITHUB.REPO}/actions/runs/${run.id}`
            );
            return;
        }

        await editStatus(`${I.check} <b>Build selesai</b>, mengirim APK ke chat ini...`);

        let artifacts = [];
        try { artifacts = await gh.getRunArtifacts(run.id); } catch {}
        let sent = 0;

        for (const art of artifacts.slice(0, 5)) {
            try {
                const dest = tmpFile("zip");
                await gh.downloadArtifact(art.id, dest);
                const zip = new AdmZip(dest);
                const files = zip.getEntries().filter(e =>
                    e.entryName.endsWith(".apk") || e.entryName.endsWith(".aab"));

                for (const entry of files.slice(0, 3)) {
                    const ext = entry.entryName.endsWith(".apk") ? "apk" : "aab";
                    const outPath = tmpFile(ext);
                    fs.writeFileSync(outPath, entry.getData());
                    try {
                        await safeSendFile(client, peerId, {
                            file: outPath,
                            caption:
                                `${I.cornerTL}${I.line.repeat(18)}${I.cornerTR}\n` +
                                `${I.pipe} ${I.star} WEB TO APP\n` +
                                `${I.teeL}${I.line.repeat(18)}\n` +
                                `${I.pipe} ${I.bullet} Nama  ${I.arrow}  <b>${name}</b>\n` +
                                `${I.pipe} ${I.bullet} Mode  ${I.arrow}  <b>${mode.toUpperCase()}</b>\n` +
                                `${I.pipe} ${I.bullet} Job   ${I.arrow}  <code>${shortJobId(jobId)}</code>\n` +
                                `${I.cornerBL}${I.line.repeat(18)}${I.cornerBR}`,
                            forceDocument: false,
                            parseMode: "html"
                        });
                        sent++;
                    } catch (e) {
                        console.log("[WEB2APP] sendFile fail:", e.message.slice(0, 100));
                    }
                    try { fs.unlinkSync(outPath); } catch {}
                }
                try { fs.unlinkSync(dest); } catch {}
            } catch (e) {
                console.log("[WEB2APP] artifact fail:", e.message.slice(0, 100));
            }
        }

        await editStatus(
            sent > 0
                ? `${I.check} <b>Selesai!</b> ${sent} file APK dikirim.`
                : `${I.cross} Build sukses tapi APK tidak ditemukan di artifact.\n${I.bulletOut} Cek log GitHub.`
        );
    } catch (e) {
        console.log("[WEB2APP] ERR:", e.message);
        await editStatus(`${I.cross} <b>Error</b>\n<code>${(e.message || "unknown").slice(0, 200)}</code>`);
    } finally {
        ACTIVE_BUILDS.delete(String(userId));
        stopKeepAlive(userId);
    }
}

module.exports = {
    command: "build_flutter_release",
    handler,
    commands: [
        "build",
        "build_menu",
        "menu_build",
        "web_to_app",
        "web2app",
        "build_native_release",
        "build_native_debug",
        "build_flutter_release",
        "build_flutter_debug",
        "build_web_to_app_release",
        "build_web_to_app_debug",
        "build_wep_to_app_release",
        "build_wep_to_app_debug"
    ],
    description: "Build APK via GitHub: menu, flutter, native, web to app (zip & link)",
    category: "build",
    cleanup: (userId) => {
        stopKeepAlive(userId);
        ACTIVE_BUILDS.delete(String(userId));
    }
};

console.log("[UBOT BUILD] module loaded (v10 — /git/blobs upload fix)");