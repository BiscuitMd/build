const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const sharp = require("sharp");
const { Api } = require("telegram");
const core = require("./gamecore");

const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];
const W = 800, H = 500, FPS = 6, FRAMES = 8;
const TMP = path.join(__dirname, "..", "..", "..", "tmp_game");
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

// ═══ DECK ═══
function makeDeck() {
    const deck = [];
    for (const s of SUITS) for (const r of RANKS) deck.push({ suit: s, rank: r });
    for (let i = deck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function cardValue(c) {
    return RANKS.indexOf(c.rank) + 2;
}

function evalHand(cards) {
    const values = cards.map(cardValue).sort((a, b) => b - a);
    const suits = cards.map(c => c.suit);
    const allSameSuit = suits.every(s => s === suits[0]);

    const counts = {};
    values.forEach(v => counts[v] = (counts[v] || 0) + 1);
    const freq = Object.values(counts).sort((a, b) => b - a);

    const isStraight = values.every((v, i) => i === 0 || values[i - 1] - v === 1);

    if (allSameSuit && values[0] === 14 && values[1] === 13 && values[2] === 12 && values[3] === 11 && values[4] === 10)
        return { rank: 9, name: "Royal Flush" };
    if (allSameSuit && isStraight) return { rank: 8, name: "Straight Flush" };
    if (freq[0] === 4) return { rank: 7, name: "Four of a Kind" };
    if (freq[0] === 3 && freq[1] === 2) return { rank: 6, name: "Full House" };
    if (allSameSuit) return { rank: 5, name: "Flush" };
    if (isStraight) return { rank: 4, name: "Straight" };
    if (freq[0] === 3) return { rank: 3, name: "Three of a Kind" };
    if (freq[0] === 2 && freq[1] === 2) return { rank: 2, name: "Two Pair" };
    if (freq[0] === 2) return { rank: 1, name: "One Pair" };
    return { rank: 0, name: "High Card" };
}

// ═══ KARTU ASLI (gaya kartu remi) ═══
function cardSvg(c, x, y, scale = 1, faceDown = false) {
    const w = 90 * scale, h = 130 * scale;
    if (faceDown) {
        return `<g>` +
            `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${8 * scale}" fill="#1e3a8a" stroke="#fff" stroke-width="2"/>` +
            `<rect x="${x + 8 * scale}" y="${y + 8 * scale}" width="${w - 16 * scale}" height="${h - 16 * scale}" rx="${6 * scale}" fill="none" stroke="#93c5fd" stroke-width="2"/>` +
            `</g>`;
    }
    const red = c.suit === "♥" || c.suit === "♦";
    const color = red ? "#dc2626" : "#111";
    const fs1 = 22 * scale, fs2 = 30 * scale;
    return `<g>` +
        `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${8 * scale}" fill="#fff" stroke="#111" stroke-width="2"/>` +
        `<text x="${x + 8 * scale}" y="${y + 24 * scale}" font-family="Arial Black,Arial" font-size="${fs1}" font-weight="900" fill="${color}">${c.rank}</text>` +
        `<text x="${x + 8 * scale}" y="${y + 46 * scale}" font-family="Arial" font-size="${fs1}" fill="${color}">${c.suit}</text>` +
        `<text x="${x + w / 2}" y="${y + h / 2 + fs2 / 3}" font-family="Arial" font-size="${fs2 * 1.6}" fill="${color}" text-anchor="middle">${c.suit}</text>` +
        `<g transform="rotate(180 ${x + w / 2} ${y + h / 2})">` +
        `<text x="${x + 8 * scale}" y="${y + 24 * scale}" font-family="Arial Black,Arial" font-size="${fs1}" font-weight="900" fill="${color}">${c.rank}</text>` +
        `<text x="${x + 8 * scale}" y="${y + 46 * scale}" font-family="Arial" font-size="${fs1}" fill="${color}">${c.suit}</text>` +
        `</g>` +
        `</g>`;
}

// ═══ SCENE ═══
function sceneSvg(room, t, reveal, caption) {
    const s = room.state;
    const hand0 = s.hands[0], hand1 = s.hands[1];
    const turnName = room.players[room.turn % 2].name;
    const bob = Math.sin(t * Math.PI * 2) * 3;

    let p0 = "", p1 = "";
    hand0.forEach((c, i) => {
        p0 += cardSvg(c, 80 + i * 90, 90 + bob, 0.7, !reveal);
    });
    hand1.forEach((c, i) => {
        p1 += cardSvg(c, 80 + i * 90, 300 - bob, 0.7, !reveal);
    });

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <radialGradient id="felt" cx="50%" cy="40%" r="70%"><stop offset="0" stop-color="#15803d"/><stop offset="1" stop-color="#052e16"/></radialGradient>
</defs>
<rect width="${W}" height="${H}" fill="url(#felt)"/>
<text x="400" y="30" font-family="Arial Black,Arial" font-size="22" font-weight="900" fill="#fde047" text-anchor="middle">♠ POKER ♥</text>
<text x="20" y="70" font-family="Arial" font-size="14" fill="#fff">${core.escapeXml(room.players[0].name)}</text>
${p0}
<text x="20" y="260" font-family="Arial" font-size="14" fill="#fff">${room.players[1] ? core.escapeXml(room.players[1].name) : "P2"}</text>
${p1}
<text x="400" y="${H - 30}" font-family="Arial" font-size="16" fill="#fde047" text-anchor="middle">Giliran: ${core.escapeXml(turnName)} · ${core.escapeXml(caption || "")}</text>
</svg>`;
}

// ═══ VIDEO ═══
async function renderVideo(room, outPath, reveal, caption) {
    const ff = spawn("ffmpeg", [
        "-y", "-f", "image2pipe", "-framerate", String(FPS), "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart", outPath
    ]);
    ff.stderr.on("data", () => {});
    ff.stdin.on("error", () => {});

    for (let i = 0; i < FRAMES; i++) {
        const t = i / (FRAMES - 1);
        const png = await sharp(Buffer.from(sceneSvg(room, t, reveal, caption))).png().toBuffer();
        ff.stdin.write(png);
    }
    ff.stdin.end();

    await new Promise((resolve, reject) => {
        ff.on("close", code => code === 0 ? resolve() : reject(new Error("ffmpeg exit " + code)));
        ff.on("error", reject);
    });
    return outPath;
}

async function sendGame(client, chatId, room, caption = "", reveal = false) {
    const outPath = path.join(TMP, `poker_${Date.now()}.mp4`);
    try {
        await renderVideo(room, outPath, reveal, caption);
        await client.sendFile(chatId, {
            file: outPath,
            caption: `♠ <b>POKER</b> ♥\n${caption}`,
            parseMode: "html",
            forceDocument: false,
            attributes: [new Api.DocumentAttributeVideo({
                duration: FRAMES / FPS, w: W, h: H, supportsStreaming: true
            })]
        });
    } catch (e) {
        console.log("[POKER VIDEO ERR]", e.message);
        await client.sendMessage(chatId, {
            message: `♠ <b>POKER</b> ♥\n${caption}\n\n<i>(video gagal dibuat, cek ffmpeg)</i>`,
            parseMode: "html"
        }).catch(() => {});
    } finally {
        try { fs.unlinkSync(outPath); } catch {}
    }
}

// ═══ COMMAND ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const deck = makeDeck();
        const hands = [deck.splice(0, 5), deck.splice(0, 5)];
        const room = core.createRoom("poker", userId, myName, me?.username || null, {
            state: { deck, hands, revealed: [false, false] },
            maxPlayers: 2,
            chatId: String(chatId)
        });
        return sendGame(client, chatId, room,
            `Room <code>${room.id}</code> dibuat. Lawan join: <code>.poker join ${room.id}</code>`);
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .poker join [KODE]" });
        const r = core.joinRoom(roomId, userId, myName, me?.username || null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });
        return sendGame(client, chatId, r.room,
            `Game dimulai! Ketik <code>.poker eval</code> buat buka kartu dan menentukan pemenang.`);
    }

    if (cmd === "eval" || cmd === "reveal") {
        const room = Object.values(core.ROOMS).find(r =>
            r.gameType === "poker" && r.status === "playing" && r.players.some(p => String(p.id) === String(userId)));
        if (!room) return client.sendMessage(chatId, { message: "✕ Ga di game aktif" });
        if (room.state.revealed[0]) return client.sendMessage(chatId, { message: "✕ Udah direveal" });

        const h1 = evalHand(room.state.hands[0]);
        const h2 = evalHand(room.state.hands[1]);
        room.state.revealed = [true, true];

        let winner = room.players[0];
        if (h2.rank > h1.rank) winner = room.players[1];

        core.saveRoom(room);

        const caption =
            `${room.players[0].name}: <b>${h1.name}</b> | ` +
            `${room.players[1].name}: <b>${h2.name}</b> | ` +
            `🏆 ${winner.name}`;

        await sendGame(client, chatId, room, caption, true);
        return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
    }

    return client.sendMessage(chatId, {
        message:
            "♠ <b>POKER</b> ♥\n\n├─────────────────\n" +
            "│ ▪ <code>.poker start</code>\n│ ▪ <code>.poker join [KODE]</code>\n" +
            "│ ▪ <code>.poker eval</code>\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "poker",
    handler,
    description: "Poker PVP (5-card draw, video otomatis)",
    category: "game"
};