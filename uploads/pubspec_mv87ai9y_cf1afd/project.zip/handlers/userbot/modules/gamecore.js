const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DB_DIR = path.join(__dirname, "..", "..", "..", "database");
const ROOMS_FILE = path.join(DB_DIR, "game_rooms.json");
const COIN_FILE = path.join(DB_DIR, "game_coins.json");
const CLAIM_FILE = path.join(DB_DIR, "game_claims.json");

// Folder video yang bisa diakses halaman web (lewat server kamu)
const PUBLIC_DIR = path.join(__dirname, "..", "..", "..", "public", "game");
if (!fs.existsSync(PUBLIC_DIR)) fs.mkdirSync(PUBLIC_DIR, { recursive: true });

const ROOM_TTL_MS = 6 * 60 * 60 * 1000; // room finished dihapus setelah 6 jam

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
if (!fs.existsSync(ROOMS_FILE)) fs.writeFileSync(ROOMS_FILE, "{}", "utf8");
if (!fs.existsSync(COIN_FILE)) fs.writeFileSync(COIN_FILE, "{}", "utf8");
if (!fs.existsSync(CLAIM_FILE)) fs.writeFileSync(CLAIM_FILE, "{}", "utf8");

function readJSON(f) { try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return {}; } }
function writeJSON(f, d) {
    try {
        const tmp = f + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(d, null, 2), "utf8");
        fs.renameSync(tmp, f);
    } catch (e) {
        console.log("[GAMECORE] gagal simpan:", e.message);
    }
}

const ROOMS = readJSON(ROOMS_FILE);
const COINS = readJSON(COIN_FILE);
const CLAIMS = readJSON(CLAIM_FILE);

function saveRooms() { writeJSON(ROOMS_FILE, ROOMS); }
function saveCoins() { writeJSON(COIN_FILE, COINS); }
function saveClaims() { writeJSON(CLAIM_FILE, CLAIMS); }

// ═══ ROOM ═══
function genRoomId() {
    return crypto.randomBytes(4).toString("hex").toUpperCase();
}

function createRoom(gameType, hostId, hostName, hostUsername, extra = {}) {
    const id = genRoomId();
    const room = {
        id,
        gameType,
        host: { id: hostId, name: hostName, username: hostUsername },
        players: [{ id: hostId, name: hostName, username: hostUsername, joinedAt: Date.now() }],
        state: extra.state || {},
        turn: 0,
        status: "waiting",
        maxPlayers: extra.maxPlayers || 2,
        createdAt: Date.now(),
        chatId: extra.chatId,
        lastMove: null,
        moveHistory: []
    };
    ROOMS[id] = room;
    saveRooms();
    return room;
}

function getRoom(id) { return ROOMS[id] || null; }
function saveRoom(room) { ROOMS[room.id] = room; saveRooms(); }
function deleteRoom(id) { delete ROOMS[id]; saveRooms(); }

function joinRoom(id, userId, userName, userUsername) {
    const room = ROOMS[id];
    if (!room) return { ok: false, error: "Room gaada" };
    if (room.status === "playing") return { ok: false, error: "Game udah mulai" };
    if (room.status === "finished") return { ok: false, error: "Game udah selesai" };
    if (room.players.length >= room.maxPlayers) return { ok: false, error: "Room penuh" };
    if (room.players.find(p => String(p.id) === String(userId))) return { ok: true, room, already: true };

    room.players.push({ id: userId, name: userName, username: userUsername, joinedAt: Date.now() });
    if (room.players.length >= room.maxPlayers) room.status = "playing";
    saveRoom(room);
    return { ok: true, room };
}

// Status room untuk ditampilkan di halaman web (tanpa data sensitif)
function getRoomPublic(id) {
    const r = ROOMS[id];
    if (!r) return null;
    return {
        id: r.id,
        gameType: r.gameType,
        status: r.status,
        turn: r.turn,
        turnName: r.players.length ? r.players[r.turn % r.players.length].name : null,
        players: r.players.map(p => ({ name: p.name })),
        state: {
            zombieHp: r.state.zombieHp,
            wave: r.state.wave,
            p1Hp: r.state.p1Hp,
            p2Hp: r.state.p2Hp,
            totalDamage: r.state.totalDamage
        }
    };
}

// Hapus room yang sudah selesai atau terlalu lama menganggur
function cleanupRooms() {
    const now = Date.now();
    let changed = false;
    for (const id of Object.keys(ROOMS)) {
        const r = ROOMS[id];
        const age = now - (r.createdAt || 0);
        if ((r.status === "finished" || r.status === "waiting") && age > ROOM_TTL_MS) {
            delete ROOMS[id];
            changed = true;
        }
    }
    if (changed) saveRooms();
}
setInterval(cleanupRooms, 30 * 60 * 1000);

// ═══ COIN & CLAIM ═══
function addCoin(userId, amount = 1) {
    COINS[userId] = (COINS[userId] || 0) + amount;
    saveCoins();
    return COINS[userId];
}

function getCoin(userId) { return COINS[userId] || 0; }

function subtractCoin(userId, amount) {
    COINS[userId] = Math.max(0, (COINS[userId] || 0) - amount);
    saveCoins();
    return COINS[userId];
}

function getClaimStatus(userId) {
    const c = CLAIMS[userId];
    if (!c) return { claimed: false, expiresAt: 0, active: false };
    const active = c.expiresAt > Date.now();
    return { claimed: true, expiresAt: c.expiresAt, active, claimedAt: c.claimedAt };
}

function setClaim(userId, days) {
    CLAIMS[userId] = {
        claimedAt: Date.now(),
        expiresAt: Date.now() + days * 86400000,
        days
    };
    saveClaims();
}

// ═══ RENDER & VIDEO ═══
async function renderSVG(svg) {
    try {
        const sharp = require("sharp");
        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch (e) {
        // Jangan kirim SVG mentah sebagai PNG. Lempar error biar ketahuan.
        throw new Error("render gambar gagal: " + e.message);
    }
}

function escapeXml(s) {
    return String(s).replace(/[<>&'"]/g, c => ({
        "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
    }[c]));
}

// Simpan video ke folder publik, return nama file (untuk URL halaman web)
function savePublicVideo(srcPath, roomId) {
    const name = `${roomId}_${Date.now()}.mp4`;
    const dest = path.join(PUBLIC_DIR, name);
    fs.copyFileSync(srcPath, dest);
    return { name, dest, url: `/game/${name}` };
}

// Hapus video publik yang lebih dari 1 jam
function cleanupPublicVideos() {
    const now = Date.now();
    for (const f of fs.readdirSync(PUBLIC_DIR)) {
        const p = path.join(PUBLIC_DIR, f);
        try {
            if (now - fs.statSync(p).mtimeMs > 60 * 60 * 1000) fs.unlinkSync(p);
        } catch {}
    }
}
setInterval(cleanupPublicVideos, 15 * 60 * 1000);

// Kirim gambar dari userbot (tanpa tombol, karena userbot tidak bisa pasang tombol)
async function sendGameImage(client, chatId, imgBuf, caption) {
    const { CustomFile } = require("telegram/client/uploads");
    const file = new CustomFile("game.png", imgBuf.length, "", imgBuf);
    await client.sendFile(chatId, { file, caption, parseMode: "html" });
}

// Kirim video dari bot (bot bisa pasang tombol inline)
async function sendGameVideoBot(bot, chatId, videoPath, caption, buttons = null) {
    const opts = { caption, parse_mode: "HTML" };
    if (buttons) opts.reply_markup = { inline_keyboard: buttons };
    return bot.sendVideo(chatId, videoPath, opts);
}

function buildLegoFrame(content, title, theme = "blue") {
    const themes = {
        blue: { bg: "#1e40af", accent: "#3b82f6", light: "#93c5fd" },
        red: { bg: "#991b1b", accent: "#ef4444", light: "#fca5a5" },
        green: { bg: "#166534", accent: "#22c55e", light: "#86efac" },
        yellow: { bg: "#a16207", accent: "#eab308", light: "#fde047" },
        purple: { bg: "#6b21a8", accent: "#a855f7", light: "#d8b4fe" },
        orange: { bg: "#c2410c", accent: "#f97316", light: "#fdba74" }
    };
    const t = themes[theme] || themes.blue;

    return (
        `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">` +
        `<defs>` +
        `<pattern id="lego" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">` +
        `<rect width="40" height="40" fill="${t.bg}"/>` +
        `<circle cx="20" cy="20" r="10" fill="${t.accent}" opacity="0.15"/>` +
        `</pattern>` +
        `<linearGradient id="header" x1="0%" y1="0%" x2="100%" y2="0%">` +
        `<stop offset="0%" stop-color="${t.accent}"/>` +
        `<stop offset="100%" stop-color="${t.light}"/>` +
        `</linearGradient>` +
        `</defs>` +
        `<rect width="800" height="800" fill="url(#lego)"/>` +
        `<rect x="20" y="20" width="760" height="80" rx="15" fill="url(#header)" stroke="#000" stroke-width="3"/>` +
        `<text x="400" y="72" font-family="Arial Black,sans-serif" font-size="36" font-weight="900" fill="#fff" text-anchor="middle" letter-spacing="2">${escapeXml(title)}</text>` +
        `<rect x="20" y="120" width="760" height="660" rx="20" fill="rgba(0,0,0,0.85)" stroke="${t.accent}" stroke-width="4"/>` +
        content +
        `</svg>`
    );
}

// ═══ WIN & REWARD ═══
// client = userbot (kirim pesan pakai parseMode) atau bot (pakai parse_mode)
async function checkWinAndReward(room, winnerId, winnerName, sender, chatId) {
    addCoin(winnerId, 1);
    const totalCoins = getCoin(winnerId);

    const text =
        "🏆 <b>WINNER!</b> 🏆\n\n" +
        "├─────────────────\n" +
        "│ 🥇 Pemenang  → " + winnerName + "\n" +
        "│ 💰 Reward    → +1 coin\n" +
        "│ 📊 Total     → " + totalCoins + " coin\n" +
        "├─────────────────\n" +
        "│ " + (totalCoins >= 20
            ? "✨ Ketik .claim buat claim userbot gratis 7 hari!"
            : "🎯 Butuh " + (20 - totalCoins) + " coin lagi buat claim") + "\n" +
        "╰─────────────────";

    try {
        if (sender && typeof sender.sendMessage === "function" && sender.constructor?.name !== "TelegramBot") {
            // userbot (GramJS)
            await sender.sendMessage(chatId, { message: text, parseMode: "html" });
        } else if (sender && typeof sender.sendMessage === "function") {
            // bot (node-telegram-bot-api)
            await sender.sendMessage(chatId, text, { parse_mode: "HTML" });
        }
    } catch (e) {
        console.log("[GAMECORE] kirim winner gagal:", e.message);
    }

    room.status = "finished";
    room.finishedAt = Date.now();
    saveRoom(room);
}

module.exports = {
    ROOMS, COINS, CLAIMS,
    createRoom, getRoom, saveRoom, deleteRoom, joinRoom, getRoomPublic,
    addCoin, getCoin, subtractCoin,
    getClaimStatus, setClaim,
    renderSVG, escapeXml, buildLegoFrame,
    savePublicVideo, cleanupPublicVideos, PUBLIC_DIR,
    sendGameImage, sendGameVideoBot,
    checkWinAndReward,
    saveRooms, saveCoins, saveClaims
};