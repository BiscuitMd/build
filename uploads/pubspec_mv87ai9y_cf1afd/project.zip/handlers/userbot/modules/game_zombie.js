const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");
const sharp = require("sharp");
const { Api } = require("telegram");
const core = require("./gamecore");

const W = 800, H = 600, FPS = 10, FRAMES = 14;
const TMP = path.join(__dirname, "..", "..", "..", "tmp_game");
if (!fs.existsSync(TMP)) fs.mkdirSync(TMP, { recursive: true });

// ═══ SCENE SVG (gaya website: gradasi, bayangan, HUD) ═══
function sceneSvg(room, s, t) {
    const shake = Math.sin(t * Math.PI * 6) * 8 * (1 - t);
    const flash = s.hit ? Math.max(0, 0.6 - t) : 0;
    const zHp = s.zHpFrom + (s.zHpTo - s.zHpFrom) * Math.min(1, t * 1.5);
    const pHp = s.pHpFrom + (s.pHpTo - s.pHpFrom) * Math.min(1, t * 1.5);
    const shooterX = s.shooterIdx === 0 ? 180 : 620;
    const bulletX = shooterX + (400 - shooterX) * Math.min(1, t * 2);
    const bulletY = 420 + (300 - 420) * Math.min(1, t * 2);
    const showBullet = t < 0.5;

    return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>
  <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1e1b2e"/><stop offset="1" stop-color="#4a1d1d"/></linearGradient>
  <linearGradient id="gnd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a2a2a"/><stop offset="1" stop-color="#0d0d0d"/></linearGradient>
  <radialGradient id="zb" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#a7f3a0"/><stop offset="1" stop-color="#2f5f2a"/></radialGradient>
  <radialGradient id="hb" cx="50%" cy="40%" r="60%"><stop offset="0" stop-color="#93c5fd"/><stop offset="1" stop-color="#1e3a8a"/></radialGradient>
  <filter id="sh" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="8" stdDeviation="6" flood-color="#000" flood-opacity="0.6"/></filter>
</defs>
<rect width="${W}" height="${H}" fill="url(#sky)"/>
<rect y="420" width="${W}" height="180" fill="url(#gnd)"/>
<ellipse cx="400" cy="470" rx="280" ry="26" fill="#000" opacity="0.5"/>

<g filter="url(#sh)" transform="translate(${400 + shake},300)">
  <ellipse cx="0" cy="120" rx="70" ry="14" fill="#000" opacity="0.4"/>
  <rect x="-45" y="-20" width="90" height="140" rx="30" fill="url(#zb)"/>
  <circle cx="0" cy="-60" r="50" fill="url(#zb)"/>
  <circle cx="-18" cy="-66" r="9" fill="#ff3b3b"/>
  <circle cx="18" cy="-66" r="9" fill="#ff3b3b"/>
  <path d="M-22 -36 Q0 -22 22 -36" stroke="#1b2e18" stroke-width="5" fill="none"/>
  ${s.hit ? `<circle cx="0" cy="-60" r="${60 * flash + 40}" fill="#fff" opacity="${flash * 0.4}"/>` : ""}
</g>

<g filter="url(#sh)" transform="translate(180,430)">
  <ellipse cx="0" cy="60" rx="40" ry="10" fill="#000" opacity="0.5"/>
  <rect x="-28" y="-10" width="56" height="70" rx="18" fill="url(#hb)"/>
  <circle cx="0" cy="-32" r="26" fill="#fcd5b4"/>
</g>
<g filter="url(#sh)" transform="translate(620,430)">
  <ellipse cx="0" cy="60" rx="40" ry="10" fill="#000" opacity="0.5"/>
  <rect x="-28" y="-10" width="56" height="70" rx="18" fill="#7c2d12"/>
  <circle cx="0" cy="-32" r="26" fill="#fcd5b4"/>
</g>

${showBullet ? `<circle cx="${bulletX}" cy="${bulletY}" r="6" fill="#fde047"/>` : ""}

<text x="400" y="50" font-family="Arial" font-size="30" font-weight="bold" fill="#fbbf24" text-anchor="middle">ZOMBIE WAVE ${room.state.wave}</text>
<rect x="200" y="70" width="400" height="22" rx="11" fill="#333"/>
<rect x="200" y="70" width="${Math.max(0, zHp) * 4}" height="22" rx="11" fill="#ef4444"/>
<text x="400" y="86" font-family="Arial" font-size="14" fill="#fff" text-anchor="middle">ZOMBIE ${Math.round(zHp)}/100</text>

<rect x="60" y="540" width="250" height="20" rx="10" fill="#333"/>
<rect x="60" y="540" width="${Math.max(0, s.shooterIdx === 0 ? pHp : room.state.p1Hp) * 2.5}" height="20" rx="10" fill="#22c55e"/>
<text x="185" y="555" font-family="Arial" font-size="13" fill="#fff" text-anchor="middle">${room.players[0].name}</text>
<rect x="490" y="540" width="250" height="20" rx="10" fill="#333"/>
<rect x="490" y="540" width="${Math.max(0, s.shooterIdx === 1 ? pHp : room.state.p2Hp) * 2.5}" height="20" rx="10" fill="#3b82f6"/>
<text x="615" y="555" font-family="Arial" font-size="13" fill="#fff" text-anchor="middle">${room.players[1]?.name || "P2"}</text>

<text x="400" y="590" font-family="Arial" font-size="16" fill="#fbbf24" text-anchor="middle">${s.caption || ""}</text>
</svg>`;
}

// ═══ ENCODE FRAME → MP4 (ffmpeg dibaca dari stdin) ═══
async function renderVideo(room, s, outPath) {
    const ff = spawn("ffmpeg", [
        "-y", "-f", "image2pipe", "-framerate", String(FPS), "-i", "-",
        "-c:v", "libx264", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        outPath
    ]);
    ff.stderr.on("data", () => {});
    ff.stdin.on("error", () => {});

    for (let i = 0; i < FRAMES; i++) {
        const t = i / (FRAMES - 1);
        const png = await sharp(Buffer.from(sceneSvg(room, s, t))).png().toBuffer();
        ff.stdin.write(png);
    }
    ff.stdin.end();

    await new Promise((resolve, reject) => {
        ff.on("close", code => code === 0 ? resolve() : reject(new Error("ffmpeg exit " + code)));
        ff.on("error", reject);
    });
    return outPath;
}

async function sendVideo(client, chatId, filePath, caption) {
    await client.sendFile(chatId, {
        file: filePath,
        caption,
        parseMode: "html",
        forceDocument: false,
        attributes: [new Api.DocumentAttributeVideo({
            duration: FRAMES / FPS, w: W, h: H, supportsStreaming: true
        })]
    });
}

// ═══ AKSI: 1 aksi = 1 video dikirim ═══
async function playAction(client, chatId, room, shooterIdx, action) {
    const head = action === "head";
    const dmg = head
        ? (Math.random() < 0.3 ? Math.floor(Math.random() * 15) + 25 : Math.floor(Math.random() * 6) + 3)
        : Math.floor(Math.random() * 20) + 10;

    const zFrom = room.state.zombieHp;
    const pFrom = shooterIdx === 0 ? room.state.p1Hp : room.state.p2Hp;

    room.state.zombieHp = Math.max(0, zFrom - dmg);
    room.state.totalDamage += dmg;
    room.state.turnDamage[shooterIdx] += dmg;

    const zAtk = Math.floor(Math.random() * 15) + 5;
    if (shooterIdx === 0) room.state.p2Hp = Math.max(0, room.state.p2Hp - zAtk);
    else room.state.p1Hp = Math.max(0, room.state.p1Hp - zAtk);

    const shooter = room.players[shooterIdx];
    const caption =
        `🎬 <b>${head ? "HEADSHOT" : "TEMBAK"}</b> — ${shooter.name}\n` +
        `🔫 -${dmg} HP zombie\n🧟 Zombie balas -${zAtk} HP\n\n` +
        `Zombie: <b>${room.state.zombieHp}/100</b>\n` +
        `Giliran berikutnya: <b>${room.players[(room.turn + 1) % 2].name}</b>\n` +
        `Ketik <code>.zombie ${head ? "head" : "shoot"}</code> atau <code>.zombie quit</code>`;

    const outPath = path.join(TMP, `zombie_${Date.now()}.mp4`);
    try {
        await renderVideo(room, {
            hit: true, shooterIdx,
            zHpFrom: zFrom, zHpTo: room.state.zombieHp,
            pHpFrom: pFrom, pHpTo: pFrom,
            caption: `${shooter.name} -${dmg}`
        }, outPath);
        await sendVideo(client, chatId, outPath, caption);
    } catch (e) {
        console.log("[ZOMBIE VIDEO ERR]", e.message);
        await client.sendMessage(chatId, { message: caption + "\n\n<i>(video gagal dibuat, cek ffmpeg)</i>", parseMode: "html" }).catch(() => {});
    } finally {
        try { fs.unlinkSync(outPath); } catch {}
    }

    if (room.state.zombieHp <= 0) {
        const winner = room.state.turnDamage[0] >= room.state.turnDamage[1] ? room.players[0] : room.players[1];
        core.saveRoom(room);
        await client.sendMessage(chatId, { message: `🏆 <b>ZOMBIE MATI!</b> ${winner.name} menang!`, parseMode: "html" });
        return core.checkWinAndReward(room, winner.id, winner.name, client, chatId);
    }
    if (room.state.p1Hp <= 0 || room.state.p2Hp <= 0) {
        const alive = room.state.p1Hp > 0 ? room.players[0] : room.players[1];
        core.saveRoom(room);
        await client.sendMessage(chatId, { message: `☠️ <b>${alive.name}</b> satu-satunya yang hidup! Menang!`, parseMode: "html" });
        return core.checkWinAndReward(room, alive.id, alive.name, client, chatId);
    }

    room.turn++;
    core.saveRoom(room);
}

// ═══ COMMAND: .zombie ═══
async function handler(userId, client, msg, args) {
    const chatId = msg.message.chatId;
    const cmd = args[0]?.toLowerCase();

    let me = null;
    try { me = await client.getMe(); } catch {}
    const myName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "Player") : "Player";

    if (cmd === "start") {
        const room = core.createRoom("zombie", userId, myName, null, {
            state: { zombieHp: 100, wave: 1, p1Hp: 100, p2Hp: 100, totalDamage: 0, turnDamage: [0, 0] },
            maxPlayers: 2,
            chatId: String(chatId)
        });
        return client.sendMessage(chatId, {
            message: `🧟 <b>ZOMBIE ATTACK</b>\n\nKode room: <code>${room.id}</code>\nLawan join: <code>.zombie join ${room.id}</code>`,
            parseMode: "html"
        });
    }

    if (cmd === "join") {
        const roomId = args[1]?.toUpperCase();
        if (!roomId) return client.sendMessage(chatId, { message: "▸ .zombie join [KODE]" });
        const r = core.joinRoom(roomId, userId, myName, null);
        if (!r.ok) return client.sendMessage(chatId, { message: "✕ " + r.error });
        if (r.already) return client.sendMessage(chatId, { message: "▸ Lu udah di room" });
        return client.sendMessage(chatId, {
            message: `🎮 <b>GAME DIMULAI!</b>\nGiliran: <b>${r.room.players[0].name}</b>\nKetik <code>.zombie shoot</code>, <code>.zombie head</code>, atau <code>.zombie quit</code>`,
            parseMode: "html"
        });
    }

    if (["shoot", "head", "quit"].includes(cmd)) {
        const room = Object.values(core.ROOMS).find(r =>
            r.gameType === "zombie" && r.status === "playing" && r.players.some(p => String(p.id) === String(userId)));
        if (!room) return client.sendMessage(chatId, { message: "✕ Lu ga lagi di game zombie" });

        const currentPlayer = room.players[room.turn % 2];
        if (String(currentPlayer.id) !== String(userId)) return client.sendMessage(chatId, { message: "✕ Bukan giliran lu" });

        const idx = room.turn % 2;
        if (cmd === "quit") {
            const other = room.players[(room.turn + 1) % 2];
            core.saveRoom(room);
            return core.checkWinAndReward(room, other.id, other.name, client, chatId);
        }
        return playAction(client, chatId, room, idx, cmd === "head" ? "head" : "shoot");
    }

    return client.sendMessage(chatId, {
        message:
            "🧟 <b>ZOMBIE ATTACK</b>\n\n├─────────────────\n" +
            "│ ▪ <code>.zombie start</code>\n│ ▪ <code>.zombie join [KODE]</code>\n" +
            "│ ▪ <code>.zombie shoot</code>\n│ ▪ <code>.zombie head</code>\n│ ▪ <code>.zombie quit</code>\n╰─────────────────",
        parseMode: "html"
    });
}

module.exports = {
    command: "zombie",
    handler,
    commands: ["zombieattack"],
    description: "Zombie attack co-op (video otomatis per aksi)",
    category: "game"
};