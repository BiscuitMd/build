// ═══════════════════════════════════════════
// USERBOT LOGIN — Telegram MTProto (GramJS 2.22)
// v33 — COMMAND ONLY
//      + .menu bisa dipakai orang lain (private / group / channel)
//      + menu lengkap semua command
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const { TelegramClient, Api } = require("telegram");
const { StringSession } = require("telegram/sessions");
const { NewMessage } = require("telegram/events");
const store = require("./session-store");
const path = require("path");

// ═══ FALLBACK API ═══
const FALLBACK_API_ID = 37192283;
const FALLBACK_API_HASH = "18e59914ed0b123b1120e4c9a516e43c";

const ACTIVE_CLIENTS = new Map();
const PENDING_LOGINS = new Map();

// Command yang boleh dipakai orang lain walau mode SELF
const PUBLIC_CMDS = [
    "menu", "help", "h", "ping", "id",
    "chess", "uno", "poker", "billiard", "pokemon",
    "ular", "puzzle", "botol", "mancing", "zombie",
    "claim", "gamecoin", "coin", "mycoin",
    "game", "games", "menugame", "menu_game"
];

// ═══ HELPER ═══
function cleanOtp(text) {
    return String(text || "").replace(/[\s\-_]/g, "").trim();
}

function validateApiId(apiId) {
    const num = parseInt(String(apiId || "").trim(), 10);
    if (isNaN(num)) return { ok: false, error: "API_ID harus angka" };
    if (num < 1 || num > 9999999999) return { ok: false, error: "API_ID di luar range" };
    return { ok: true, value: num };
}

function validateApiHash(apiHash) {
    const hash = String(apiHash || "").trim();
    if (!hash) return { ok: false, error: "API_HASH kosong" };
    if (hash.length !== 32) return { ok: false, error: `API_HASH harus 32 karakter (lu kirim ${hash.length})` };
    if (!/^[a-f0-9]+$/i.test(hash)) return { ok: false, error: "API_HASH cuma boleh hex" };
    return { ok: true, value: hash.toLowerCase() };
}

// ═══ CATEGORY ICON ═══
const CATEGORY_ICON = {
    ai: "◈", download: "▣", fun: "✦", tools: "⚙",
    info: "◉", media: "▤", text: "▥", crypto: "◆",
    osint: "◎", admin: "▲", group: "▦", build: "▧",
    forward: "⇒", general: "▪", userbot: "●",
    music: "♫", panel: "■", security: "⚿",
    monitor: "◉", vault: "◆", session: "●",
    automation: "◇", dev: "◆", finance: "◆",
    archive: "▣", utility: "◆", game: "◆", bot: "▣"
};

function getCategoryIcon(cat) {
    return CATEGORY_ICON[cat] || "▪";
}

// ═══ HELPER KIRIM KE CHAT ASAL PESAN (private / group / channel) ═══
async function getTarget(event) {
    try {
        return await event.message.getInputChat();
    } catch {
        return event.message.peerId;
    }
}

// Pecah teks panjang jadi beberapa pesan (batas Telegram 4096)
function chunkText(text, max = 3800) {
    const out = [];
    let cur = "";
    for (const line of String(text).split("\n")) {
        if ((cur + line + "\n").length > max) {
            out.push(cur);
            cur = "";
        }
        cur += line + "\n";
    }
    if (cur.trim()) out.push(cur);
    return out;
}

// ═══════════════════════════════════════════
// START LOGIN
// ═══════════════════════════════════════════
async function startLogin(bot, chatId, userId, phoneNumber, ctx, customApi = null) {
    try {
        const apiId = customApi?.apiId || FALLBACK_API_ID;
        const apiHash = customApi?.apiHash || FALLBACK_API_HASH;
        const isCustom = !!customApi?.apiId;

        const vId = validateApiId(apiId);
        if (!vId.ok) return { ok: false, error: vId.error };
        const vHash = validateApiHash(apiHash);
        if (!vHash.ok) return { ok: false, error: vHash.error };

        const session = new StringSession("");
        const client = new TelegramClient(session, vId.value, vHash.value, {
            connectionRetries: 3,
            useWSS: false
        });

        await client.connect();

        let phoneCodeHash;
        let codeType = "app";
        try {
            const result = await client.invoke(
                new Api.auth.SendCode({
                    phoneNumber,
                    apiId: vId.value,
                    apiHash: vHash.value,
                    settings: new Api.CodeSettings({})
                })
            );
            phoneCodeHash = result.phoneCodeHash;

            if (result.type) {
                const typeName = result.type.className || "";
                if (typeName.includes("App")) codeType = "app";
                else if (typeName.includes("Sms")) codeType = "sms";
                else if (typeName.includes("Call")) codeType = "call";
            }
        } catch (e) {
            try { await client.disconnect(); } catch {}
            let errMsg = e.message || "Unknown";
            if (errMsg.includes("API_ID_INVALID")) errMsg = "<b>API_ID / API_HASH tidak valid</b>";
            else if (errMsg.includes("FLOOD_WAIT")) {
                const m = errMsg.match(/FLOOD_WAIT_(\d+)/);
                errMsg = m ? `Tunggu ${m[1]} detik` : "Flood wait";
            }
            return { ok: false, error: errMsg };
        }

        PENDING_LOGINS.set(String(userId), {
            client, phoneNumber, phoneCodeHash,
            apiId: vId.value, apiHash: vHash.value, isCustom,
            step: "otp", createdAt: Date.now()
        });

        ctx.setState(String(userId), "userbot_await_otp", { phoneNumber });

        const codeTypeText = codeType === "app" ? "Telegram App" :
                             codeType === "sms" ? "SMS" : "Telepon";

        await bot.sendMessage(chatId,
            `<b>𖡛 OTP DIKIRIM 𖡛</b>\n` +
            `<i>Kode verifikasi Telegram</i>\n\n` +
            `<blockquote>` +
            `▸ Nomor <b>→</b> <code>${phoneNumber}</code>\n` +
            `▸ Metode <b>→</b> <b>${codeTypeText}</b>\n` +
            `▸ API <b>→</b> <b>${isCustom ? "CUSTOM" : "DEFAULT"}</b>` +
            `</blockquote>\n\n` +
            `<blockquote expandable><b>📝 Cara kirim OTP</b>\n` +
            `▸ Ketik <b>5 digit</b> OTP ke chat ini\n` +
            `▸ Bisa pake spasi: <code>1 2 3 4 5</code>\n` +
            `▸ Bisa tanpa spasi: <code>12345</code>` +
            `</blockquote>`,
            { parse_mode: "HTML" });

        return { ok: true };
    } catch (e) {
        console.log("[USERBOT] startLogin exception:", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ VERIFY OTP ═══
async function verifyOtp(userId, otpCode, bot, chatId, ctx) {
    const uid = String(userId);
    const pending = PENDING_LOGINS.get(uid);
    if (!pending) return { ok: false, error: "Sesi login hilang." };

    try {
        const { client, phoneNumber, phoneCodeHash, apiId, apiHash, isCustom } = pending;
        const cleanCode = cleanOtp(otpCode);

        try {
            await client.invoke(new Api.auth.SignIn({ phoneNumber, phoneCodeHash, phoneCode: cleanCode }));
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("SESSION_PASSWORD_NEEDED")) {
                pending.step = "password";
                PENDING_LOGINS.set(uid, pending);
                ctx.setState(uid, "userbot_await_password", {});
                await bot.sendMessage(chatId,
                    `<b>𖡛 2FA REQUIRED 𖡛</b>\n\n` +
                    `<blockquote>Kirim <b>password 2FA</b> lu ke chat ini.</blockquote>`,
                    { parse_mode: "HTML" });
                return { ok: false, needPassword: true };
            }
            if (msg.includes("PHONE_CODE_INVALID") || msg.includes("PHONE_CODE_EXPIRED")) {
                return { ok: false, error: msg.includes("EXPIRED") ? "Kode OTP expired." : "Kode OTP salah." };
            }
            throw e;
        }

        return await finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx, { apiId, apiHash, isCustom });
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══ VERIFY 2FA ═══
async function verifyPassword(userId, password, bot, chatId, ctx) {
    const uid = String(userId);
    const pending = PENDING_LOGINS.get(uid);
    if (!pending) return { ok: false, error: "Sesi 2FA hilang." };

    try {
        const { client, phoneNumber, apiId, apiHash, isCustom } = pending;
        const pwdInfo = await client.invoke(new Api.account.GetPassword());
        const { computeCheck } = require("telegram/Password");
        const pwdCheck = await computeCheck(pwdInfo, password);

        try {
            await client.invoke(new Api.auth.CheckPassword({ password: pwdCheck }));
        } catch (e) {
            const msg = e.message || "";
            if (msg.includes("PASSWORD_HASH_INVALID") || msg.includes("SRP_ID_INVALID")) {
                return { ok: false, error: "Password 2FA salah." };
            }
            throw e;
        }

        return await finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx, { apiId, apiHash, isCustom });
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══ FINALIZE ═══
async function finalizeLogin(userId, client, phoneNumber, bot, chatId, ctx, apiInfo = {}) {
    try {
        const uid = String(userId);
        const sessionString = client.session.save();

        store.saveSession(uid, {
            phone: phoneNumber, sessionString, connectedAt: Date.now(),
            apiId: apiInfo.apiId, apiHash: apiInfo.apiHash, isCustom: !!apiInfo.isCustom
        });

        ACTIVE_CLIENTS.set(uid, client);
        PENDING_LOGINS.delete(uid);
        store.clearPending(uid);
        ctx.clearState(uid);

        setupEventHandler(userId, client, bot);

        let userName = "-", userUsername = "-";
        try {
            const me = await client.getMe();
            userName = [me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "-";
            userUsername = me.username ? "@" + me.username : "-";
        } catch {}

        const currentMode = store.getMode(uid);

        await bot.sendMessage(chatId,
            `<b>𖡛 USERBOT CONNECTED 𖡛</b>\n` +
            `<i>Session aktif & online</i>\n\n` +
            `<blockquote>` +
            `▸ Nama <b>→</b> <b>${userName}</b>\n` +
            `▸ Username <b>→</b> <code>${userUsername}</code>\n` +
            `▸ Mode <b>→</b> <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `▸ API <b>→</b> <b>${apiInfo.isCustom ? "CUSTOM" : "DEFAULT"}</b>` +
            `</blockquote>\n\n` +
            `<blockquote>Ketik <code>.menu</code> buat mulai 👇</blockquote>`,
            { parse_mode: "HTML" });

        return { ok: true };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// SETUP EVENT HANDLER — COMMAND ONLY
// ═══════════════════════════════════════════
function setupEventHandler(userId, client, bot) {
    client.addEventHandler(async (event) => {
        try {
            const text = event.message?.message || event.message?.text || "";
            if (!text) return;

            const senderId = event.message?.senderId?.toString() || "";
            const isFromMe = !!event.message?.out;
            const isFromSelf = String(senderId) === String(userId);

            const mode = store.getMode(userId);

            // nama command tanpa titik, huruf kecil
            const cmdName = text.startsWith(".")
                ? text.slice(1).trim().split(/\s+/)[0].toLowerCase()
                : "";
            const isPublicCmd = !!cmdName && (PUBLIC_CMDS.includes(cmdName) || cmdName.startsWith("menu_"));

            if (mode === "self") {
                if (!isFromSelf && !isFromMe && !isPublicCmd) return;
            }

            if (text.startsWith(".")) {
                const args = text.slice(1).trim().split(/\s+/);
                const cmd = args.shift().toLowerCase();
                await handleUserbotCommand(userId, client, event, cmd, args, bot);
                return;
            }

            if (!isFromMe) {
                try {
                    const autofw = require("./modules/autofw");
                    if (typeof autofw.handleForward === "function") await autofw.handleForward(userId, client, event);
                } catch {}
                try {
                    const autorespon = require("./modules/autorespon");
                    if (typeof autorespon.handleIncoming === "function") await autorespon.handleIncoming(userId, client, event);
                } catch {}
                try {
                    const afk = require("./modules/afk");
                    if (typeof afk.handleIncoming === "function") await afk.handleIncoming(userId, client, event);
                } catch {}
            }
        } catch (e) {
            console.log("[USERBOT MSG ERR]", (e.message || "").slice(0, 100));
        }
    }, new NewMessage({}));

    console.log(`[USERBOT] ✅ Event handler aktif (v33 — command only, menu public)`);
}

// ═══════════════════════════════════════════
// MENU LENGKAP: header (foto) + semua command per kategori
// ═══════════════════════════════════════════
async function sendFullMenu(client, target, userId, loader) {
    const groups = loader.groupByCategory();
    const totalModules = loader.listModules().length;
    const totalCategories = Object.keys(groups).length;
    const currentMode = store.getMode(userId);

    let me = null;
    try { me = await client.getMe(); } catch {}
    const userName = me ? ([me.firstName, me.lastName].filter(Boolean).join(" ") || me.username || "User") : "User";
    const userUsername = me?.username ? "@" + me.username : "-";

    const userRole = store.getUserRole(userId);
    const roleName = userRole ? userRole.role.toUpperCase() : "FREE";

    let expiredText = "UNLIMITED";
    if (userRole && userRole.expiresAt) {
        const days = Math.ceil((userRole.expiresAt - Date.now()) / 86400000);
        expiredText = days > 0 ? `${days} DAYS` : "EXPIRED";
    }

    // ── 1. HEADER + FOTO (caption di bawah 1024 karakter) ──
    const header =
        `<b>𖡛 USERBOT MENU 𖡛</b>\n` +
        `<i>Powered by SpartaX • ${totalModules} modules • ${totalCategories} kategori</i>\n\n` +
        `<blockquote>` +
        `▸ Username <b>→</b> <code>${userUsername}</code>\n` +
        `▸ Name <b>→</b> ${userName.slice(0, 20)}\n` +
        `▸ Mode <b>→</b> <b>${currentMode.toUpperCase()}</b>\n` +
        `▸ Role <b>→</b> <b>${roleName}</b>\n` +
        `▸ Expired <b>→</b> ${expiredText}\n` +
        `▸ Status <b>→</b> <b>ONLINE</b>` +
        `</blockquote>`;

    let cfgLocal = {};
    try { cfgLocal = require(path.join(__dirname, "..", "..", "config.js")); } catch {}
    const fotoUrl = cfgLocal?.FOTO?.MENU || "https://files.catbox.moe/3hj0vu.png";

    let photoSent = false;
    try {
        await client.sendFile(target, { file: fotoUrl, caption: header, parseMode: "html" });
        photoSent = true;
    } catch (e) {
        console.log("[UBOT MENU] foto fail:", (e.message || "").slice(0, 100));
    }
    if (!photoSent) {
        await client.sendMessage(target, { message: header, parseMode: "html" }).catch(() => {});
    }

    // ── 2. SEMUA COMMAND PER KATEGORI (dipecah jadi beberapa pesan) ──
    const categories = Object.keys(groups).sort();
    let body = "";
    for (const cat of categories) {
        const icon = getCategoryIcon(cat);
        body += `\n${icon} <b>${cat.toUpperCase()}</b> · <code>${groups[cat].length}</code>\n`;
        for (const m of groups[cat]) {
            const desc = (m.description || "-").slice(0, 40);
            body += `▸ <code>.${m.command}</code> — ${desc}\n`;
        }
        body += `<i>Kategori: .menu_${cat}</i>\n`;
    }

    const parts = chunkText(body, 3800);
    for (let i = 0; i < parts.length; i++) {
        const label = parts.length > 1 ? `<b>■ COMMANDS (${i + 1}/${parts.length})</b>\n` : `<b>■ COMMANDS</b>\n`;
        await client.sendMessage(target, {
            message: label + parts[i],
            parseMode: "html"
        }).catch(e => console.log("[UBOT MENU] part fail:", (e.message || "").slice(0, 100)));
    }

    // ── 3. FOOTER ──
    await client.sendMessage(target, {
        message:
            `<blockquote><b>→ Usage:</b>\n` +
            `▸ Ketik command tanpa tanda ragu, contoh <code>.ping</code>\n` +
            `▸ Detail per kategori: <code>.menu_[kategori]</code></blockquote>`,
        parseMode: "html"
    }).catch(() => {});
}

// ═══════════════════════════════════════════
// HANDLE COMMAND
// ═══════════════════════════════════════════
async function handleUserbotCommand(userId, client, event, cmd, args, bot) {
    const target = await getTarget(event);
    const chatId = String(event.message.chatId || "");

    console.log(`[UBOT CMD] .${cmd}`);

    try {
        // ═══════════════════════════════════════
        // .menu — MENU LENGKAP (bisa dipakai siapa saja)
        // ═══════════════════════════════════════
        if (cmd === "menu") {
            const loader = require("./module-loader");
            await sendFullMenu(client, target, userId, loader);
            return;
        }

        // ═══ .menu_[kategori] ═══
        if (cmd.startsWith("menu_")) {
            const category = cmd.slice(5);
            const loader = require("./module-loader");
            const groups = loader.groupByCategory();
            const modules = groups[category];

            if (!modules) {
                return client.sendMessage(target, {
                    message:
                        `<b>✕ Kategori <code>${category}</code> gaada</b>\n\n` +
                        `<blockquote>Ketik <code>.menu</code> buat liat semua kategori</blockquote>`,
                    parseMode: "html"
                });
            }

            const icon = getCategoryIcon(category);
            let cmdList = "";
            for (const m of modules) {
                const desc = (m.description || "-").slice(0, 40);
                cmdList += `▸ <code>.${m.command}</code>\n  ${desc}\n`;
            }

            const caption =
                `<b>${icon} ${category.toUpperCase()} ${icon}</b>\n` +
                `<i>Kategori • ${modules.length} commands</i>\n\n` +
                `<b>■ COMMANDS</b>\n\n` +
                `${cmdList}\n` +
                `<blockquote>▸ Balik menu: <code>.menu</code></blockquote>`;

            for (const part of chunkText(caption, 3800)) {
                await client.sendMessage(target, { message: part, parseMode: "html" })
                    .catch(e => console.log("[UBOT MENU] category fail:", (e.message || "").slice(0, 100)));
            }
            return;
        }

        // ═══ .help ═══
        if (cmd === "help" || cmd === "h") {
            const loader = require("./module-loader");
            const totalModules = loader.listModules().length;

            await client.sendMessage(target, {
                message:
                    `<b>𖡛 HELP MENU 𖡛</b>\n` +
                    `<i>Panduan penggunaan userbot</i>\n\n` +
                    `<blockquote>` +
                    `◆ <b>BASIC COMMANDS</b>\n` +
                    `▸ <code>.menu</code> <b>→</b> Menu lengkap\n` +
                    `▸ <code>.help</code> <b>→</b> Bantuan\n` +
                    `▸ <code>.ping</code> <b>→</b> Test bot\n` +
                    `▸ <code>.id</code> <b>→</b> Info chat\n` +
                    `▸ <code>.mode self</code> <b>→</b> Private mode\n` +
                    `▸ <code>.mode public</code> <b>→</b> Public mode` +
                    `</blockquote>\n\n` +
                    `<blockquote>▸ Total <code>${totalModules}</code> commands tersedia</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        // ═══ .mode ═══
        if (cmd === "mode") {
            const senderId = event.message?.senderId?.toString() || "";
            const isFromMe = !!event.message?.out;
            const isFromSelf = String(senderId) === String(userId);

            if (!isFromSelf && !isFromMe) {
                return client.sendMessage(target, {
                    message: `<b>✕ Cuma owner userbot yang bisa ganti mode</b>`,
                    parseMode: "html"
                });
            }

            const newMode = args[0]?.toLowerCase();
            const currentMode = store.getMode(userId);

            if (!newMode) {
                return client.sendMessage(target, {
                    message:
                        `<b>◆ USERBOT MODE</b>\n\n` +
                        `<blockquote>▸ Current <b>→</b> <b>${currentMode.toUpperCase()}</b></blockquote>\n\n` +
                        `<b>→ Usage:</b>\n` +
                        `▸ <code>.mode self</code>\n` +
                        `▸ <code>.mode public</code>`,
                    parseMode: "html"
                });
            }

            if (!["self", "public"].includes(newMode)) {
                return client.sendMessage(target, {
                    message: `<b>✕ Mode invalid</b>\n\n<blockquote>▸ <code>self</code>\n▸ <code>public</code></blockquote>`,
                    parseMode: "html"
                });
            }

            if (currentMode === newMode) {
                return client.sendMessage(target, {
                    message: `<b>■ Mode udah <code>${newMode.toUpperCase()}</code></b>`,
                    parseMode: "html"
                });
            }

            store.setMode(userId, newMode);
            await client.sendMessage(target, {
                message:
                    `<b>✓ Mode diubah</b>\n\n` +
                    `<blockquote>` +
                    `▸ From <b>→</b> <code>${currentMode.toUpperCase()}</code>\n` +
                    `▸ To <b>→</b> <code>${newMode.toUpperCase()}</code>` +
                    `</blockquote>\n\n` +
                    (newMode === "self" ? `<i>▸ Private mode: cuma lu (command publik tetap bisa)</i>` : `<i>▸ Public mode: semua orang</i>`),
                parseMode: "html"
            });
            return;
        }

        // ═══ .ping ═══
        if (cmd === "ping") {
            const start = Date.now();
            const sent = await client.sendMessage(target, { message: "▸ Pinging..." });
            const latency = Date.now() - start;
            try {
                await client.editMessage(target, {
                    message: sent.id,
                    text: `<b>✓ Pong!</b>\n\n<blockquote>▸ Latency <b>→</b> <code>${latency}ms</code></blockquote>`,
                    parseMode: "html"
                });
            } catch {
                await client.sendMessage(target, { message: `<b>✓ Pong!</b> <code>${latency}ms</code>`, parseMode: "html" });
            }
            return;
        }

        // ═══ .id ═══
        if (cmd === "id") {
            const senderId = event.message?.senderId?.toString() || "";
            await client.sendMessage(target, {
                message:
                    `<b>◆ CHAT INFO</b>\n\n` +
                    `<blockquote>` +
                    `▸ Chat ID <b>→</b> <code>${chatId}</code>\n` +
                    `▸ Sender ID <b>→</b> <code>${senderId}</code>` +
                    `</blockquote>`,
                parseMode: "html"
            });
            return;
        }

        // ═══ Auto-load module ═══
        const loader = require("./module-loader");
        const handled = await loader.execute(userId, client, event, cmd, args, bot);
        if (handled) return;

        await client.sendMessage(target, {
            message:
                `<b>✕ Command <code>.${cmd}</code> gaada</b>\n\n` +
                `<blockquote>Ketik <code>.menu</code> buat liat semua command</blockquote>`,
            parseMode: "html"
        });
    } catch (e) {
        console.log("[USERBOT CMD ERR]", e.message);
    }
}

// ═══════════════════════════════════════════
// RESTORE ALL SESSIONS
// ═══════════════════════════════════════════
async function restoreAllSessions(bot) {
    const userIds = store.listSessions();
    console.log(`[USERBOT] restore ${userIds.length} sesi...`);

    for (const userId of userIds) {
        try {
            const sessionData = store.loadSession(userId);
            if (!sessionData?.sessionString) continue;

            const apiId = sessionData.apiId || FALLBACK_API_ID;
            const apiHash = sessionData.apiHash || FALLBACK_API_HASH;

            const session = new StringSession(sessionData.sessionString);
            const client = new TelegramClient(session, apiId, apiHash, {
                connectionRetries: 3,
                useWSS: false
            });

            await client.connect();
            ACTIVE_CLIENTS.set(String(userId), client);
            setupEventHandler(userId, client, bot);
            console.log(`[USERBOT] ✅ restored ${userId}`);
        } catch (e) {
            console.log(`[USERBOT] restore ${userId} fail:`, e.message);
        }
    }
}

// ═══════════════════════════════════════════
// GET CLIENT / STOP CLIENT / CANCEL LOGIN
// ═══════════════════════════════════════════
function getClient(userId) {
    return ACTIVE_CLIENTS.get(String(userId));
}

async function stopClient(userId) {
    const client = ACTIVE_CLIENTS.get(String(userId));
    if (client) {
        try { await client.disconnect(); } catch {}
        ACTIVE_CLIENTS.delete(String(userId));
    }
    store.deleteSession(userId);

    try {
        const build = require("./modules/build");
        if (build && typeof build.cleanup === "function") {
            build.cleanup(userId);
        }
    } catch {}
}

function cancelLogin(userId) {
    const pending = PENDING_LOGINS.get(String(userId));
    if (pending) {
        try { pending.client.disconnect(); } catch {}
        PENDING_LOGINS.delete(String(userId));
    }
    store.clearPending(userId);
}

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports = {
    startLogin,
    verifyOtp,
    verifyPassword,
    restoreAllSessions,
    getClient,
    stopClient,
    cancelLogin,
    validateApiId,
    validateApiHash,
    FALLBACK_API_ID,
    FALLBACK_API_HASH
};

console.log("[USERBOT LOGIN] loaded");