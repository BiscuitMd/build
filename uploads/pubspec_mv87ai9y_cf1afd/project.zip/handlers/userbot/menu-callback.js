const path = require("path");
const router = require(path.join(__dirname, "..", "..", "modules", "router.js"));
const cfg = require(path.join(__dirname, "..", "..", "config.js"));
const store = require("./session-store");
const login = require("./login");

// ═══ ICON ═══
const I = {
    bullet: "▸", bulletOut: "▪", dot: "●", dotOut: "○",
    circle: "◉", square: "■", squareOut: "□",
    diamond: "◆", diamondOut: "◇", star: "✦",
    check: "✓", cross: "✕", arrow: "→", arrowRight: "⇒",
    line: "─", pipe: "│",
    cornerTL: "╭", cornerTR: "╮", cornerBL: "╰", cornerBR: "╯",
    teeL: "├", teeR: "┤", doubleH: "═",
    clock: "🕐"    // ⚡ FIX: I.clock yang Tuan pakai tapi ga ada
};

// ═══ ROLE PRICES ═══
const ROLE_PRICES = {
    permanent: 3000,
    reseller: 6000,
    admin: 9000,
    owner: 12000
};

const ROLE_BENEFIT = {
    permanent: "Akses ubot permanen selamanya",
    reseller: "Akses ubot + add permanen only",
    admin: "Akses ubot + add permanen sampai reseller",
    owner: "Akses ubot + add permanen sampai admin"
};

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const m = e.message || "";
        if (m.includes("message is not modified")) return null;
        if (m.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch {}
        }
        if (m.includes("message to edit not found") || m.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU UTAMA USERBOT
// ═══════════════════════════════════════════
router.registerCallback("menu_userbot", async (bot, q, data, user, ctx) => {
    try {
        const userRole = store.getUserRole(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const activeClient = login.getClient(user.id);
        const currentMode = store.getMode(user.id);

        const statusIcon = activeClient ? I.check : (sessionExists ? I.clock : I.cross);
        const statusText = activeClient ? "Online" : (sessionExists ? "Session ada, offline" : "Belum login");

        const expiredText = userRole && userRole.expiresAt
            ? Math.ceil((userRole.expiresAt - Date.now()) / 86400000) + " hari"
            : "∞";

        const caption =
            `<b>╭━━━ ◈ USERBOT CONTROL CENTER ◈ ━━━╮</b>\n` +
            `<i>TELEGRAM AUTOMATION · RICH HTML PANEL</i>\n\n` +
            `<blockquote>🛰️ <b>SESSION STATUS</b>\n` +
            `├ Status  : <b>${statusIcon} ${statusText}</b>\n` +
            `├ Mode    : <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `├ Role    : <b>${userRole ? userRole.role.toUpperCase() : "TIDAK ADA"}</b>\n` +
            `└ Expired : <b>${expiredText}</b></blockquote>\n` +
            `<b>╭─ ✦ MODULE CENTER</b>\n` +
            `<blockquote>▸ Katalog modul otomatis\n▸ Auto-forward & automation\n▸ Build APK melalui GitHub\n▸ Profile tools, AFK & auto-reply\n▸ Utilitas teks, media, AI, dan informasi</blockquote>\n` +
            `<i>Pilih tombol di bawah untuk membuka panel interaktif.</i>\n` +
            `<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>`;

        const kb = [];
        if (!userRole) {
            kb.push([{ text: `▸ Beli Role Ubot`, callback_data: "userbot_buy", style: "success" }]);
        } else if (!activeClient) {
            kb.push([{ text: `▸ Login Telegram`, callback_data: "userbot_login", style: "success" }]);
        } else {
            kb.push([{ text: `▸ Manage Session`, callback_data: "userbot_manage", style: "primary" }]);
        }
        kb.push([{ text: `▦ BUKA KATALOG MODUL`, callback_data: "userbot_catalog", style: "primary" }]);
        kb.push([{ text: `⌕ CARI FITUR`, callback_data: "userbot_search", style: "success" }]);
        kb.push([{ text: `✕ MENU UTAMA`, callback_data: "menu_back", style: "danger" }]);

        if (typeof bot.sendRichMenu === "function") {
            await bot.sendRichMenu(q.message.chat.id, cfg.FOTO?.MENU || null, caption, kb, q);
        } else {
            await bot.sendMessage(q.message.chat.id, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
        }
    } catch (e) { console.log("[USERBOT MENU ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BELI ROLE (sama kayak sebelumnya)
// ═══════════════════════════════════════════
router.registerCallback("userbot_buy", async (bot, q, data, user, ctx) => {
    try {
        const rows = [];
        for (const [role, price] of Object.entries(ROLE_PRICES)) {
            rows.push([{
                text: `▸ ${role.toUpperCase()} — Rp${price.toLocaleString("id-ID")}`,
                callback_data: `userbot_buy_pick:${role}`,
                style: "success"
            }]);
        }
        rows.push([{ text: `✕ Batal`, callback_data: "userbot_main", style: "danger" }]);

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 BELI ROLE USERBOT 𖡛</b>\n` +
            `<i>Pilih role yang mau lu beli</i>\n\n` +
            `<blockquote>` +
            `▸ Permanent <b>→</b> akses ubot selamanya\n` +
            `▸ Reseller <b>→</b> akses + add ubot\n` +
            `▸ Admin <b>→</b> akses + add sampai reseller\n` +
            `▸ Owner <b>→</b> akses + add sampai admin` +
            `</blockquote>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[USERBOT BUY ERR]", e.message); }
});

router.registerCallback("userbot_buy_pick", async (bot, q, data, user, ctx) => {
    try {
        const role = data.split(":")[1];
        const price = ROLE_PRICES[role];
        const benefit = ROLE_BENEFIT[role];

        ctx.setState(String(user.id), "userbot_await_bukti", { role, price });

        const caption =
            `<b>𖡛 PEMBAYARAN 𖡛</b>\n` +
            `<i>Role: ${role.toUpperCase()}</i>\n\n` +
            `<blockquote>` +
            `◆ <b>ORDER DETAIL</b>\n` +
            `▸ Role <b>→</b> <b>${role.toUpperCase()}</b>\n` +
            `▸ Harga <b>→</b> <b>Rp${price.toLocaleString("id-ID")}</b>\n` +
            `▸ Benefit <b>→</b> ${benefit}` +
            `</blockquote>\n\n` +
            `<blockquote>` +
            `✦ <b>Scan QRIS di bawah</b>\n` +
            `▸ Setelah transfer, kirim foto bukti ke chat ini` +
            `</blockquote>`;

        const kb = { inline_keyboard: [[{ text: `✕ Batal`, callback_data: "userbot_main", style: "danger" }]] };

        let sent = false;
        try {
            await bot.sendPhoto(q.message.chat.id, cfg.FOTO.QRIS, {
                caption, parse_mode: "HTML", reply_markup: kb
            });
            sent = true;
        } catch (e) { console.log("[USERBOT BUY PICK] sendPhoto fail:", e.message.slice(0, 100)); }

        if (!sent) {
            await bot.sendMessage(q.message.chat.id,
                caption + `\n\n${I.arrow} <a href="${cfg.FOTO.QRIS}">Link QRIS</a>`,
                { parse_mode: "HTML", reply_markup: kb }).catch(() => {});
        }
    } catch (e) { console.log("[USERBOT BUY PICK ERR]", e.message); }
});

router.registerMessage("userbot_await_bukti", async (bot, msg, state, ctx) => {
    try {
        if (!msg.photo) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kirim foto bukti transfer.</b>`, { parse_mode: "HTML" });
        }

        const photo = msg.photo[msg.photo.length - 1];
        const { role, price } = state;

        ctx.clearState(String(msg.from.id));

        try {
            const notifGen = require("./modules/notif-generator");
            let photoUrl = null;
            try {
                const photos = await bot.getUserProfilePhotos(msg.from.id, { limit: 1 });
                if (photos.total_count > 0 && photos.photos[0].length > 0) {
                    const fileId = photos.photos[0][0].file_id;
                    photoUrl = await bot.getFileLink(fileId);
                }
            } catch (e) {}

            await notifGen.sendBuyRoleNotif(bot, cfg, {
                roleName: role.toUpperCase(),
                price: `Rp${price.toLocaleString("id-ID")}`,
                status: "pending",
                username: msg.from.username ? `@${msg.from.username}` : "-",
                fullName: [msg.from.first_name, msg.from.last_name].filter(Boolean).join(" ") || "User",
                userPhotoUrl: photoUrl,
                userId: msg.from.id,
                timestamp: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
            });
        } catch (e) { console.log("[USERBOT BUKTI] notif fail:", e.message); }

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 BUKTI DITERIMA 𖡛</b>\n` +
            `<i>Menunggu konfirmasi admin</i>\n\n` +
            `<blockquote>` +
            `▸ Role <b>→</b> <b>${role.toUpperCase()}</b>\n` +
            `▸ Status <b>→</b> <i>Menunggu acc admin...</i>` +
            `</blockquote>\n\n` +
            `<blockquote>Bakal di-acc dalam 1x24 jam</blockquote>`,
            { parse_mode: "HTML" });

        try {
            await bot.sendPhoto(cfg.OWNER_ID, photo.file_id, {
                caption:
                    `<b>𖡛 BUKTI TRANSFER 𖡛</b>\n\n` +
                    `<blockquote>` +
                    `▸ User ID <b>→</b> <code>${msg.from.id}</code>\n` +
                    `▸ Nama <b>→</b> ${msg.from.first_name || "-"}\n` +
                    `▸ Username <b>→</b> ${msg.from.username ? "@" + msg.from.username : "-"}\n` +
                    `▸ Role <b>→</b> <b>${role.toUpperCase()}</b>\n` +
                    `▸ Harga <b>→</b> <b>Rp${price.toLocaleString("id-ID")}</b>` +
                    `</blockquote>\n\n` +
                    `<b>→ Ketik:</b>\n` +
                    `<code>/accubot ${msg.from.id} ${role}</code>`,
                parse_mode: "HTML"
            });
        } catch (e) { console.log("[USERBOT FORWARD BUKTI ERR]", e.message); }
    } catch (e) { console.log("[USERBOT BUKTI ERR]", e.message); }
});

// ═══════════════════════════════════════════
// 🔥 LOGIN — STEP 1: MINTA API_ID
// ═══════════════════════════════════════════
router.registerCallback("userbot_login", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "userbot_await_api_id", {});

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 LOGIN USERBOT — STEP 1/4 𖡛</b>\n` +
            `<i>Input API_ID dari Telegram lu</i>\n\n` +
            `<blockquote>` +
            `◆ <b>KENAPA PAKE API_ID SENDIRI?</b>\n` +
            `▸ Ga ada rate limit dari bot\n` +
            `▸ Lebih aman (API lu sendiri)\n` +
            `▸ Bisa dipake banyak device\n` +
            `▸ Bot ga nanggung abuse` +
            `</blockquote>\n\n` +
            `<b>📝 Cara dapet API_ID:</b>\n` +
            `<blockquote expandable><b>Instruksi — Klik untuk lihat</b>\n` +
            `1. Buka <a href="https://my.telegram.org/apps">my.telegram.org/apps</a>\n` +
            `2. Login pake nomor Telegram lu\n` +
            `3. Isi form (App title, Short name, Platform)\n` +
            `4. Klik "Create application"\n` +
            `5. Copy <b>App api_id</b> & <b>App api_hash</b>` +
            `</blockquote>\n\n` +
            `<b>→ Kirim API_ID lu sekarang:</b>\n` +
            `<i>Contoh: <code>37192283</code></i>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: `✕ Batal`, callback_data: "userbot_cancel_login", style: "danger" }]] } });
    } catch (e) { console.log("[USERBOT LOGIN ERR]", e.message); }
});

// ═══════════════════════════════════════════
// 🔥 LOGIN — STEP 2: TERIMA API_ID, MINTA API_HASH
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_api_id", async (bot, msg, state, ctx) => {
    try {
        const text = (msg.text || "").trim();
        if (!text) return;

        const v = login.validateApiId(text);
        if (!v.ok) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ API_ID tidak valid</b>\n\n` +
                `<blockquote>${v.error}\n\n` +
                `→ Kirim ulang API_ID (angka doang):</blockquote>`,
                { parse_mode: "HTML" });
        }

        ctx.setState(String(msg.from.id), "userbot_await_api_hash", { apiId: v.value });

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 LOGIN USERBOT — STEP 2/4 𖡛</b>\n` +
            `<i>Input API_HASH</i>\n\n` +
            `<blockquote>` +
            `◆ <b>API_ID TERSIMPAN</b>\n` +
            `▸ API_ID <b>→</b> <code>${v.value}</code> ${I.check}` +
            `</blockquote>\n\n` +
            `<b>→ Kirim API_HASH lu sekarang:</b>\n` +
            `<i>Format: 32 karakter hex (contoh: <code>18e59914ed0b123b1120e4c9a516e43c</code>)</i>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: `✕ Batal`, callback_data: "userbot_cancel_login", style: "danger" }]] } });
    } catch (e) { console.log("[USERBOT API_ID ERR]", e.message); }
});

// ═══════════════════════════════════════════
// 🔥 LOGIN — STEP 3: TERIMA API_HASH, MINTA NOMOR
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_api_hash", async (bot, msg, state, ctx) => {
    try {
        const text = (msg.text || "").trim();
        if (!text) return;

        const v = login.validateApiHash(text);
        if (!v.ok) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ API_HASH tidak valid</b>\n\n` +
                `<blockquote>${v.error}\n\n` +
                `→ Kirim ulang API_HASH:</blockquote>`,
                { parse_mode: "HTML" });
        }

        ctx.setState(String(msg.from.id), "userbot_await_phone_custom", {
            apiId: state.apiId,
            apiHash: v.value
        });

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 LOGIN USERBOT — STEP 3/4 𖡛</b>\n` +
            `<i>Input nomor HP</i>\n\n` +
            `<blockquote>` +
            `◆ <b>API TERSIMPAN</b>\n` +
            `▸ API_ID <b>→</b> <code>${state.apiId}</code> ${I.check}\n` +
            `▸ API_HASH <b>→</b> <code>${v.value.slice(0, 8)}...${v.value.slice(-8)}</code> ${I.check}` +
            `</blockquote>\n\n` +
            `<b>→ Kirim nomor HP Telegram lu:</b>\n` +
            `<i>Format internasional: <code>+6281234567890</code></i>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: `✕ Batal`, callback_data: "userbot_cancel_login", style: "danger" }]] } });
    } catch (e) { console.log("[USERBOT API_HASH ERR]", e.message); }
});

// ═══════════════════════════════════════════
// 🔥 LOGIN — STEP 4: TERIMA NOMOR, KIRIM OTP
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_phone_custom", async (bot, msg, state, ctx) => {
    try {
        const phone = (msg.text || "").trim();
        if (!phone.match(/^\+\d{8,15}$/)) {
            return bot.sendMessage(msg.chat.id,
                `<b>✕ Format nomor salah</b>\n\n` +
                `<blockquote>Gunakan: <code>+6281234567890</code>\n` +
                `(harus ada tanda <code>+</code> di depan)</blockquote>`,
                { parse_mode: "HTML" });
        }

        const { apiId, apiHash } = state;
        ctx.clearState(String(msg.from.id));

        const loading = await bot.sendMessage(msg.chat.id,
            `<b>◉ Mengirim OTP...</b>\n\n` +
            `<blockquote>` +
            `▸ Nomor <b>→</b> <code>${phone}</code>\n` +
            `▸ API_ID <b>→</b> <code>${apiId}</code>\n` +
            `▸ Mode <b>→</b> <b>CUSTOM</b>` +
            `</blockquote>\n\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        // ⚡ PAKE API USER
        const result = await login.startLogin(bot, msg.chat.id, msg.from.id, phone, ctx, {
            apiId,
            apiHash
        });

        if (!result.ok) {
            await safeEdit(bot, msg.chat.id, loading.message_id,
                `<b>✕ Gagal kirim OTP</b>\n\n` +
                `<blockquote>${String(result.error).slice(0, 300)}</blockquote>\n\n` +
                `→ Coba login ulang: <code>/menu → Userbot → Login</code>`,
                { parse_mode: "HTML" });
        } else {
            try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}
        }
    } catch (e) { console.log("[USERBOT PHONE CUSTOM ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA OTP
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_otp", async (bot, msg, state, ctx) => {
    try {
        const otp = (msg.text || "").trim().replace(/\s/g, "");
        if (!otp.match(/^\d{4,6}$/)) {
            return bot.sendMessage(msg.chat.id, `<b>✕ Kode OTP harus 4-6 digit angka.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(String(msg.from.id));

        const loading = await bot.sendMessage(msg.chat.id, `<b>◉ Verifikasi OTP...</b>`, { parse_mode: "HTML" });
        const result = await login.verifyOtp(msg.from.id, otp, bot, msg.chat.id, ctx);
        try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

        if (!result.ok && !result.needPassword) {
            await bot.sendMessage(msg.chat.id,
                `<b>✕ Verifikasi gagal:</b>\n<code>${String(result.error).slice(0, 200)}</code>\n\n` +
                `<blockquote>Ketik /menu → Userbot → Login buat ulang.</blockquote>`,
                { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[USERBOT OTP ERR]", e.message); }
});

// ═══════════════════════════════════════════
// TERIMA 2FA PASSWORD
// ═══════════════════════════════════════════
router.registerMessage("userbot_await_password", async (bot, msg, state, ctx) => {
    try {
        const password = (msg.text || "").trim();
        if (!password) return;

        ctx.clearState(String(msg.from.id));
        try { await bot.deleteMessage(msg.chat.id, msg.message_id); } catch {}

        const loading = await bot.sendMessage(msg.chat.id, `<b>◉ Verifikasi 2FA...</b>`, { parse_mode: "HTML" });
        const result = await login.verifyPassword(msg.from.id, password, bot, msg.chat.id, ctx);
        try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

        if (!result.ok) {
            await bot.sendMessage(msg.chat.id,
                `<b>✕ 2FA salah:</b>\n<code>${String(result.error).slice(0, 200)}</code>\n\n` +
                `<blockquote>Ketik /menu → Userbot → Login buat ulang.</blockquote>`,
                { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[USERBOT PWD ERR]", e.message); }
});

router.registerCallback("userbot_cancel_login", async (bot, q, data, user, ctx) => {
    try {
        login.cancelLogin(user.id);
        ctx.clearState(String(user.id));
        await bot.sendMessage(q.message.chat.id, `<b>✕ Login dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[USERBOT CANCEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// MANAGE SESSION
// ═══════════════════════════════════════════
router.registerCallback("userbot_manage", async (bot, q, data, user, ctx) => {
    try {
        const activeClient = login.getClient(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const currentMode = store.getMode(user.id);
        const sessionData = sessionExists ? store.loadSession(user.id) : null;

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 MANAGE SESSION 𖡛</b>\n` +
            `<i>Kelola userbot session</i>\n\n` +
            `<blockquote>` +
            `▸ Status <b>→</b> ${activeClient ? "<b>Online</b>" : "Offline"}\n` +
            `▸ Session <b>→</b> ${sessionExists ? "Ada" : "Gaada"}\n` +
            `▸ Mode <b>→</b> <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>` +
            (sessionData?.apiId ? `\n▸ API_ID <b>→</b> <code>${sessionData.apiId}</code>` : "") +
            `</blockquote>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: `▸ Logout Userbot`, callback_data: "userbot_logout", style: "danger" }],
                        [{ text: `✕ Kembali`, callback_data: "userbot_main", style: "danger" }]
                    ]
                }
            });
    } catch (e) { console.log("[USERBOT MANAGE ERR]", e.message); }
});

router.registerCallback("userbot_logout", async (bot, q, data, user, ctx) => {
    try {
        await login.stopClient(user.id);
        store.deleteSession(user.id);
        await bot.sendMessage(q.message.chat.id,
            `<b>✓ USERBOT LOGOUT</b>\n\n<blockquote><i>Session lu udah dihapus.</i></blockquote>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[USERBOT LOGOUT ERR]", e.message); }
});

// ═══════════════════════════════════════════
// BACK KE MENU USERBOT
// ═══════════════════════════════════════════
router.registerCallback("userbot_main", async (bot, q, data, user, ctx) => {
    try {
        const userRole = store.getUserRole(user.id);
        const sessionExists = !!store.loadSession(user.id);
        const activeClient = login.getClient(user.id);
        const currentMode = store.getMode(user.id);

        const statusIcon = activeClient ? I.check : (sessionExists ? I.clock : I.cross);
        const statusText = activeClient ? "Online" : (sessionExists ? "Session ada, offline" : "Belum login");

        const caption =
            `<b>𖡛 USERBOT TELEGRAM 𖡛</b>\n` +
            `<i>Auto-forward, build APK, clone profile</i>\n\n` +
            `<blockquote>` +
            `◆ <b>STATUS AKUN</b>\n` +
            `▸ Status <b>→</b> <b>${statusIcon} ${statusText}</b>\n` +
            `▸ Mode <b>→</b> <b>${currentMode === "self" ? "SELF" : "PUBLIC"}</b>\n` +
            `▸ Role <b>→</b> <b>${userRole ? userRole.role.toUpperCase() : "TIDAK ADA"}</b>` +
            `</blockquote>`;

        const kb = [];
        if (!userRole) {
            kb.push([{ text: `▸ Beli Role Ubot`, callback_data: "userbot_buy", style: "success" }]);
        } else if (!activeClient) {
            kb.push([{ text: `▸ Login Telegram`, callback_data: "userbot_login", style: "success" }]);
        } else {
            kb.push([{ text: `▸ Manage Session`, callback_data: "userbot_manage", style: "primary" }]);
        }
        kb.push([{ text: `✕ Kembali`, callback_data: "menu_back", style: "danger" }]);

        try {
            await bot.editMessageText(caption, {
                chat_id: q.message.chat.id,
                message_id: q.message.message_id,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
        } catch (e) {
            if (e.message.includes("message is not modified")) return;
            await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }
    } catch (e) { console.log("[USERBOT MAIN ERR]", e.message); }
});


// KATALOG MODUL USERBOT — kategori dan setiap command dapat dibuka lewat tombol.
router.registerCallback("userbot_catalog", async (bot, q, data, user, ctx) => {
    try {
        const loader = require("./module-loader");
        const categories = loader.getCategoryList();
        const rows = [];
        for (let i = 0; i < categories.length; i += 2) {
            const a = categories[i], b = categories[i + 1];
            const row = [{ text: `${loader.getCategoryEmoji(a)} ${a.toUpperCase()}`, callback_data: `userbot_cat:${a}` }];
            if (b) row.push({ text: `${loader.getCategoryEmoji(b)} ${b.toUpperCase()}`, callback_data: `userbot_cat:${b}` });
            rows.push(row);
        }
        rows.push([{ text: "🔎 Cari modul", callback_data: "userbot_catalog_search" }]);
        rows.push([{ text: "‹ Kembali", callback_data: "userbot_main" }]);
        await bot.sendMessage(q.message.chat.id,
            `<h2>▦ KATALOG FITUR USERBOT</h2><p>Pilih kategori untuk melihat modul yang tersedia. Tombol modul membuka detail perintah dan deskripsinya.</p><p><i>Untuk fitur yang membutuhkan argumen, jalankan command yang ditampilkan bersama argumennya.</i></p>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[UBOT CATALOG]", e.message); }
});

router.registerCallback("userbot_cat", async (bot, q, data, user, ctx) => {
    try {
        const loader = require("./module-loader");
        const category = data.split(":")[1] || "general";
        const mods = loader.getModulesByCategory(category).slice(0, 80);
        const rows = [];
        for (let i = 0; i < mods.length; i += 2) {
            const a = mods[i], b = mods[i + 1];
            const row = [{ text: `/${a.command}`, callback_data: `userbot_mod:${a.command}` }];
            if (b) row.push({ text: `/${b.command}`, callback_data: `userbot_mod:${b.command}` });
            rows.push(row);
        }
        rows.push([{ text: "‹ Kategori", callback_data: "userbot_catalog" }]);
        await bot.sendMessage(q.message.chat.id,
            `<h2>${loader.getCategoryEmoji(category)} ${category.toUpperCase()}</h2><p>${mods.length} modul ditampilkan. Pilih tombol modul untuk melihat fungsi dan cara pakainya.</p>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[UBOT CATEGORY]", e.message); }
});

router.registerCallback("userbot_mod", async (bot, q, data, user, ctx) => {
    try {
        const loader = require("./module-loader");
        const command = data.split(":")[1];
        const mod = loader.MODULES.get(command);
        if (!mod) return bot.sendMessage(q.message.chat.id, "Modul tidak ditemukan atau belum dimuat.");
        const desc = String(mod.description || "Tidak ada deskripsi.").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
        const html = `<h2>▣ MODUL /${command}</h2><p>${desc}</p><hr/><p><b>Perintah:</b> <code>.${command}</code></p><p>Kirim <code>.${command} argumen</code> pada chat tempat userbot aktif bila fitur ini membutuhkan argumen.</p>`;
        await bot.sendMessage(q.message.chat.id, html, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "‹ Kembali ke kategori", callback_data: `userbot_cat:${mod.category || "general"}` }],[{ text: "▦ Katalog", callback_data: "userbot_catalog" }]] } });
    } catch (e) { console.log("[UBOT MODULE DETAIL]", e.message); }
});

router.registerCallback("userbot_catalog_search", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "userbot_catalog_search_await", {});
    await bot.sendMessage(q.message.chat.id, `<b>🔎 CARI MODUL USERBOT</b>\nKirim nama command, kategori, atau kata pada deskripsi.`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "userbot_catalog" }]] } });
});
router.registerMessage("userbot_catalog_search_await", async (bot, msg, state, ctx) => {
    const loader = require("./module-loader");
    const query = String(msg.text || "").trim();
    const found = loader.searchModules(query).slice(0, 50);
    ctx.clearState(String(msg.from.id));
    if (!found.length) return bot.sendMessage(msg.chat.id, "Modul tidak ditemukan.", { reply_markup: { inline_keyboard: [[{ text: "▦ Katalog", callback_data: "userbot_catalog" }]] } });
    const rows = [];
    for (let i = 0; i < found.length; i += 2) {
        const row = [{ text: `/${found[i].command}`, callback_data: `userbot_mod:${found[i].command}` }];
        if (found[i + 1]) row.push({ text: `/${found[i + 1].command}`, callback_data: `userbot_mod:${found[i + 1].command}` });
        rows.push(row);
    }
    rows.push([{ text: "▦ Katalog", callback_data: "userbot_catalog" }]);
    await bot.sendMessage(msg.chat.id, `<h2>🔎 HASIL PENCARIAN</h2><p>Ditemukan ${found.length} modul yang cocok.</p>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
});

module.exports = { ROLE_PRICES, ROLE_BENEFIT };
console.log("[USERBOT MENU] v10 loaded — custom API flow");