// ═══════════════════════════════════════════
// USERBOT INDEX — Entry Point Loader
// v2 — Auto-load semua module userbot
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const path = require("path");
const fs = require("fs");

// ═══ LOAD SEMUA MODULE USERBOT ═══
const loaded = [];
const failed = [];

function safeLoad(file) {
    try {
        require(path.join(__dirname, file));
        loaded.push(file);
        console.log(`[USERBOT INDEX] ✓ ${file}`);
        return true;
    } catch (e) {
        failed.push({
            file,
            error: e.message.split("\n")[0].slice(0, 150)
        });
        console.log(`[USERBOT INDEX] ✕ ${file}: ${e.message.slice(0, 100)}`);
        return false;
    }
}

// ⚡ URUTAN PENTING:
// 1. session-store → init storage (harus pertama)
// 2. login → init login logic (butuh session-store)
// 3. module-loader → load 200+ modules (butuh session-store)
// 4. menu-callback → register handler menu (butuh session-store + login)
safeLoad("./session-store");
safeLoad("./login");
safeLoad("./module-loader");
safeLoad("./menu-callback");

// ═══ SUMMARY ═══
console.log("[USERBOT INDEX] ═══════════════════════════════════");
console.log("[USERBOT INDEX] ✅ Loaded :", loaded.length, "modules");
console.log("[USERBOT INDEX] ❌ Failed :", failed.length, "modules");
console.log("[USERBOT INDEX] ═══════════════════════════════════");

if (failed.length > 0) {
    console.log("[USERBOT INDEX] Failed details:");
    for (const f of failed) {
        console.log(`  ❌ ${f.file}`);
        console.log(`     → ${f.error}`);
    }
}

// ═══ EXPORT ═══
module.exports = {
    loaded,
    failed,
    // Shortcut akses
    login: require("./login"),
    store: require("./session-store"),
    loader: require("./module-loader"),
};

console.log("[USERBOT INDEX] v2 loaded — auto-loader ready");