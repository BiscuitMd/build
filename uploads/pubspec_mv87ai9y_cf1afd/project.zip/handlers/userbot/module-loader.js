const fs = require("fs");
const path = require("path");

const MODULES_DIR = path.join(__dirname, "modules");
const MODULES = new Map();

// Rich payload wrapper: format plain text responses from a command as Telegram HTML.
// Inline keyboards are only supported on the Bot API menu messages; GramJS user-account
// messages cannot attach bot inline keyboards. Preserve messages sent to other targets.
function escapeHtml(value) {
    return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function richTextPayload(value) {
    const text = String(value ?? "");
    // Preserve intentional HTML payloads; otherwise render plain text safely as a rich block.
    if (/<\/?(?:b|strong|i|em|u|s|code|pre|blockquote|a|br)\b/i.test(text)) return text;
    return `<blockquote>${escapeHtml(text).replace(/\r?\n/g, "<br/>")}</blockquote>`;
}
async function withRichOutput(client, originChatId, run) {
    if (!client || typeof client.sendMessage !== "function") return run();
    const original = client.sendMessage;
    client.sendMessage = async function(target, params, ...rest) {
        try {
            const targetId = target && typeof target === "object"
                ? (target.chatId ?? target.channelId ?? target.userId ?? target.id)
                : target;
            const sameChat = targetId != null && String(targetId) === String(originChatId);
            if (sameChat && params && typeof params === "object" && typeof params.message === "string") {
                params = { ...params, message: richTextPayload(params.message), parseMode: params.parseMode || "html" };
            }
        } catch {}
        return original.call(this, target, params, ...rest);
    };
    try { return await run(); }
    finally { client.sendMessage = original; }
}

// ═══ CATEGORY ICON ═══
const CATEGORY_ICON = {
    ai: "◈", download: "▣", fun: "✦", tools: "⚙",
    info: "◉", media: "▤", text: "▥", crypto: "◆",
    osint: "◎", admin: "▲", group: "▦", build: "▧",
    forward: "⇒", general: "▪", userbot: "●",
    music: "♫", panel: "■", security: "⚿",
    monitor: "◉", vault: "◆", session: "●",
    automation: "◇", dev: "◆", finance: "◆",
    archive: "▣", utility: "◆", game: "◆", bot: "▣"
};

function getCategoryEmoji(cat) {
    return CATEGORY_ICON[cat] || "▪";
}

function loadAll() {
    if (!fs.existsSync(MODULES_DIR)) {
        console.log("[UBOT LOADER] folder modules gaada, skip");
        return;
    }

    const files = fs.readdirSync(MODULES_DIR).filter(f =>
        f.endsWith(".js") &&
        !f.startsWith("_") &&
        f !== "notif-generator.js"
    );

    let loaded = 0;
    let failed = 0;

    for (const file of files) {
        try {
            const modPath = path.join(MODULES_DIR, file);
            delete require.cache[require.resolve(modPath)];
            const mod = require(modPath);

            if (mod && mod.command && typeof mod.handler === "function") {
                MODULES.set(mod.command, mod);

                if (Array.isArray(mod.commands)) {
                    for (const c of mod.commands) {
                        if (!MODULES.has(c)) MODULES.set(c, mod);
                    }
                }

                loaded++;
            } else {
                failed++;
            }
        } catch (e) {
            failed++;
            console.log(`[UBOT LOADER] ✕ ${file} error: ${e.message.slice(0, 100)}`);
        }
    }

    console.log(`[UBOT LOADER] ✅ loaded: ${loaded} module | ⚠️ failed: ${failed}`);
    console.log(`[UBOT LOADER] Total module aktif: ${MODULES.size}`);
}

async function execute(userId, client, msg, cmd, args, bot) {
    if (cmd === "build" || cmd.startsWith("build_")) {
        try {
            const build = require("./modules/build");
            if (build && typeof build.handler === "function") {
                await withRichOutput(client, msg.message.chatId, () => build.handler(userId, client, msg, args));
                return true;
            }
        } catch (e) {
            console.log("[UBOT CMD] .build err:", e.message.slice(0, 150));
            try {
                await client.sendMessage(msg.message.chatId, {
                    message: `<b>✕ Error build:</b>\n<code>${e.message.slice(0, 150)}</code>`,
                    parseMode: "html"
                });
            } catch {}
            return true;
        }
    }

    if (cmd === "autofw" || cmd === "addbl" || cmd === "delbl" || cmd === "listbl") {
        try {
            const autofw = require("./modules/autofw");
            if (autofw && typeof autofw.handler === "function") {
                await withRichOutput(client, msg.message.chatId, () => autofw.handler(userId, client, msg, args, bot));
                return true;
            }
        } catch (e) {
            console.log(`[UBOT CMD] .${cmd} err:`, e.message.slice(0, 150));
            try {
                await client.sendMessage(msg.message.chatId, {
                    message: `<b>✕ Error ${cmd}:</b>\n<code>${e.message.slice(0, 150)}</code>`,
                    parseMode: "html"
                });
            } catch {}
            return true;
        }
    }

    if (cmd === "menu" || cmd === "help" || cmd === "h" || cmd.startsWith("menu_")) {
        return false;
    }

    const mod = MODULES.get(cmd);
    if (!mod) return false;

    try {
        await withRichOutput(client, msg.message.chatId, () => mod.handler(userId, client, msg, args, bot));
        return true;
    } catch (e) {
        console.log(`[UBOT CMD] .${cmd} err:`, e.message.slice(0, 150));
        try {
            await client.sendMessage(msg.message.chatId, {
                message: `<b>✕ Error .${cmd}:</b>\n<code>${e.message.slice(0, 150)}</code>`,
                parseMode: "html"
            });
        } catch {}
        return true;
    }
}

function listModules() {
    const result = [];
    const seen = new Set();

    for (const [cmd, mod] of MODULES.entries()) {
        const key = mod.command;
        if (seen.has(key)) continue;
        seen.add(key);

        result.push({
            command: mod.command,
            description: mod.description || "",
            category: mod.category || "general"
        });
    }

    return result;
}

function groupByCategory() {
    const list = listModules();
    const groups = {};
    for (const m of list) {
        const cat = m.category || "general";
        if (!groups[cat]) groups[cat] = [];
        groups[cat].push(m);
    }
    for (const cat in groups) {
        groups[cat].sort((a, b) => a.command.localeCompare(b.command));
    }
    return groups;
}

function getCategoryList() {
    const groups = groupByCategory();
    return Object.keys(groups).sort();
}

function getModulesByCategory(category) {
    const groups = groupByCategory();
    return groups[category] || [];
}

function countModules() {
    return listModules().length;
}

function hasModule(cmd) {
    return MODULES.has(cmd);
}

function searchModules(query) {
    const q = String(query || "").toLowerCase();
    if (!q) return [];

    return listModules().filter(m =>
        m.command.toLowerCase().includes(q) ||
        (m.description || "").toLowerCase().includes(q) ||
        (m.category || "").toLowerCase().includes(q)
    );
}

loadAll();

module.exports = {
    execute,
    listModules,
    groupByCategory,
    getCategoryList,
    getModulesByCategory,
    getCategoryEmoji,
    countModules,
    hasModule,
    searchModules,
    loadAll,
    MODULES,
    MODULES_DIR
};

console.log("[UBOT LOADER] module-loader v5 ready (rich format)");