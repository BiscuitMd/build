module.exports = {
    // Dapetin di: https://my.telegram.org / GAUSAH GANTI KALO LU GATAU BEGO
    API_ID: 37192283,                                 // ← GANTI dengan API_ID lo
    API_HASH: "18e59914ed0b123b1120e4c9a516e43c", // Isi langsung di config.js

    BUILD_SERVERS: {
        1: { name: "Server 1",           scope: "public",  workflow: "flutter-build.yml", repoKey: "GITHUB_2" },
        2: { name: "Server 2",           scope: "public",  workflow: "flutter-build.yml", repoKey: "GITHUB_2" },
        3: { name: "Server 3",           scope: "public",  workflow: "flutter-build.yml", repoKey: "GITHUB_2" },
        4: { name: "Server 4",           scope: "public",  workflow: "flutter-build.yml", repoKey: "GITHUB_2" },
        5: { name: "Server 5 (Owner)",   scope: "owner",   workflow: "flutter-build.yml", repoKey: "GITHUB"   },
        6: { name: "Server 6 (Premium)", scope: "premium", workflow: "flutter-build.yml", repoKey: "GITHUB"   }
    },

    BUILD_QUEUE_MAX: 20,

    // ═══════════════════════════════════════════
    // BOT CONFIG
    // ═══════════════════════════════════════════
    BOT_TOKEN: "8851814221:AAE1sbDpicb5nyGtOvJ0YquCv2y9IGm3xJQ",
    OWNER_ID: "8938118595",
    OWNER_USERNAME: "@biscuitMD",
    GROUP_UPDATE: "https://t.me/biscuitMD",

    MAIN_GROUP_ID: "-1003963880893",

    // Channel tujuan moderasi laporan (bot harus admin dengan izin ban anggota).
    // Ganti dengan @username channel atau ID channel -100... yang benar.
    REPORT_MODERATION_CHANNEL_ID: "@GANTI_USERNAME_CHANNEL",

    APP_MODE: "production",
    MAX_PAIRING: 5,
    TIMEOUT_PAIRING: 30000,

    CREDIT_PER_USE: 1,

    CHANNELS: [
        { name: "Channel 1", url: "https://t.me/Aboutlyd" },
        { name: "Channel 2", url: "https://t.me/testilyd" },
        { name: "Channel 3", url: "https://t.me/monitortesfuncexoid" }
    ],

    NOTIF_CHANNEL: "-1004389804220",
    BUY_ROLE_NOTIF_CHANNEL: "-1004389804220",
    BOT_STORAGE_CHAT_ID: "-1004446331607",
    BOT_STORAGE_USERNAME: "@multifungsibiscuitbot",

    // ═══════════════════════════════════════════
    // PANEL — Legacy
    // ═══════════════════════════════════════════
    PANEL: {
        PLTA: "ISI_PLTA_DI_SINI",
        PLTC: "ISI_PLTC_DI_SINI",
        DOMAIN: "https://minimal-modal-buka-cpanel-by-key.keyganteng.my.id",
        DEFAULT_DAYS: 30,
        DEFAULT_CREDIT: 10,
        ROLE_DEFAULT: "reseller",
        MONITOR_INTERVAL: 5 * 60 * 1000
    },

    PANEL_ILLEGAL: {
        LABEL: "Server 1 (Ilegal)",
        TYPE: "illegal",
        URL: "https://minimal-modal-buka-cpanel-by-key.keyganteng.my.id",
        DOMAIN: "https://minimal-modal-buka-cpanel-by-key.keyganteng.my.id",
        API_KEY: "ptla_LPLxyvJuRX4APGZUKQCioCN2BCRdCuyoUNxLRhTySoK",
        NEST_ID: 5,
        DEFAULT_LOCATION: 1,
        DEFAULT_MEMORY: 1024,
        DEFAULT_DISK: 2048,
        DEFAULT_CPU: 50,
        DEFAULT_DATABASES: 1,
        DEFAULT_BACKUPS: 1,
        DEFAULT_ALLOCATIONS: 0,
        GROUP_LINK: "https://t.me/biscuitMD"
    },

    PANEL_LEGAL: {
        LABEL: "Server 2 (Legal)",
        TYPE: "legal",
        URL: "https://panel2-lu.com",
        DOMAIN: "panel2-lu.com",
        API_KEY: "ptla_ISI_API_KEY_SERVER_2",
        NEST_ID: 5,
        DEFAULT_LOCATION: 1,
        DEFAULT_MEMORY: 1024,
        DEFAULT_DISK: 2048,
        DEFAULT_CPU: 50,
        DEFAULT_DATABASES: 1,
        DEFAULT_BACKUPS: 1,
        DEFAULT_ALLOCATIONS: 0,
        GROUP_LINK: "https://t.me/biscuitMD"
    },

    PANEL_ADP1: {
        LABEL: "ADP 1",
        TYPE: "adp",
        URL: "https://minimal-modal-buka-cpanel-by-key.keyganteng.my.id",
        DOMAIN: "adp1-lu.com",
        API_KEY: "ptla_LPLxyvJuRX4APGZUKQCioCN2BCRdCuyoUNxLRhTySoK",
        NEST_ID: 5,
        DEFAULT_LOCATION: 1,
        DEFAULT_MEMORY: 1024,
        DEFAULT_DISK: 2048,
        DEFAULT_CPU: 50,
        DEFAULT_DATABASES: 1,
        DEFAULT_BACKUPS: 1,
        DEFAULT_ALLOCATIONS: 0,
        GROUP_LINK: "https://t.me/biscuitMD"
    },

    PANEL_ADP2: {
        LABEL: "ADP 2",
        TYPE: "adp",
        URL: "https://adp2-lu.com",
        DOMAIN: "adp2-lu.com",
        API_KEY: "ptla_ISI_API_KEY_ADP_2",
        NEST_ID: 5,
        DEFAULT_LOCATION: 1,
        DEFAULT_MEMORY: 1024,
        DEFAULT_DISK: 2048,
        DEFAULT_CPU: 50,
        DEFAULT_DATABASES: 1,
        DEFAULT_BACKUPS: 1,
        DEFAULT_ALLOCATIONS: 0,
        GROUP_LINK: "https://t.me/biscuitMD"
    },

    // ═══════════════════════════════════════════
    // ROLE SYSTEM
    // ═══════════════════════════════════════════
    HARGA_ROLE: {
        illegal: {
            reseller: 1000,
            admin: 2000,
            owner: 3000,
            partner: 4000,
            tangankanann: 5000,
            ceo: 6000,
            developer: 10000
        },
        legal: {
            reseller: 10000,
            admin: 25000,
            owner: 40000,
            partner: 55000,
            tangankanann: 70000,
            ceo: 85000,
            developer: 100000
        }
    },

    ROLE_BENEFIT: {
        reseller: "Buat panel + akses menu dasar",
        admin: "Semua benefit Reseller + add reseller + CADP",
        owner: "Semua benefit Admin + add admin",
        partner: "Semua benefit Owner + add owner",
        tangankanann: "Semua benefit Partner + add partner",
        ceo: "Semua benefit Tangan Kanan + add tangan kanan + delete offline server",
        developer: "SEMUA AKSES + add semua role + delete offline + monitoring"
    },

    // ═══════════════════════════════════════════
    // EGGS — Fallback
    // ═══════════════════════════════════════════
    EGG_15: [
        { id: "nodejs_18", name: "Node.js 18", egg_id: 1, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_18", startup: "npm start", category: "nodejs" },
        { id: "nodejs_20", name: "Node.js 20", egg_id: 2, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_20", startup: "node index.js", category: "nodejs" },
        { id: "nodejs_22", name: "Node.js 22", egg_id: 3, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nodejs_22", startup: "node index.js", category: "nodejs" },
        { id: "python_310", name: "Python 3.10", egg_id: 4, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.10", startup: "python main.py", category: "python" },
        { id: "python_311", name: "Python 3.11", egg_id: 5, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.11", startup: "python main.py", category: "python" },
        { id: "python_312", name: "Python 3.12", egg_id: 6, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:python_3.12", startup: "python main.py", category: "python" },
        { id: "minecraft_java", name: "Minecraft Java", egg_id: 7, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}", category: "minecraft" },
        { id: "minecraft_paper", name: "Minecraft PaperMC", egg_id: 8, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}", category: "minecraft" },
        { id: "minecraft_bedrock", name: "Minecraft Bedrock", egg_id: 9, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:debian", startup: "./bedrock_server", category: "minecraft" },
        { id: "ubuntu_2204", name: "Ubuntu 22.04", egg_id: 10, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:ubuntu", startup: "bash", category: "os" },
        { id: "debian_12", name: "Debian 12", egg_id: 11, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:debian", startup: "bash", category: "os" },
        { id: "alpine", name: "Alpine", egg_id: 12, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:alpine", startup: "sh", category: "os" },
        { id: "java_17", name: "Java 17", egg_id: 13, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:java_17", startup: "java -jar {{SERVER_JARFILE}}", category: "java" },
        { id: "golang", name: "Golang", egg_id: 14, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:go", startup: "./main", category: "golang" },
        { id: "nginx", name: "Nginx", egg_id: 15, nest_id: 1, docker_image: "ghcr.io/parkervcp/yolks:nginx", startup: "nginx -g 'daemon off;'", category: "web" }
    ],

    // ═══════════════════════════════════════════
    // ALLOCATION & RAM
    // ═══════════════════════════════════════════
    ALLOCATION_1: {
        location_id: 1,
        default_ip: "0.0.0.0",
        default_port: 25565,
        additional_ports: 5,
        memory_min: 512,
        memory_max: 10240,
        disk_min: 1024,
        disk_max: 51200,
        cpu_min: 10,
        cpu_max: 100,
        databases: 1,
        backups: 3,
        allocations: 3
    },

    RAM_OPTIONS: {
        nodejs: ["512MB", "1GB", "2GB", "3GB", "4GB", "5GB", "8GB", "Unli"],
        python: ["512MB", "1GB", "2GB", "3GB", "4GB", "5GB", "8GB", "Unli"],
        minecraft: ["2GB", "4GB", "6GB", "8GB", "12GB", "16GB", "Unli"],
        os: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        java: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        golang: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"],
        web: ["512MB", "1GB", "2GB", "4GB", "8GB", "Unli"]
    },

    // ═══════════════════════════════════════════
    // ⚡ AI — PROVIDER KEYS
    // ═══════════════════════════════════════════
    AI: {
        GROK_KEY: "",
        GROQ_KEY: "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",
        GEMINI_KEY: "",
        CEREBRAS_KEY: "",
        OPENROUTER_KEY: "",
        DEEPINFRA_KEY: "",
        HF_KEY: "",
        MAX_MEMORY: 15,
        TEMPERATURE: 0.85
    },

    // ═══════════════════════════════════════════
    // API KEYS — OTHER SERVICES
    // ═══════════════════════════════════════════
    API_KEYS: {
        DEEZER: "",
        OPENWEATHER: "",
        SPOTIFY_CLIENT_ID: "",
        SPOTIFY_CLIENT_SECRET: "",
        SPOTIFY_ACCESS_TOKEN: "",
        YOUTUBE: "",
        OPENAI: "",
        REPLICATE: "",
        BETABOTZ: "Btz-Xx9CJ",
        VERCEL_TOKEN: "",
        NETFLIX_TOKEN: ""
    },

    VERCEL: {
        TOKEN: "",
        TEAM_ID: "",
        PROJECT_NAME_PREFIX: "spartax-deploy"
    },

    NETFLIX: {
        TOKEN: "",
        API_URL: "https://api.netflix-deploy.example.com",
        TEAM_ID: "",
        PROJECT_NAME_PREFIX: "spartax-nf"
    },

    API_ENDPOINTS: {
        WEATHER: "https://api.open-meteo.com/v1/forecast",
        GEO: "https://geocoding-api.open-meteo.com/v1/search",
        PRAYER: "https://api.aladhan.com/v1/timingsByCity",
        DEEZER: "https://api.deezer.com/search",
        LYRICS: "https://api.lyrics.ovh/v1",
        TIKTOK: "https://tikwm.com/api/",
        BRAT: "https://api.siputzx.my.id/api/m/brat",
        ANIME: "https://api.siputzx.my.id/api/ai/animediffusion",
        NGL: "https://ngl.link/api/submit",
        INSTAGRAM: "https://api.instagram.com/oembed/",
        YOUTUBE_OEMBED: "https://www.youtube.com/oembed"
    },

    // ═══════════════════════════════════════════
    // FOTO / IMAGE URLs
    // ═══════════════════════════════════════════
    FOTO: {
        MENU: "https://files.catbox.moe/k9sxvm.png",
        // Static banner image: menu caption and buttons stay on one message.
        MENU_VIDEO: "",
        TQTO: "https://files.catbox.moe/k9sxvm.png",
        ADD_SENDER: "https://files.catbox.moe/k9sxvm.png",
        CLEAR_SENDER: "https://files.catbox.moe/k9sxvm.png",
        TESFUNC: "https://files.catbox.moe/k9sxvm.png",
        BUY_CREDIT: "https://files.catbox.moe/k9sxvm.png",
        BUY_PREMIUM: "https://files.catbox.moe/k9sxvm.png",
        REPORT: "https://files.catbox.moe/k9sxvm.png",
        CHATDEV: "https://files.catbox.moe/k9sxvm.png",
        BUY_SCRIPT: "https://files.catbox.moe/k9sxvm.png",
        DEVELOPER: "https://files.catbox.moe/k9sxvm.png",
        PREMIUM_MENU: "https://files.catbox.moe/k9sxvm.png",
        BROADCAST: "https://files.catbox.moe/k9sxvm.png",
        QRIS: "https://files.catbox.moe/d272b6.jpeg",
        CEKERROR: "https://files.catbox.moe/k9sxvm.png",
        DEPLOY: "https://files.catbox.moe/k9sxvm.png",
        TOOLS: "https://files.catbox.moe/k9sxvm.png",
        MUSIC: "https://files.catbox.moe/k9sxvm.png",
        GUARD: "https://files.catbox.moe/k9sxvm.png",
        PANEL: "https://files.catbox.moe/k9sxvm.png",
        MONITOR: "https://files.catbox.moe/k9sxvm.png",
        PROMPT_BUILDER: "https://files.catbox.moe/k9sxvm.png",
        PROMPT_NOTIF: "https://files.catbox.moe/k9sxvm.png"
    },

    // ═══════════════════════════════════════════
    // HARGA
    // ═══════════════════════════════════════════
    HARGA: {
        CREDIT_PER_1: 100,
        MAX_CREDIT: 500,
        PREMIUM: 10000,
        SCRIPT_NO_UP: 10000,
        SCRIPT_FULL_UP: 25000
    },

    BAN_DURASI: {
        "1jam": 60 * 60 * 1000,
        "1hari": 24 * 60 * 60 * 1000,
        "1bulan": 30 * 24 * 60 * 60 * 1000,
        "1tahun": 365 * 24 * 60 * 60 * 1000
    },

    REDEEM_MAX_CREDIT: 500,
    DEFAULT_CREDIT: 5,
    DEFAULT_ROLE: "free",

    // ═══════════════════════════════════════════
    // GITHUB REPO 1 — buat server 5 & 6
    // ═══════════════════════════════════════════
    GITHUB: {
        TOKEN: "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",
        USERNAME: "BiscuitMd",
        REPO: "build",
        BRANCH: "main",
        WORKFLOW_FLUTTER: "flutter-build.yml",
        WORKFLOW_NATIVE: "native-build.yml",
        WORKFLOW_WEB2APP: "web-to-app.yml"
    },

    // ═══════════════════════════════════════════
    // ⚡ GITHUB REPO 2 — buat server 1-4
    // ═══════════════════════════════════════════
    GITHUB_2: {
        TOKEN: "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",
        USERNAME: "BiscuitMd",
        REPO: "build2",
        BRANCH: "main",
        WORKFLOW_FLUTTER: "flutter-build.yml",
        WORKFLOW_NATIVE: "native-build.yml",
        WORKFLOW_WEB2APP: "web-to-app.yml"
    },

    BUILD_LOG_CHANNEL: "-1004389804220",
    BUILD_POLL_INTERVAL: 15000,
    BUILD_MAX_WAIT_MS: 1800000,
    BUILD_TMP_DIR: "tmp_build",

    // ═══════════════════════════════════════════
    // ORDER
    // ═══════════════════════════════════════════
    ORDER: {
        QRIS_IMAGE: "https://files.catbox.moe/d272b6.jpeg",
        QRIS_MERCHANT: "LYDIA STOEE",
        QRIS_NOTE: "Scan QRIS, transfer sesuai nominal, kirim bukti ke sini",
        ORDER_CHANNEL: "-1004389804220",
        GROUP_LINK: "https://t.me/biscuitMD",
        APPROVAL_TIMEOUT_MS: 24 * 60 * 60 * 1000,
        IMG_WIDTH: 900,
        IMG_HEIGHT: 1200
    },

    ORDER_HARGA: {
        admin_panel_legal: 25000,
        admin_panel_ilegal: 2000,
        panel_legal: {
            "1GB": 1000, "2GB": 2000, "3GB": 3000, "4GB": 4000, "5GB": 5000,
            "6GB": 6000, "7GB": 7000, "8GB": 8000, "9GB": 9000, "10GB": 10000,
            "UNLIMITED": 12000
        },
        panel_ilegal: {
            "1GB": 500, "2GB": 1000, "3GB": 1500, "4GB": 2000, "5GB": 2500,
            "6GB": 3000, "7GB": 3500, "8GB": 4000, "9GB": 4500, "10GB": 5000,
            "UNLIMITED": 6000
        }
    },

    // ═══════════════════════════════════════════
    // SCRIPT PACKAGES
    // ═══════════════════════════════════════════
    SCRIPT: {
        no_update: {
            label: "Script No Update",
            harga: 10000,
            files: [],
            groupLink: null,
            desc: "File script doang. Tanpa update, tanpa grup."
        },
        full_update: {
            label: "Script Full Update",
            harga: 25000,
            files: [],
            groupLink: "https://t.me/+GROUP_UPDATE_ID",
            desc: "Script + update gratis + grup update."
        },
        full_update_no_enc: {
            label: "Script Full Update + No Enc",
            harga: 35000,
            files: [],
            groupLink: "https://t.me/+GROUP_NOENC_ID",
            desc: "Script no encrypt + grup eksklusif + update lifetime."
        }
    }
};