const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");

function isOwner(ctx, id) { return ctx.db.isOwner(id); }

const loginStates = new Map();

// ═══════════════════════════════════════════
// MENU OWNER
// ═══════════════════════════════════════════
router.registerCallback("menu_owner", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) {
            return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true }).catch(() => {});
        }

        const sessionFile = path.join(__dirname, "..", "user-session.txt");
        const hasSession = fs.existsSync(sessionFile);
        const sessionStatus = hasSession ? "✅ Aktif" : "❌ Belum login";

        const caption =
            `<b>▸ MENU OWNER</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Selamat datang Owner\n` +
            `▸ <b>User Session:</b> ${sessionStatus}\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        const kb = [
            [
                { text: "🔐 Login User Session", callback_data: "owner_login_session", style: "success" },
                { text: "🚪 Logout Session", callback_data: "owner_logout_session", style: "danger" }
            ],
            [
                { text: "▸ Add Credit", callback_data: "dev_addcredit", style: "success" },
                { text: "▸ Add Premium", callback_data: "dev_addpremium", style: "success" }
            ],
            [
                { text: "▸ Add Script", callback_data: "dev_addscript", style: "primary" },
                { text: "▸ Create Redeem", callback_data: "dev_createredeem", style: "primary" }
            ],
            [
                { text: "▸ Ban User", callback_data: "dev_banuser", style: "success" },
                { text: "▸ Unban User", callback_data: "dev_unbanuser", style: "success" }
            ],
            [
                { text: "▸ Add Fitur", callback_data: "dev_addfitur", style: "primary" },
                { text: "▸ Del Fitur", callback_data: "dev_delfitur", style: "primary" }
            ],
            [
                { text: "▸ Add Bot", callback_data: "dev_addbot", style: "success" },
                { text: "▸ Del Bot", callback_data: "dev_delbot", style: "success" }
            ],
            [
                { text: "▸ Del Credit", callback_data: "dev_delcredit", style: "primary" },
                { text: "▸ Del Premium", callback_data: "dev_delpremium", style: "primary" }
            ],
            [
                { text: "▸ Del Redeem", callback_data: "dev_delredeem", style: "success" }
            ],
            [
                { text: "▸ Broadcast", callback_data: "dev_broadcast", style: "primary" }
            ],
            [
                { text: "✕ Tutup", callback_data: "menu_close", style: "danger" }
            ]
        ];

        await bot.sendMessage(q.message.chat.id, caption, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[MENU OWNER ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// LOGIN USER SESSION — START
// ═══════════════════════════════════════════
router.registerCallback("owner_login_session", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) {
            return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true }).catch(() => {});
        }

        await bot.answerCallbackQuery(q.id).catch(() => {});

        const chatId = q.message.chat.id;
        const userId = String(user.id);

        if (!cfg.API_ID || !cfg.API_HASH) {
            return bot.sendMessage(chatId,
                `<b>✕ API_ID / API_HASH belum di-set</b>\n\n` +
                `<i>Buka config.js, isi:</i>\n` +
                `▸ API_ID: <code>12345678</code>\n` +
                `▸ API_HASH: <code>abcdef...</code>\n\n` +
                `<i>Dapetin di: https://my.telegram.org</i>`,
                { parse_mode: "HTML" });
        }

        // Clean old state
        const oldState = loginStates.get(userId);
        if (oldState && oldState.client) {
            try { await oldState.client.disconnect(); } catch {}
        }

        const state = {
            step: "WAITING_PHONE",
            client: null,
            phoneNumber: null,
            phoneCodeHash: null,
            processedMessages: new Set(),
            _otpResolved: false,
            _pwdResolved: false,
            cancelled: false,
            _t: Date.now()
        };
        loginStates.set(userId, state);

        await bot.sendMessage(chatId,
            `<b>🔐 LOGIN USER SESSION — Step 1/3</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Masukin <b>nomor HP</b> lo yang terdaftar di Telegram.\n\n` +
            `<b>Format:</b> <code>+628123456789</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Ketik /cancel buat batal.</i>`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "owner_cancel_login", style: "danger" }]] }
            });
    } catch (e) {
        console.log("[OWNER LOGIN START ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// CANCEL LOGIN
// ═══════════════════════════════════════════
router.registerCallback("owner_cancel_login", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) return;
        await bot.answerCallbackQuery(q.id).catch(() => {});

        const userId = String(user.id);
        const state = loginStates.get(userId);
        if (state) {
            state.cancelled = true;
            if (state.client) try { await state.client.disconnect(); } catch {}
        }
        loginStates.delete(userId);

        await bot.sendMessage(q.message.chat.id, `<b>✕ Login dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) {}
});

// ═══════════════════════════════════════════
// LOGOUT SESSION
// ═══════════════════════════════════════════
router.registerCallback("owner_logout_session", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) {
            return bot.answerCallbackQuery(q.id, { text: "✕ Owner only!", show_alert: true }).catch(() => {});
        }

        const sessionFile = path.join(__dirname, "..", "user-session.txt");
        if (!fs.existsSync(sessionFile)) {
            return bot.answerCallbackQuery(q.id, { text: "ℹ️ Belum ada session", show_alert: true }).catch(() => {});
        }

        await bot.answerCallbackQuery(q.id).catch(() => {});
        await bot.sendMessage(q.message.chat.id,
            `<b>⚠️ KONFIRMASI LOGOUT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Yakin mau logout?\n\n` +
            `▸ Session bakal dihapus\n` +
            `▸ Bot gak bisa download file >20MB\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "✅ Ya, Logout", callback_data: "owner_logout_confirm", style: "danger" },
                            { text: "✕ Batal", callback_data: "owner_logout_cancel", style: "primary" }
                        ]
                    ]
                }
            });
    } catch (e) {}
});

router.registerCallback("owner_logout_confirm", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) return;
        await bot.answerCallbackQuery(q.id).catch(() => {});

        const sessionFile = path.join(__dirname, "..", "user-session.txt");
        try { fs.unlinkSync(sessionFile); } catch {}

        // Destroy current client
        try {
            const gramjsDownloader = require("../libs/gramjs-downloader");
            await gramjsDownloader.destroy();
        } catch {}

        await bot.sendMessage(q.message.chat.id,
            `<b>✅ Logout berhasil</b>\n\n` +
            `<i>Session dihapus. Bot pakai Bot API (max 20MB).</i>`,
            { parse_mode: "HTML" });
    } catch (e) {}
});

router.registerCallback("owner_logout_cancel", async (bot, q, data, user, ctx) => {
    try {
        if (!isOwner(ctx, user.id)) return;
        await bot.answerCallbackQuery(q.id).catch(() => {});
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) {}
});

// ═══════════════════════════════════════════
// HANDLE MESSAGE — LOGIN FLOW
// ═══════════════════════════════════════════
function isInLoginFlow(userId) {
    return loginStates.has(String(userId));
}

async function handleLoginMessage(bot, msg, ctx) {
    const userId = String(msg.from.id);
    const chatId = msg.chat.id;
    const text = (msg.text || "").trim();

    if (!isOwner(ctx, msg.from.id)) return false;

    const state = loginStates.get(userId);
    if (!state) return false;

    // Anti duplikat
    if (state.processedMessages && state.processedMessages.has(msg.message_id)) return true;
    if (!state.processedMessages) state.processedMessages = new Set();
    state.processedMessages.add(msg.message_id);
    if (state.processedMessages.size > 50) {
        state.processedMessages = new Set(Array.from(state.processedMessages).slice(-25));
    }

    console.log(`[LOGIN FLOW] User ${userId} step=${state.step} text="${text.slice(0, 30)}"`);

    // CANCEL
    if (text === "/cancel") {
        state.cancelled = true;
        if (state.client) try { await state.client.disconnect(); } catch {}
        loginStates.delete(userId);
        await bot.sendMessage(chatId, `<b>✕ Login dibatalkan.</b>`, { parse_mode: "HTML" });
        return true;
    }

    // ═══════════════════════════════════════════
    // STEP 1: NOMOR HP
    // ═══════════════════════════════════════════
    if (state.step === "WAITING_PHONE") {
        const cleanPhone = text.replace(/\s/g, "");
        if (!/^\+\d{10,15}$/.test(cleanPhone)) {
            await bot.sendMessage(chatId,
                `<b>✕ Format nomor salah</b>\n\n` +
                `<i>Harus format internasional:</i>\n` +
                `▸ <code>+628123456789</code>`,
                { parse_mode: "HTML" });
            return true;
        }

        state.phoneNumber = cleanPhone;
        state.step = "PROCESSING_PHONE";
        loginStates.set(userId, state);

        await bot.sendMessage(chatId,
            `<b>⏳ Mengirim OTP...</b>\n\n` +
            `<i>Mohon tunggu 5-15 detik.</i>`,
            { parse_mode: "HTML" });

        try {
            const { TelegramClient } = require("telegram");
            const { StringSession } = require("telegram/sessions");
            const { Api } = require("telegram");

            console.log("[LOGIN FLOW] Init TelegramClient...");
            const client = new TelegramClient(
                new StringSession(""),
                parseInt(cfg.API_ID),
                cfg.API_HASH,
                {
                    connectionRetries: 20,
                    useWSS: false,
                    autoReconnect: true,
                    retryDelay: 1000,
                    timeout: 60,
                    requestRetries: 10,
                    floodSleepThreshold: 0
                }
            );

            console.log("[LOGIN FLOW] Connecting...");
            await client.connect();

            try {
                await client.getMe();
                console.log("[LOGIN FLOW] Connected, DC:", client.session.dcId);
            } catch (e) {
                console.log("[LOGIN FLOW] getMe warn:", e.message);
            }

            console.log("[LOGIN FLOW] Send code (raw MTProto)...");

            const result = await client.invoke(
                new Api.auth.SendCode({
                    phoneNumber: cleanPhone,
                    apiId: parseInt(cfg.API_ID),
                    apiHash: cfg.API_HASH,
                    settings: new Api.CodeSettings({
                        allowFlashcall: false,
                        currentNumber: false,
                        allowAppHash: false,
                        allowMissedCall: false
                    })
                })
            );

            console.log("[LOGIN FLOW] ✅ OTP sent. Hash:", result.phoneCodeHash.slice(0, 20) + "...");

            state.client = client;
            state.phoneCodeHash = result.phoneCodeHash;
            state.step = "WAITING_OTP";
            state._t = Date.now();
            loginStates.set(userId, state);

            // Jeda 2 detik biar server sync
            await new Promise(r => setTimeout(r, 2000));

            await bot.sendMessage(chatId,
                `<b>🔐 LOGIN USER SESSION — Step 2/3</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `✅ OTP dikirim ke Telegram lo!\n\n` +
                `Masukin <b>kode OTP</b> (5-6 digit).\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `📌 <b>CARA MASUKIN OTP:</b>\n` +
                `<blockquote>` +
                `▸ Ketik langsung: <code>12345</code>\n` +
                `▸ Atau pakai spasi: <code>1 2 3 4 5</code>\n` +
                `▸ Atau pakai strip: <code>1-2-3-4-5</code>\n` +
                `▸ Bot otomatis bersihin spasi/strip\n` +
                `▸ Yang penting <b>angka 5-6 digit</b>\n` +
                `</blockquote>\n\n` +
                `<i>Kirim SEKALI aja, tunggu bot respon.</i>\n` +
                `<i>Ketik /cancel buat batal.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "owner_cancel_login", style: "danger" }]] }
                });
            return true;
        } catch (e) {
            console.log("[LOGIN FLOW ERR phone]", e.message);
            state.step = "WAITING_PHONE";
            loginStates.set(userId, state);

            let errMsg = e.message || String(e);
            if (errMsg.includes("PHONE_NUMBER_INVALID")) errMsg = "Nomor HP salah / gak valid";
            if (errMsg.includes("FLOOD_WAIT")) errMsg = "Kena limit Telegram. Tunggu beberapa menit.";
            if (errMsg.includes("API_ID_INVALID")) errMsg = "API_ID/API_HASH salah";

            await bot.sendMessage(chatId,
                `<b>✕ Gagal kirim OTP</b>\n\n<code>${errMsg.slice(0, 200)}</code>\n\n` +
                `<i>Kirim nomor HP lagi.</i>`,
                { parse_mode: "HTML" });
            return true;
        }
    }

    // ═══════════════════════════════════════════
    // STEP 2: OTP
    // ═══════════════════════════════════════════
    if (state.step === "WAITING_OTP") {
        if (state._otpResolved) {
            console.log("[LOGIN FLOW] OTP udah resolved, skip");
            return true;
        }

        // ⚡ SANITASI OTP — hapus spasi, strip, karakter aneh
        const cleanOtp = text
            .replace(/\s/g, "")           // hapus semua spasi
            .replace(/[^\d]/g, "")         // hapus semua non-digit
            .trim();

        console.log(`[LOGIN FLOW] OTP input: "${text}" → clean: "${cleanOtp}" (length: ${cleanOtp.length})`);

        if (!/^\d{5,6}$/.test(cleanOtp)) {
            await bot.sendMessage(chatId,
                `<b>✕ OTP harus angka 5-6 digit</b>\n\n` +
                `▸ <b>Yang lo kirim:</b> <code>${text}</code>\n` +
                `▸ <b>Setelah dibersihin:</b> <code>${cleanOtp}</code>\n` +
                `▸ <b>Panjang:</b> ${cleanOtp.length} digit\n\n` +
                `<i>Contoh yang bener:</i>\n` +
                `▸ <code>12345</code>\n` +
                `▸ <code>1 2 3 4 5</code>\n` +
                `▸ <code>1-2-3-4-5</code>`,
                { parse_mode: "HTML" });
            return true;
        }

        state._otpResolved = true;
        state.step = "PROCESSING_OTP";
        state._t = Date.now();
        loginStates.set(userId, state);

        const client = state.client;

        await bot.sendMessage(chatId,
            `<b>⏳ Memverifikasi OTP...</b>\n\n` +
            `<i>Mohon tunggu 5-10 detik.</i>`,
            { parse_mode: "HTML" });

        // RETRY LOGIC 3x
        let lastErr = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                console.log(`[LOGIN FLOW] SignIn attempt ${attempt}/3...`);
                const { Api } = require("telegram");

                await client.invoke(
                    new Api.auth.SignIn({
                        phoneNumber: state.phoneNumber,
                        phoneCodeHash: state.phoneCodeHash,
                        phoneCode: cleanOtp
                    })
                );

                console.log("[LOGIN FLOW] ✅ SignIn OK");
                lastErr = null;
                break;
            } catch (e) {
                lastErr = e;
                const msg = e.message || "";

                if (msg.includes("SESSION_PASSWORD_NEEDED")) break;
                if (msg.includes("PHONE_CODE_INVALID")) break;
                if (msg.includes("PHONE_CODE_EXPIRED")) break;

                console.log(`[LOGIN FLOW] SignIn attempt ${attempt} FAIL:`, msg);

                if (attempt < 3) {
                    console.log("[LOGIN FLOW] Retry in 3 sec...");
                    await new Promise(r => setTimeout(r, 3000));
                }
            }
        }

        // HANDLE RESULT
        if (!lastErr) {
            // SUKSES
            const session = client.session.save();
            const sessionFile = path.join(__dirname, "..", "user-session.txt");
            fs.writeFileSync(sessionFile, session, "utf8");

            let meName = "";
            try {
                const me = await client.getMe();
                meName = me.firstName || me.username || me.id;
            } catch {}

            try { await client.disconnect(); } catch {}
            loginStates.delete(userId);

            // ⚡ AUTO RELOAD SESSION
            try {
                const gramjsDownloader = require("../libs/gramjs-downloader");
                await gramjsDownloader.reloadSession();
                console.log("[OWNER] ✅ Session auto-reloaded");
            } catch (e) {
                console.log("[OWNER] reloadSession err:", e.message);
            }

            await bot.sendMessage(chatId,
                `<b>✅ LOGIN USER SESSION BERHASIL</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Login sebagai: <b>${meName}</b>\n` +
                `▸ Session tersimpen: <code>user-session.txt</code>\n` +
                `▸ Ukuran file maksimal: <b>2 GB</b>\n` +
                `▸ Status: <b>Auto-reloaded</b> ✅\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Kamu bisa langsung build sekarang. Ga perlu restart bot.</i>`,
                { parse_mode: "HTML" });
            return true;
        }

        let errMsg = lastErr.message || String(lastErr);
        console.log("[LOGIN FLOW ERR otp]", errMsg);

        // 2FA
        if (errMsg.includes("SESSION_PASSWORD_NEEDED")) {
            state.step = "WAITING_2FA";
            state._t = Date.now();
            loginStates.set(userId, state);

            await bot.sendMessage(chatId,
                `<b>🔐 LOGIN USER SESSION — Step 3/3</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `Akun lo punya <b>2FA</b> aktif.\n\n` +
                `Masukin <b>password 2FA</b> lo.\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Ketik /cancel buat batal.</i>`,
                { parse_mode: "HTML" });
            return true;
        }

        if (errMsg.includes("PHONE_CODE_EXPIRED")) {
            try { await client.disconnect(); } catch {}
            loginStates.delete(userId);

            await bot.sendMessage(chatId,
                `<b>✕ OTP Expired</b>\n\n` +
                `<i>Kode OTP kadaluarsa. Klik Login User Session lagi buat coba ulang.</i>`,
                { parse_mode: "HTML" });
            return true;
        }

        if (errMsg.includes("PHONE_CODE_INVALID")) errMsg = "OTP salah";

        state.step = "WAITING_OTP";
        state._otpResolved = false;
        loginStates.set(userId, state);

        await bot.sendMessage(chatId,
            `<b>✕ Gagal verifikasi</b>\n\n<code>${errMsg.slice(0, 200)}</code>\n\n` +
            `<i>Coba kirim OTP lagi, atau /cancel buat batal.</i>`,
            { parse_mode: "HTML" });
        return true;
    }

    // ═══════════════════════════════════════════
    // STEP 3: 2FA
    // ═══════════════════════════════════════════
    if (state.step === "WAITING_2FA") {
        if (state._pwdResolved) return true;

        state._pwdResolved = true;
        state.step = "PROCESSING_2FA";
        loginStates.set(userId, state);

        const client = state.client;

        await bot.sendMessage(chatId, `<b>⏳ Memverifikasi 2FA...</b>`, { parse_mode: "HTML" });

        try {
            console.log("[LOGIN FLOW] Check 2FA...");
            const { Api } = require("telegram");
            const { computeCheck } = require("telegram/Password");

            const pwd = await client.invoke(new Api.account.GetPassword());
            const check = await computeCheck(pwd, text);

            await client.invoke(new Api.auth.CheckPassword({ password: check }));

            console.log("[LOGIN FLOW] ✅ 2FA OK");

            const session = client.session.save();
            const sessionFile = path.join(__dirname, "..", "user-session.txt");
            fs.writeFileSync(sessionFile, session, "utf8");

            let meName = "";
            try {
                const me = await client.getMe();
                meName = me.firstName || me.username || me.id;
            } catch {}

            try { await client.disconnect(); } catch {}
            loginStates.delete(userId);

            // ⚡ AUTO RELOAD SESSION
            try {
                const gramjsDownloader = require("../libs/gramjs-downloader");
                await gramjsDownloader.reloadSession();
                console.log("[OWNER] ✅ Session auto-reloaded");
            } catch (e) {
                console.log("[OWNER] reloadSession err:", e.message);
            }

            await bot.sendMessage(chatId,
                `<b>✅ LOGIN USER SESSION BERHASIL</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Login sebagai: <b>${meName}</b>\n` +
                `▸ Session tersimpen: <code>user-session.txt</code>\n` +
                `▸ Ukuran file maksimal: <b>2 GB</b>\n` +
                `▸ Status: <b>Auto-reloaded</b> ✅\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Kamu bisa langsung build sekarang. Ga perlu restart bot.</i>`,
                { parse_mode: "HTML" });
            return true;
        } catch (e) {
            let errMsg = e.message || String(e);
            console.log("[LOGIN FLOW ERR 2fa]", errMsg);
            if (errMsg.includes("PASSWORD_HASH_INVALID")) errMsg = "Password 2FA salah";

            state.step = "WAITING_2FA";
            state._pwdResolved = false;
            loginStates.set(userId, state);

            await bot.sendMessage(chatId,
                `<b>✕ Gagal verifikasi 2FA</b>\n\n<code>${errMsg.slice(0, 200)}</code>\n\n` +
                `<i>Coba kirim password lagi, atau /cancel buat batal.</i>`,
                { parse_mode: "HTML" });
            return true;
        }
    }

    if (state.step === "PROCESSING_PHONE" || state.step === "PROCESSING_OTP" || state.step === "PROCESSING_2FA") {
        console.log("[LOGIN FLOW] Processing, skip input");
        return true;
    }

    return false;
}

module.exports = {
    isInLoginFlow,
    handleLoginMessage,
    loginStates
};