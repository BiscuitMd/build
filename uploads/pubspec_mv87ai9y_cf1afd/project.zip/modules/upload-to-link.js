// ═══════════════════════════════════════════
// UPLOAD TO LINK — File → URL
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const axios = require("axios");
const fs = require("fs");
const path = require("path");
const FormData = require("form-data");

const TMP_DIR = path.join(__dirname, "..", "tmp_upload");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══════════════════════════════════════════
// UPLOAD KE CATBOX.MOE
// ═══════════════════════════════════════════
async function uploadToCatbox(filePath, fileName) {
    try {
        const form = new FormData();
        form.append("reqtype", "fileupload");
        form.append("userhash", ""); // kosong = anonim
        form.append("fileToUpload", fs.createReadStream(filePath), {
            filename: fileName
        });

        const res = await axios.post("https://catbox.moe/user/api.php", form, {
            headers: form.getHeaders(),
            timeout: 120000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });

        const url = String(res.data).trim();
        if (!url || !url.startsWith("http")) {
            return { ok: false, error: "Catbox response invalid: " + url.slice(0, 100) };
        }

        return { ok: true, url, host: "catbox" };
    } catch (e) {
        console.log("[CATBOX ERR]", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// UPLOAD KE 0X0.ST (fallback)
// ═══════════════════════════════════════════
async function uploadTo0x0(filePath, fileName) {
    try {
        const form = new FormData();
        form.append("file", fs.createReadStream(filePath), {
            filename: fileName
        });
        form.append("expires", "72"); // 72 hours default

        const res = await axios.post("https://0x0.st", form, {
            headers: {
                ...form.getHeaders(),
                "User-Agent": "SpartaX-Bot/1.0"
            },
            timeout: 120000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });

        const url = String(res.data).trim();
        if (!url || !url.startsWith("http")) {
            return { ok: false, error: "0x0 response invalid: " + url.slice(0, 100) };
        }

        return { ok: true, url, host: "0x0" };
    } catch (e) {
        console.log("[0X0 ERR]", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// UPLOAD KE TMPFILES (fallback 2)
// ═══════════════════════════════════════════
async function uploadToTmpfiles(filePath, fileName) {
    try {
        const form = new FormData();
        form.append("file", fs.createReadStream(filePath), {
            filename: fileName
        });

        const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
            headers: form.getHeaders(),
            timeout: 120000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });

        if (!res.data || !res.data.data || !res.data.data.url) {
            return { ok: false, error: "Tmpfiles response invalid" };
        }

        // Format: https://tmpfiles.org/xxxx/file.png → https://tmpfiles.org/dl/xxxx/file.png
        let url = res.data.data.url;
        url = url.replace("tmpfiles.org/", "tmpfiles.org/dl/");

        return { ok: true, url, host: "tmpfiles" };
    } catch (e) {
        console.log("[TMPFILES ERR]", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// UPLOAD KE TELEGRAPH (khusus gambar, permanent)
// ═══════════════════════════════════════════
async function uploadToTelegraph(filePath) {
    try {
        const buf = fs.readFileSync(filePath);
        const b64 = buf.toString("base64");

        const form = new FormData();
        form.append("file", `data:image/png;base64,${b64}`);

        const res = await axios.post("https://telegra.ph/upload", form, {
            headers: form.getHeaders(),
            timeout: 60000,
            maxBodyLength: Infinity,
            maxContentLength: Infinity
        });

        if (!Array.isArray(res.data) || !res.data[0] || !res.data[0].src) {
            return { ok: false, error: "Telegraph response invalid" };
        }

        const url = "https://telegra.ph" + res.data[0].src;
        return { ok: true, url, host: "telegraph" };
    } catch (e) {
        console.log("[TELEGRAPH ERR]", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// MAIN UPLOAD — Try multiple providers
// ═══════════════════════════════════════════
async function uploadToLink(filePath, fileName, options = {}) {
    const { prefer = "auto", isImage = false } = options;

    if (!fs.existsSync(filePath)) {
        return { ok: false, error: "File ga ada" };
    }

    const stat = fs.statSync(filePath);
    const sizeMB = (stat.size / 1024 / 1024).toFixed(2);
    console.log(`[UPLOAD] ${fileName} (${sizeMB} MB)`);

    const providers = [];

    if (prefer === "catbox_only") {
        // File-to-link explicitly promises Catbox URLs; do not silently return a different host.
        providers.push({ name: "catbox", fn: () => uploadToCatbox(filePath, fileName) });
    } else {
        // Kalau user mau telegraph (khusus gambar)
        if (prefer === "telegraph" || (prefer === "auto" && isImage && stat.size < 5 * 1024 * 1024)) {
            providers.push({ name: "telegraph", fn: () => uploadToTelegraph(filePath) });
        }
        // Default fallback order for other callers
        providers.push(
            { name: "catbox", fn: () => uploadToCatbox(filePath, fileName) },
            { name: "0x0", fn: () => uploadTo0x0(filePath, fileName) },
            { name: "tmpfiles", fn: () => uploadToTmpfiles(filePath, fileName) }
        );
    }

    for (const provider of providers) {
        try {
            console.log(`[UPLOAD] Coba ${provider.name}...`);
            const result = await provider.fn();
            if (result.ok) {
                console.log(`[UPLOAD] ✓ ${provider.name} → ${result.url}`);
                return result;
            }
            console.log(`[UPLOAD] ✕ ${provider.name} gagal:`, result.error?.slice(0, 100));
        } catch (e) {
            console.log(`[UPLOAD] ✗ ${provider.name} error:`, e.message);
        }
    }

    return { ok: false, error: "Semua provider gagal. Coba lagi nanti." };
}

// ═══════════════════════════════════════════
// DETECT FILE TYPE
// ═══════════════════════════════════════════
function detectType(fileName) {
    const ext = path.extname(fileName || "").toLowerCase();
    if ([".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"].includes(ext)) return "image";
    if ([".mp4", ".mkv", ".mov", ".avi", ".webm", ".flv"].includes(ext)) return "video";
    if ([".mp3", ".wav", ".ogg", ".m4a", ".flac", ".aac"].includes(ext)) return "audio";
    if ([".pdf", ".doc", ".docx", ".txt", ".zip", ".rar", ".apk"].includes(ext)) return "document";
    return "other";
}

module.exports = {
    uploadToLink,
    uploadToCatbox,
    uploadTo0x0,
    uploadToTmpfiles,
    uploadToTelegraph,
    detectType
};

console.log("[UPLOAD TO LINK] module loaded");