const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const sharp = require("sharp");

const panelApi = require("./panel-api.js");

const ORDER_FILE = path.join(__dirname, "..", "database", "orders.json");
const TMP_ORDER = path.join(__dirname, "..", "tmp_order");
if (!fs.existsSync(TMP_ORDER)) fs.mkdirSync(TMP_ORDER, { recursive: true });

const L = "─", P = "│", TL = "╭", TR = "╮", BL = "╰", BR = "╯", T = "├";
const B = "▸", C = "◉", OK = "✓", X = "✕", AR = "→", ST = "✦", D = "◆";

// ═══════════════════════════════════════════
// ⚡ BYPASS WRAPPER — pakai bot._request()
// ═══════════════════════════════════════════
// node-telegram-bot-api punya bot._request() untuk panggil Telegram API langsung.
// Router wrapAndExecute cuma override: sendMessage, sendPhoto, sendDocument,
// editMessageText, editMessageCaption, editMessageMedia, editMessageReplyMarkup,
// answerCallbackQuery, deleteMessage.
// bot._request TIDAK di-override → panggil langsung = kirim pesan BARU.

async function sendNewMessage(bot, chatId, text, options = {}) {
    // Use the native Bot API Rich Message endpoint for all HTML notifications when installed.
    if (typeof bot.sendRichMessage === "function") {
        return bot.sendRichMessage(chatId, String(text || ""), options);
    }
    if (typeof bot._request === "function") {
        try {
            const form = {
                chat_id: chatId,
                text: text,
                parse_mode: options.parse_mode || "HTML"
            };
            if (options.reply_markup) {
                form.reply_markup = JSON.stringify(options.reply_markup);
            }
            if (options.disable_web_page_preview !== undefined) {
                form.disable_web_page_preview = options.disable_web_page_preview;
            }
            if (options.link_preview_options) {
                form.link_preview_options = JSON.stringify(options.link_preview_options);
            }
            return await bot._request("sendMessage", { form });
        } catch (e) {
            console.log("[sendNewMessage] _request fail:", e.message.slice(0, 150));
        }
    }
    console.log("[sendNewMessage] FALLBACK ke bot.sendMessage — bisa ke-wrap!");
    return await bot.sendMessage(chatId, text, options);
}

async function sendNewPhoto(bot, chatId, photo, options = {}) {
    // URLs and generated buffers are sent as native Rich Message media + HTML payload.
    if (typeof bot.sendRichMessage === "function" && ((typeof photo === "string" && /^https?:\/\//i.test(photo)) || Buffer.isBuffer(photo))) {
        return bot.sendRichMessage(chatId, String(options.caption || ""), options, photo);
    }
    if (typeof bot._request === "function") {
        try {
            // Kalau photo = URL string
            if (typeof photo === "string" && /^https?:\/\//i.test(photo)) {
                const form = {
                    chat_id: chatId,
                    photo: photo,
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    form.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendPhoto", { form });
            }
            // Kalau photo = file_id (string panjang, no protocol)
            if (typeof photo === "string" && !/^https?:\/\//i.test(photo)) {
                const form = {
                    chat_id: chatId,
                    photo: photo,
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    form.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendPhoto", { form });
            }
            // Kalau photo = Buffer
            if (Buffer.isBuffer(photo)) {
                const formData = {
                    chat_id: chatId,
                    photo: {
                        value: photo,
                        options: { filename: "image.png", contentType: "image/png" }
                    },
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    formData.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendPhoto", { formData });
            }
        } catch (e) {
            console.log("[sendNewPhoto] _request fail:", e.message.slice(0, 150));
        }
    }
    console.log("[sendNewPhoto] FALLBACK ke bot.sendPhoto — bisa ke-wrap!");
    return await bot.sendPhoto(chatId, photo, options);
}

async function sendNewDocument(bot, chatId, doc, options = {}) {
    if (typeof bot._request === "function") {
        try {
            // Kalau doc = path file lokal
            if (typeof doc === "string" && fs.existsSync(doc)) {
                const formData = {
                    chat_id: chatId,
                    document: fs.createReadStream(doc),
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    formData.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendDocument", { formData });
            }
            // Kalau doc = file_id (string)
            if (typeof doc === "string") {
                const form = {
                    chat_id: chatId,
                    document: doc,
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    form.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendDocument", { form });
            }
            // Kalau doc = Buffer
            if (Buffer.isBuffer(doc)) {
                const formData = {
                    chat_id: chatId,
                    document: {
                        value: doc,
                        options: { filename: options.filename || "file.bin", contentType: "application/octet-stream" }
                    },
                    caption: options.caption || "",
                    parse_mode: options.parse_mode || "HTML"
                };
                if (options.reply_markup) {
                    formData.reply_markup = JSON.stringify(options.reply_markup);
                }
                return await bot._request("sendDocument", { formData });
            }
        } catch (e) {
            console.log("[sendNewDocument] _request fail:", e.message.slice(0, 150));
        }
    }
    console.log("[sendNewDocument] FALLBACK ke bot.sendDocument — bisa ke-wrap!");
    return await bot.sendDocument(chatId, doc, options);
}

// ═══ READ / WRITE ORDERS.JSON ═══
function readOrders() {
    try {
        const d = JSON.parse(fs.readFileSync(ORDER_FILE, "utf8"));
        d.orders = d.orders || {};
        d.pending = d.pending || {};
        d.stats = d.stats || { total: 0, success: 0, failed: 0, pending: 0, revenue: 0 };
        return d;
    } catch {
        return { orders: {}, pending: {}, stats: { total: 0, success: 0, failed: 0, pending: 0, revenue: 0 } };
    }
}

function writeOrders(d) {
    try {
        const tmp = ORDER_FILE + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(d, null, 2), "utf8");
        fs.renameSync(tmp, ORDER_FILE);
        return true;
    }
    catch { return false; }
}

function genOrderId() {
    const ts = Date.now().toString(36).toUpperCase();
    const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `ORD${ts}${rand}`;
}

function rupiah(n) { return "Rp " + (n || 0).toLocaleString("id-ID"); }

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, { chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options });
    } catch (e) {
        const m = e.message || "";
        if (m.includes("message is not modified")) return null;
        if (m.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, { chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options });
            } catch {}
        }
        if (m.includes("message to edit not found") || m.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ KATEGORI ═══
const KATEGORI = {
    admin_panel_legal: { label: "Admin Panel Legal", harga: 25000, scope: "pltc", type: "admin" },
    admin_panel_ilegal: { label: "Admin Panel Ilegal", harga: 2000, scope: "plta", type: "admin" },
    panel_legal: { label: "Panel Legal", scope: "pltc", type: "panel" },
    panel_ilegal: { label: "Panel Ilegal", scope: "plta", type: "panel" }
};

const HARGA_PANEL_LEGAL = {
    "1GB": 1000, "2GB": 2000, "3GB": 3000, "4GB": 4000, "5GB": 5000,
    "6GB": 6000, "7GB": 7000, "8GB": 8000, "9GB": 9000, "10GB": 10000,
    "UNLIMITED": 12000
};

const HARGA_PANEL_ILEGAL = {
    "1GB": 500, "2GB": 1000, "3GB": 1500, "4GB": 2000, "5GB": 2500,
    "6GB": 3000, "7GB": 3500, "8GB": 4000, "9GB": 4500, "10GB": 5000,
    "UNLIMITED": 6000
};

// ═══ GENERATE ORDER CARD PAKAI SHARP ═══
async function generateOrderCard(data) {
    try {
        const W = (cfg.ORDER && cfg.ORDER.IMG_WIDTH) || 900;
        const H = (cfg.ORDER && cfg.ORDER.IMG_HEIGHT) || 1200;
        const status = (data.status || "pending").toLowerCase();

        const colorMap = {
            success: { accent: "#22c55e" },
            failed:  { accent: "#ef4444" },
            pending: { accent: "#eab308" }
        };
        const c = colorMap[status] || colorMap.pending;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const bricks = [];
        const brickColors = ["#ef4444", "#dc2626", "#fbbf24", "#f59e0b", "#ffffff", "#fef3c7"];
        for (let i = 0; i < 22; i++) {
            const x = Math.random() * W;
            const y = Math.random() * H;
            const bw = 40 + Math.random() * 60;
            const bh = 25 + Math.random() * 35;
            const col = brickColors[Math.floor(Math.random() * brickColors.length)];
            const op = 0.08 + Math.random() * 0.12;
            bricks.push(`<rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="4" fill="${col}" opacity="${op}"/>`);
            for (let s = 0; s < 2; s++) {
                bricks.push(`<circle cx="${x + 15 + s * (bw / 2)}" cy="${y + 5}" r="6" fill="${col}" opacity="${op + 0.05}"/>`);
            }
        }

        const name = esc((data.buyerName || "User").slice(0, 24));
        const username = esc((data.buyerUsername || "-").slice(0, 24));
        const itemName = esc((data.itemName || "-").slice(0, 30));
        const harga = esc(rupiah(data.harga || 0));
        const waktu = esc(new Date(data.timestamp || Date.now()).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }));
        const statusLabel = status === "success" ? "SUCCESS" : status === "failed" ? "FAILED" : "PENDING";

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#7f1d1d"/>
      <stop offset="45%" stop-color="#dc2626"/>
      <stop offset="100%" stop-color="#7f1d1d"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#fef3c7"/>
      <stop offset="50%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
    <linearGradient id="cardGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#fef3c7"/>
    </linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  ${bricks.join("")}
  <rect x="0" y="0" width="${W}" height="130" fill="url(#goldGrad)"/>
  <rect x="0" y="130" width="${W}" height="6" fill="#7f1d1d"/>
  <text x="${W/2}" y="70" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="42" fill="#7f1d1d" font-weight="900">𖡛 ORDER NOTIFICATION</text>
  <text x="${W/2}" y="105" text-anchor="middle" font-family="Arial, sans-serif" font-size="20" fill="#7f1d1d" font-weight="700">SpartaX Store • Powered by BiscuitMD</text>
  <rect x="${W/2 - 180}" y="180" width="360" height="90" rx="45" fill="${c.accent}" stroke="#ffffff" stroke-width="4"/>
  <text x="${W/2}" y="240" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="42" fill="#ffffff" font-weight="900">${statusLabel}</text>
  <rect x="70" y="310" width="${W - 140}" height="${H - 480}" rx="30" fill="url(#cardGrad)" stroke="url(#goldGrad)" stroke-width="6"/>
  <text x="110" y="380" font-family="Arial Black, sans-serif" font-size="22" fill="#7f1d1d">𖡛 PEMBELI</text>
  <line x1="110" y1="395" x2="${W-110}" y2="395" stroke="#fbbf24" stroke-width="3"/>
  <text x="110" y="440" font-family="Arial, sans-serif" font-size="26" fill="#111" font-weight="700">Nama: <tspan fill="#dc2626">${name}</tspan></text>
  <text x="110" y="480" font-family="Arial, sans-serif" font-size="22" fill="#111">Username: <tspan fill="#dc2626" font-weight="700">@${username}</tspan></text>
  <text x="110" y="560" font-family="Arial Black, sans-serif" font-size="22" fill="#7f1d1d">𖡛 ITEM DIBELI</text>
  <line x1="110" y1="575" x2="${W-110}" y2="575" stroke="#fbbf24" stroke-width="3"/>
  <text x="110" y="625" font-family="Arial, sans-serif" font-size="28" fill="#111" font-weight="700">${itemName}</text>
  <text x="110" y="680" font-family="Arial Black, sans-serif" font-size="30" fill="#dc2626">${harga}</text>
  <text x="110" y="760" font-family="Arial Black, sans-serif" font-size="22" fill="#7f1d1d">𖡛 WAKTU</text>
  <line x1="110" y1="775" x2="${W-110}" y2="775" stroke="#fbbf24" stroke-width="3"/>
  <text x="110" y="820" font-family="Arial, sans-serif" font-size="22" fill="#111">${waktu}</text>
  <text x="110" y="900" font-family="Arial Black, sans-serif" font-size="22" fill="#7f1d1d">𖡛 ORDER ID</text>
  <line x1="110" y1="915" x2="${W-110}" y2="915" stroke="#fbbf24" stroke-width="3"/>
  <text x="110" y="960" font-family="Courier New, monospace" font-size="26" fill="#dc2626" font-weight="700">${esc(data.orderId || "-")}</text>
  <rect x="0" y="${H - 130}" width="${W}" height="130" fill="url(#goldGrad)"/>
  <text x="${W/2}" y="${H - 75}" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="24" fill="#7f1d1d" font-weight="900">𖡛 ${esc(cfg.OWNER_USERNAME || "@biscuitMD")} 𖡛</text>
  <text x="${W/2}" y="${H - 40}" text-anchor="middle" font-family="Arial, sans-serif" font-size="18" fill="#7f1d1d">${esc(cfg.GROUP_UPDATE || "")}</text>
</svg>`.trim();

        const buf = await sharp(Buffer.from(svg)).png().toBuffer();
        return buf;
    } catch (e) {
        console.log("[SHARP GEN ERR]", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU ORDER
// ═══════════════════════════════════════════
router.registerCallback("menu_order", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;

        const kb = [
            [
                { text: "𖡛 Admin Panel Legal", callback_data: "order_cat:admin_panel_legal", style: "success" },
                { text: "𖡛 Admin Panel Ilegal", callback_data: "order_cat:admin_panel_ilegal", style: "success" }
            ],
            [
                { text: "𖡛 Panel Legal", callback_data: "order_cat:panel_legal", style: "primary" },
                { text: "𖡛 Panel Ilegal", callback_data: "order_cat:panel_ilegal", style: "primary" }
            ],
            [{ text: "♛ Auto Order Role", callback_data: "order_role_menu", style: "success" }],
            [
                { text: "𖡛 Buy Script", callback_data: "menu_buyscript", style: "success" }
            ],
            [
                { text: "✕ Kembali", callback_data: "menu_back", style: "danger" }
            ]
        ];

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} ORDER PANEL & SCRIPT ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${AR} Pilih kategori:\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${D} ADMIN PANEL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Legal  ${AR}  ${rupiah(25000)}\n` +
            `${P} ${B} Ilegal ${AR}  ${rupiah(2000)}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${D} PANEL SERVER (by RAM)\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Legal  ${AR}  ${rupiah(1000)} - ${rupiah(12000)}\n` +
            `${P} ${B} Ilegal ${AR}  ${rupiah(500)} - ${rupiah(6000)}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${D} SCRIPT\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} No Update         ${AR}  ${rupiah(10000)}\n` +
            `${P} ${B} Full Update       ${AR}  ${rupiah(25000)}\n` +
            `${P} ${B} Full Update+NoEnc ${AR}  ${rupiah(35000)}\n` +
            `${BL}${L.repeat(22)}${BR}`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[MENU ORDER ERR]", e.message);
    }
});

// ═══ AUTO ORDER ROLE MENU ═══
router.registerCallback("order_role_menu", async (bot, q, data, user, ctx) => {
    const html = `<h1>♛ AUTO ORDER ROLE</h1><p>Pilih jenis panel untuk melihat role yang tersedia.</p>`;
    const kb = [[{text:"Panel Ilegal",callback_data:"order_role_type:ilegal",style:"primary"},{text:"Panel Legal",callback_data:"order_role_type:legal",style:"success"}],[{text:"‹ Kembali ke Order",callback_data:"menu_order",style:"danger"}]];
    if (typeof bot.sendRichMenu === "function") return bot.sendRichMenu(q.message.chat.id, null, html, kb, q);
    return bot.sendMessage(q.message.chat.id, html, {parse_mode:"HTML",reply_markup:{inline_keyboard:kb}});
});
const ROLE_PRICES = {
  ilegal: { reseller:1000, admin:2000, owner:3000, partner:4000, right_hand:5000, ceo:7000, developer:10000 },
  legal: { reseller:15000, admin:30000, owner:50000, partner:70000, right_hand:90000, ceo:110000, developer:130000 }
};
const ROLE_LABELS = { reseller:"Reseller", admin:"Admin", owner:"Owner", partner:"Partner", right_hand:"Right Hand", ceo:"CEO", developer:"Developer" };
router.registerCallback("order_role_type", async (bot,q,data,user,ctx)=>{
  const type=data.split(":")[1]; if(!ROLE_PRICES[type]) return;
  const rows=[]; const entries=Object.entries(ROLE_PRICES[type]);
  for(let i=0;i<entries.length;i+=2){
    const row=[{text:`${ROLE_LABELS[entries[i][0]]} — ${rupiah(entries[i][1])}`,callback_data:`order_role_buy:${type}:${entries[i][0]}`,style:"primary"}];
    if(entries[i+1]) row.push({text:`${ROLE_LABELS[entries[i+1][0]]} — ${rupiah(entries[i+1][1])}`,callback_data:`order_role_buy:${type}:${entries[i+1][0]}`,style:"success"});
    rows.push(row);
  }
  rows.push([{text:"‹ Pilih jenis panel",callback_data:"order_role_menu",style:"danger"}]);
  const html=`<h1>♛ ROLE PANEL ${type.toUpperCase()}</h1><p>Pilih role dan harga. QRIS akan dikirim setelah role dipilih.</p>`;
  if(typeof bot.sendRichMenu==="function") return bot.sendRichMenu(q.message.chat.id,null,html,rows,q);
  return bot.sendMessage(q.message.chat.id,html,{parse_mode:"HTML",reply_markup:{inline_keyboard:rows}});
});
router.registerCallback("order_role_buy", async(bot,q,data,user,ctx)=>{
  const [,type,role]=data.split(":"); if(!ROLE_PRICES[type]||!ROLE_PRICES[type][role]) return;
  const label=`Role ${ROLE_LABELS[role]} Panel ${type}`;
  return showQris(bot,q.message.chat.id,q.message.message_id,{userId:String(user.id),chatId:q.message.chat.id,kategori:`role_${type}`,label,harga:ROLE_PRICES[type][role],scope:type==="legal"?"pltc":"plta",type:"role",ram:null,roleKey:role,rolePanel:type},ctx);
});

// ═══ HANDLE /order (fallback command) ═══
module.exports.handleOrder = async function (bot, msg, ctx) {
    try {
        const chatId = msg.chat.id;

        const kb = [
            [
                { text: "𖡛 Admin Panel Legal", callback_data: "order_cat:admin_panel_legal", style: "success" },
                { text: "𖡛 Admin Panel Ilegal", callback_data: "order_cat:admin_panel_ilegal", style: "success" }
            ],
            [
                { text: "𖡛 Panel Legal", callback_data: "order_cat:panel_legal", style: "primary" },
                { text: "𖡛 Panel Ilegal", callback_data: "order_cat:panel_ilegal", style: "primary" }
            ],
            [{ text: "𖡛 Buy Script", callback_data: "menu_buyscript", style: "success" }],
            [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
        ];

        await bot.sendMessage(chatId,
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} ORDER PANEL & SCRIPT ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${AR} Pilih kategori:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[ORDER ERR]", e.message);
    }
};

// ═══ CALLBACK: kategori ═══
router.registerCallback("order_cat", async (bot, q, data, user, ctx) => {
    try {
        const cat = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        if (cat === "admin_panel_legal" || cat === "admin_panel_ilegal") {
            return showQris(bot, chatId, q.message.message_id, {
                userId, chatId,
                kategori: cat,
                label: KATEGORI[cat].label,
                harga: KATEGORI[cat].harga,
                scope: KATEGORI[cat].scope,
                type: "admin",
                ram: null
            }, ctx);
        }

        if (cat === "panel_legal" || cat === "panel_ilegal") {
            const hargaMap = cat === "panel_legal" ? HARGA_PANEL_LEGAL : HARGA_PANEL_ILEGAL;
            const rows = [];
            const entries = Object.entries(hargaMap);
            for (let i = 0; i < entries.length; i += 2) {
                const row = [];
                row.push({ text: `${B} ${entries[i][0]} — ${rupiah(entries[i][1])}`, callback_data: `order_ram:${cat}:${entries[i][0]}`, style: "primary" });
                if (entries[i + 1]) row.push({ text: `${B} ${entries[i + 1][0]} — ${rupiah(entries[i + 1][1])}`, callback_data: `order_ram:${cat}:${entries[i + 1][0]}`, style: "primary" });
                rows.push(row);
            }
            rows.push([{ text: `✕ Kembali`, callback_data: "menu_order", style: "danger" }]);

            return safeEdit(bot, chatId, q.message.message_id,
                `${TL}${"═".repeat(20)}${TR}\n` +
                `${P}  ${ST} ${KATEGORI[cat].label} ${ST}  ${P}\n` +
                `${BL}${"═".repeat(20)}${BR}\n\n` +
                `${AR} Pilih RAM:`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
        }
    } catch (e) { console.log("[ORDER CAT ERR]", e.message); }
});

// ═══ CALLBACK: menu_buyscript ═══
router.registerCallback("menu_buyscript", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const pkgs = getScriptPackages();

        const kb = [
            [{ text: `𖡛 ${pkgs.no_update.label} — ${rupiah(pkgs.no_update.harga)}`, callback_data: "order_script:no_update", style: "primary" }],
            [{ text: `𖡛 ${pkgs.full_update.label} — ${rupiah(pkgs.full_update.harga)}`, callback_data: "order_script:full_update", style: "success" }],
            [{ text: `𖡛 ${pkgs.full_update_no_enc.label} — ${rupiah(pkgs.full_update_no_enc.harga)}`, callback_data: "order_script:full_update_no_enc", style: "success" }],
            [{ text: "✕ Kembali", callback_data: "menu_order", style: "danger" }]
        ];

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} BUY SCRIPT ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${AR} Pilih paket script:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[MENU BUYSCRIPT ERR]", e.message); }
});

// ═══ CALLBACK: RAM ═══
router.registerCallback("order_ram", async (bot, q, data, user, ctx) => {
    try {
        const parts = data.split(":");
        const cat = parts[1];
        const ram = parts[2];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const hargaMap = cat === "panel_legal" ? HARGA_PANEL_LEGAL : HARGA_PANEL_ILEGAL;
        const harga = hargaMap[ram];
        const scope = cat === "panel_legal" ? "pltc" : "plta";

        return showQris(bot, chatId, q.message.message_id, {
            userId, chatId,
            kategori: cat,
            label: `${KATEGORI[cat].label} ${ram}`,
            harga, scope,
            type: "panel",
            ram
        }, ctx);
    } catch (e) { console.log("[ORDER RAM ERR]", e.message); }
});

// ═══════════════════════════════════════════
// SHOW QRIS — PERMANEN (pakai sendNewPhoto)
// ═══════════════════════════════════════════
async function showQris(bot, chatId, msgId, orderData, ctx) {
    try {
        const o = cfg.ORDER || {};
        const orderId = genOrderId();
        const qrisUrl = o.QRIS_IMAGE || (cfg.FOTO && cfg.FOTO.QRIS) || "https://files.catbox.moe/d272b6.jpeg";

        const data = readOrders();
        data.pending[orderId] = {
            orderId,
            userId: orderData.userId,
            chatId: orderData.chatId,
            kategori: orderData.kategori,
            label: orderData.label,
            harga: orderData.harga,
            scope: orderData.scope,
            type: orderData.type,
            ram: orderData.ram,
            roleKey: orderData.roleKey || null,
            rolePanel: orderData.rolePanel || null,
            status: "waiting_payment",
            createdAt: Date.now(),
            buktiFileId: null
        };
        data.stats.total += 1;
        writeOrders(data);

        ctx.setState(String(orderData.userId), "order_await_bukti", { orderId });

        const caption =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} PEMBAYARAN ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} DETAIL ORDER\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Order ID  ${AR}  <code>${orderId}</code>\n` +
            `${P} ${B} Item      ${AR}  <b>${orderData.label}</b>\n` +
            `${P} ${B} Server    ${AR}  ${orderData.scope === "pltc" ? "Legal" : "Ilegal"}\n` +
            (orderData.ram ? `${P} ${B} RAM       ${AR}  <b>${orderData.ram}</b>\n` : "") +
            `${P} ${B} Harga     ${AR}  <b>${rupiah(orderData.harga)}</b>\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${D} CARA BAYAR\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Scan QRIS di atas\n` +
            `${P} ${B} Transfer sesuai nominal\n` +
            `${P} ${B} Kirim FOTO BUKTI ke chat ini\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `<i>${o.QRIS_NOTE || "Tunggu ACC owner (estimasi 1-30 menit)"}</i>`;

        const kb = [
            [{ text: "✕ Batalkan Order", callback_data: `order_cancel:${orderId}`, style: "danger" }],
            [{ text: "☰ Menu Utama", callback_data: "order_menu", style: "primary" }]
        ];

        // ⚡ KIRIM QRIS SEBAGAI PESAN BARU — via _request bypass wrapper
        let sent = false;

        try {
            await sendNewPhoto(bot, chatId, qrisUrl, {
                caption,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
            sent = true;
            console.log("[SHOW QRIS] ✅ QRIS terkirim permanen (bypass wrapper via _request)");
        } catch (e) {
            console.log("[SHOW QRIS] sendNewPhoto fail:", e.message.slice(0, 120));
            try {
                await sendNewMessage(bot, chatId, caption, {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
                sent = true;
                console.log("[SHOW QRIS] ✅ fallback text terkirim");
            } catch (e2) {
                console.log("[SHOW QRIS] fallback text fail:", e2.message.slice(0, 120));
            }
        }

        if (sent && msgId) {
            try {
                await bot.editMessageText(
                    `<i>𖡛 Order berhasil dibuat — QRIS dikirim di bawah 👇</i>`,
                    { chat_id: chatId, message_id: msgId, parse_mode: "HTML" }
                );
            } catch {}
        }

        return sent;
    } catch (e) {
        console.log("[SHOW QRIS ERR]", e.message);
    }
}

// ═══ CALLBACK: MENU UTAMA DARI QRIS ═══
router.registerCallback("order_menu", async (bot, q, data, user, ctx) => {
    try {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        return ctx.sendMenu(q.message.chat.id, ctx.db.getUser(user.id));
    } catch (e) { console.log("[ORDER MENU ERR]", e.message); }
});

// ═══ CALLBACK: CANCEL ORDER ═══
router.registerCallback("order_cancel", async (bot, q, data, user, ctx) => {
    try {
        const orderId = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const dataOrd = readOrders();
        if (dataOrd.pending[orderId]) {
            dataOrd.pending[orderId].status = "cancelled";
            delete dataOrd.pending[orderId];
            writeOrders(dataOrd);
        }

        ctx.clearState(userId);

        try { await bot.deleteMessage(chatId, q.message.message_id); } catch {}

        await sendNewMessage(bot, chatId,
            `${X} <b>Order dibatalkan</b>\n\n` +
            `${B} Order ID: <code>${orderId}</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[ORDER CANCEL ERR]", e.message); }
});

router.registerMessage("order_await_bukti", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const orderId = state.orderId;

        console.log(`[ORDER BUKTI] user=${userId} orderId=${orderId} hasPhoto=${!!msg.photo} hasDoc=${!!msg.document}`);

        const data = readOrders();
        const order = data.pending[orderId];
        if (!order) {
            ctx.clearState(userId);
            console.log(`[ORDER BUKTI] Order ${orderId} GA DITEMUKAN di pending!`);
            return bot.sendMessage(chatId, `${X} Order gak ditemukan / expired.`, { parse_mode: "HTML" });
        }

        let fileId = null;
        if (msg.photo && msg.photo.length > 0) fileId = msg.photo[msg.photo.length - 1].file_id;
        else if (msg.document) fileId = msg.document.file_id;

        if (!fileId) {
            return bot.sendMessage(chatId,
                `${X} Kirim <b>FOTO</b> bukti transfer (bukan teks/link).`,
                { parse_mode: "HTML" });
        }

        console.log(`[ORDER BUKTI] fileId=${fileId.slice(0, 40)}...`);

        order.buktiFileId = fileId;
        order.status = "waiting_approval";
        order.uploadedAt = Date.now();
        order.buyerName = (msg.from.first_name || "") + (msg.from.last_name ? " " + msg.from.last_name : "");
        order.buyerUsername = msg.from.username || "-";
        order.buyerId = msg.from.id;
        data.pending[orderId] = order;
        data.stats.pending += 1;
        writeOrders(data);

        ctx.clearState(userId);

        await bot.sendMessage(chatId,
            `${OK} <b>Bukti transfer diterima!</b>\n\n` +
            `${B} Order ID: <code>${orderId}</code>\n` +
            `${B} Status: <b>Menunggu ACC Owner</b>\n` +
            `${B} Estimasi: <i>1 - 30 menit</i>\n\n` +
            `<i>Jika di-ACC, panel langsung dibuat & data dikirim ke DM lu.</i>`,
            { parse_mode: "HTML" });

        console.log(`[ORDER BUKTI] Kirim approval ke owner...`);
        const ok = await sendApprovalToOwner(bot, order, userId, msg.from);
        console.log(`[ORDER BUKTI] Approval result: ${ok}`);

    } catch (e) {
        console.log("[ORDER AWAIT BUKTI ERR]", e.message);
        console.log("[ORDER AWAIT BUKTI STACK]", e.stack);
    }
});

// ═══════════════════════════════════════════
// KIRIM APPROVAL KE OWNER
// ═══════════════════════════════════════════
async function sendApprovalToOwner(bot, order, userId, fromUser) {
    try {
        const ownerId = cfg.OWNER_ID;
        if (!ownerId) {
            console.log("[APPROVAL OWNER ERR] OWNER_ID kosong di config!");
            return false;
        }

        console.log(`[APPROVAL OWNER] Kirim ke owner: ${ownerId}, bukti: ${order.buktiFileId ? order.buktiFileId.slice(0, 30) + "..." : "KOSONG"}`);

        if (!order.buktiFileId) {
            console.log("[APPROVAL OWNER ERR] buktiFileId kosong!");
            return false;
        }

        const caption =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} APPROVAL ORDER ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} PEMBELI\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Nama  ${AR}  <a href="tg://user?id=${userId}">${fromUser.first_name || "User"}</a>\n` +
            `${P} ${B} ID    ${AR}  <code>${userId}</code>\n` +
            `${P} ${B} User  ${AR}  ${fromUser.username ? "@" + fromUser.username : "-"}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} ORDER DETAIL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Order ID  ${AR}  <code>${order.orderId}</code>\n` +
            `${P} ${B} Item      ${AR}  <b>${order.label}</b>\n` +
            `${P} ${B} Server    ${AR}  ${order.scope === "pltc" ? "Legal" : "Ilegal"}\n` +
            (order.ram ? `${P} ${B} RAM       ${AR}  <b>${order.ram}</b>\n` : "") +
            `${P} ${B} Harga     ${AR}  <b>${rupiah(order.harga)}</b>\n` +
            `${P} ${B} Waktu     ${AR}  ${new Date(order.uploadedAt).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${AR} <b>ACC / REJECT?</b>`;

        const kb = [
            [
                { text: `${OK} ACC`, callback_data: `order_acc:${order.orderId}`, style: "success" },
                { text: `${X} REJECT`, callback_data: `order_rej:${order.orderId}`, style: "danger" }
            ]
        ];

        let sent = false;
        let lastErr = null;

        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                console.log(`[APPROVAL OWNER] Attempt ${attempt}/3 — sendNewPhoto`);
                await sendNewPhoto(bot, ownerId, order.buktiFileId, {
                    caption,
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
                sent = true;
                console.log(`[APPROVAL OWNER] ✅ Bukti terkirim ke owner (attempt ${attempt})`);
                break;
            } catch (e) {
                lastErr = e;
                console.log(`[APPROVAL OWNER] attempt ${attempt} FAIL:`, e.message.slice(0, 150));
                if (attempt < 3) await new Promise(r => setTimeout(r, 1500));
            }
        }

        if (!sent) {
            try {
                console.log("[APPROVAL OWNER] Fallback: sendNewDocument");
                await sendNewDocument(bot, ownerId, order.buktiFileId, {
                    caption,
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
                sent = true;
                console.log("[APPROVAL OWNER] ✅ Fallback document sukses");
            } catch (e) {
                console.log("[APPROVAL OWNER] fallback doc FAIL:", e.message.slice(0, 150));
            }
        }

        if (!sent) {
            try {
                console.log("[APPROVAL OWNER] Fallback terakhir: sendNewMessage tanpa foto");
                await sendNewMessage(bot, ownerId,
                    caption + `\n\n⚠️ <i>Bukti foto gagal dikirim. Cek manual di chat user.</i>`,
                    {
                        parse_mode: "HTML",
                        reply_markup: { inline_keyboard: kb }
                    });
                sent = true;
                console.log("[APPROVAL OWNER] ✅ Fallback text sukses");
            } catch (e) {
                console.log("[APPROVAL OWNER] fallback text FAIL:", e.message.slice(0, 150));
            }
        }

        if (sent) {
            // Channel notification is sent only after proof reaches the owner, never when QRIS is displayed.
            await sendNotifChannel(bot, order, { first_name: order.buyerName || fromUser.first_name || "User", username: order.buyerUsername || fromUser.username || "-", id: userId }, "pending");
            try {
                await bot.sendMessage(order.chatId,
                    `${OK} <b>Bukti udah masuk ke owner!</b>\n\n` +
                    `${B} Order: <code>${order.orderId}</code>\n` +
                    `${B} Status: <i>Menunggu ACC</i>\n` +
                    `${B} Estimasi: 1-30 menit`,
                    { parse_mode: "HTML" });
            } catch {}
        } else {
            console.log("[APPROVAL OWNER] ❌ SEMUA ATTEMPT GAGAL!");
            try {
                await bot.sendMessage(order.chatId,
                    `<b>⚠️ Bukti gagal terkirim ke owner</b>\n\n` +
                    `${B} Order: <code>${order.orderId}</code>\n` +
                    `${B} Error: <code>${(lastErr?.message || "unknown").slice(0, 100)}</code>\n\n` +
                    `<i>Coba kirim ulang bukti, atau chat owner manual: <a href="tg://user?id=${ownerId}">Klik sini</a></i>`,
                    { parse_mode: "HTML" });
            } catch {}
        }

        return sent;
    } catch (e) {
        console.log("[APPROVAL OWNER ERR]", e.message);
        console.log("[APPROVAL OWNER STACK]", e.stack);
        return false;
    }
}

// ═══ CALLBACK: OWNER ACC ═══
router.registerCallback("order_acc", async (bot, q, data, user, ctx) => {
    try {
        console.log(`[ORDER ACC] owner=${user.id} orderId=${data.split(":")[1]}`);

        if (String(user.id) !== String(cfg.OWNER_ID)) {
            console.log(`[ORDER ACC] BUKAN OWNER!`);
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const orderId = data.split(":")[1];
        const chatId = q.message.chat.id;

        const dataOrd = readOrders();
        const order = dataOrd.pending[orderId];

        if (!order) {
            console.log(`[ORDER ACC] Order ${orderId} GA ADA di pending!`);
            return bot.sendMessage(chatId, `${X} Order gak ada / expired.`, { parse_mode: "HTML" });
        }

        console.log(`[ORDER ACC] Order: type=${order.type} scope=${order.scope} ram=${order.ram}`);

        await safeEdit(bot, chatId, q.message.message_id,
            `${ST} <b>Memproses ACC...</b>\n\n${B} Order: <code>${orderId}</code>\n${B} Type: <b>${order.type}</b>`,
            { parse_mode: "HTML" }).catch(() => {});

        if (order.type === "script") {
            return handleScriptAcc(bot, chatId, q.message.message_id, order, dataOrd);
        }

        order.status = "approved";
        order.approvedAt = Date.now();
        order.approvedBy = user.id;

        if (order.type === "role") {
            const roleName = ROLE_LABELS[order.roleKey] || order.roleKey || "role";
            const panelName = order.rolePanel === "legal" ? "legal" : "ilegal";
            ctx.db.saveUser(order.userId, { role: roleName.toLowerCase(), panelType: panelName, purchasedRole: roleName, rolePurchasedAt: Date.now() });
            order.status = "success";
            order.roleGranted = true;
            dataOrd.orders[orderId] = order;
            delete dataOrd.pending[orderId];
            if (dataOrd.stats.pending > 0) dataOrd.stats.pending -= 1;
            dataOrd.stats.success += 1;
            dataOrd.stats.revenue += order.harga;
            writeOrders(dataOrd);
            const groupLink = String((cfg.ORDER && cfg.ORDER.GROUP_LINK) || cfg.GROUP_LINK || "").trim();
            const groupButton = /^https:\/\//i.test(groupLink) ? { reply_markup: { inline_keyboard: [[{ text: "➜ Gabung Group", url: groupLink, style: "success" }]] } } : {};
            await bot.sendMessage(order.userId,
                `<h2>✅ ORDER ROLE DISETUJUI</h2><p>Role: <b>${roleName}</b></p><p>Panel: <b>${panelName.toUpperCase()}</b></p><p>Order: <code>${orderId}</code></p><p>Pesananmu sudah disetujui. Gunakan tombol di bawah untuk bergabung ke grup.</p>`,
                { parse_mode:"HTML", ...groupButton }).catch(()=>{});
            await safeEdit(bot, chatId, q.message.message_id, `<h2>✅ ROLE ORDER APPROVED</h2><p>Order: <code>${orderId}</code></p><p>Pembeli: <code>${order.userId}</code></p><p>Role: <b>${roleName} (${panelName})</b></p><p>Status role telah diperbarui.</p>`, {parse_mode:"HTML"});
            await sendNotifChannel(bot, order, { first_name: order.buyerName || "User", username: order.buyerUsername || "-", id: order.userId }, "success");
            return;
        }

        console.log(`[ORDER ACC] Auto create panel...`);
        const result = await autoCreatePanel(bot, order);
        console.log(`[ORDER ACC] Result:`, JSON.stringify(result).slice(0, 200));

        if (result.ok) {
            order.status = "success";
            order.panelData = result.panelData;
            dataOrd.stats.success += 1;
            dataOrd.stats.revenue += order.harga;
            if (dataOrd.stats.pending > 0) dataOrd.stats.pending -= 1;

            dataOrd.orders[orderId] = order;
            delete dataOrd.pending[orderId];
            writeOrders(dataOrd);

            console.log(`[ORDER ACC] Kirim panel ke pembeli user=${order.userId}...`);
            const sendOk = await sendPanelToBuyer(bot, order, result.panelData);
            console.log(`[ORDER ACC] sendPanelToBuyer: ${sendOk}`);

            await safeEdit(bot, chatId, q.message.message_id,
                `${OK} <b>ORDER APPROVED</b>\n\n` +
                `${B} Order: <code>${orderId}</code>\n` +
                `${B} User: <code>${order.userId}</code>\n` +
                `${B} Item: <b>${order.label}</b>\n` +
                `${B} Panel: <b>BERHASIL DIBUAT</b>\n` +
                `${B} Kirim ke DM: ${sendOk ? "✓ SUKSES" : "⚠️ GAGAL (user blm /start)"}\n\n` +
                (sendOk ? `<i>Data udah masuk ke DM pembeli</i>` : `<i>⚠️ User belum /start bot. Data ada di bawah, kirim manual.</i>`),
                { parse_mode: "HTML" });

            if (!sendOk) {
                await bot.sendMessage(chatId,
                    `${ST} <b>CREDENTIAL MANUAL</b>\n\n` +
                    `Karena user ga bisa di-DM, kirim data ini manual:\n\n` +
                    `${B} Username: <code>${result.panelData.username}</code>\n` +
                    `${B} Password: <code>${result.panelData.password}</code>\n` +
                    `${B} Email: <code>${result.panelData.email}</code>\n` +
                    `${B} Panel URL: ${result.panelData.domain}`,
                    { parse_mode: "HTML" });
            }

            await sendNotifChannel(bot, order, { first_name: order.buyerName || "User" }, "success");
        } else {
            console.log(`[ORDER ACC] autoCreatePanel GAGAL: ${result.error}`);
            order.status = "failed";
            order.error = result.error;
            dataOrd.orders[orderId] = order;
            delete dataOrd.pending[orderId];
            writeOrders(dataOrd);

            await safeEdit(bot, chatId, q.message.message_id,
                `${X} <b>GAGAL BUAT PANEL</b>\n\n` +
                `${B} Order: <code>${orderId}</code>\n` +
                `${B} Error: <code>${(result.error || "unknown").slice(0, 200)}</code>\n\n` +
                `<i>Order dibatalkan. Cek log console untuk detail.</i>`,
                { parse_mode: "HTML" });

            await bot.sendMessage(order.userId,
                `${X} <b>Maaf, panel gagal dibuat</b>\n\n` +
                `${B} Order: <code>${orderId}</code>\n` +
                `${B} Error: ${(result.error || "unknown").slice(0, 150)}\n\n` +
                `<i>Hubungi owner untuk refund / retry.</i>`,
                { parse_mode: "HTML" }).catch(() => {});

            await sendNotifChannel(bot, order, { first_name: order.buyerName || "User" }, "failed");
        }
    } catch (e) {
        console.log("[ORDER ACC ERR]", e.message);
        console.log("[ORDER ACC STACK]", e.stack);
        try {
            await bot.sendMessage(q.message.chat.id,
                `<b>✕ Error ACC:</b>\n<code>${e.message.slice(0, 200)}</code>`,
                { parse_mode: "HTML" });
        } catch {}
    }
});

// ═══ CALLBACK: OWNER REJECT ═══
router.registerCallback("order_rej", async (bot, q, data, user, ctx) => {
    try {
        if (String(user.id) !== String(cfg.OWNER_ID)) {
            return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true }).catch(() => {});
        }

        const orderId = data.split(":")[1];
        const chatId = q.message.chat.id;

        const dataOrd = readOrders();
        const order = dataOrd.pending[orderId];
        if (!order) return bot.answerCallbackQuery(q.id, { text: "Order gak ada", show_alert: true }).catch(() => {});

        order.status = "rejected";
        order.rejectedAt = Date.now();
        order.rejectedBy = user.id;
        dataOrd.orders[orderId] = order;
        delete dataOrd.pending[orderId];
        if (dataOrd.stats.pending > 0) dataOrd.stats.pending -= 1;
        writeOrders(dataOrd);

        await safeEdit(bot, chatId, q.message.message_id,
            `${X} <b>ORDER REJECTED</b>\n\n${B} Order: <code>${orderId}</code>`,
            { parse_mode: "HTML" });

        await bot.sendMessage(order.userId,
            `${X} <b>Order Ditolak</b>\n\n` +
            `${B} Order: <code>${orderId}</code>\n` +
            `${B} Alasan: Bukti tidak valid\n\n` +
            `<i>Hubungi owner untuk info lebih lanjut.</i>`,
            { parse_mode: "HTML" }).catch(() => {});

        await sendNotifChannel(bot, order, { first_name: order.buyerName || "User" }, "failed");
    } catch (e) { console.log("[ORDER REJ ERR]", e.message); }
});

async function autoCreatePanel(bot, order) {
    try {
        const scope = order.scope;
        const pc = panelApi.getPanelConfig(scope);
        const v = panelApi.validateApiKey(pc.API_KEY, "application");
        if (!v.ok) return { ok: false, error: v.error || "API key invalid" };

        const username = `usr${Date.now().toString(36)}${Math.floor(Math.random() * 999)}`;
        const password = panelApi.generatePassword(14);
        const email = panelApi.generateEmail(username, pc.DOMAIN || "panel.local");

        const isAdminPanel = order.type === "admin";
        console.log(`[autoCreatePanel] type=${order.type} → rootAdmin=${isAdminPanel}`);

        const ramMap = {
            "1GB": 1024, "2GB": 2048, "3GB": 3072, "4GB": 4096,
            "5GB": 5120, "6GB": 6144, "7GB": 7168, "8GB": 8192,
            "9GB": 9216, "10GB": 10240, "UNLIMITED": 0
        };
        const memory = order.ram ? (ramMap[order.ram] || 1024) : (pc.DEFAULT_MEMORY || 1024);
        const disk = memory === 0 ? 0 : memory * 2;
        const cpu = memory === 0 ? 0 : (pc.DEFAULT_CPU || 100);

        const nu = await panelApi.createUser(scope, {
            email, username,
            firstName: username, lastName: "Panel",
            password,
            rootAdmin: isAdminPanel
        });
        console.log(`[autoCreatePanel] createUser result:`, JSON.stringify(nu).slice(0, 200));
        if (!nu.ok) return { ok: false, error: `Create user: ${nu.error}` };

        if (isAdminPanel) {
            console.log(`[autoCreatePanel] ADMIN PANEL — skip create server`);
            return {
                ok: true,
                panelData: {
                    username, password, email,
                    domain: pc.URL,
                    scope,
                    serverId: null,
                    ram: null,
                    label: pc.LABEL || scope.toUpperCase(),
                    isAdmin: true
                }
            };
        }

        const alloc = await panelApi.getAllocations(scope, pc.DEFAULT_LOCATION || 1);
        if (!alloc.ok) return { ok: false, error: `Allocation: ${alloc.error}` };
        const allocation = alloc.allocations[0].attributes;

        let eggId = 1, dockerImage = "ghcr.io/parkervcp/yolks:nodejs_20", startup = "npm start";
        try {
            const eggsRes = await panelApi.listEggs(scope, pc.NEST_ID || 5);
            if (eggsRes.ok && eggsRes.eggs && eggsRes.eggs.length > 0) {
                const firstEgg = eggsRes.eggs[0].attributes;
                eggId = firstEgg.id;
                dockerImage = firstEgg.docker_image;
                startup = firstEgg.startup;
            }
        } catch {}

        const sv = await panelApi.createServer(scope, {
            name: `${username}-server`,
            userId: nu.user.id,
            nestId: pc.NEST_ID || 5,
            eggId, dockerImage, startup,
            environment: {},
            memory: memory === 0 ? 0 : memory,
            disk: memory === 0 ? 0 : disk,
            cpu: memory === 0 ? 0 : cpu,
            allocationId: allocation.id,
            locationId: pc.DEFAULT_LOCATION || 1,
            databases: pc.DEFAULT_DATABASES || 1,
            backups: pc.DEFAULT_BACKUPS || 1,
            allocations: pc.DEFAULT_ALLOCATIONS || 0
        });
        if (!sv.ok) return { ok: false, error: `Create server: ${sv.error}` };

        return {
            ok: true,
            panelData: {
                username, password, email,
                domain: pc.URL,
                scope,
                serverId: sv.server.id,
                ram: order.ram,
                label: pc.LABEL || scope.toUpperCase(),
                isAdmin: false
            }
        };
    } catch (e) {
        console.log("[autoCreatePanel ERR]", e.message);
        return { ok: false, error: e.message };
    }
}

// ═══ KIRIM DATA PANEL KE PEMBELI ═══
async function sendPanelToBuyer(bot, order, pd) {
    try {
        const caption =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${OK} PANEL SIAP ${OK}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} CREDENTIAL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Order ID  ${AR}  <code>${order.orderId}</code>\n` +
            `${P} ${B} Username  ${AR}  <code>${pd.username}</code>\n` +
            `${P} ${B} Password  ${AR}  <code>${pd.password}</code>\n` +
            `${P} ${B} Email     ${AR}  <code>${pd.email}</code>\n` +
            `${P} ${B} Login URL ${AR}  ${pd.domain}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} DETAIL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Item   ${AR}  ${order.label}\n` +
            `${P} ${B} Server ${AR}  ${pd.scope === "pltc" ? "Legal" : "Ilegal"}\n` +
            (pd.ram ? `${P} ${B} RAM    ${AR}  ${pd.ram}\n` : "") +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${ST} <i>Simpan credential ini baik-baik. Jangan share!</i>`;

        const kb = [
            [
                { text: "𖡛 Copy Username", copy_text: { text: pd.username }, style: "primary" },
                { text: "𖡛 Copy Password", copy_text: { text: pd.password }, style: "primary" }
            ],
            [{ text: "𖡛 Buka Panel", url: pd.domain.startsWith("http") ? pd.domain : "https://" + pd.domain, style: "success" }]
        ];

        try {
            await sendNewMessage(bot, order.userId, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
            console.log(`[SEND PANEL] ✅ Terkirim ke user ${order.userId}`);
            return true;
        } catch (e) {
            console.log(`[SEND PANEL] ❌ Gagal kirim ke user ${order.userId}:`, e.message);
            return false;
        }
    } catch (e) {
        console.log("[SEND PANEL BUYER ERR]", e.message);
        return false;
    }
}

// ═══ NOTIF CHANNEL + SHARP IMAGE ═══
async function sendNotifChannel(bot, order, fromUser, status) {
    try {
        const channelId = (cfg.ORDER && cfg.ORDER.ORDER_CHANNEL) || cfg.NOTIF_CHANNEL;
        if (!channelId) return;

        const buyerName = fromUser.first_name || "User";
        const buyerUsername = fromUser.username || "-";

        const imgBuf = await generateOrderCard({
            buyerName, buyerUsername,
            buyerId: order.buyerId || fromUser.id,
            itemName: order.label,
            harga: order.harga,
            timestamp: order.uploadedAt || order.createdAt || Date.now(),
            orderId: order.orderId,
            status
        });

        const caption =
            `<b>𖡛 ORDER ${status.toUpperCase()}</b>\n\n` +
            `${B} Order: <code>${order.orderId}</code>\n` +
            `${B} Nama: ${buyerName}\n` +
            `${B} Item: <b>${order.label}</b>\n` +
            `${B} Harga: <b>${rupiah(order.harga)}</b>`;

        if (imgBuf) {
            try {
                await sendNewPhoto(bot, channelId, imgBuf, { caption, parse_mode: "HTML" });
                return;
            } catch (e) { console.log("[NOTIF IMG ERR]", e.message); }
        }

        await sendNewMessage(bot, channelId, caption, { parse_mode: "HTML" });
    } catch (e) { console.log("[NOTIF CHANNEL ERR]", e.message); }
}

// ═══ STATS ═══
module.exports.getStats = () => readOrders().stats;

module.exports.statsHandler = async function (bot, msg, ctx) {
    try {
        if (String(msg.from.id) !== String(cfg.OWNER_ID)) return;
        const s = readOrders().stats;
        await bot.sendMessage(msg.chat.id,
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} ORDER STATS ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${B} Total: <code>${s.total}</code>\n` +
            `${B} Success: <code>${s.success}</code>\n` +
            `${B} Failed: <code>${s.failed}</code>\n` +
            `${B} Pending: <code>${s.pending}</code>\n` +
            `${B} Revenue: <b>${rupiah(s.revenue)}</b>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[ORDER STATS ERR]", e.message); }
};

// ═══ SCRIPT PACKAGES ═══
function getScriptPackages() {
    const s = cfg.SCRIPT || {};
    return {
        no_update: {
            label: s.no_update?.label || "Script No Update",
            harga: s.no_update?.harga || 10000,
            files: s.no_update?.files || [],
            groupLink: null,
            desc: s.no_update?.desc || "File script doang."
        },
        full_update: {
            label: s.full_update?.label || "Script Full Update",
            harga: s.full_update?.harga || 25000,
            files: s.full_update?.files || [],
            groupLink: s.full_update?.groupLink || null,
            desc: s.full_update?.desc || "Script + update + grup."
        },
        full_update_no_enc: {
            label: s.full_update_no_enc?.label || "Script Full Update + No Enc",
            harga: s.full_update_no_enc?.harga || 35000,
            files: s.full_update_no_enc?.files || [],
            groupLink: s.full_update_no_enc?.groupLink || null,
            desc: s.full_update_no_enc?.desc || "Script no enc + grup khusus."
        }
    };
}

// ═══ CALLBACK: order_script — pilih paket ═══
router.registerCallback("order_script", async (bot, q, data, user, ctx) => {
    try {
        const pkgKey = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);
        const pkgs = getScriptPackages();
        const pkg = pkgs[pkgKey];

        if (!pkg) return bot.answerCallbackQuery(q.id, { text: "Paket tidak valid", show_alert: true }).catch(() => {});

        return showScriptQris(bot, chatId, q.message.message_id, {
            userId, chatId,
            pkgKey,
            label: pkg.label,
            harga: pkg.harga,
            desc: pkg.desc,
            type: "script"
        }, ctx);
    } catch (e) { console.log("[ORDER SCRIPT ERR]", e.message); }
});

// ═══ SHOW SCRIPT QRIS ═══
async function showScriptQris(bot, chatId, msgId, data, ctx) {
    try {
        const o = cfg.ORDER || {};
        const orderId = genOrderId();
        const qrisUrl = o.QRIS_IMAGE || (cfg.FOTO && cfg.FOTO.QRIS) || "https://files.catbox.moe/d272b6.jpeg";

        const ord = readOrders();
        ord.pending[orderId] = {
            orderId,
            userId: data.userId,
            chatId: data.chatId,
            kategori: `script_${data.pkgKey}`,
            label: data.label,
            harga: data.harga,
            scope: "script",
            type: "script",
            pkgKey: data.pkgKey,
            ram: null,
            status: "waiting_payment",
            createdAt: Date.now(),
            buktiFileId: null
        };
        ord.stats.total += 1;
        writeOrders(ord);

        ctx.setState(String(data.userId), "order_await_bukti", { orderId });

        const caption =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${ST} PEMBAYARAN SCRIPT ${ST}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} DETAIL ORDER\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Order ID  ${AR}  <code>${orderId}</code>\n` +
            `${P} ${B} Paket     ${AR}  <b>${data.label}</b>\n` +
            `${P} ${B} Harga     ${AR}  <b>${rupiah(data.harga)}</b>\n` +
            `${P} ${B} Benefit   ${AR}  ${data.desc}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${D} CARA BAYAR\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Scan QRIS di atas\n` +
            `${P} ${B} Transfer sesuai nominal\n` +
            `${P} ${B} Kirim FOTO BUKTI ke chat ini\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `<i>${o.QRIS_NOTE || "Tunggu ACC owner (estimasi 1-30 menit)"}</i>`;

        const kb = [
            [{ text: "✕ Batalkan Order", callback_data: `order_cancel:${orderId}`, style: "danger" }],
            [{ text: "☰ Menu Utama", callback_data: "order_menu", style: "primary" }]
        ];

        let sent = false;

        try {
            await sendNewPhoto(bot, chatId, qrisUrl, {
                caption,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
            sent = true;
            console.log("[SHOW SCRIPT QRIS] ✅ terkirim permanen (bypass wrapper)");
        } catch (e) {
            console.log("[SHOW SCRIPT QRIS] sendNewPhoto fail:", e.message.slice(0, 120));
            try {
                await sendNewMessage(bot, chatId, caption, {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
                sent = true;
            } catch (e2) {
                console.log("[SHOW SCRIPT QRIS] fallback fail:", e2.message.slice(0, 120));
            }
        }

        if (sent && msgId) {
            try {
                await bot.editMessageText(
                    `<i>𖡛 Order berhasil dibuat — QRIS dikirim di bawah 👇</i>`,
                    { chat_id: chatId, message_id: msgId, parse_mode: "HTML" }
                );
            } catch {}
        }

        return sent;
    } catch (e) { console.log("[SHOW SCRIPT QRIS ERR]", e.message); }
}

// ═══ HANDLE SCRIPT ACC ═══
async function handleScriptAcc(bot, ownerChatId, ownerMsgId, order, dataOrd) {
    try {
        const pkgs = getScriptPackages();
        const pkg = pkgs[order.pkgKey];

        order.status = "approved";
        order.approvedAt = Date.now();

        const deliverResult = await deliverScript(bot, order, pkg);

        if (deliverResult.ok) {
            order.status = "success";
            dataOrd.stats.success += 1;
            dataOrd.stats.revenue += order.harga;
            if (dataOrd.stats.pending > 0) dataOrd.stats.pending -= 1;

            dataOrd.orders[order.orderId] = order;
            delete dataOrd.pending[order.orderId];
            writeOrders(dataOrd);

            await safeEdit(bot, ownerChatId, ownerMsgId,
                `${OK} <b>SCRIPT APPROVED</b>\n\n` +
                `${B} Order: <code>${order.orderId}</code>\n` +
                `${B} Paket: ${order.label}\n` +
                `${B} Data dikirim ke DM pembeli`,
                { parse_mode: "HTML" });

            await sendScriptNotifChannel(bot, order, "success");
        } else {
            order.status = "failed";
            order.error = deliverResult.error;
            dataOrd.orders[order.orderId] = order;
            delete dataOrd.pending[order.orderId];
            writeOrders(dataOrd);

            await safeEdit(bot, ownerChatId, ownerMsgId,
                `${X} <b>GAGAL KIRIM SCRIPT</b>\n\n` +
                `${B} Error: <code>${(deliverResult.error || "unknown").slice(0, 200)}</code>`,
                { parse_mode: "HTML" });

            await sendScriptNotifChannel(bot, order, "failed");
        }
    } catch (e) { console.log("[SCRIPT ACC ERR]", e.message); }
}

// ═══ DELIVER SCRIPT — PAKAI sendNewMessage + sendNewDocument ═══
async function deliverScript(bot, order, pkg) {
    try {
        const userId = order.userId;

        const caption =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${OK} SCRIPT DELIVERY ${OK}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} DETAIL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Order ID  ${AR}  <code>${order.orderId}</code>\n` +
            `${P} ${B} Paket     ${AR}  <b>${pkg.label}</b>\n` +
            `${P} ${B} Harga     ${AR}  <b>${rupiah(order.harga)}</b>\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +
            `${ST} <i>Simpan file & link di bawah ini.</i>`;

        const kb = [];
        if (pkg.groupLink) {
            kb.push([{ text: "𖡛 Join Group", url: pkg.groupLink, style: "success" }]);
        }

        await sendNewMessage(bot, userId, caption, {
            parse_mode: "HTML",
            reply_markup: kb.length > 0 ? { inline_keyboard: kb } : undefined
        });

        let sent = 0;
        for (const filePath of (pkg.files || [])) {
            try {
                if (!fs.existsSync(filePath)) continue;
                await sendNewDocument(bot, userId, filePath, {
                    caption: `𖡛 <b>${path.basename(filePath)}</b>`,
                    parse_mode: "HTML"
                });
                sent++;
            } catch (e) { console.log("[DELIVER FILE ERR]", e.message); }
        }

        return { ok: true, filesSent: sent };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══ NOTIF CHANNEL SCRIPT ═══
async function sendScriptNotifChannel(bot, order, status) {
    try {
        const channelId = (cfg.ORDER && cfg.ORDER.ORDER_CHANNEL) || cfg.NOTIF_CHANNEL;
        if (!channelId) return;

        const caption =
            `<b>𖡛 SCRIPT ${status.toUpperCase()}</b>\n\n` +
            `${B} Order: <code>${order.orderId}</code>\n` +
            `${B} Nama: ${order.buyerName || "-"}\n` +
            `${B} Paket: <b>${order.label}</b>\n` +
            `${B} Harga: <b>${rupiah(order.harga)}</b>`;

        await sendNewMessage(bot, channelId, caption, { parse_mode: "HTML" });
    } catch (e) { console.log("[SCRIPT NOTIF ERR]", e.message); }
}

console.log("[ORDER] v9 loaded — QRIS & delivery permanen (bot._request bypass)");