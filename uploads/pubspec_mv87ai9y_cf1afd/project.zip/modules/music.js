// ═══════════════════════════════════════════
// MUSIC — v8
// Multi-chain downloader + lyrics + cache
// FIX: yt-dlp portable binary auto-install
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const https = require("https");
const notify = require("./notify");
const { exec } = require("child_process");
const util = require("util");
const execAsync = util.promisify(exec);

const TMP_DIR = path.join(__dirname, "..", "tmp");
const CACHE_DIR = path.join(TMP_DIR, "music_cache");
const BIN_DIR = path.join(__dirname, "..", "bin");
const YTDLP_BIN = path.join(BIN_DIR, "yt-dlp");

if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });
if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
if (!fs.existsSync(BIN_DIR)) fs.mkdirSync(BIN_DIR, { recursive: true });

const MAX_AUDIO_MB = 45;
const MAX_AUDIO_BYTES = MAX_AUDIO_MB * 1024 * 1024;
const MIN_AUDIO_BYTES = 100 * 1024;
const MAX_DURATION_SEC = 360;
const MIN_DURATION_SEC = 15;
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;


// ═══════════════════════════════════════════
// UTIL
// ═══════════════════════════════════════════
function tmpPath(ext = "mp3") {
    return path.join(TMP_DIR, `${Date.now()}_${crypto.randomBytes(4).toString("hex")}.${ext}`);
}

function cacheKey(s) {
    return crypto.createHash("md5").update(String(s)).digest("hex");
}

function cleanOldCache() {
    try {
        const now = Date.now();
        for (const f of fs.readdirSync(CACHE_DIR)) {
            const p = path.join(CACHE_DIR, f);
            const st = fs.statSync(p);
            if (now - st.mtimeMs > CACHE_TTL_MS) fs.unlinkSync(p);
        }
    } catch {}
}

async function sendPhoto(bot, chatId, url, caption, keyboard, q = null) {
    if (typeof bot.sendRichMenu === "function") {
        return bot.sendRichMenu(chatId, url, caption, keyboard, q);
    }
    const reply_markup = keyboard ? { inline_keyboard: keyboard } : undefined;
    return bot.sendPhoto(chatId, url, { caption, parse_mode: "HTML", reply_markup });
}


// ═══════════════════════════════════════════
// HTTP CLIENT
// ═══════════════════════════════════════════
function makeClient(opts = {}) {
    return axios.create({
        timeout: opts.timeout || 90000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            ...(opts.headers || {})
        },
        validateStatus: s => s >= 200 && s < 400
    });
}

const httpClient = makeClient();
const httpLong = makeClient({ timeout: 300000 });
const httpFast = makeClient({ timeout: 25000 });

async function retry(fn, times = 3, delayMs = 800) {
    let lastErr;
    for (let i = 0; i < times; i++) {
        try { return await fn(); } catch (e) {
            lastErr = e;
            if (i < times - 1) await new Promise(r => setTimeout(r, delayMs * (i + 1)));
        }
    }
    throw lastErr;
}


// ═══════════════════════════════════════════
// DOWNLOAD BINARY — HTTPS FOLLOW REDIRECT
// ═══════════════════════════════════════════
function downloadBinary(url, dest, redirects = 5) {
    return new Promise((resolve, reject) => {
        if (redirects <= 0) return reject(new Error("Too many redirects"));

        https.get(url, {
            headers: { "User-Agent": "Mozilla/5.0 SpartaX/8.0" }
        }, (res) => {
            if (res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) {
                const loc = res.headers.location;
                if (!loc) return reject(new Error("Redirect tanpa location"));
                return downloadBinary(loc, dest, redirects - 1).then(resolve).catch(reject);
            }

            if (res.statusCode !== 200) {
                return reject(new Error(`HTTP ${res.statusCode}`));
            }

            const file = fs.createWriteStream(dest);
            res.pipe(file);
            file.on("finish", () => {
                file.close();
                resolve();
            });
            file.on("error", (e) => {
                try { fs.unlinkSync(dest); } catch {}
                reject(e);
            });
        }).on("error", (e) => {
            try { fs.unlinkSync(dest); } catch {}
            reject(e);
        });
    });
}


// ═══════════════════════════════════════════
// AUDIO VALIDATION
// ═══════════════════════════════════════════
function isValidAudio(buf) {
    if (!buf || buf.length < MIN_AUDIO_BYTES) return false;
    if (buf[0] === 0x49 && buf[1] === 0x44 && buf[2] === 0x33) return true;
    if (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0) return true;
    if (buf[4] === 0x66 && buf[5] === 0x74 && buf[6] === 0x79 && buf[7] === 0x70) return true;
    if (buf[0] === 0x4f && buf[1] === 0x67 && buf[2] === 0x67 && buf[3] === 0x53) return true;
    if (buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46) return true;
    return false;
}

async function probeDuration(filePath) {
    try {
        const cmd = `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${filePath}"`;
        const { stdout } = await execAsync(cmd, { timeout: 20000 });
        const dur = parseFloat(stdout.trim());
        return isNaN(dur) ? null : dur;
    } catch {
        return null;
    }
}


// ═══════════════════════════════════════════
// DOWNLOAD FROM URL
// ═══════════════════════════════════════════
async function downloadFromUrl(url, label) {
    try {
        console.log(`[MUSIC] GET ${label} ${url.slice(0, 90)}`);
        const res = await retry(() => httpLong.get(url, { responseType: "arraybuffer" }), 2, 700);
        const buf = Buffer.from(res.data);

        if (!isValidAudio(buf)) {
            console.log(`[MUSIC] ${label} invalid audio (${buf.length} b)`);
            return null;
        }

        const filePath = tmpPath("mp3");
        fs.writeFileSync(filePath, buf);

        const dur = await probeDuration(filePath);
        if (dur && (dur < MIN_DURATION_SEC || dur > MAX_DURATION_SEC)) {
            console.log(`[MUSIC] ${label} durasi ${dur}s di luar range`);
            try { fs.unlinkSync(filePath); } catch {}
            return null;
        }

        console.log(`[MUSIC] ✅ ${label} ${buf.length} b / ${dur ? dur.toFixed(1) + "s" : "?"}`);
        return { path: filePath, source: label, size: buf.length, duration: dur };
    } catch (e) {
        console.log(`[MUSIC] ${label} fail:`, e.message.slice(0, 120));
        return null;
    }
}


// ═══════════════════════════════════════════
// YT-DLP — PORTABLE BINARY AUTO-INSTALL
// ═══════════════════════════════════════════
let ytDlpChecked = false;
let ytDlpCmd = null;

async function ensureYtDlp() {
    if (ytDlpChecked) return ytDlpCmd;
    ytDlpChecked = true;

    // ═══ STEP 1: CEK BINARY PORTABLE LOKAL DULU ═══
    if (fs.existsSync(YTDLP_BIN)) {
        try {
            await execAsync(`chmod +x "${YTDLP_BIN}"`, { timeout: 5000 });
            const { stdout } = await execAsync(`"${YTDLP_BIN}" --version`, { timeout: 15000 });
            if (stdout.trim().match(/^\d+\./)) {
                ytDlpCmd = `"${YTDLP_BIN}"`;
                console.log(`[MUSIC] ✅ yt-dlp portable: ${stdout.trim()}`);
                return ytDlpCmd;
            }
        } catch (e) {
            console.log("[MUSIC] portable binary fail, re-download:", e.message.slice(0, 80));
            try { fs.unlinkSync(YTDLP_BIN); } catch {}
        }
    }

    // ═══ STEP 2: CEK SYSTEM CANDIDATES ═══
    const systemCandidates = [
        "yt-dlp",
        "/usr/local/bin/yt-dlp",
        "/usr/bin/yt-dlp",
        "$HOME/.local/bin/yt-dlp",
        "./node_modules/.bin/yt-dlp",
        "python3 -m yt_dlp",
        "python -m yt_dlp"
    ];

    for (const c of systemCandidates) {
        try {
            const { stdout } = await execAsync(`${c} --version`, { timeout: 15000 });
            if (stdout.trim().match(/^\d+\./)) {
                ytDlpCmd = c;
                console.log(`[MUSIC] ✅ yt-dlp system: ${c} (${stdout.trim()})`);
                return c;
            }
        } catch {}
    }

    // ═══ STEP 3: DOWNLOAD PORTABLE BINARY DARI GITHUB ═══
    console.log("[MUSIC] ── yt-dlp belum ada, download portable binary...");
    const urls = [
        "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp",
        "https://github.com/yt-dlp/yt-dlp/releases/download/2024.11.18/yt-dlp"
    ];

    for (const url of urls) {
        try {
            console.log(`[MUSIC] Download: ${url.slice(0, 90)}`);
            await downloadBinary(url, YTDLP_BIN);
            await execAsync(`chmod +x "${YTDLP_BIN}"`, { timeout: 10000 });

            const { stdout } = await execAsync(`"${YTDLP_BIN}" --version`, { timeout: 15000 });
            if (stdout.trim().match(/^\d+\./)) {
                ytDlpCmd = `"${YTDLP_BIN}"`;
                console.log(`[MUSIC] ✅ yt-dlp portable installed: ${stdout.trim()}`);
                return ytDlpCmd;
            } else {
                throw new Error("Version check fail: " + stdout.trim().slice(0, 50));
            }
        } catch (e) {
            console.log(`[MUSIC] download fail:`, e.message.slice(0, 120));
            try { fs.unlinkSync(YTDLP_BIN); } catch {}
        }
    }

    // ═══ STEP 4: FALLBACK PIP INSTALL (last resort) ═══
    console.log("[MUSIC] ── yt-dlp portable gagal, coba pip...");
    const pipCmds = [
        "pip3 install --user --upgrade yt-dlp",
        "pip install --user --upgrade yt-dlp",
        "python3 -m pip install --user --upgrade yt-dlp",
        "python -m pip install --user --upgrade yt-dlp"
    ];
    for (const cmd of pipCmds) {
        try {
            await execAsync(cmd, { timeout: 180000 });
            for (const c of ["$HOME/.local/bin/yt-dlp", "python3 -m yt_dlp", "python -m yt_dlp"]) {
                try {
                    const { stdout } = await execAsync(`${c} --version`, { timeout: 15000 });
                    if (stdout.trim().match(/^\d+\./)) {
                        ytDlpCmd = c;
                        console.log(`[MUSIC] ✅ yt-dlp via pip: ${c}`);
                        return c;
                    }
                } catch {}
            }
        } catch {}
    }

    console.log("[MUSIC] ❌ yt-dlp ga bisa diinstall — chain 9 disabled");
    return null;
}

async function downloadViaYtDlp(track) {
    const cmd = await ensureYtDlp();
    if (!cmd) return null;

    const query = `${track.title} ${track.artist?.name || ""} audio`;
    const stamp = Date.now();
    const outTpl = path.join(TMP_DIR, `ytdlp_${stamp}_%(id)s.%(ext)s`);

    const full = `${cmd} -x --audio-format mp3 --audio-quality 0 --no-playlist --no-warnings --no-check-certificates -o "${outTpl}" "ytsearch1:${query.replace(/"/g, "")}"`;
    console.log("[MUSIC] yt-dlp cmd:", full.slice(0, 180));

    try {
        await execAsync(full, { timeout: 240000, maxBuffer: 25 * 1024 * 1024 });

        const files = fs.readdirSync(TMP_DIR)
            .filter(f => f.startsWith(`ytdlp_${stamp}_`) && /\.(mp3|m4a|webm|opus|wav)$/i.test(f))
            .map(f => {
                const p = path.join(TMP_DIR, f);
                return { name: f, path: p, size: fs.statSync(p).size, mtime: fs.statSync(p).mtimeMs };
            })
            .sort((a, b) => b.mtime - a.mtime);

        if (files.length === 0) return null;
        const f = files[0];
        if (f.size < MIN_AUDIO_BYTES) { try { fs.unlinkSync(f.path); } catch {} return null; }

        const dur = await probeDuration(f.path);
        if (dur && (dur < MIN_DURATION_SEC || dur > MAX_DURATION_SEC)) {
            try { fs.unlinkSync(f.path); } catch {}
            return null;
        }

        console.log(`[MUSIC] ✅ yt-dlp ${f.size} b / ${dur ? dur.toFixed(1) + "s" : "?"}`);
        return { path: f.path, source: "yt-dlp", size: f.size, duration: dur };
    } catch (e) {
        console.log("[MUSIC] yt-dlp fail:", e.message.slice(0, 200));
        return null;
    }
}


// ═══ PIPED MIRRORS — Updated Nov 2025 ═══
const PIPED_MIRRORS = [
    "https://pipedapi.reallyaweso.me",
    "https://pipedapi.adminforge.de",
    "https://pipedapi.leptons.xyz",
    "https://pipedapi.ducks.party",
    "https://piped-api.lunar.icu",
    "https://pipedapi.astartes.nl",
    "https://pipedapi.orangenet.cc",
    "https://pipedapi.reallyaweso.me"
];

// ═══ INVIDIOUS MIRRORS — Updated Nov 2025 ═══
const INVIDIOUS_MIRRORS = [
    "https://inv.nadeko.net",
    "https://invidious.nerdvpn.de",
    "https://yewtu.be",
    "https://invidious.f5.si",
    "https://iv.melmac.space",
    "https://invidious.reallyaweso.me",
    "https://invidious.privacyredirect.com",
    "https://invidious.dhusch.de",
    "https://inv.zzls.xyz"
];

async function downloadViaPiped(query) {
    const q = encodeURIComponent(query);
    for (const base of PIPED_MIRRORS) {
        try {
            console.log(`[MUSIC] piped: ${base}`);
            const sr = await httpFast.get(`${base}/search?q=${q}&filter=music_songs`, { timeout: 20000 });
            const items = sr.data?.items;
            if (!Array.isArray(items) || !items[0]?.url) continue;

            const videoId = items[0].url.replace("/watch?v=", "");
            const sr2 = await httpFast.get(`${base}/streams/${videoId}`, { timeout: 20000 });
            const audios = (sr2.data?.audioStreams || []).filter(a => a.url);
            if (audios.length === 0) continue;

            audios.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
            const best = audios[0];

            const dl = await downloadFromUrl(best.url, `piped:${new URL(base).hostname}`);
            if (dl) return dl;
        } catch (e) {
            console.log(`[MUSIC] piped fail:`, e.message.slice(0, 80));
        }
    }
    return null;
}

async function downloadViaInvidious(query) {
    const q = encodeURIComponent(query);
    for (const base of INVIDIOUS_MIRRORS) {
        try {
            console.log(`[MUSIC] invidious: ${base}`);
            const sr = await httpFast.get(`${base}/api/v1/search?q=${q}&type=video`, { timeout: 20000 });
            if (!Array.isArray(sr.data) || !sr.data[0]?.videoId) continue;

            const vid = sr.data[0].videoId;
            const dl = await downloadFromUrl(`${base}/latest_version?id=${vid}&itag=140`, `invidious:${new URL(base).hostname}`);
            if (dl) return dl;
        } catch (e) {
            console.log(`[MUSIC] invidious fail:`, e.message.slice(0, 80));
        }
    }
    return null;
}


// ═══ COBALT INSTANCES — Updated Nov 2025 ═══
const COBALT_INSTANCES = [
    "https://cobalt-api.kwiatekmiki.com",
    "https://cobalt.255x.ru",
    "https://cobalt-api.ayo.tf",
    "https://cobalt-api.drgns.space",
    "https://api.cobalt.tools",
    "https://co.wuk.sh"
];

async function downloadViaCobalt(track) {
    const spotifyUrl = track.link || "";
    const youtubeQuery = `${track.title} ${track.artist?.name || ""}`.trim();

    const payloads = [
        { url: spotifyUrl, isAudioOnly: true, aFormat: "mp3", audioBitrate: "320", filenamePattern: "basic" },
        { url: spotifyUrl, isAudioOnly: true, aFormat: "mp3", filenamePattern: "basic" },
        { url: `ytsearch:${youtubeQuery}`, isAudioOnly: true, aFormat: "mp3" },
        { url: youtubeQuery, isAudioOnly: true, aFormat: "mp3" }
    ];

    for (const base of COBALT_INSTANCES) {
        for (const payload of payloads) {
            try {
                console.log(`[MUSIC] cobalt: ${base}`);
                const r = await httpFast.post(`${base}/api/json`, payload, {
                    headers: { "Content-Type": "application/json", "Accept": "application/json" },
                    timeout: 30000
                });
                const url = r.data?.url;
                if (!url) continue;
                const dl = await downloadFromUrl(url, `cobalt:${new URL(base).hostname}`);
                if (dl) return dl;
            } catch (e) {
                console.log(`[MUSIC] cobalt fail:`, e.message.slice(0, 80));
            }
        }
    }
    return null;
}


// ═══════════════════════════════════════════
// API INDONESIA
// ═══════════════════════════════════════════
async function downloadViaItzpire(spotifyUrl) {
    try {
        const r = await httpFast.get(`https://itzpire.com/download/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 30000 });
        const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.url || r.data?.url;
        if (!url) return null;
        return await downloadFromUrl(url, "itzpire");
    } catch { return null; }
}

async function downloadViaVreden(spotifyUrl) {
    try {
        const r = await httpFast.get(`https://api.vreden.my.id/api/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 30000 });
        const url = r.data?.result?.download || r.data?.result?.url || r.data?.data?.url;
        if (!url) return null;
        return await downloadFromUrl(url, "vreden");
    } catch { return null; }
}

async function downloadViaNexoracle(spotifyUrl) {
    try {
        const r = await httpFast.get(`https://api.nexoracle.com/downloader/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 30000 });
        const url = r.data?.result?.url || r.data?.result?.download || r.data?.data?.url;
        if (!url) return null;
        return await downloadFromUrl(url, "nexoracle");
    } catch { return null; }
}

async function downloadViaSiputzx(spotifyUrl) {
    try {
        const r = await httpFast.get(`https://api.siputzx.my.id/api/d/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 30000 });
        const url = r.data?.data?.download || r.data?.data?.url || r.data?.result?.download;
        if (!url) return null;
        return await downloadFromUrl(url, "siputzx");
    } catch { return null; }
}

async function downloadViaDelirius(spotifyUrl) {
    try {
        const r = await httpFast.get(`https://api.delirius.store/download/spotify?url=${encodeURIComponent(spotifyUrl)}`, { timeout: 30000 });
        const url = r.data?.data?.download || r.data?.result?.url || r.data?.data?.url;
        if (!url) return null;
        return await downloadFromUrl(url, "delirius");
    } catch { return null; }
}


// ═══════════════════════════════════════════
// LYRICS FETCHER
// ═══════════════════════════════════════════
async function fetchLyrics(title, artist) {
    const t = encodeURIComponent(title);
    const a = encodeURIComponent(artist);

    try {
        const r = await httpFast.get(`https://lrclib.net/api/get?track_name=${t}&artist_name=${a}`, { timeout: 15000 });
        if (r.data?.plainLyrics) return r.data.plainLyrics;
    } catch {}

    try {
        const r = await httpFast.get(`https://lrclib.net/api/search?q=${t}+${a}`, { timeout: 15000 });
        if (Array.isArray(r.data) && r.data[0]?.plainLyrics) return r.data[0].plainLyrics;
    } catch {}

    try {
        const r = await httpFast.get(`https://api.lyrics.ovh/v1/${a}/${t}`, { timeout: 15000 });
        if (r.data?.lyrics) return r.data.lyrics;
    } catch {}

    try {
        const r = await httpFast.get(`https://some-random-api.com/lyrics?title=${t}%20${a}`, { timeout: 15000 });
        if (r.data?.lyrics) return r.data.lyrics;
    } catch {}

    return null;
}


// ═══════════════════════════════════════════
// MAIN DOWNLOAD
// ═══════════════════════════════════════════
async function downloadFullAudio(track) {
    const title = track.title || "";
    const artist = track.artist?.name || "";
    const spotifyUrl = track.link || "";
    const query = `${title} ${artist}`.trim();

    const key = cacheKey(`spotify:${spotifyUrl || query}`);
    const cached = path.join(CACHE_DIR, `${key}.mp3`);
    if (fs.existsSync(cached)) {
        const st = fs.statSync(cached);
        console.log(`[MUSIC] ✅ cache hit ${st.size} b`);
        return { path: cached, source: "cache", size: st.size, duration: await probeDuration(cached), isCache: true };
    }

    const chains = [
        { name: "cobalt-pool",  fn: () => downloadViaCobalt(track) },
        { name: "itzpire",      fn: () => downloadViaItzpire(spotifyUrl) },
        { name: "vreden",       fn: () => downloadViaVreden(spotifyUrl) },
        { name: "nexoracle",    fn: () => downloadViaNexoracle(spotifyUrl) },
        { name: "siputzx",      fn: () => downloadViaSiputzx(spotifyUrl) },
        { name: "delirius",     fn: () => downloadViaDelirius(spotifyUrl) },
        { name: "piped",        fn: () => downloadViaPiped(query) },
        { name: "invidious",    fn: () => downloadViaInvidious(query) },
        { name: "yt-dlp",       fn: () => downloadViaYtDlp(track) }
    ];

    for (let i = 0; i < chains.length; i++) {
        const c = chains[i];
        try {
            console.log(`[MUSIC] ── chain ${i + 1}/${chains.length}: ${c.name}`);
            const result = await c.fn();
            if (result && result.path) {
                try {
                    fs.copyFileSync(result.path, cached);
                    result.path = cached;
                    result.isCache = true;
                    console.log(`[MUSIC] cached → ${key}.mp3`);
                } catch {}
                console.log(`[MUSIC] ✅ chain ${c.name} sukses`);
                return result;
            }
        } catch (e) {
            console.log(`[MUSIC] chain ${c.name} error:`, e.message.slice(0, 100));
        }
    }

    console.log("[MUSIC] ❌ semua chain gagal");
    return null;
}


// ═══════════════════════════════════════════
// HANDLERS
// ═══════════════════════════════════════════
router.registerCallback("menu_music", async (bot, q, data, user, ctx) => {
    const caption =
        `<b>𖡛 MUSIC</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Cari lagu & dapet file audio <b>FULL DURASI</b> + <b>LIRIK</b>.\n\n` +
        `𖡛 Support: <b>15 detik - 15 menit</b>\n` +
        `𖡛 Multi-sumber: <b>9 API + yt-dlp</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;
    await sendPhoto(bot, q.message.chat.id, cfg.FOTO.MUSIC || cfg.FOTO.MENU, caption, [
        [{ text: "𖡛 Search Lagu", callback_data: "music_search", style: "success" }],
        [{ text: "⬅️ Kembali", callback_data: "menu_back", style: "danger" }]
    ]);
});

router.registerCallback("music_search", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "music_search_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 SEARCH LAGU</b>\n\nKirim judul / artist:\nContoh: <code>Bruno Mars</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "𖡛 Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("music_search_await", async (bot, msg, state, ctx) => {
    const query = msg.text?.trim();
    if (!query) return;
    ctx.clearState(String(msg.from.id));

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cari "${query}"...</b>`, { parse_mode: "HTML" });

    try {
        let results = [];

        try {
            const sr = await httpFast.get(`https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=5`, { timeout: 15000 });
            if (sr.data?.data?.length) results = sr.data.data;
        } catch {}

        if (results.length === 0) {
            try {
                const sr = await httpFast.get(`https://itunes.apple.com/search?term=${encodeURIComponent(query)}&media=music&limit=5`, { timeout: 15000 });
                results = (sr.data?.results || []).map(r => ({
                    title: r.trackName,
                    artist: { name: r.artistName },
                    album: { title: r.collectionName, cover_xl: (r.artworkUrl100 || "").replace("100x100", "600x600") },
                    link: r.trackViewUrl,
                    duration: Math.round((r.trackTimeMillis || 0) / 1000)
                }));
            } catch {}
        }

        if (results.length === 0) {
            return bot.editMessageText(`<b>❌ Lagu "${query}" ga ditemukan.</b>`,
                { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        }

        const list = results.map((t, i) => {
            const dur = t.duration ? `${Math.floor(t.duration / 60)}:${String(t.duration % 60).padStart(2, "0")}` : "?";
            return `${i + 1}. <b>${t.title}</b> — ${t.artist.name} <i>(${dur})</i>`;
        }).join("\n");

        ctx.setState(String(msg.from.id), "music_pick", { results });

        await bot.editMessageText(
            `<b>𖡛 HASIL PENCARIAN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Query: <code>${query}</code>\n\n${list}\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            {
                chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML",
                reply_markup: { inline_keyboard: results.map((t, i) => [{ text: `${i + 1}. ${t.title.slice(0, 32)}`, callback_data: `music_pick:${i}` }]) }
            });
    } catch (e) {
        await bot.editMessageText(`<b>❌ Error:</b> <code>${e.message.slice(0, 150)}</code>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    }
});

router.registerCallback("music_pick", async (bot, q, data, user, ctx) => {
    const idx = parseInt(data.split(":")[1]);
    const st = ctx.getState(String(user.id));
    if (!st || !st.results || !st.results[idx]) {
        return bot.answerCallbackQuery(q.id, { text: "❌ Sesi habis", show_alert: true });
    }

    const track = st.results[idx];
    ctx.clearState(String(user.id));
    await bot.answerCallbackQuery(q.id, { text: "𖡛 Download audio full..." });

    const loading = await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 Download audio</b>\n\n` +
        `<b>${track.title}</b>\n` +
        `<i>${track.artist.name}</i>\n\n` +
        `▸ Mencari sumber full durasi...\n` +
        `▸ Chain 1/9: cobalt pool`,
        { parse_mode: "HTML" });

    const startAt = Date.now();
    const audio = await downloadFullAudio(track);
    const elapsed = ((Date.now() - startAt) / 1000).toFixed(1);

    await bot.deleteMessage(q.message.chat.id, loading.message_id).catch(() => {});

    if (audio && fs.existsSync(audio.path)) {
        await sendAudioResult(bot, q, track, audio, elapsed, ctx);
    } else {
        await sendFailure(bot, q, track);
    }
});

async function sendAudioResult(bot, q, track, audio, elapsed, ctx) {
    const stat = fs.statSync(audio.path);
    const sizeMB = stat.size / 1024 / 1024;

    if (stat.size > MAX_AUDIO_BYTES) {
        await bot.sendMessage(q.message.chat.id,
            `<b>⚠️ File ${sizeMB.toFixed(1)} MB > 45 MB</b>\n\n` +
            `<i>Lagu terlalu panjang buat Telegram bot. Coba lagu pendek atau pakai userbot.</i>`,
            { parse_mode: "HTML" });
        return;
    }

    const lyricsPromise = fetchLyrics(track.title, track.artist.name).catch(() => null);

    const durStr = audio.duration
        ? `${Math.floor(audio.duration / 60)}:${String(Math.floor(audio.duration % 60)).padStart(2, "0")}`
        : "?";

    const caption =
        `<b>𖡛 ${track.title}</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Artist</b>: ${track.artist.name}\n` +
        `𖡛 <b>Album</b>: ${track.album?.title || "-"}\n` +
        `𖡛 <b>Durasi</b>: <code>${durStr}</code>\n` +
        `𖡛 <b>Size</b>: <code>${sizeMB.toFixed(2)} MB</code>\n` +
        `𖡛 <b>Source</b>: <code>${audio.source}</code>\n` +
        `𖡛 <b>Waktu</b>: <code>${elapsed}s</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━`;

    try {
        await bot.sendAudio(q.message.chat.id, audio.path, {
            caption,
            parse_mode: "HTML",
            title: track.title,
            performer: track.artist.name,
            duration: audio.duration ? Math.floor(audio.duration) : undefined,
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𖡛 Buka di Spotify", url: track.link }]
                ].filter(r => r[0].url)
            }
        });

        const lyrics = await lyricsPromise;
        if (lyrics && lyrics.trim().length > 0) {
            const trimmed = lyrics.trim().slice(0, 3800);
            await bot.sendMessage(q.message.chat.id,
                `<b>𖡛 LIRIK — ${track.title}</b>\n\n` +
                `<pre>${trimmed.replace(/</g, "&lt;")}</pre>`,
                { parse_mode: "HTML" }).catch(() => {});
        }

        await notify.notifySuccess(bot, "MUSIC DOWNLOAD", [
            { label: "𖡛 User", value: q.from.first_name || "User" },
            { label: "𖡛 Lagu", value: track.title.slice(0, 30) },
            { label: "𖡛 Source", value: audio.source },
            { label: "𖡛 Size", value: sizeMB.toFixed(2) + " MB" },
            { label: "𖡛 Waktu", value: elapsed + "s" }
        ]).catch(() => {});

    } catch (e) {
        console.log("[MUSIC] sendAudio FAIL:", e.message);
        await bot.sendMessage(q.message.chat.id,
            `<b>❌ Gagal kirim audio:</b> <code>${e.message.slice(0, 200)}</code>`,
            { parse_mode: "HTML" });
    }
}

async function sendFailure(bot, q, track) {
    const ytSearch = `https://www.youtube.com/results?search_query=${encodeURIComponent(track.title + " " + track.artist.name)}`;
    const spotifySearch = `https://open.spotify.com/search/${encodeURIComponent(track.title + " " + track.artist.name)}`;

    try {
        await bot.sendPhoto(q.message.chat.id, track.album?.cover_xl || track.album?.cover_big, {
            caption:
                `<b>𖡛 ${track.title}</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `𖡛 <b>Artist</b>: ${track.artist.name}\n` +
                `𖡛 <b>Album</b>: ${track.album?.title || "-"}\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>⚠️ Semua 9 chain download gagal.</b>\n` +
                `<i>Kemungkinan server API eksternal down, atau lagu region-locked.</i>\n\n` +
                `<b>💡 Coba:</b>\n` +
                `▸ Install yt-dlp + ffmpeg di VPS (biar chain 9 always work)\n` +
                `▸ Coba lagu lain\n` +
                `▸ Buka link di bawah`,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "🎵 Cari di YouTube", url: ytSearch }],
                    [{ text: "𖡛 Buka di Spotify", url: spotifySearch }]
                ]
            }
        });
    } catch {
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 ${track.title}</b> — ${track.artist.name}\n𖡛 ${track.link}`,
            { parse_mode: "HTML" });
    }

    await notify.notifyFailed(bot, "MUSIC DOWNLOAD", [
        { label: "𖡛 User", value: q.from.first_name || "User" },
        { label: "𖡛 Lagu", value: track.title.slice(0, 30) },
        { label: "❌ Error", value: "semua chain gagal" }
    ]).catch(() => {});
}

setInterval(cleanOldCache, 30 * 60 * 1000);

module.exports = {
    downloadFullAudio,
    downloadViaYtDlp,
    downloadViaCobalt,
    downloadViaPiped,
    downloadViaInvidious,
    fetchLyrics,
    ensureYtDlp,
    probeDuration,
    downloadBinary
};
console.log("[MUSIC] module loaded (v8 — portable yt-dlp + multi-chain + lyrics + cache)");