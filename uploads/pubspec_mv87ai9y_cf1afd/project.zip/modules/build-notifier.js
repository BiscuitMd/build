// ═══════════════════════════════════════════
// BUILD NOTIFIER — Auto Generate Foto Live
// v2 — Anti EFATAL + Retry
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const sharp = require("sharp");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

const AVATAR_CACHE = path.join(TMP_DIR, "avatar_cache");
if (!fs.existsSync(AVATAR_CACHE)) fs.mkdirSync(AVATAR_CACHE, { recursive: true });

const THEMES = {
    processing: {
        label: "PROCESSING", c1: "#FCD34D", c2: "#F59E0B", c3: "#B45309",
        glow: "#FBBF24", accent: "#FEF3C7", text: "#78350F", subtext: "#92400E", icon: "⟳"
    },
    success: {
        label: "SUCCESS", c1: "#34D399", c2: "#10B981", c3: "#047857",
        glow: "#6EE7B7", accent: "#D1FAE5", text: "#064E3B", subtext: "#065F46", icon: "✓"
    },
    failed: {
        label: "FAILED", c1: "#F87171", c2: "#EF4444", c3: "#B91C1C",
        glow: "#FCA5A5", accent: "#FEE2E2", text: "#7F1D1D", subtext: "#991B1B", icon: "✕"
    }
};

function escXml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function truncate(s, max) {
    s = String(s || "");
    if (s.length <= max) return s;
    return s.slice(0, max - 1) + "…";
}

async function getUserAvatar(bot, userId) {
    const cacheFile = path.join(AVATAR_CACHE, `${userId}.jpg`);
    try {
        const stat = fs.statSync(cacheFile);
        if (Date.now() - stat.mtimeMs < 3600 * 1000) return fs.readFileSync(cacheFile);
    } catch {}

    try {
        const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
        if (!photos || !photos.photos || photos.photos.length === 0) return null;
        const fileId = photos.photos[0][0].file_id;
        const link = await bot.getFileLink(fileId);
        const res = await axios.get(link, { responseType: "arraybuffer", timeout: 15000 });
        const buf = Buffer.from(res.data);
        const resized = await sharp(buf).resize(256, 256, { fit: "cover" }).jpeg({ quality: 90 }).toBuffer();
        fs.writeFileSync(cacheFile, resized);
        return resized;
    } catch (e) {
        console.log("[AVATAR] fail:", userId, e.message);
        return null;
    }
}

async function generateBuildImage({
    bot, status = "processing", feature = "Build", baseName = "",
    user = {}, subtitle = "", fields = []
}) {
    const theme = THEMES[status] || THEMES.processing;
    const W = 1000, H = 640;

    let avatarBuffer = null;
    try { avatarBuffer = await getUserAvatar(bot, user.id); } catch {}
    const avatarB64 = avatarBuffer ? avatarBuffer.toString("base64") : null;

    const username = truncate(user.username ? `@${user.username}` : "-", 24);
    const fullName = truncate(user.first_name ? [user.first_name, user.last_name].filter(Boolean).join(" ") : "User", 28);
    const userId = truncate(String(user.id || "-"), 20);
    const baseDisplay = baseName ? truncate(baseName, 40) : "-";

    const fieldRows = (fields || []).slice(0, 5).map((f, i) => {
        const y = 460 + i * 32;
        return `
  <text x="80" y="${y}" font-family="'Segoe UI', Arial" font-size="14" fill="${theme.subtext}">${escXml(truncate(f.label, 22))}</text>
  <text x="${W - 80}" y="${y}" font-family="'Segoe UI', Arial" font-size="14" font-weight="bold" fill="${theme.text}" text-anchor="end">${escXml(truncate(String(f.value), 38))}</text>
  <line x1="80" y1="${y + 10}" x2="${W - 80}" y2="${y + 10}" stroke="${theme.c3}" stroke-width="1" opacity="0.15"/>
        `;
    }).join("");

    let avatarSvg = "";
    if (avatarB64) {
        avatarSvg = `
  <clipPath id="avatarClip"><circle cx="140" cy="200" r="60"/></clipPath>
  <circle cx="140" cy="200" r="63" fill="none" stroke="${theme.c2}" stroke-width="3"/>
  <circle cx="140" cy="200" r="69" fill="none" stroke="${theme.c3}" stroke-width="1" opacity="0.4"/>
  <image href="data:image/jpeg;base64,${avatarB64}" x="80" y="140" width="120" height="120" clip-path="url(#avatarClip)" preserveAspectRatio="xMidYMid slice"/>
  <circle cx="140" cy="200" r="60" fill="none" stroke="${theme.text}" stroke-width="1" opacity="0.3"/>
        `;
    } else {
        const initial = escXml((fullName[0] || "?").toUpperCase());
        avatarSvg = `
  <circle cx="140" cy="200" r="63" fill="none" stroke="${theme.c2}" stroke-width="3"/>
  <circle cx="140" cy="200" r="60" fill="${theme.accent}" opacity="0.6"/>
  <text x="140" y="225" font-family="'Segoe UI', Arial" font-size="52" font-weight="bold" fill="${theme.text}" text-anchor="middle">${initial}</text>
        `;
    }

    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${theme.c1}"/>
      <stop offset="50%" stop-color="${theme.c2}"/>
      <stop offset="100%" stop-color="${theme.c3}"/>
    </linearGradient>
    <radialGradient id="radial1" cx="50%" cy="30%" r="60%">
      <stop offset="0%" stop-color="${theme.accent}" stop-opacity="0.35"/>
      <stop offset="100%" stop-color="${theme.accent}" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="radial2" cx="80%" cy="80%" r="50%">
      <stop offset="0%" stop-color="${theme.glow}" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="${theme.glow}" stop-opacity="0"/>
    </radialGradient>
    <filter id="blur1"><feGaussianBlur stdDeviation="40"/></filter>
    <filter id="blur2"><feGaussianBlur stdDeviation="25"/></filter>
    <filter id="softShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="6"/>
      <feOffset dx="0" dy="4" result="offsetblur"/>
      <feComponentTransfer><feFuncA type="linear" slope="0.4"/></feComponentTransfer>
      <feMerge><feMergeNode/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bg)"/>
  <rect width="${W}" height="${H}" fill="url(#radial1)"/>
  <rect width="${W}" height="${H}" fill="url(#radial2)"/>
  <circle cx="150" cy="120" r="140" fill="${theme.glow}" opacity="0.5" filter="url(#blur1)"/>
  <circle cx="${W - 100}" cy="${H - 100}" r="180" fill="${theme.accent}" opacity="0.35" filter="url(#blur1)"/>
  <circle cx="${W - 200}" cy="100" r="80" fill="${theme.glow}" opacity="0.4" filter="url(#blur2)"/>
  <circle cx="100" cy="${H - 150}" r="100" fill="${theme.accent}" opacity="0.3" filter="url(#blur2)"/>
  <rect x="30" y="30" width="${W - 60}" height="${H - 60}" rx="28" fill="#FFFFFF" fill-opacity="0.18" stroke="${theme.accent}" stroke-width="1.5" stroke-opacity="0.5" filter="url(#softShadow)"/>
  <rect x="30" y="30" width="${W - 60}" height="6" rx="3" fill="${theme.text}" opacity="0.5"/>
  <text x="${W - 60}" y="75" font-family="'Segoe UI', Arial" font-size="13" font-weight="bold" fill="${theme.text}" text-anchor="end" opacity="0.7" letter-spacing="3">SPARTAX BUILD SYSTEM</text>
  <text x="60" y="75" font-family="'Segoe UI', Arial" font-size="13" font-weight="bold" fill="${theme.text}" opacity="0.7" letter-spacing="3">● LIVE</text>
  ${avatarSvg}
  <text x="230" y="180" font-family="'Segoe UI', Arial" font-size="22" font-weight="bold" fill="${theme.text}">${escXml(fullName)}</text>
  <text x="230" y="208" font-family="'Segoe UI', Arial" font-size="15" fill="${theme.subtext}">${escXml(username)}</text>
  <text x="230" y="232" font-family="'Segoe UI', Arial" font-size="13" fill="${theme.subtext}" opacity="0.8">ID: ${escXml(userId)}</text>
  <g transform="translate(${W / 2 - 160}, 290)">
    <rect x="0" y="0" width="320" height="80" rx="40" fill="${theme.text}" opacity="0.15"/>
    <rect x="0" y="0" width="320" height="80" rx="40" fill="none" stroke="${theme.text}" stroke-width="2" opacity="0.5"/>
    <circle cx="60" cy="40" r="22" fill="${theme.text}" opacity="0.9"/>
    <text x="60" y="50" font-family="'Segoe UI', Arial" font-size="26" font-weight="bold" fill="${theme.accent}" text-anchor="middle">${theme.icon}</text>
    <text x="100" y="49" font-family="'Segoe UI', Arial" font-size="26" font-weight="bold" fill="${theme.text}" letter-spacing="3">${theme.label}</text>
  </g>
  <text x="${W / 2}" y="410" font-family="'Segoe UI', Arial" font-size="20" font-weight="bold" fill="${theme.text}" text-anchor="middle" opacity="0.85" letter-spacing="1">${escXml(truncate(feature, 50))}</text>
  <text x="${W / 2}" y="440" font-family="'Segoe UI', Arial" font-size="15" font-weight="bold" fill="${theme.text}" text-anchor="middle" opacity="0.9">📦 ${escXml(baseDisplay)}</text>
  <line x1="80" y1="455" x2="${W - 80}" y2="455" stroke="${theme.text}" stroke-width="1" opacity="0.2"/>
  ${fieldRows}
  <text x="${W / 2}" y="${H - 20}" font-family="'Segoe UI', Arial" font-size="11" fill="${theme.text}" text-anchor="middle" opacity="0.6" letter-spacing="2">${escXml(truncate(subtitle || "spartax-bot", 80))}  ·  ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}</text>
</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
}

async function sendBuildNotif(bot, {
    status, feature, baseName = "", user, subtitle = "", fields = [], caption = null
}) {
    // Privasi: aktivitas Owner tidak pernah diposting ke channel build.
    if (user && String(user.id) === String(cfg.OWNER_ID)) {
        console.log("[BUILD NOTIF] skipped Owner activity for privacy");
        return;
    }
    const channelId = cfg.BUILD_LOG_CHANNEL || cfg.NOTIF_CHANNEL;
    if (!channelId || channelId === "-1001234567890") return;

    const theme = THEMES[status] || THEMES.processing;
    const userMention = `<a href="tg://user?id=${user.id}">${escXml(user.first_name || "User")}</a>`;

    const finalCaption = caption || (
        `<b>${theme.icon} ${theme.label}</b>\n\n` +
        `▸ <b>Fitur</b>: ${escXml(feature)}\n` +
        `▸ <b>Base</b>: <code>${escXml(baseName || "-")}</code>\n` +
        `▸ <b>User</b>: ${userMention}\n` +
        `▸ <b>Username</b>: ${escXml(user.username ? "@" + user.username : "-")}\n` +
        `▸ <b>ID</b>: <code>${user.id}</code>\n` +
        (subtitle ? `▸ <b>Info</b>: ${escXml(subtitle)}\n` : "")
    );

    // Retry max 2x
    for (let i = 1; i <= 2; i++) {
        try {
            const img = await generateBuildImage({ bot, status, feature, baseName, user, subtitle, fields });
            await bot.sendPhoto(channelId, img, { caption: finalCaption, parse_mode: "HTML" });
            console.log(`[BUILD NOTIF] ${status} → ${channelId} | base: ${baseName}`);
            return;
        } catch (e) {
            const m = e.message || "";
            console.log(`[BUILD NOTIF] attempt ${i}/2 fail:`, m.slice(0, 100));
            if (m.includes("EFATAL") || m.includes("AggregateError")) {
                await new Promise(r => setTimeout(r, 3000 * i));
                continue;
            }
            break;
        }
    }

    // Fallback text
    try {
        await bot.sendMessage(channelId,
            `<b>${theme.icon} ${theme.label}</b>\n\n` +
            `▸ Fitur: ${escXml(feature)}\n` +
            `▸ Base: <code>${escXml(baseName || "-")}</code>\n` +
            `▸ User: ${userMention} (${user.id})\n` +
            (subtitle ? `▸ ${escXml(subtitle)}` : ""),
            { parse_mode: "HTML" });
    } catch (e2) {
        console.log("[BUILD NOTIF] fallback fail:", e2.message.slice(0, 100));
    }
}

module.exports = { generateBuildImage, sendBuildNotif, THEMES };
console.log("[BUILD NOTIFIER] module loaded");