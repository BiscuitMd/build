// ═══════════════════════════════════════════
// BUILD PROMPT GENERATOR
// v2 — FIXED: anti-loop step + state clean
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch {}
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ ANTI-LOOP STATE HELPER ═══
// Cek apakah pesan yang masuk = duplikat dari pesan sebelumnya (user kirim 2x)
const lastMsgCache = new Map(); // userId -> { text, state, ts }

function isDuplicate(userId, text, stateName) {
    const key = String(userId);
    const prev = lastMsgCache.get(key);
    const now = Date.now();

    if (prev &&
        prev.text === text &&
        prev.state === stateName &&
        (now - prev.ts) < 3000) {   // dalam 3 detik
        return true;
    }

    lastMsgCache.set(key, { text, state: stateName, ts: now });
    return false;
}

// Bersihin cache lama
setInterval(() => {
    const now = Date.now();
    for (const [k, v] of lastMsgCache.entries()) {
        if (now - v.ts > 30000) lastMsgCache.delete(k);
    }
}, 30000);

// ═══ COMMON HANDLER WRAPPER ═══
function makeStepHandler({ stateName, nextStateName, fieldName, promptNext, validation }) {
    return async (bot, msg, state, ctx) => {
        try {
            const chatId = msg.chat.id;
            const userId = String(msg.from.id);
            const text = (msg.text || "").trim();

            // ⚡ Skip kalau command
            if (msg.text && msg.text.startsWith("/")) {
                ctx.clearState(userId);
                return;
            }

            // ⚡ Skip kalau kosong
            if (!text) return;

            // ⚡ Anti-duplicate — user kirim 2x pesan sama
            if (isDuplicate(userId, text, stateName)) {
                console.log("[BUILDPROMPT] duplicate input skipped:", userId, stateName);
                return;
            }

            // ⚡ Validasi opsional
            if (validation) {
                const err = validation(text);
                if (err) {
                    return bot.sendMessage(chatId,
                        `<b>✕ ${err}</b>\n\n<i>Kirim ulang:</i>`,
                        { parse_mode: "HTML" });
                }
            }

            // ⚡ Susun data baru — COPY field penting dari state lama
            const newData = {};
            // Copy field data lama yang bukan "state" atau "_*"
            for (const k of Object.keys(state || {})) {
                if (k !== "state" && k !== "_updatedAt" && !k.startsWith("_")) {
                    newData[k] = state[k];
                }
            }
            newData[fieldName] = text;
            newData._step = (state._step || 0) + 1;

            // ⚡ Kalau state terakhir → generate prompt
            if (!nextStateName) {
                ctx.clearState(userId);
                return await promptNext(bot, msg, newData, ctx);
            }

            // ⚡ Set state baru
            ctx.setState(userId, nextStateName, newData);

            // ⚡ Kirim prompt step berikutnya
            const nextPrompt = await promptNext(bot, msg, newData, ctx);
            return nextPrompt;
        } catch (e) {
            console.log(`[BUILDPROMPT ${stateName} ERR]`, e.message);
        }
    };
}

// ═══════════════════════════════════════════
// GENERATOR PROMPT — ROMBAK BASE
// ═══════════════════════════════════════════
function generateRombakPrompt(data) {
    const { theme, primaryColor, secondaryColor, buttonStyle, font, extra } = data;

    const fl = "flutter build apk";

    return `# ✦ PROMPT ROMBAK BASE — FLUTTER/DART

## ⚠️ ATURAN KETAT — WAJIB DIBACA

1. **JANGAN** ubah struktur file, folder, atau logic utama
2. **JANGAN** hapus function/widget yang sudah ada
3. **JANGAN** ubah nama class/function/variable
4. **JANGAN** tambah dependency baru tanpa alasan jelas
5. **JANGAN** ubah behavior — HANYA visual/UI yang berubah
6. **HASIL HARUS BISA DI-BUILD** — test \`${fl}\` wajib sukses
7. **PERTAHANKAN** format code — jangan di-minify
8. Setiap perubahan kasih komentar // MODIFIED: alasan

## ✦ TARGET ROMBAKAN

### 1. TEMA VISUAL
- **Tema**: ${theme || "Modern Dark Premium"}
- **Warna Primary**: ${primaryColor || "#7C3AED"}
- **Warna Secondary**: ${secondaryColor || "#F59E0B"}
- **Warna Background**: Dark gradient ke secondary
- **Warna Text**: Putih + aksen secondary

### 2. BUTTON STYLE
- **Bentuk**: ${buttonStyle || "Rounded (radius 12)"}
- **Warna**: Gradient primary → secondary
- **Shadow**: Soft glow (elevation 8)
- **Text**: Bold, uppercase

### 3. TYPOGRAPHY
- **Font**: ${font || "Poppins (Google Fonts)"}
- **Heading**: Bold 700, ukuran 24-32
- **Body**: Regular 400, ukuran 14-16

### 4. KOMPONEN YANG HARUS DIUBAH
- ✓ AppBar — warna primary, text white, elevation 0
- ✓ BottomNavBar — warna background dark, icon primary
- ✓ Card — radius 16, shadow soft
- ✓ Button — gradient, radius 12
- ✓ Input field — radius 12, border primary
- ✓ Icon — warna primary/secondary
- ✓ Dialog — background dark, radius 20
- ✓ Snackbar — background primary

### 5. ${extra ? `TAMBAHAN DARI USER:\n${extra}` : "TAMBAHAN: -\n"}

## ✦ FORMAT OUTPUT

Untuk setiap file yang diubah:

\`\`\`
✦ path/to/file.dart
MODIFIED: [alasan singkat]
\`\`\`

\`\`\`dart
// [kode lengkap file — JANGAN POTONG]
\`\`\`

## ✕ JANGAN LAKUIN INI

- ✕ Ubah nama file/folder
- ✕ Hapus import existing
- ✕ Ubah struktur widget tree
- ✕ Ubah state management
- ✕ Ubah routing
- ✕ Ubah logic API/database
- ✕ Ganti nama class/function
- ✕ Ubah dependency versi tanpa alasan

## ✓ HASIL YANG DIHARAPKAN

- Base Flutter/Dart dengan tema **${theme || "Modern Dark Premium"}**
- Warna **primary ${primaryColor || "#7C3AED"}** + **secondary ${secondaryColor || "#F59E0B"}**
- Button **${buttonStyle || "Rounded 12"}**
- Font **${font || "Poppins"}**
- **BUILD SUKSES** — tanpa error

## ✓ GOAL
Rombak visual base jadi kayak startup/profesional app.
JANGAN rusak fungsionalitas — HANYA tampilan yang berubah.`;
}

// ═══════════════════════════════════════════
// GENERATOR PROMPT — FIX ERROR
// ═══════════════════════════════════════════
function generateFixPrompt(data) {
    const { errorText, platform, targetBuild, additional } = data;

    const fl = "flutter build apk --release";
    const flTest = "flutter clean && flutter pub get && flutter build apk";

    return `# ✦ PROMPT FIX ERROR — FLUTTER/DART

## ⚠️ ATURAN KETAT

1. **JANGAN** hapus code untuk "hilangin error" — FIX asli
2. **JANGAN** comment out line yang error — benerin
3. **JANGAN** downgrade dependency tanpa alasan
4. **JANGAN** ubah logic utama
5. **HASIL HARUS BISA DI-BUILD** — test \`${fl}\` wajib sukses
6. **JELASIN** kenapa error + cara fix-nya
7. **KASIH** full code yang udah di-fix
8. **KALAU** butuh ubah config (pubspec, gradle, dll), kasih file lengkap

## ✦ ERROR YANG HARUS DI-FIX

\`\`\`
${errorText}
\`\`\`

## ✦ TARGET

- **Platform**: ${platform || "Android (Flutter)"}
- **Target Build**: ${targetBuild || fl}

## ✦ LANGKAH YANG HARUS DILAKUIN

1. **ANALISA** — identifikasi jenis error
2. **ROOT CAUSE** — cari penyebab UTAMA
3. **SOLUSI** — kasih fix yang bener
4. **VERIFIKASI** — pastiin setelah fix, build sukses
5. **KASIH** full code file yang diubah

## ✦ FORMAT OUTPUT

### 1. ANALISA ERROR
- Tipe error
- Penyebab
- File yang bermasalah

### 2. SOLUSI
Untuk setiap file yang perlu diubah:

\`\`\`
✦ path/to/file.dart
FIXED: [alasan singkat]
\`\`\`

\`\`\`dart
// [kode lengkap file — JANGAN POTONG]
\`\`\`

### 3. VERIFIKASI
- Cara test: \`${flTest}\`
- Harus sukses tanpa error

## ✕ JANGAN LAKUIN INI

- ✕ Hapus code biar error ilang
- ✕ Comment line error
- ✕ Ganti nama function/class tanpa alasan
- ✕ Ubah logic yang ga perlu
- ✕ Downgrade dependency
- ✕ Tinggalin placeholder // TODO

## ✓ HASIL YANG DIHARAPKAN

- Error **HILANG TOTAL**
- Build **SUKSES**
- Code **RAPI** dan **FUNGSIONAL**

${additional ? `## ✦ TAMBAHAN DARI USER\n${additional}\n` : ""}

## ✦ GOAL
Fix error **SAMPAI AKAR** — bukan tambal sulam.`;
}

// ═══════════════════════════════════════════
// BUTTON GO TO AI
// ═══════════════════════════════════════════
function buildAIAccessButtons(prompt) {
    const encodedPrompt = encodeURIComponent(prompt.slice(0, 1800));

    return [
        [
            { text: "✦ Buka ChatGPT", url: `https://chatgpt.com/?q=${encodedPrompt}`, style: "success" },
            { text: "✦ Buka Gemini", url: `https://gemini.google.com/app`, style: "primary" }
        ],
        [
            { text: "✦ Buka DeepSeek", url: `https://chat.deepseek.com/`, style: "primary" },
            { text: "✦ Buka Claude", url: `https://claude.ai/new`, style: "success" }
        ],
        [
            { text: "✦ Copy Prompt (lihat caption)", callback_data: "buildprompt_copied", style: "primary" },
            { text: "✕ Menu", callback_data: "menu_buildmenu", style: "danger" }
        ]
    ];
}

// ═══════════════════════════════════════════
// MENU BUILD PROMPT
// ═══════════════════════════════════════════
router.registerCallback("menu_buildprompt", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;

        const caption =
            `<b>𖡛 BUILD PROMPT GENERATOR</b>\n\n` +
            `<blockquote>` +
            `✦ <b>FITUR UTAMA</b>\n` +
            `    ▾ ✦ Prompt Rombak Base — generate prompt tema\n` +
            `    ▾ ✦ Prompt Fix Error — generate prompt fix\n` +
            `    ▾ ✦ Auto redirect ke GPT/Gemini/DeepSeek\n` +
            `    ▾ ✦ Copy paste langsung ke AI` +
            `</blockquote>\n\n` +
            `✦ <b><i>PILIH TIPE PROMPT:</i></b>`;

        const kb = [
            [
                { text: "✦ Prompt Rombak Base", callback_data: "buildprompt_rombak", style: "success" },
                { text: "✦ Prompt Fix Error", callback_data: "buildprompt_fix", style: "danger" }
            ],
            [
                { text: "✕ Kembali", callback_data: "menu_buildmenu", style: "danger" }
            ]
        ];

        await safeEdit(bot, chatId, q.message.message_id, caption, {
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) { console.log("[MENU BUILDPROMPT ERR]", e.message); }
});

// ═══════════════════════════════════════════
// PROMPT ROMBAK BASE — STEP 1
// ═══════════════════════════════════════════
router.registerCallback("buildprompt_rombak", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        ctx.clearState(userId);
        ctx.setState(userId, "buildprompt_rombak_theme", { _step: 1 });

        await safeEdit(bot, chatId, q.message.message_id,
            `<b>✦ PROMPT ROMBAK BASE — STEP 1/5</b>\n\n` +
            `<blockquote>` +
            `    ▸ Tema aplikasi lu apa?\n\n` +
            `    <b>Contoh:</b>\n` +
            `    ▸ Modern Dark Premium\n` +
            `    ▸ Minimalist White\n` +
            `    ▸ Neon Cyberpunk\n` +
            `    ▸ Pastel Cute\n` +
            `    ▸ Elegant Gold` +
            `</blockquote>\n\n` +
            `✦ <b>Kirim tema:</b>`,
            { reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[PROMPT ROMBAK ERR]", e.message); }
});

// ═══ STEP 1 → 2: TEMA ═══
router.registerMessage("buildprompt_rombak_theme",
    makeStepHandler({
        stateName: "buildprompt_rombak_theme",
        nextStateName: "buildprompt_rombak_primary",
        fieldName: "theme",
        validation: (text) => {
            if (text.length < 3) return "Tema terlalu pendek (min 3 karakter)";
            if (text.length > 60) return "Tema terlalu panjang (max 60 karakter)";
            return null;
        },
        promptNext: async (bot, msg, data) => {
            await bot.sendMessage(msg.chat.id,
                `<b>✦ PROMPT ROMBAK BASE — STEP 2/5</b>\n\n` +
                `<blockquote>` +
                `    ▸ Tema: <b>${escHtml(data.theme)}</b> ✓\n` +
                `    ▸ Warna primary?\n\n` +
                `    <b>Contoh:</b>\n` +
                `    ▸ #7C3AED (ungu)\n` +
                `    ▸ #3B82F6 (biru)\n` +
                `    ▸ #22C55E (hijau)\n` +
                `    ▸ #F59E0B (emas)\n` +
                `    ▸ #EF4444 (merah)` +
                `</blockquote>\n\n` +
                `✦ <b>Kirim warna primary (hex):</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
        }
    })
);

// ═══ STEP 2 → 3: PRIMARY COLOR ═══
router.registerMessage("buildprompt_rombak_primary",
    makeStepHandler({
        stateName: "buildprompt_rombak_primary",
        nextStateName: "buildprompt_rombak_secondary",
        fieldName: "primaryColor",
        validation: (text) => {
            if (!/^#?[0-9A-Fa-f]{6}$/.test(text.trim())) return "Format hex salah. Contoh: #7C3AED";
            return null;
        },
        promptNext: async (bot, msg, data) => {
            await bot.sendMessage(msg.chat.id,
                `<b>✦ PROMPT ROMBAK BASE — STEP 3/5</b>\n\n` +
                `<blockquote>` +
                `    ▸ Tema: <b>${escHtml(data.theme)}</b> ✓\n` +
                `    ▸ Primary: <b>${escHtml(data.primaryColor)}</b> ✓\n` +
                `    ▸ Warna secondary?\n\n` +
                `    <b>Contoh:</b>\n` +
                `    ▸ #F59E0B (emas)\n` +
                `    ▸ #EC4899 (pink)\n` +
                `    ▸ #06B6D4 (cyan)\n` +
                `    ▸ #FFFFFF (putih)` +
                `</blockquote>\n\n` +
                `✦ <b>Kirim warna secondary (hex):</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
        }
    })
);

// ═══ STEP 3 → 4: SECONDARY COLOR ═══
router.registerMessage("buildprompt_rombak_secondary",
    makeStepHandler({
        stateName: "buildprompt_rombak_secondary",
        nextStateName: "buildprompt_rombak_button",
        fieldName: "secondaryColor",
        validation: (text) => {
            if (!/^#?[0-9A-Fa-f]{6}$/.test(text.trim())) return "Format hex salah. Contoh: #F59E0B";
            return null;
        },
        promptNext: async (bot, msg, data) => {
            await bot.sendMessage(msg.chat.id,
                `<b>✦ PROMPT ROMBAK BASE — STEP 4/5</b>\n\n` +
                `<blockquote>` +
                `    ▸ Tema: <b>${escHtml(data.theme)}</b> ✓\n` +
                `    ▸ Primary: <b>${escHtml(data.primaryColor)}</b> ✓\n` +
                `    ▸ Secondary: <b>${escHtml(data.secondaryColor)}</b> ✓\n` +
                `    ▸ Button style?\n\n` +
                `    <b>Contoh:</b>\n` +
                `    ▸ Rounded radius 12\n` +
                `    ▸ Pill (radius 30)\n` +
                `    ▸ Square (radius 0)\n` +
                `    ▸ Gradient glow` +
                `</blockquote>\n\n` +
                `✦ <b>Kirim button style:</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
        }
    })
);

// ═══ STEP 4 → 5: BUTTON STYLE ═══
router.registerMessage("buildprompt_rombak_button",
    makeStepHandler({
        stateName: "buildprompt_rombak_button",
        nextStateName: "buildprompt_rombak_font",
        fieldName: "buttonStyle",
        promptNext: async (bot, msg, data) => {
            await bot.sendMessage(msg.chat.id,
                `<b>✦ PROMPT ROMBAK BASE — STEP 5/5</b>\n\n` +
                `<blockquote>` +
                `    ▸ Tema: <b>${escHtml(data.theme)}</b> ✓\n` +
                `    ▸ Primary: <b>${escHtml(data.primaryColor)}</b> ✓\n` +
                `    ▸ Secondary: <b>${escHtml(data.secondaryColor)}</b> ✓\n` +
                `    ▸ Button: <b>${escHtml(data.buttonStyle)}</b> ✓\n` +
                `    ▸ Font?\n\n` +
                `    <b>Contoh:</b>\n` +
                `    ▸ Poppins\n` +
                `    ▸ Inter\n` +
                `    ▸ Roboto\n` +
                `    ▸ Montserrat` +
                `</blockquote>\n\n` +
                `✦ <b>Kirim font:</b>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
        }
    })
);

// ═══ STEP 5 → GENERATE PROMPT ═══
router.registerMessage("buildprompt_rombak_font",
    makeStepHandler({
        stateName: "buildprompt_rombak_font",
        nextStateName: null,   // ⚡ null = selesai, generate prompt
        fieldName: "font",
        promptNext: async (bot, msg, data) => {
            const chatId = msg.chat.id;

            const prompt = generateRombakPrompt({
                theme: data.theme,
                primaryColor: data.primaryColor,
                secondaryColor: data.secondaryColor,
                buttonStyle: data.buttonStyle,
                font: data.font,
                extra: ""
            });

            const chunks = [];
            const maxLen = 3500;
            for (let i = 0; i < prompt.length; i += maxLen) {
                chunks.push(prompt.slice(i, i + maxLen));
            }

            await bot.sendMessage(chatId,
                `<b>✓ PROMPT ROMBAK BASE — SIAP!</b>\n\n` +
                `<blockquote>` +
                `    ▸ Tema: <b>${escHtml(data.theme)}</b> ✓\n` +
                `    ▸ Primary: <b>${escHtml(data.primaryColor)}</b> ✓\n` +
                `    ▸ Secondary: <b>${escHtml(data.secondaryColor)}</b> ✓\n` +
                `    ▸ Button: <b>${escHtml(data.buttonStyle)}</b> ✓\n` +
                `    ▸ Font: <b>${escHtml(data.font)}</b> ✓` +
                `</blockquote>\n\n` +
                `✦ <b>COPY prompt di bawah ini</b> — kirim ke AI pilihan lu:`,
                { parse_mode: "HTML" });

            for (let i = 0; i < chunks.length; i++) {
                await bot.sendMessage(chatId,
                    `<pre>${escHtml(chunks[i])}</pre>`,
                    { parse_mode: "HTML" });
            }

            await bot.sendMessage(chatId,
                `✦ <b>PILIH AI:</b>\n\n` +
                `▸ Copy prompt di atas\n` +
                `▸ Buka GPT/Gemini/DeepSeek\n` +
                `▸ Paste prompt\n` +
                `▸ Tunggu hasil`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: buildAIAccessButtons(prompt) } });
        }
    })
);

// ═══════════════════════════════════════════
// PROMPT FIX ERROR
// ═══════════════════════════════════════════
router.registerCallback("buildprompt_fix", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        ctx.clearState(userId);
        ctx.setState(userId, "buildprompt_fix_error", { _step: 1 });

        await safeEdit(bot, chatId, q.message.message_id,
            `<b>✦ PROMPT FIX ERROR — STEP 1/1</b>\n\n` +
            `<blockquote>` +
            `    ▸ Kirim <b>error log</b> dari build\n` +
            `    ▸ Bisa text atau file .txt\n` +
            `    ▸ Copy lengkap dari terminal` +
            `</blockquote>\n\n` +
            `✦ <b>Kirim error:</b>\n` +
            `<i>Contoh: Compiler message: 'xxx' is not defined</i>`,
            { reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildprompt_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[PROMPT FIX ERR]", e.message); }
});

router.registerMessage("buildprompt_fix_error", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        let errorText = "";
        const platform = "Android (Flutter)";
        const targetBuild = "flutter build apk --release";

        if (msg.text && msg.text.startsWith("/")) { ctx.clearState(userId); return; }

        if (msg.document) {
            if (msg.document.file_size > 500 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 500KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const axios = require("axios");
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                errorText = String(res.data).slice(0, 5000);
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            errorText = msg.text.trim();
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim error text atau file.</b>`, { parse_mode: "HTML" });
        }

        if (errorText.length < 10) {
            return bot.sendMessage(chatId, `<b>✕ Error text terlalu pendek.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);

        const prompt = generateFixPrompt({
            errorText,
            platform,
            targetBuild,
            additional: ""
        });

        const chunks = [];
        const maxLen = 3500;
        for (let i = 0; i < prompt.length; i += maxLen) {
            chunks.push(prompt.slice(i, i + maxLen));
        }

        await bot.sendMessage(chatId,
            `<b>✓ PROMPT FIX ERROR — SIAP!</b>\n\n` +
            `<blockquote>` +
            `    ▸ Error: <b>${escHtml(errorText.slice(0, 100))}...</b>\n` +
            `    ▸ Platform: <b>${escHtml(platform)}</b>\n` +
            `    ▸ Target: <b>${escHtml(targetBuild)}</b>` +
            `</blockquote>\n\n` +
            `✦ <b>COPY prompt di bawah ini</b> — kirim ke AI pilihan lu:`,
            { parse_mode: "HTML" });

        for (let i = 0; i < chunks.length; i++) {
            await bot.sendMessage(chatId,
                `<pre>${escHtml(chunks[i])}</pre>`,
                { parse_mode: "HTML" });
        }

        await bot.sendMessage(chatId,
            `✦ <b>PILIH AI:</b>\n\n` +
            `▸ Copy prompt di atas\n` +
            `▸ Buka GPT/Gemini/DeepSeek\n` +
            `▸ Paste prompt\n` +
            `▸ Tunggu hasil fix`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: buildAIAccessButtons(prompt) } });
    } catch (e) { console.log("[PROMPT FIX ERROR ERR]", e.message); }
});

// ═══ CALLBACK — COPY ═══
router.registerCallback("buildprompt_copied", async (bot, q, data, user, ctx) => {
    try {
        await bot.answerCallbackQuery(q.id, { text: "✓ Prompt siap di-copy dari chat", show_alert: true });
    } catch (e) {}
});

// ═══ CALLBACK — CANCEL ═══
router.registerCallback("buildprompt_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) {}
});

module.exports = {};
console.log("[BUILD PROMPT] module loaded — v2 anti-loop step");