// ═══════════════════════════════════════════
// TOOLS — Menu Tools Bot
// v3 — FIXED: syntax error + semua handler utuh
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const notify = require("./notify");
// Tools are private-user features: suppress channel notifications from this module.
notify.notifySuccess = async () => {};
notify.notifyFailure = async () => {};
const crypto = require("crypto");
const sharp = require("sharp");

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function tmpPath(ext = "jpg") {
    return path.join(TMP_DIR, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`);
}

async function downloadFile(url, dest, referer = "") {
    const res = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 180000,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
            ...(referer ? { "Referer": referer } : {})
        }
    });
    fs.writeFileSync(dest, Buffer.from(res.data));
    return dest;
}

function errorMsg(e) {
    if (e.code === "ECONNABORTED") return "Server API timeout";
    if (e.code === "ENOTFOUND") return "Ga bisa akses API";
    if (e.code === "ECONNREFUSED") return "Koneksi ditolak";
    if (e.response?.status) return `HTTP ${e.response.status}`;
    return e.message || "Unknown error";
}

function escapeXml(s) {
    return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}

// ═══ SAFE EDIT (anti-stuck) ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch {}
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ SAFE SEND PHOTO (anti-stuck) ═══
async function sendPhoto(bot, chatId, url, caption, keyboard, q = null) {
    if (typeof bot.sendRichMenu === "function") {
        return bot.sendRichMenu(chatId, url, caption, keyboard, q);
    }
    const reply_markup = keyboard ? { inline_keyboard: keyboard } : undefined;
    return bot.sendPhoto(chatId, url, { caption, parse_mode: "HTML", reply_markup });
}

// ═══════════════════════════════════════════
// MENU TOOLS
// ═══════════════════════════════════════════

/* ═══════════════════════════════════════
   RICH MESSAGE • MENU TOOLS
   UI refresh — callback fitur dipertahankan
═══════════════════════════════════════ */

router.registerCallback("menu_tools", async (bot, q, data, user, ctx) => {
    const caption =
        `<b>✦ MULTI FUNGSI · TOOLS CENTER</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Selamat datang di pusat tools!\n` +
        `Pilih fitur yang ingin kamu gunakan.\n\n` +
        `✧ <b>TOOLS GRATIS</b>\n` +
        `<i>Praktis • Cepat • Mudah digunakan</i>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<blockquote>Gunakan tombol di bawah untuk membuka fitur pilihanmu.</blockquote>\n` +
        `<i>Powered by MULTI FUNGSI</i>`;

    const keyboard = [
        [
            { text: "☁️ Cek Cuaca", callback_data: "tool_cuaca", style: "success" },
            { text: "🕌 Jam Sholat", callback_data: "tool_sholat", style: "success" }
        ],
        [
            { text: "🪪 Cek ID", callback_data: "menu_cekid", style: "primary" },
            { text: "💬 Fake Chat", callback_data: "menu_fakechat", style: "primary" }
        ],
        [
            { text: "📥 Downloader", callback_data: "tool_downloader", style: "primary" },
            { text: "🎨 Brat Sticker", callback_data: "tool_brat", style: "primary" }
        ],
        [
            { text: "🖼️ HD Upscale", callback_data: "tool_hd", style: "success" },
            { text: "⚡ Cek Ping", callback_data: "tool_ping", style: "success" }
        ],
        [
            { text: "📨 Spam NGL", callback_data: "tool_ngl", style: "primary" },
            { text: "🌸 Anime AI", callback_data: "tool_anime", style: "primary" }
        ],
        [
            { text: "🔎 OSINT Publik", callback_data: "tool_osint_public", style: "primary" },
            { text: "📍 Google Maps", callback_data: "tool_maps_search", style: "success" }
        ],
        [
            { text: "🔗 Image to Link", callback_data: "menu_filetolink", style: "primary" },
            { text: "🔤 Text Styler", callback_data: "tool_textstyler", style: "primary" }
        ],
        [
            { text: "📣 Reach Channel", callback_data: "menu_reactemoji", style: "success" },
            { text: "🎨 Generator DANA (Demo)", callback_data: "tool_dana_generator", style: "primary" }
        ],
        [
            { text: "‹ Kembali ke Menu", callback_data: "menu_back", style: "danger" }
        ]
    ];

    try {
        await sendPhoto(
            bot,
            q.message.chat.id,
            cfg.FOTO.TOOLS || cfg.FOTO.MENU,
            caption,
            keyboard,
            q
        );
    } catch (e) {
        console.log("[RICH MENU TOOLS ERR]", e.message);
    }
});


// ═══════════════════════════════════════════
// PRIVATE TEXT-ONLY PROMO RICH MESSAGE BUILDER — no photo or image URL.
router.registerCallback("menu_promotext", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "promo_text_await", {});
    await bot.sendMessage(q.message.chat.id, `<h2>✦ PEMBUAT PROMOSI</h2><p><b>1/4</b> Kirim caption promosi yang ingin ditampilkan.</p><p><i>Hasil berupa Rich Message teks saja — tanpa foto dan tanpa link gambar.</i></p>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});
router.registerMessage("promo_text_await", async (bot, msg, state, ctx) => {
    const body = String(msg.text || "").trim();
    if (!body) return bot.sendMessage(msg.chat.id, "Kirim teks promosi biasa, bukan file.");
    ctx.setState(String(msg.from.id), "promo_product_await", { body: body.slice(0, 3000) });
    await bot.sendMessage(msg.chat.id, `<b>2/4 Produk atau jasa yang dijual</b>\nContoh: bot build, bot multifungsi, jasa pembuatan website, panel hosting, atau aplikasi Android.`, { parse_mode: "HTML" });
});
router.registerMessage("promo_product_await", async (bot, msg, state, ctx) => {
    const product = String(msg.text || "").trim().slice(0, 120);
    if (!product) return bot.sendMessage(msg.chat.id, "Kirim nama produk atau jasa yang dijual.");
    const low = product.toLowerCase();
    let details = "Layanan ini dirancang untuk membantu kebutuhan pengguna dengan proses yang lebih praktis, informasi yang jelas, serta dukungan sesuai paket yang ditawarkan.";
    if (/bot build|build bot|bot multifungsi|telegram bot/.test(low)) details = "Layanan pembuatan bot Telegram dengan fitur sesuai kebutuhan, menu interaktif, otomasi tugas, pengelolaan perintah, serta opsi penyesuaian tampilan dan alur kerja. Fitur akhir mengikuti paket dan spesifikasi yang disepakati.";
    else if (/panel|hosting|pterodactyl/.test(low)) details = "Layanan panel/hosting untuk menjalankan aplikasi atau bot, dengan pengaturan resource sesuai paket, pengelolaan server, serta bantuan konfigurasi dasar sesuai ketentuan penjual.";
    else if (/website|web/.test(low)) details = "Jasa pembuatan website dengan tampilan responsif, struktur halaman yang rapi, dan fitur sesuai kebutuhan. Detail desain, integrasi, dan pemeliharaan mengikuti kesepakatan paket.";
    else if (/android|apk|aplikasi/.test(low)) details = "Jasa pembuatan aplikasi Android dengan fitur dan tampilan sesuai spesifikasi, pengujian dasar, serta panduan build atau pemasangan sesuai paket.";
    ctx.setState(String(msg.from.id), "promo_owner_await", { ...state, product, details });
    await bot.sendMessage(msg.chat.id, `<b>3/4 Username owner</b>\nKirim username owner, contoh <code>@biscuitMD</code>.`, { parse_mode: "HTML" });
});
router.registerMessage("promo_owner_await", async (bot, msg, state, ctx) => {
    const owner = String(msg.text || "").trim().replace(/^https?:\/\/(?:www\.)?t\.me\//i, "").replace(/^@/, "").split(/[/?#\s]/)[0];
    if (!/^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(owner)) return bot.sendMessage(msg.chat.id, "Username owner tidak valid. Kirim format <code>@username</code>.", { parse_mode: "HTML" });
    ctx.setState(String(msg.from.id), "promo_target_await", { ...state, owner: "@" + owner });
    await bot.sendMessage(msg.chat.id, `<b>4/4 Username channel</b>\nKirim <code>@username</code> atau <code>https://t.me/username</code>.`, { parse_mode: "HTML" });
});
router.registerMessage("promo_target_await", async (bot, msg, state, ctx) => {
    const raw = String(msg.text || "").trim();
    const target = raw.replace(/^https?:\/\/(?:www\.)?(?:t\.me|telegram\.me)\//i, "").replace(/^@/, "").split(/[/?#\s]/)[0].trim();
    if (!/^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(target)) return bot.sendMessage(msg.chat.id, "Username channel tidak valid. Contoh: <code>@testilyd</code>.", { parse_mode: "HTML" });
    const esc = v => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\"/g,"&quot;");
    const html = `<h1>✦ PESAN PROMOSI</h1><blockquote>${esc(state.body).replace(/\r?\n/g,"<br/>")}</blockquote><hr/><h2>✦ Tentang Produk</h2><p><b>${esc(state.product || "Produk/Jasa")}</b></p><p>${esc(state.details || "Detail produk mengikuti spesifikasi penjual.")}</p><hr/><p>👤 <b>Owner:</b> ${esc(state.owner)}</p><p>📢 <b>Channel:</b> ${esc("@" + target)}</p><footer>Rich Message · Dibuat secara privat oleh MULTI FUNGSI</footer>`;
    const kb = [[{ text: `👤 Owner ${state.owner}`, url: `https://t.me/${state.owner.slice(1)}`, style: "primary" }], [{ text: `📢 Channel @${target}`, url: `https://t.me/${target}`, style: "success" }], [{ text: "↻ Buat Promosi Lagi", callback_data: "menu_promotext" }]];
    try {
        if (typeof bot.sendRichMessage === "function") await bot.sendRichMessage(msg.chat.id, html, { reply_markup: { inline_keyboard: kb } });
        else await bot.sendMessage(msg.chat.id, html, { parse_mode: "HTML", disable_web_page_preview: true, reply_markup: { inline_keyboard: kb } });
        ctx.clearState(String(msg.from.id));
    } catch (e) {
        console.log("[PROMO TEXT BUILDER]", e.message);
        await bot.sendMessage(msg.chat.id, `Gagal membuat Rich Message.\n<code>${esc(e.message)}</code>`, { parse_mode: "HTML" });
    }
});

// CREATE SCRIPT PROMPT — Rich Message text with a selectable/copyable prompt block.
router.registerCallback("menu_create_script_prompt", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "scriptprompt_name_await", {});
    await bot.sendMessage(q.message.chat.id, `<h2>✦ CREATE SCRIPT · RICH MESSAGE</h2><p><b>1/4</b> Kirim nama script.</p>`, { parse_mode: "HTML" });
});
router.registerMessage("scriptprompt_name_await", async (bot, msg, state, ctx) => {
    const name = String(msg.text || "").trim().slice(0, 80);
    if (!name) return bot.sendMessage(msg.chat.id, "Nama script tidak boleh kosong.");
    ctx.setState(String(msg.from.id), "scriptprompt_features_await", { name });
    await bot.sendMessage(msg.chat.id, `<b>2/4</b> Jelaskan fitur script yang diinginkan. Jangan masukkan token/password.`, { parse_mode: "HTML" });
});
router.registerMessage("scriptprompt_features_await", async (bot, msg, state, ctx) => {
    const features = String(msg.text || "").trim().slice(0, 1800);
    if (!features) return bot.sendMessage(msg.chat.id, "Kirim deskripsi fitur script.");
    ctx.setState(String(msg.from.id), "scriptprompt_runtime_await", { ...state, features });
    await bot.sendMessage(msg.chat.id, `<b>3/4</b> Script dijalankan via apa? Contoh: terminal, Telegram Bot API, Express, atau CLI.`, { parse_mode: "HTML" });
});
router.registerMessage("scriptprompt_runtime_await", async (bot, msg, state, ctx) => {
    const runtime = String(msg.text || "").trim().slice(0, 120);
    if (!runtime) return bot.sendMessage(msg.chat.id, "Kirim runtime/cara menjalankan script.");
    ctx.setState(String(msg.from.id), "scriptprompt_language_await", { ...state, runtime });
    await bot.sendMessage(msg.chat.id, `<b>4/4</b> Pilih bahasa dengan mengirim <code>node</code> atau <code>py</code>.`, { parse_mode: "HTML" });
});
router.registerMessage("scriptprompt_language_await", async (bot, msg, state, ctx) => {
    const language = String(msg.text || "").trim().toLowerCase();
    if (!["node", "py", "python"].includes(language)) return bot.sendMessage(msg.chat.id, `Kirim <code>node</code> atau <code>py</code>.`, { parse_mode: "HTML" });
    const lang = language === "node" ? "Node.js" : "Python";
    const esc = v => String(v ?? "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    const prompt = `Buat script bernama "${state.name}" menggunakan ${lang}.\nFitur yang diminta:\n${state.features}\n\nRuntime/cara menjalankan: ${state.runtime}\n\nPersyaratan: kode modular dan siap dijalankan, validasi input, penanganan error, logging aman, README instalasi dan cara menjalankan. Jangan hardcode token/password. Gunakan API/library stabil yang sesuai. Jika Rich Message tidak didukung endpoint/library, sediakan fallback HTML biasa.`;
    const html = `<h1>✦ SCRIPT SPECIFICATION</h1><p><b>Nama:</b> ${esc(state.name)}</p><p><b>Bahasa:</b> ${lang}</p><p><b>Via run:</b> ${esc(state.runtime)}</p><hr/><h2>Fitur</h2><p>${esc(state.features).replace(/\n/g,"<br/>")}</p><hr/><h2>📋 PROMPT SIAP DISALIN</h2><pre>${esc(prompt)}</pre><p>Tekan dan tahan blok prompt di atas untuk menyalin teksnya.</p><footer>Generated privately · MULTI FUNGSI</footer>`;
    ctx.clearState(String(msg.from.id));
    const kb = [[{ text: "↻ Buat Lagi", callback_data: "menu_create_script_prompt", style: "primary" }]];
    if (typeof bot.sendRichMessage === "function") await bot.sendRichMessage(msg.chat.id, html, { reply_markup: { inline_keyboard: kb } });
    else await bot.sendMessage(msg.chat.id, html, { parse_mode: "HTML", disable_web_page_preview: true, reply_markup: { inline_keyboard: kb } });
    // Telegram doesn't expose a universal clipboard callback. For long prompts, attach a .txt file
    // so the complete prompt can be opened/copied without message truncation.
    if (prompt.length > 2800) {
        await bot.sendDocument(msg.chat.id, Buffer.from(prompt, "utf8"), {
            filename: `script-prompt-${String(state.name).replace(/[^a-z0-9_-]/gi, "_").slice(0, 40) || "spec"}.txt`,
            caption: `<b>📄 Prompt lengkap siap disalin</b>
${prompt.length} karakter · UTF-8`,
            parse_mode: "HTML"
        });
    }
});

// Generator DANA hanya untuk visual konsep/demo, bukan bukti transaksi atau pembayaran asli.
router.registerCallback("tool_dana_generator", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "tool_dana_demo_await", {});
    await bot.sendMessage(q.message.chat.id, `<h2>🎨 GENERATOR VISUAL DANA · DEMO</h2><p>Kirim nominal untuk membuat kartu konsep. Hasil diberi label DEMO dan bukan bukti pembayaran.</p><p>Contoh: <code>25000</code></p>`, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "‹ Kembali ke Tools", callback_data: "menu_tools", style: "danger" }]] } });
});
router.registerMessage("tool_dana_demo_await", async (bot, msg, state, ctx) => {
    const raw = String(msg.text || "").replace(/[^0-9]/g, "");
    const nominal = Number(raw);
    if (!Number.isSafeInteger(nominal) || nominal < 1 || nominal > 1000000000) return bot.sendMessage(msg.chat.id, "Nominal tidak valid. Kirim angka, contoh 25000.");
    const rupiah = nominal.toLocaleString("id-ID");
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="520"><rect width="900" height="520" rx="42" fill="#0878e8"/><text x="60" y="100" font-size="48" fill="white" font-family="Arial" font-weight="bold">DANA · KONSEP DEMO</text><text x="60" y="220" font-size="30" fill="white" font-family="Arial">Nominal contoh</text><text x="60" y="300" font-size="64" fill="white" font-family="Arial" font-weight="bold">Rp ${rupiah}</text><rect x="55" y="360" width="790" height="95" rx="18" fill="#ffffff" opacity=".18"/><text x="450" y="420" text-anchor="middle" font-size="38" fill="#ffffff" font-family="Arial" font-weight="bold">BUKAN BUKTI PEMBAYARAN</text></svg>`;
    try {
        const buf = await sharp(Buffer.from(svg)).png().toBuffer();
        await bot.sendPhoto(msg.chat.id, buf, { caption: `<b>🎨 Visual konsep DANA</b>\nNominal contoh: <b>Rp ${rupiah}</b>\n<i>DEMO — tidak menunjukkan transaksi nyata.</i>`, parse_mode: "HTML" });
    } catch (e) { console.log("[DANA DEMO]", e.message); await bot.sendMessage(msg.chat.id, `Visual demo DANA\nNominal contoh: Rp ${rupiah}\nDEMO — bukan bukti pembayaran.`); }
});

// ═══════════════════════════════════════════
// CEK CUACA
// ═══════════════════════════════════════════
router.registerCallback("tool_cuaca", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_cuaca_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 CEK CUACA</b>\n\nKirim nama kota:\nContoh: <code>Jakarta</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_cuaca_await", async (bot, msg, state, ctx) => {
    const kota = msg.text?.trim();
    if (!kota) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek cuaca ${kota}...</b>`, { parse_mode: "HTML" });

    try {
        const geo = await axios.get("https://geocoding-api.open-meteo.com/v1/search", {
            params: { name: kota, count: 1, language: "id" }, timeout: 10000
        });
        if (!geo.data.results || geo.data.results.length === 0) {
            return safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Kota "${kota}" ga ditemukan.</b>`);
        }
        const loc = geo.data.results[0];
        const w = await axios.get("https://api.open-meteo.com/v1/forecast", {
            params: {
                latitude: loc.latitude, longitude: loc.longitude,
                current: "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
                timezone: "auto"
            }, timeout: 10000
        });
        const cur = w.data.current;
        const codes = {
            0: "Cerah", 1: "Cerah Berawan", 2: "Berawan", 3: "Mendung",
            45: "Berkabut", 48: "Kabut Beku", 51: "Gerimis Ringan", 53: "Gerimis",
            55: "Gerimis Lebat", 61: "Hujan Ringan", 63: "Hujan", 65: "Hujan Lebat",
            71: "Salju Ringan", 73: "Salju", 75: "Salju Lebat", 80: "Hujan Lokal",
            81: "Hujan Lokal Lebat", 82: "Hujan Sangat Lebat", 95: "Badai Petir", 96: "Badai + Hujan Es"
        };

        await safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>𖡛 CUACA ${loc.name.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Lokasi: ${loc.name}, ${loc.country}\n` +
            `𖡛 Suhu: <b>${cur.temperature_2m}°C</b>\n` +
            `𖡛 Terasa: ${cur.apparent_temperature}°C\n` +
            `𖡛 Kelembapan: ${cur.relative_humidity_2m}%\n` +
            `𖡛 Angin: ${cur.wind_speed_10m} km/h\n` +
            `𖡛 Cuaca: ${codes[cur.weather_code] || "Unknown"}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Real-time dari Open-Meteo</i>`);
    } catch (e) {
        console.log("[CUACA ERR]", e.code, e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// JAM SHOLAT
// ═══════════════════════════════════════════
router.registerCallback("tool_sholat", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_sholat_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 JADWAL SHOLAT</b>\n\nKirim nama kota:\nContoh: <code>Jakarta</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back" }]] } });
});

router.registerMessage("tool_sholat_await", async (bot, msg, state, ctx) => {
    const kota = msg.text?.trim();
    if (!kota) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek jadwal sholat ${kota}...</b>`, { parse_mode: "HTML" });

    try {
        const today = new Date();
        const dd = String(today.getDate()).padStart(2, "0");
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const yyyy = today.getFullYear();

        const res = await axios.get(`https://api.aladhan.com/v1/timingsByCity/${dd}-${mm}-${yyyy}`, {
            params: { city: kota, country: "Indonesia", method: 11 }, timeout: 10000
        });
        if (!res.data || !res.data.data) throw new Error("Data tidak tersedia");

        const t = res.data.data.timings;
        const meta = res.data.data.meta;

        await safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>𖡛 JADWAL SHOLAT ${kota.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Tanggal: ${meta.date.readable}\n` +
            `𖡛 Hijriah: ${meta.date.hijri.day} ${meta.date.hijri.month.en} ${meta.date.hijri.year}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Imsak: <code>${t.Imsak}</code>\n` +
            `𖡛 Subuh: <code>${t.Fajr}</code>\n` +
            `𖡛 Syuruq: <code>${t.Sunrise}</code>\n` +
            `𖡛 Dzuhur: <code>${t.Dhuhr}</code>\n` +
            `𖡛 Ashar: <code>${t.Asr}</code>\n` +
            `𖡛 Maghrib: <code>${t.Maghrib}</code>\n` +
            `𖡛 Isya: <code>${t.Isha}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Real-time dari Aladhan</i>`);
    } catch (e) {
        console.log("[SHOLAT ERR]", e.code, e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// MENU: DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("tool_downloader", async (bot, q, data, user, ctx) => {
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Pilih platform:\n` +
        `▸ 𖡛 <b>TikTok</b> — No WM + HD\n` +
        `▸ 𖡛 <b>Instagram</b> — No WM + HD\n` +
        `▸ 𖡛 <b>YouTube</b> — Video HD (shorts + full)\n` +
        `━━━━━━━━━━━━━━━━━━━━`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [{ text: "𖡛 TikTok", callback_data: "dl_tiktok", style: "primary" }],
                [{ text: "𖡛 Instagram", callback_data: "dl_instagram", style: "primary" }],
                [{ text: "𖡛 YouTube", callback_data: "dl_youtube", style: "primary" }],
                [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
            ] }
        });
});

// ═══════════════════════════════════════════
// TIKTOK DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("dl_tiktok", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_tiktok_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 TIKTOK DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim URL TikTok:\n` +
        `𖡛 <b>Format</b>: Video, Foto, Slide\n` +
        `𖡛 <b>Output</b>: No WM + HD\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Contoh: https://tiktok.com/@user/video/xxx</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_tiktok_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("tiktok")) return bot.sendMessage(msg.chat.id, "<b>✕ URL TikTok ga valid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Download video...</b>`, { parse_mode: "HTML" });

    try {
        const res = await axios.get(`https://tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`, { timeout: 15000 });
        if (!res.data || !res.data.data) throw new Error("Gagal ambil data");
        const d = res.data.data;
        const videoUrl = d.hdplay || d.play;
        const title = d.title || "TikTok Video";

        const vidPath = tmpPath("mp4");
        await downloadFile(videoUrl, vidPath);

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendVideo(msg.chat.id, vidPath, {
            caption: `<b>✓ TIKTOK NO WM</b>\n\n𖡛 ${title.slice(0, 100)}\n𖡛 @${d.author?.unique_id || "unknown"}\n𖡛 ${d.duration}s`,
            parse_mode: "HTML"
        });

        try { fs.unlinkSync(vidPath); } catch {}
    } catch (e) {
        console.log("[TIKTOK ERR]", e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// INSTAGRAM DOWNLOADER
// ═══════════════════════════════════════════
router.registerCallback("dl_instagram", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_instagram_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 INSTAGRAM DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim URL Instagram:\n` +
        `𖡛 <b>Support</b>: Post, Reels, IGTV, Slide\n` +
        `𖡛 <b>Output</b>: HD + No Watermark\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Contoh: https://instagram.com/p/xxx</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_instagram_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("instagram")) return bot.sendMessage(msg.chat.id, "<b>✕ URL invalid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Download Instagram HD...</b>`, { parse_mode: "HTML" });

    const APIS = [
        {
            name: "siputzx",
            get: async () => {
                const r = await axios.get(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.data && Array.isArray(r.data.data) && r.data.data.length > 0) {
                    return r.data.data.map(x => ({
                        url: x.url || x.download_url || x.src,
                        isVideo: x.url ? /\.mp4|video/i.test(x.url) : true,
                        thumb: x.thumbnail || null
                    }));
                }
                return null;
            }
        },
        {
            name: "ryzendesu",
            get: async () => {
                const r = await axios.get(`https://api.ryzendesu.vip/api/downloader/igdl?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.data && Array.isArray(r.data.data)) {
                    return r.data.data.map(x => ({
                        url: x.url || x.download_url,
                        isVideo: /\.mp4/i.test(x.url || ""),
                        thumb: x.thumbnail
                    }));
                }
                return null;
            }
        },
        {
            name: "vreden",
            get: async () => {
                const r = await axios.get(`https://api.vreden.my.id/api/igdownload?url=${encodeURIComponent(url)}`, { timeout: 20000 });
                if (r.data && r.data.result && Array.isArray(r.data.result) && r.data.result.length > 0) {
                    return r.data.result.map(x => ({
                        url: x.url || x.download_url,
                        isVideo: /\.mp4/i.test(x.url || ""),
                        thumb: x.thumbnail
                    }));
                }
                return null;
            }
        }
    ];

    let mediaList = null;
    let usedApi = "";

    for (const api of APIS) {
        try {
            console.log(`[IG] Coba API: ${api.name}`);
            const result = await api.get();
            if (result && result.length > 0) {
                mediaList = result.filter(m => m.url && m.url.startsWith("http"));
                if (mediaList.length > 0) {
                    usedApi = api.name;
                    console.log(`[IG] ✓ ${api.name} → ${mediaList.length} media`);
                    break;
                }
            }
        } catch (e) {
            console.log(`[IG] ✕ ${api.name} error:`, e.message.slice(0, 100));
        }
    }

    if (!mediaList || mediaList.length === 0) {
        return safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>✕ Gagal download Instagram</b>\n\n` +
            `<i>Kemungkinan:</i>\n` +
            `𖡛 Post private / ga public\n` +
            `𖡛 API server lagi down\n` +
            `𖡛 URL bukan post/reels valid\n\n` +
            `<i>Coba lagi beberapa saat.</i>`);
    }

    await safeEdit(bot, msg.chat.id, loading.message_id,
        `<b>𖡛 Downloading ${mediaList.length} media...</b>`);

    let success = 0;
    let failed = 0;

    for (let i = 0; i < mediaList.length; i++) {
        const media = mediaList[i];
        const ext = media.isVideo ? "mp4" : "jpg";
        const tmp = tmpPath(ext);

        try {
            await downloadFile(media.url, tmp);
            const stat = fs.statSync(tmp);

            if (stat.size < 1000) throw new Error("File corrupt");

            const caption =
                `<b>✓ INSTAGRAM HD</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `𖡛 Media: ${i + 1}/${mediaList.length}\n` +
                `𖡛 Type: ${media.isVideo ? "𖡛 Video" : "𖡛 Foto"}\n` +
                `𖡛 Size: ${(stat.size / 1024 / 1024).toFixed(2)} MB\n` +
                `𖡛 Quality: HD No WM\n` +
                `━━━━━━━━━━━━━━━━━━━━`;

            if (media.isVideo) {
                await bot.sendVideo(msg.chat.id, tmp, {
                    caption,
                    parse_mode: "HTML",
                    supports_streaming: true
                });
            } else {
                await bot.sendPhoto(msg.chat.id, tmp, {
                    caption,
                    parse_mode: "HTML"
                });
            }

            success++;
        } catch (e) {
            console.log(`[IG] Send fail ${i + 1}:`, e.message);
            failed++;
        } finally {
            try { fs.unlinkSync(tmp); } catch {}
        }
    }

    try { await bot.deleteMessage(msg.chat.id, loading.message_id); } catch {}

    if (success === 0) {
        await bot.sendMessage(msg.chat.id,
            `<b>✕ Gagal kirim media Instagram</b>\n\n<i>Kemungkinan file terlalu besar atau server error.</i>`,
            { parse_mode: "HTML" });
    } else if (success < mediaList.length) {
        await bot.sendMessage(msg.chat.id,
            `<b>✓ Partial sukses</b>\n\n▸ Sukses: ${success}\n▸ Gagal: ${failed}`,
            { parse_mode: "HTML" });
    }

    try {
        await notify.notifySuccess(bot, "IG DOWNLOAD", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Media", value: `${success}/${mediaList.length}` },
            { label: "API", value: usedApi }
        ]).catch(() => {});
    } catch {}
});

// ═══════════════════════════════════════════
// YOUTUBE DOWNLOADER
// ═══════════════════════════════════════════
function extractYouTubeId(url) {
    const patterns = [
        /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
        /(?:m\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/,
        /(?:youtube\.com\/v\/)([a-zA-Z0-9_-]{11})/
    ];
    for (const p of patterns) {
        const m = url.match(p);
        if (m && m[1]) return m[1];
    }
    return null;
}

router.registerCallback("dl_youtube", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "dl_youtube_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>▶️ YOUTUBE DOWNLOADER</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<b>Support Link:</b>\n` +
        `▸ <code>youtube.com/watch?v=xxx</code>\n` +
        `▸ <code>youtu.be/xxx</code>\n` +
        `▸ <code>youtube.com/shorts/xxx</code>\n` +
        `▸ <code>m.youtube.com/watch?v=xxx</code>\n\n` +
        `<b>Output:</b> Video MP4 HD\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Kirim link YouTube:</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("dl_youtube_await", async (bot, msg, state, ctx) => {
    const url = msg.text?.trim();
    if (!url || !url.includes("youtu")) return bot.sendMessage(msg.chat.id, "<b>✕ URL invalid.</b>", { parse_mode: "HTML" });

    const videoId = extractYouTubeId(url);
    if (!videoId) {
        return bot.sendMessage(msg.chat.id,
            `<b>✕ Link YouTube ga valid!</b>\n\n` +
            `<b>Format yang didukung:</b>\n` +
            `▸ <code>youtube.com/watch?v=xxx</code>\n` +
            `▸ <code>youtu.be/xxx</code>\n` +
            `▸ <code>youtube.com/shorts/xxx</code>`,
            { parse_mode: "HTML" });
    }

    ctx.clearState(msg.from.id);

    console.log("[YT] URL:", url, "→ videoId:", videoId);

    const loading = await bot.sendMessage(msg.chat.id,
        `<b>𖡛 Youtube Download</b>\n\n` +
        `▸ Video ID: <code>${videoId}</code>\n` +
        `▸ Status: Fetching video info...\n\n` +
        `<i>Mohon tunggu...</i>`,
        { parse_mode: "HTML" });

    const APIS = [
        {
            name: "siputzx-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.data?.dl) {
                    return {
                        videoUrl: r.data.data.dl,
                        title: r.data.data.title || "YouTube Video",
                        author: r.data.data.author || "-",
                        duration: r.data.data.duration || "?",
                        thumb: r.data.data.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "ryzendesu-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.ryzendesu.vip/api/downloader/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.url) {
                    return {
                        videoUrl: r.data.url,
                        title: r.data.title || "YouTube Video",
                        author: r.data.author || "-",
                        duration: r.data.duration || "?",
                        thumb: r.data.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "vreden-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.vreden.my.id/api/ytmp4?url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.result?.download?.url) {
                    return {
                        videoUrl: r.data.result.download.url,
                        title: r.data.result.title || "YouTube Video",
                        author: r.data.result.author || "-",
                        duration: r.data.result.duration || "?",
                        thumb: r.data.result.thumbnail
                    };
                }
                return null;
            }
        },
        {
            name: "zahwazein-ytmp4",
            get: async () => {
                const r = await axios.get(`https://api.zahwazein.xyz/downloader/ytmp4?apikey=isi_api_key&url=${encodeURIComponent(url)}`, { timeout: 30000 });
                if (r.data?.result?.url) {
                    return {
                        videoUrl: r.data.result.url,
                        title: r.data.result.title || "YouTube Video",
                        author: r.data.result.author || "-",
                        duration: r.data.result.duration || "?",
                        thumb: r.data.result.thumbnail
                    };
                }
                return null;
            }
        }
    ];

    let data = null;
    let usedApi = "";

    for (const api of APIS) {
        try {
            console.log(`[YT] Coba API: ${api.name}`);
            const result = await api.get();
            if (result && result.videoUrl) {
                data = result;
                usedApi = api.name;
                console.log(`[YT] ✓ ${api.name} sukses`);
                break;
            }
            console.log(`[YT] ✕ ${api.name} gagal`);
        } catch (e) {
            console.log(`[YT] ✗ ${api.name} error:`, e.message.slice(0, 100));
        }
    }

    if (!data) {
        return safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>✕ Gagal download YouTube</b>\n\n` +
            `<i>Kemungkinan:</i>\n` +
            `▸ Video private / age-restricted\n` +
            `▸ Video copyrighted (block download)\n` +
            `▸ API server down\n\n` +
            `<i>Coba video lain atau ulangi beberapa saat.</i>`);
    }

    await safeEdit(bot, msg.chat.id, loading.message_id,
        `<b>𖡛 Downloading video...</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Title</b>: <code>${String(data.title).slice(0, 60)}</code>\n` +
        `▸ <b>Author</b>: <code>${data.author}</code>\n` +
        `▸ <b>Duration</b>: <code>${data.duration}</code>\n` +
        `▸ <b>API</b>: <code>${usedApi}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Mohon tunggu, file mungkin gede...</i>`);

    try {
        const vidPath = tmpPath("mp4");
        await downloadFile(data.videoUrl, vidPath, "https://www.youtube.com/");
        const stat = fs.statSync(vidPath);
        const sizeMB = stat.size / 1024 / 1024;

        console.log(`[YT] Downloaded: ${sizeMB.toFixed(2)} MB`);

        if (sizeMB > 49) {
            await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
            await bot.sendMessage(msg.chat.id,
                `<b>⚠️ Video terlalu besar</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Title: ${String(data.title).slice(0, 80)}\n` +
                `▸ Size: <code>${sizeMB.toFixed(2)} MB</code>\n` +
                `▸ Limit TG: <code>50 MB</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<b>▶️ Download manual:</b>\n` +
                `<code>${data.videoUrl}</code>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [
                        [{ text: "▶️ Buka Video", url: data.videoUrl }],
                        [{ text: "▶️ Lihat di YouTube", url }]
                    ] }
                });
            try { fs.unlinkSync(vidPath); } catch {}
            return;
        }

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendVideo(msg.chat.id, vidPath, {
            caption:
                `<b>✓ YOUTUBE HD</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ <b>${String(data.title).slice(0, 80)}</b>\n` +
                `▸ Author: <code>${data.author}</code>\n` +
                `▸ Duration: <code>${data.duration}</code>\n` +
                `▸ Size: <code>${sizeMB.toFixed(2)} MB</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Kualitas: HD</i>`,
            parse_mode: "HTML",
            supports_streaming: true
        });

        try { fs.unlinkSync(vidPath); } catch {}

        try {
            await notify.notifySuccess(bot, "YT DOWNLOAD", [
                { label: "User", value: msg.from.first_name || "User" },
                { label: "Title", value: String(data.title).slice(0, 40) },
                { label: "Size", value: sizeMB.toFixed(2) + " MB" },
                { label: "API", value: usedApi }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[YT DOWNLOAD ERR]", e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>✕ Gagal download video</b>\n\n<code>${errorMsg(e)}</code>\n\n` +
            `<i>Coba lagi beberapa saat.</i>`);
    }
});

// ═══════════════════════════════════════════
// BRAT STICKER
// ═══════════════════════════════════════════
router.registerCallback("tool_brat", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_brat_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 BRAT STICKER</b>\n\nKirim teks yang mau dijadikan sticker:\n<i>Max 200 karakter.</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_brat_await", async (bot, msg, state, ctx) => {
    const text = msg.text?.trim();
    if (!text) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Membuat sticker...</b>`, { parse_mode: "HTML" });

    try {
        let avatarBuffer = null;
        try {
            const photos = await bot.getUserProfilePhotos(msg.from.id, { limit: 1 });
            if (photos && photos.total_count > 0) {
                const fileId = photos.photos[0][0].file_id;
                const fileLink = await bot.getFileLink(fileId);
                const avatarRes = await axios.get(fileLink, { responseType: "arraybuffer", timeout: 15000 });
                avatarBuffer = Buffer.from(avatarRes.data);
            }
        } catch (e) {
            console.log("[BRAT] avatar fail:", e.message);
        }

        const firstName = msg.from.first_name || "User";
        const lastName = msg.from.last_name || "";
        const fullName = [firstName, lastName].filter(Boolean).join(" ");
        const username = msg.from.username ? `@${msg.from.username}` : "no_username";
        const initial = firstName.charAt(0).toUpperCase();

        const W = 512;
        const H = 512;

        const words = String(text).slice(0, 200).split(/\s+/);
        const lines = [];
        let current = "";
        for (const w of words) {
            if ((current + " " + w).trim().length > 18) {
                lines.push(current.trim());
                current = w;
            } else {
                current = (current + " " + w).trim();
            }
        }
        if (current) lines.push(current);
        const showLines = lines.slice(0, 7);
        const fontSize = showLines.length > 5 ? 26 : showLines.length > 3 ? 32 : 40;
        const startY = 260;

        const textElements = showLines.map((line, i) =>
            `<text x="${W / 2}" y="${startY + i * (fontSize + 8)}" font-family="Arial, Helvetica, sans-serif" font-size="${fontSize}" font-weight="bold" fill="#FFFFFF" text-anchor="middle">${escapeXml(line)}</text>`
        ).join("");

        const baseSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <rect width="${W}" height="${H}" fill="#000000"/>
  <text x="${W / 2}" y="${H - 20}" font-family="Arial" font-size="11" fill="#6b7280" text-anchor="middle">𖡛 spartaX</text>
  ${textElements}
</svg>`;

        let baseBuffer = await sharp(Buffer.from(baseSvg)).png().toBuffer();

        if (avatarBuffer) {
            try {
                const avatarSize = 64;
                const avatarRounded = await sharp(avatarBuffer)
                    .resize(avatarSize, avatarSize, { fit: "cover" })
                    .composite([{
                        input: Buffer.from(
                            `<svg width="${avatarSize}" height="${avatarSize}"><circle cx="${avatarSize / 2}" cy="${avatarSize / 2}" r="${avatarSize / 2}" fill="#fff"/></svg>`
                        ),
                        blend: "dest-in"
                    }])
                    .png()
                    .toBuffer();

                const nameSvg = `<svg width="${W}" height="100" xmlns="http://www.w3.org/2000/svg">
                    <text x="105" y="45" font-family="Arial, Helvetica, sans-serif" font-size="20" font-weight="bold" fill="#FFFFFF">${escapeXml(fullName.slice(0, 25))}</text>
                    <text x="105" y="72" font-family="Arial, Helvetica, sans-serif" font-size="15" fill="#9ca3af">${escapeXml(username)}</text>
                </svg>`;
                const nameBuffer = await sharp(Buffer.from(nameSvg)).png().toBuffer();

                baseBuffer = await sharp(baseBuffer)
                    .composite([
                        { input: avatarRounded, top: 30, left: 30 },
                        { input: nameBuffer, top: 30, left: 0 }
                    ])
                    .png()
                    .toBuffer();
            } catch (e) {
                console.log("[BRAT] overlay fail:", e.message);
            }
        } else {
            const initialSvg = `<svg width="${W}" height="100" xmlns="http://www.w3.org/2000/svg">
                <circle cx="62" cy="62" r="32" fill="#1f2937" stroke="#ffffff" stroke-width="2"/>
                <text x="62" y="74" font-family="Arial" font-size="32" font-weight="bold" fill="#ffffff" text-anchor="middle">${escapeXml(initial)}</text>
                <text x="110" y="55" font-family="Arial" font-size="20" font-weight="bold" fill="#FFFFFF">${escapeXml(fullName.slice(0, 25))}</text>
                <text x="110" y="80" font-family="Arial" font-size="15" fill="#9ca3af">${escapeXml(username)}</text>
            </svg>`;
            const overlayBuffer = await sharp(Buffer.from(initialSvg)).png().toBuffer();
            baseBuffer = await sharp(baseBuffer)
                .composite([{ input: overlayBuffer, top: 30, left: 0 }])
                .png()
                .toBuffer();
        }

        const tmp = tmpPath("png");
        fs.writeFileSync(tmp, baseBuffer);

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        await bot.sendSticker(msg.chat.id, tmp, {
            reply_markup: { inline_keyboard: [[{ text: "𖡛 Menu", callback_data: "menu_back" }]] }
        });
        try { fs.unlinkSync(tmp); } catch {}

        try {
            await notify.notifySuccess(bot, "BRAT STICKER", [
                { label: "User", value: fullName.slice(0, 30) },
                { label: "Teks", value: text.slice(0, 30) }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[BRAT ERR]", e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// HD UPSCALE
// ═══════════════════════════════════════════
router.registerCallback("tool_hd", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_hd_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 HD UPSCALE</b>\n\nKirim foto/video yang mau di-HD-kan:`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_hd_await", async (bot, msg, state, ctx) => {
    if (!msg.photo && !msg.video) return bot.sendMessage(msg.chat.id, "<b>✕ Kirim foto/video.</b>", { parse_mode: "HTML" });

    const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : msg.video.file_id;
    const isVideo = !!msg.video;

    ctx.setState(msg.from.id, "tool_hd_pick", { fileId, isVideo });
    await bot.sendMessage(msg.chat.id,
        `<b>𖡛 PILIH LEVEL HD</b>\n\nSemakin gede, semakin HD:`,
        {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [{ text: "𖡛 2x HD", callback_data: "tool_hd_level:2", style: "success" }],
                [{ text: "𖡛 3x HD", callback_data: "tool_hd_level:3", style: "success" }],
                [{ text: "𖡛 4x HD", callback_data: "tool_hd_level:4", style: "success" }],
                [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
            ] }
        });
});

router.registerCallback("tool_hd_level", async (bot, q, data, user, ctx) => {
    const level = parseInt(data.split(":")[1]) || 2;
    const st = ctx.getState(user.id);
    if (!st || !st.fileId) return bot.sendMessage(q.message.chat.id, `<b>✕ Sesi habis.</b>`, { parse_mode: "HTML" });

    ctx.clearState(user.id);

    const loading = await bot.sendMessage(q.message.chat.id, `<b>𖡛 Upscale ${level}x...</b>`, { parse_mode: "HTML" });

    try {
        const fileLink = await bot.getFileLink(st.fileId);
        const img = await axios.get(fileLink, { responseType: "arraybuffer", timeout: 30000 });

        const metadata = await sharp(Buffer.from(img.data)).metadata();
        const newWidth = Math.min((metadata.width || 512) * level, 4096);
        const newHeight = Math.min((metadata.height || 512) * level, 4096);

        const upscaled = await sharp(Buffer.from(img.data))
            .resize(newWidth, newHeight, { kernel: sharp.kernel.lanczos3, fit: "fill" })
            .sharpen({ sigma: 1.5, m1: 1.0, m2: 0.5 })
            .modulate({ brightness: 1.05, saturation: 1.15 })
            .linear(1.1, -10)
            .jpeg({ quality: 98, chromaSubsampling: "4:4:4" })
            .toBuffer();

        const tmp = tmpPath("jpg");
        fs.writeFileSync(tmp, upscaled);

        await bot.deleteMessage(q.message.chat.id, loading.message_id).catch(() => {});

        if (st.isVideo) {
            await bot.sendDocument(q.message.chat.id, tmp, {
                caption: `<b>✓ HD ${level}x</b>\n\n𖡛 ${metadata.width}x${metadata.height} → ${newWidth}x${newHeight}`,
                parse_mode: "HTML"
            });
        } else {
            await bot.sendPhoto(q.message.chat.id, tmp, {
                caption:
                    `<b>✓ HD ${level}x</b>\n\n` +
                    `𖡛 Resolusi: ${metadata.width}x${metadata.height} → <b>${newWidth}x${newHeight}</b>\n` +
                    `𖡛 Size: ${(upscaled.length / 1024).toFixed(2)} KB`,
                parse_mode: "HTML"
            });
        }

        try { fs.unlinkSync(tmp); } catch {}

        try {
            await notify.notifySuccess(bot, "HD UPSCALE", [
                { label: "User", value: q.from.first_name || "User" },
                { label: "Level", value: level + "x" },
                { label: "Resolusi", value: `${newWidth}x${newHeight}` }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[HD ERR]", e.message);
        await safeEdit(bot, q.message.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// CEK PING WEB
// ═══════════════════════════════════════════
router.registerCallback("tool_ping", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_ping_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 CEK PING WEB</b>\n\nKirim domain website:\nContoh: <code>google.com</code>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_ping_await", async (bot, msg, state, ctx) => {
    let domain = msg.text?.trim().replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!domain || !domain.includes(".")) return bot.sendMessage(msg.chat.id, "<b>✕ Domain invalid.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Cek ${domain}...</b>`, { parse_mode: "HTML" });

    try {
        const start = Date.now();
        let res;
        try {
            res = await axios.get(`https://${domain}`, { timeout: 10000, validateStatus: () => true });
        } catch {
            res = await axios.get(`http://${domain}`, { timeout: 10000, validateStatus: () => true });
        }
        const ping = Date.now() - start;
        const https_valid = res.request?.res?.socket?.encrypted || domain.includes("https");
        const secure = https_valid ? "HTTPS (Aman)" : "HTTP (Kurang Aman)";

        await safeEdit(bot, msg.chat.id, loading.message_id,
            `<b>𖡛 HASIL CEK ${domain}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Ping: <code>${ping}ms</code>\n` +
            `𖡛 Status: <code>${res.status} ${res.statusText}</code>\n` +
            `𖡛 Keamanan: ${secure}\n` +
            `𖡛 Check: ${new Date().toLocaleString("id-ID")}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Ping ${ping < 300 ? "Cepat" : ping < 1000 ? "Sedang" : "Lambat"}</i>`);
    } catch (e) {
        console.log("[PING ERR]", e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Website ga bisa diakses:</b>\n<code>${errorMsg(e)}</code>`);
    }
});

// ═══════════════════════════════════════════
// SPAM NGL
// ═══════════════════════════════════════════
router.registerCallback("tool_ngl", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_ngl_user", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 SPAM NGL</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `Kirim username NGL (tanpa @):\n` +
        `<b>Contoh:</b> <code>spartax</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Pastiin username NGL bener & aktif.</i>`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_ngl_user", async (bot, msg, state, ctx) => {
    const user = msg.text?.trim().replace(/^@/, "").replace(/https?:\/\/ngl\.link\//i, "").replace(/\//g, "");
    if (!user) return;
    if (!/^[a-zA-Z0-9._]+$/.test(user)) {
        return bot.sendMessage(msg.chat.id, `<b>✕ Username NGL invalid.</b>`, { parse_mode: "HTML" });
    }
    ctx.setState(msg.from.id, "tool_ngl_count", { nglUser: user });
    await bot.sendMessage(msg.chat.id,
        `<b>Username:</b> <code>${user}</code>\n\n` +
        `<b>Berapa kali spam? (max 100)</b>`,
        { parse_mode: "HTML" });
});

router.registerMessage("tool_ngl_count", async (bot, msg, state, ctx) => {
    const count = Math.min(parseInt(msg.text) || 1, 100);
    if (count < 1) return bot.sendMessage(msg.chat.id, `<b>✕ Minimal 1.</b>`, { parse_mode: "HTML" });
    ctx.setState(msg.from.id, "tool_ngl_text", { nglUser: state.nglUser, count });
    await bot.sendMessage(msg.chat.id, `<b>Kirim teks spam nya:</b>`, { parse_mode: "HTML" });
});

router.registerMessage("tool_ngl_text", async (bot, msg, state, ctx) => {
    const text = msg.text?.trim();
    if (!text) return;
    ctx.clearState(msg.from.id);

    const loading = await bot.sendMessage(msg.chat.id,
        `<b>▸ Spam NGL</b>\n\n` +
        `▸ Target: <code>${state.nglUser}</code>\n` +
        `▸ Total: <code>${state.count}</code>\n` +
        `▸ Progress: 0/${state.count}`,
        { parse_mode: "HTML" });

    let success = 0;
    let failed = 0;
    const errors = [];

    const HEADERS = {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "User-Agent": "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate, br",
        "Origin": "https://ngl.link",
        "Referer": `https://ngl.link/${state.nglUser}`,
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "X-Requested-With": "XMLHttpRequest",
        "Connection": "keep-alive"
    };

    for (let i = 0; i < state.count; i++) {
        let attempt = 0;
        let maxAttempts = 3;
        let successThis = false;

        while (attempt < maxAttempts && !successThis) {
            attempt++;
            try {
                const deviceId = crypto.randomUUID().replace(/-/g, "") + crypto.randomBytes(8).toString("hex");

                const body = new URLSearchParams({
                    username: state.nglUser,
                    question: text,
                    deviceId: deviceId,
                    gameSlug: "",
                    referrer: ""
                }).toString();

                const res = await axios.post(
                    "https://ngl.link/api/submit",
                    body,
                    {
                        headers: HEADERS,
                        timeout: 20000,
                        validateStatus: () => true
                    }
                );

                const isSuccess =
                    (res.status >= 200 && res.status < 300) &&
                    (res.data?.success === true || res.data?.status === "ok" || res.data === "" || typeof res.data === "object");

                if (isSuccess) {
                    success++;
                    successThis = true;
                } else if (res.status === 429) {
                    if (attempt < maxAttempts) {
                        console.log(`[NGL] Rate limited, retry ${attempt}/${maxAttempts}`);
                        await new Promise(r => setTimeout(r, 5000));
                        continue;
                    } else {
                        failed++;
                        if (errors.length < 3) errors.push(`Rate limit (429)`);
                    }
                } else if (res.status === 404) {
                    if (errors.length < 3) errors.push(`Username "${state.nglUser}" ga ditemukan`);
                    failed++;
                    i = state.count;
                    break;
                } else {
                    if (attempt < maxAttempts) {
                        await new Promise(r => setTimeout(r, 2000));
                        continue;
                    }
                    failed++;
                    if (errors.length < 3) errors.push(`HTTP ${res.status}`);
                }
            } catch (e) {
                if (attempt < maxAttempts) {
                    await new Promise(r => setTimeout(r, 2000));
                    continue;
                }
                failed++;
                if (errors.length < 3) errors.push(e.message.slice(0, 50));
            }
        }

        if ((i + 1) % 3 === 0 || i === state.count - 1) {
            try {
                await safeEdit(bot, msg.chat.id, loading.message_id,
                    `<b>▸ Spam NGL</b>\n\n` +
                    `▸ Target: <code>${state.nglUser}</code>\n` +
                    `▸ Progress: ${i + 1}/${state.count}\n` +
                    `▸ ✓ Sukses: <b>${success}</b>\n` +
                    `▸ ✕ Gagal: <b>${failed}</b>`);
            } catch {}
        }

        await new Promise(r => setTimeout(r, 1500));
    }

    let resultMsg =
        `<b>${success > 0 ? "✓" : "✕"} SPAM NGL SELESAI</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ Target: <code>${state.nglUser}</code>\n` +
        `▸ Pesan: <i>${text.slice(0, 100)}</i>\n` +
        `▸ Total: <code>${state.count}</code>\n` +
        `▸ ✓ Sukses: <b>${success}</b>\n` +
        `▸ ✕ Gagal: <b>${failed}</b>\n`;

    if (errors.length > 0) {
        resultMsg += `━━━━━━━━━━━━━━━━━━━━\n<b>Error:</b>\n`;
        for (const e of errors) resultMsg += `▸ <code>${e}</code>\n`;
    }

    if (success === 0) {
        resultMsg += `\n<b>Kemungkinan gagal:</b>\n`;
        resultMsg += `▸ Username NGL salah / ga aktif\n`;
        resultMsg += `▸ NGL blok IP server (VPS)\n`;
        resultMsg += `▸ Coba pakai VPN / proxy\n`;
    }

    resultMsg += `━━━━━━━━━━━━━━━━━━━━`;

    await safeEdit(bot, msg.chat.id, loading.message_id, resultMsg);

    try {
        await notify.notifySuccess(bot, "SPAM NGL", [
            { label: "User", value: msg.from.first_name || "User" },
            { label: "Target", value: state.nglUser },
            { label: "Sukses", value: `${success}/${state.count}` }
        ]).catch(() => {});
    } catch {}
});

// ═══════════════════════════════════════════
// ANIME AI
// ═══════════════════════════════════════════
router.registerCallback("tool_anime", async (bot, q, data, user, ctx) => {
    ctx.setState(user.id, "tool_anime_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<b>𖡛 ANIME AI</b>\n\nKirim foto/video yang mau dijadikan anime HD:`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] } });
});

router.registerMessage("tool_anime_await", async (bot, msg, state, ctx) => {
    if (!msg.photo && !msg.video) return bot.sendMessage(msg.chat.id, "<b>✕ Kirim foto/video.</b>", { parse_mode: "HTML" });
    ctx.clearState(msg.from.id);

    const fileId = msg.photo ? msg.photo[msg.photo.length - 1].file_id : msg.video.file_id;
    const isVideo = !!msg.video;

    const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Proses anime AI...</b>`, { parse_mode: "HTML" });

    try {
        const fileLink = await bot.getFileLink(fileId);
        const api = `https://api.siputzx.my.id/api/ai/animediffusion?url=${encodeURIComponent(fileLink)}`;
        const res = await axios.get(api, { responseType: "arraybuffer", timeout: 60000 });

        const tmp = tmpPath(isVideo ? "mp4" : "jpg");
        fs.writeFileSync(tmp, Buffer.from(res.data));

        await bot.deleteMessage(msg.chat.id, loading.message_id).catch(() => {});
        if (isVideo) {
            await bot.sendVideo(msg.chat.id, tmp, { caption: `<b>✓ ANIME HD</b>`, parse_mode: "HTML" });
        } else {
            await bot.sendPhoto(msg.chat.id, tmp, { caption: `<b>✓ ANIME HD</b>`, parse_mode: "HTML" });
        }
        try { fs.unlinkSync(tmp); } catch {}
    } catch (e) {
        console.log("[ANIME ERR]", e.message);
        await safeEdit(bot, msg.chat.id, loading.message_id, `<b>✕ Error:</b> <code>${errorMsg(e)}</code>`);
    }
});

// ═══ GENERATE FOTO CEK ID — MODERN PREMIUM ═══
async function generateIdCard(data) {
    try {
        const W = 900;
        const H = 1350;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const name = esc((data.firstName || "User").slice(0, 26));
        const username = esc(data.username || "-");
        const userId = esc(String(data.userId || "-"));
        const bio = esc((data.bio || "Tidak ada bio").slice(0, 60));
        const createdDate = esc(data.createdDate || "Unknown");
        const daysSince = esc(String(data.daysSince || 0));
        const premium = data.isPremium ? "PREMIUM" : "FREE";
        const premiumColor = data.isPremium ? "#22c55e" : "#3b82f6";
        const premiumColor2 = data.isPremium ? "#16a34a" : "#1d4ed8";
        const initial = name.charAt(0).toUpperCase();

        const pattern = [];
        for (let x = 30; x < W - 30; x += 40) {
            for (let y = 30; y < H - 30; y += 40) {
                pattern.push(`<circle cx="${x}" cy="${y}" r="1.5" fill="#ffffff" opacity="0.06"/>`);
            }
        }
        pattern.push(`<circle cx="200" cy="250" r="220" fill="#fbbf24" opacity="0.10"/>`);
        pattern.push(`<circle cx="${W - 100}" cy="450" r="180" fill="#ef4444" opacity="0.08"/>`);
        pattern.push(`<circle cx="150" cy="${H - 200}" r="200" fill="#fbbf24" opacity="0.07"/>`);
        pattern.push(`<circle cx="${W - 150}" cy="${H - 300}" r="160" fill="#dc2626" opacity="0.08"/>`);

        let avatarSVG = "";
        if (data.avatarBase64) {
            avatarSVG = `
                <defs>
                    <clipPath id="avatarClip">
                        <circle cx="${W/2}" cy="480" r="115"/>
                    </clipPath>
                </defs>
                <circle cx="${W/2}" cy="480" r="130" fill="#fbbf24" opacity="0.25"/>
                <circle cx="${W/2}" cy="480" r="125" fill="none" stroke="url(#goldGrad)" stroke-width="3" opacity="0.6"/>
                <image x="${W/2 - 115}" y="365" width="230" height="230"
                       href="data:image/png;base64,${data.avatarBase64}"
                       clip-path="url(#avatarClip)" preserveAspectRatio="xMidYMid slice"/>
                <circle cx="${W/2}" cy="480" r="116" fill="none" stroke="#ffffff" stroke-width="4"/>
                <circle cx="${W/2}" cy="480" r="120" fill="none" stroke="url(#goldGrad)" stroke-width="2"/>
            `;
        } else {
            avatarSVG = `
                <circle cx="${W/2}" cy="480" r="130" fill="#fbbf24" opacity="0.25"/>
                <circle cx="${W/2}" cy="480" r="116" fill="#fbbf24" stroke="#7f1d1d" stroke-width="5"/>
                <text x="${W/2}" y="535" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="110" fill="#7f1d1d" font-weight="900">${initial}</text>
            `;
        }

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#1a0a0a"/>
      <stop offset="35%" stop-color="#7f1d1d"/>
      <stop offset="70%" stop-color="#b91c1c"/>
      <stop offset="100%" stop-color="#7f1d1d"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#fef3c7"/>
      <stop offset="50%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
    <linearGradient id="cardGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.98"/>
      <stop offset="100%" stop-color="#fef9f3" stop-opacity="0.98"/>
    </linearGradient>
    <linearGradient id="premGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="${premiumColor}"/>
      <stop offset="100%" stop-color="${premiumColor2}"/>
    </linearGradient>
    <linearGradient id="headerGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#0f172a" stop-opacity="0.95"/>
      <stop offset="100%" stop-color="#1e293b" stop-opacity="0.95"/>
    </linearGradient>
    <filter id="cardShadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="20" stdDeviation="25" flood-color="#000000" flood-opacity="0.4"/>
    </filter>
    <filter id="glowEffect" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="8" result="blur"/>
      <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  ${pattern.join("")}

  <rect x="0" y="0" width="${W}" height="90" fill="url(#goldGrad)"/>
  <rect x="0" y="90" width="${W}" height="3" fill="#7f1d1d"/>

  <text x="40" y="55" font-family="Arial Black, sans-serif" font-size="28" fill="#7f1d1d" font-weight="900">𖡛 CEK ID</text>
  <text x="40" y="78" font-family="Arial, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.8">BOT MULTI FUNGSI</text>
  <text x="${W - 40}" y="55" text-anchor="end" font-family="Arial Black, sans-serif" font-size="20" fill="#7f1d1d" font-weight="900">${esc(cfg.OWNER_USERNAME || "@biscuitMD")}</text>
  <text x="${W - 40}" y="78" text-anchor="end" font-family="Arial, sans-serif" font-size="12" fill="#7f1d1d" opacity="0.8">Powered by BiscuitMD</text>

  <g filter="url(#glowEffect)">
    <rect x="${W/2 - 130}" y="140" width="260" height="56" rx="28" fill="url(#premGrad)" stroke="#ffffff" stroke-width="2"/>
    <text x="${W/2}" y="178" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="24" fill="#ffffff" font-weight="900" letter-spacing="3">${premium}</text>
  </g>

  ${avatarSVG}

  <text x="${W/2}" y="660" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="42" fill="#ffffff" font-weight="900" letter-spacing="0.5">${name}</text>
  <text x="${W/2}" y="700" text-anchor="middle" font-family="Arial, sans-serif" font-size="22" fill="#fbbf24" opacity="0.9">@${username}</text>

  <g filter="url(#cardShadow)">
    <rect x="60" y="760" width="${W - 120}" height="470" rx="28" fill="url(#cardGrad)" stroke="url(#goldGrad)" stroke-width="3"/>
  </g>

  <rect x="60" y="760" width="${W - 120}" height="60" rx="28" fill="url(#headerGrad)"/>
  <rect x="60" y="800" width="${W - 120}" height="20" fill="url(#headerGrad)"/>
  <text x="${W/2}" y="798" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="20" fill="#fbbf24" font-weight="900" letter-spacing="2">DATA USER</text>

  <text x="100" y="870" font-family="Arial Black, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.7" letter-spacing="1">ID TELEGRAM</text>
  <text x="100" y="900" font-family="Courier New, monospace" font-size="26" fill="#dc2626" font-weight="900">${userId}</text>
  <line x1="100" y1="920" x2="${W-100}" y2="920" stroke="#fbbf24" stroke-width="1" opacity="0.3"/>

  <text x="100" y="960" font-family="Arial Black, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.7" letter-spacing="1">BIO</text>
  <text x="100" y="990" font-family="Arial, sans-serif" font-size="18" fill="#111" font-style="italic">"${bio}"</text>
  <line x1="100" y1="1010" x2="${W-100}" y2="1010" stroke="#fbbf24" stroke-width="1" opacity="0.3"/>

  <text x="100" y="1050" font-family="Arial Black, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.7" letter-spacing="1">DIBUAT SEJAK</text>
  <text x="100" y="1085" font-family="Arial, sans-serif" font-size="22" fill="#111" font-weight="700">${createdDate}</text>

  <text x="${W - 100}" y="1050" text-anchor="end" font-family="Arial Black, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.7" letter-spacing="1">UMUR AKUN</text>
  <text x="${W - 100}" y="1090" text-anchor="end" font-family="Arial Black, sans-serif" font-size="32" fill="#dc2626" font-weight="900">${daysSince}</text>
  <text x="${W - 100}" y="1110" text-anchor="end" font-family="Arial, sans-serif" font-size="14" fill="#7f1d1d" opacity="0.7">HARI</text>

  <rect x="0" y="${H - 90}" width="${W}" height="3" fill="url(#goldGrad)"/>
  <rect x="0" y="${H - 87}" width="${W}" height="87" fill="url(#goldGrad)"/>
  <text x="${W/2}" y="${H - 50}" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="18" fill="#7f1d1d" font-weight="900" letter-spacing="2">𖡛 BOT MULTI FUNGSI 𖡛</text>
  <text x="${W/2}" y="${H - 24}" text-anchor="middle" font-family="Arial, sans-serif" font-size="13" fill="#7f1d1d" opacity="0.85">${esc(cfg.GROUP_UPDATE || "@biscuitMD")}</text>
</svg>`.trim();

        const buf = await sharp(Buffer.from(svg)).png().toBuffer();
        return buf;
    } catch (e) {
        console.log("[ID CARD ERR]", e.message);
        return null;
    }
}

// ═══ GET AVATAR BASE64 ═══
async function getProfilePhotoBase64(bot, userId) {
    try {
        const photos = await bot.getUserProfilePhotos(userId, { limit: 1 });
        if (!photos || !photos.photos || photos.photos.length === 0) return null;

        const fileId = photos.photos[0][photos.photos[0].length - 1].file_id;
        const fileInfo = await bot.getFile(fileId);
        const fileUrl = `https://api.telegram.org/file/bot${cfg.BOT_TOKEN}/${fileInfo.file_path}`;

        const res = await axios.get(fileUrl, { responseType: "arraybuffer", timeout: 15000 });
        return Buffer.from(res.data).toString("base64");
    } catch (e) {
        console.log("[GET AVATAR ERR]", e.message);
        return null;
    }
}

// ═══ CALLBACK: CEK ID ═══
router.registerCallback("tool_cekid", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 CEK ID</b>\n\n` +
            `<blockquote>` +
            `    ▸ User: <b>${user.first_name || "User"}</b>\n` +
            `    ▸ ID: <code>${userId}</code>\n` +
            `    ▸ Status: <i>Generating card...</i>` +
            `</blockquote>`,
            { parse_mode: "HTML" });

        const firstName = user.first_name || "User";
        const username = user.username || "-";

        const avatarBase64 = await getProfilePhotoBase64(bot, userId);

        const dbUser = ctx.db.getUser(userId);
        const createdDate = dbUser.createdAt
            ? new Date(dbUser.createdAt).toLocaleDateString("id-ID", { day: "2-digit", month: "long", year: "numeric" })
            : "Unknown";

        const daysSince = dbUser.createdAt
            ? Math.floor((Date.now() - dbUser.createdAt) / 86400000)
            : 0;

        const bio = dbUser.bio || "Tidak ada bio";

        const imgBuf = await generateIdCard({
            firstName,
            username,
            userId,
            bio,
            createdDate,
            daysSince,
            isPremium: !!dbUser.premium,
            avatarBase64
        });

        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        if (!imgBuf) {
            return bot.sendMessage(chatId,
                `<b>✕ Gagal generate ID Card</b>`,
                { parse_mode: "HTML" });
        }

        await bot.sendPhoto(chatId, imgBuf, {
            caption:
                `<b>𖡛 CEK ID SUCCESS</b>\n\n` +
                `<blockquote>` +
                `    ▸ Nama: <b>${firstName}</b>\n` +
                `    ▸ Username: @${username}\n` +
                `    ▸ ID: <code>${userId}</code>\n` +
                `    ▸ Dibuat: <b>${createdDate}</b>\n` +
                `    ▸ Umur Akun: <b>${daysSince} hari</b>` +
                `</blockquote>`,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [
                    { text: "𖡛 Cek Lagi", callback_data: "tool_cekid", style: "success" },
                    { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
                ]
            ] }
        });
    } catch (e) {
        console.log("[CEKID ERR]", e.message);
        await bot.sendMessage(q.message.chat.id,
            `<b>✕ Error:</b> <code>${e.message.slice(0, 150)}</code>`,
            { parse_mode: "HTML" });
    }
});

// ═══ CALLBACK: MENU CEK ID ═══
router.registerCallback("menu_cekid", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;

        await safeEdit(bot, chatId, q.message.message_id,
            `╭═══════════════╮\n` +
            `│  ✦ CEK ID ✦  │\n` +
            `╰═══════════════╯\n\n` +

            `<blockquote>` +
            `𖡛 <b>INFO</b>\n` +
            `    ▸ Generate kartu ID Telegram kamu\n` +
            `    ▸ Tema kartun + Lego HD\n` +
            `    ▸ Include foto profil\n` +
            `    ▸ Include data akun` +
            `</blockquote>\n\n` +

            `𖡛 <b><i>TEKAN TOMBOL DI BAWAH:</i></b>`,
            {
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "𖡛 Generate ID Card", callback_data: "tool_cekid", style: "success" },
                            { text: "✕ Kembali", callback_data: "menu_tools", style: "danger" }
                        ]
                    ]
                }
            });
    } catch (e) { console.log("[MENU CEKID ERR]", e.message); }
});

// ═══ GENERATE FAKE CHAT ═══
async function generateFakeChat(data) {
    try {
        const W = 720;
        const H = 1280;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const msgText = esc((data.text || "Halo").slice(0, 100));
        const time = esc(data.time || "21.47");
        const bubbleColor = data.bubbleColor || "#f8c8d3";
        const bubbleTextColor = data.bubbleTextColor || "#000000";

        const statusBar = `
            <rect x="0" y="0" width="${W}" height="70" fill="#ffffff" opacity="0.95"/>
            <text x="30" y="42" font-family="Arial, sans-serif" font-size="22" fill="#000" font-weight="700">${time.slice(0, 5)}</text>
            <text x="${W - 30}" y="42" text-anchor="end" font-family="Arial, sans-serif" font-size="22" fill="#000" font-weight="700">5G</text>
            <rect x="${W - 100}" y="22" width="40" height="20" rx="3" fill="none" stroke="#000" stroke-width="2"/>
            <rect x="${W - 96}" y="25" width="32" height="14" rx="1" fill="#34C759"/>
            <rect x="${W - 108}" y="26" width="3" height="12" fill="#000"/>
            <line x1="${W - 118}" y1="24" x2="${W - 118}" y2="40" stroke="#000" stroke-width="2"/>
            <line x1="${W - 122}" y1="27" x2="${W - 122}" y2="37" stroke="#000" stroke-width="2"/>
            <line x1="${W - 126}" y1="30" x2="${W - 126}" y2="34" stroke="#000" stroke-width="2"/>
        `;

        const bgPattern = `
            <rect width="${W}" height="${H}" fill="#fdeef1"/>
            <ellipse cx="200" cy="300" rx="180" ry="200" fill="#f9d5dd" opacity="0.7"/>
            <ellipse cx="550" cy="600" rx="150" ry="180" fill="#fbe4ea" opacity="0.6"/>
            <ellipse cx="300" cy="900" rx="200" ry="220" fill="#fce7ec" opacity="0.5"/>
            <ellipse cx="600" cy="1100" rx="140" ry="160" fill="#fadde5" opacity="0.5"/>
        `;

        const emojiPicker = `
            <rect x="${W/2 - 220}" y="620" width="440" height="90" rx="45" fill="#ffffff" stroke="#e0e0e0" stroke-width="1"/>
            <text x="${W/2 - 180}" y="680" font-size="50" text-anchor="middle">👍</text>
            <text x="${W/2 - 120}" y="680" font-size="50" text-anchor="middle">❤️</text>
            <text x="${W/2 - 60}" y="680" font-size="50" text-anchor="middle">😂</text>
            <text x="${W/2}" y="680" font-size="50" text-anchor="middle">😮</text>
            <text x="${W/2 + 60}" y="680" font-size="50" text-anchor="middle">😢</text>
            <text x="${W/2 + 120}" y="680" font-size="50" text-anchor="middle">🙏</text>
            <circle cx="${W/2 + 190}" cy="665" r="28" fill="#e5e5e5"/>
            <text x="${W/2 + 190}" y="678" font-size="36" fill="#666" text-anchor="middle" font-weight="900">+</text>
        `;

        const bubbleX = W - 400;
        const bubbleWidth = 360;
        const bubbleY = 730;
        const bubbleH = 90;

        const bubble = `
            <rect x="${bubbleX}" y="${bubbleY}" width="${bubbleWidth}" height="${bubbleH}" rx="20" fill="${bubbleColor}"/>
            <text x="${bubbleX + 25}" y="${bubbleY + 45}" font-family="Arial, sans-serif" font-size="24" fill="${bubbleTextColor}">${msgText}</text>
            <text x="${bubbleX + bubbleWidth - 80}" y="${bubbleY + 70}" font-family="Arial, sans-serif" font-size="16" fill="#666">${time}</text>
            <text x="${bubbleX + bubbleWidth - 25}" y="${bubbleY + 70}" font-family="Arial, sans-serif" font-size="16" fill="#666">✓✓</text>
        `;

        const menuY = bubbleY + bubbleH + 20;
        const menuItems = [
            { label: "Balas", icon: "↩" },
            { label: "Teruskan", icon: "↪" },
            { label: "Salin", icon: "⧉" },
            { label: "Edit", icon: "✎" },
            { label: "Info", icon: "ⓘ" },
            { label: "Beri bintang", icon: "★" },
            { label: "Hapus", icon: "🗑", danger: true }
        ];

        const itemH = 70;
        const menuH = menuItems.length * itemH + 40;

        let menuContent = `
            <rect x="30" y="${menuY}" width="${W - 60}" height="${menuH}" rx="20" fill="#ffffff" opacity="0.98"/>
        `;

        menuItems.forEach((item, i) => {
            const y = menuY + 20 + i * itemH;
            const color = item.danger ? "#ff3b30" : "#000";
            menuContent += `
                <text x="60" y="${y + 45}" font-family="Arial, sans-serif" font-size="26" fill="${color}">${item.label}</text>
                <text x="${W - 60}" y="${y + 45}" text-anchor="end" font-family="Arial, sans-serif" font-size="30" fill="${color}">${item.icon}</text>
            `;
            if (i < menuItems.length - 1) {
                menuContent += `<line x1="30" y1="${y + itemH}" x2="${W - 30}" y2="${y + itemH}" stroke="#f0f0f0" stroke-width="1"/>`;
            }
        });

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  ${bgPattern}
  ${statusBar}
  ${emojiPicker}
  ${bubble}
  ${menuContent}
</svg>`.trim();

        const buf = await sharp(Buffer.from(svg)).png().toBuffer();
        return buf;
    } catch (e) {
        console.log("[FAKE CHAT ERR]", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU FAKE CHAT
// ═══════════════════════════════════════════
router.registerCallback("menu_fakechat", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "fakechat_await_text", {});

        await safeEdit(bot, chatId, q.message.message_id,
            `<b>𖡛 FAKE CHAT GENERATOR</b>\n\n` +
            `<blockquote>` +
            `    ▸ Buat gambar Iphone\n` +
            `    ▸ Bubble chat + emoji picker + menu\n` +
            `    ▸ Status bar iPhone (batre, jam, signal)\n` +
            `    ▸ Tema pink lembut\n` +
            `    ▸ Ukuran: 720x1280 HD` +
            `</blockquote>\n\n` +
            `📝 <b>Kirim teks chat:</b>\n` +
            `<i>Contoh: olinhshshsj</i>`,
            {
                reply_markup: {
                    inline_keyboard: [[
                        { text: "✕ Batal", callback_data: "fakechat_cancel", style: "danger" }
                    ]]
                }
            });
    } catch (e) { console.log("[MENU FAKECHAT ERR]", e.message); }
});

// ═══ TERIMA TEKS CHAT ═══
router.registerMessage("fakechat_await_text", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const text = (msg.text || "").trim();

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        if (!text) return;
        if (text.length > 100) {
            return bot.sendMessage(chatId, `<b>✕ Teks terlalu panjang! Max 100 karakter.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);

        const loading = await bot.sendMessage(chatId,
            `<b>🎨 Generating Fake Chat...</b>\n\n` +
            `<blockquote>` +
            `    ▸ Teks: <b>${text.slice(0, 50)}</b>\n` +
            `    ▸ Status: <i>Processing...</i>` +
            `</blockquote>`,
            { parse_mode: "HTML" });

        const imgBuf = await generateFakeChat({
            text: text,
            time: new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" }).replace(":", "."),
            bubbleColor: "#f8c8d3",
            bubbleTextColor: "#000000"
        });

        await bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        if (!imgBuf) {
            return bot.sendMessage(chatId, `<b>✕ Gagal generate gambar.</b>`, { parse_mode: "HTML" });
        }

        await bot.sendPhoto(chatId, imgBuf, {
            caption:
                `<b>✓ FAKE CHAT GENERATED</b>\n\n` +
                `<blockquote>` +
                `    ▸ Teks: <b>${text.slice(0, 50)}</b>\n` +
                `    ▸ Ukuran: <b>720x1280</b>\n` +
                `    ▸ Tema: <b>Pink iOS</b>` +
                `</blockquote>`,
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [
                [
                    { text: "𖡛 Buat Lagi", callback_data: "menu_fakechat", style: "success" },
                    { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
                ]
            ] }
        });

        // Tools run privately for the requesting user. Do not send tool-use notifications to any channel.
    } catch (e) {
        console.log("[FAKECHAT TEXT ERR]", e.message);
    }
});

// ═══ CANCEL ═══
router.registerCallback("fakechat_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[FAKECHAT CANCEL ERR]", e.message); }
});

module.exports = {};
console.log("[TOOLS] module loaded (v3 FIXED — syntax error resolved)");

// ═══════════════════════════════════════════
// GOOGLE MAPS / OPENSTREETMAP LOCATION SEARCH
// Uses public geocoding data; no fabricated coordinates or addresses.
// ═══════════════════════════════════════════
router.registerCallback("tool_maps_search", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "tool_maps_search_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<h2>⌖ PENCARIAN LOKASI</h2><p>Kirim nama tempat, alamat, kota, atau daerah yang ingin dicari.</p><p><i>Contoh: rumah sakit di Semarang</i></p>`,
        { reply_markup: { inline_keyboard: [[{ text: "Batal", callback_data: "menu_tools", style: "danger" }]] } });
});

router.registerMessage("tool_maps_search_await", async (bot, msg, state, ctx) => {
    const query = String(msg.text || "").trim();
    if (!query || query.startsWith("/")) { ctx.clearState(String(msg.from.id)); return; }
    ctx.clearState(String(msg.from.id));
    const loading = await bot.sendMessage(msg.chat.id, `<h2>⌖ MENCARI LOKASI</h2><p>Query: <b>${escapeXml(query.slice(0,160))}</b></p><p>Memeriksa data lokasi publik…</p>`);
    try {
        const res = await axios.get("https://nominatim.openstreetmap.org/search", {
            params: { q: query, format: "jsonv2", addressdetails: 1, limit: 5, "accept-language": "id" },
            headers: { "User-Agent": "MULTI-FUNGSI-TelegramBot/1.0 (location search)" }, timeout: 15000
        });
        const items = Array.isArray(res.data) ? res.data : [];
        if (!items.length) return safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌖ LOKASI TIDAK DITEMUKAN</h2><p>Coba tambahkan nama kota atau wilayah yang lebih spesifik.</p>`);
        const blocks = items.map((x,i) => {
            const name = escapeXml(String(x.name || x.type || "Lokasi").slice(0,120));
            const address = escapeXml(String(x.display_name || "Alamat tidak tersedia").slice(0,500));
            const lat = Number(x.lat), lon = Number(x.lon);
            const map = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${lat},${lon}`)}`;
            return `<h3>${i+1}. ${name}</h3><p>${address}</p><p><code>${lat.toFixed(6)}, ${lon.toFixed(6)}</code></p><p><a href="${map}">Buka di Google Maps</a></p><hr/>`;
        }).join("");
        await safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌖ HASIL PENCARIAN LOKASI</h2><p>Query: <b>${escapeXml(query.slice(0,160))}</b></p><p><i>Sumber: OpenStreetMap Nominatim. Periksa kembali alamat sebelum berkunjung.</i></p><hr/>${blocks}`);
    } catch (e) {
        await safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌖ PENCARIAN GAGAL</h2><p>${escapeXml(errorMsg(e))}</p><p>Coba lagi beberapa saat lagi.</p>`);
    }
});

// ═══════════════════════════════════════════
// OSINT DASAR: public IP / domain DNS only
// Does not enumerate private accounts or collect sensitive personal data.
// ═══════════════════════════════════════════
router.registerCallback("tool_osint_public", async (bot, q, data, user, ctx) => {
    ctx.setState(String(user.id), "tool_osint_public_await", {});
    await bot.sendMessage(q.message.chat.id,
        `<h2>⌕ OSINT PUBLIK</h2><p>Masukkan alamat IP publik atau domain yang ingin diperiksa.</p><p>Contoh: <code>8.8.8.8</code> atau <code>example.com</code></p><p><i>Hanya informasi jaringan/domain publik, bukan data pribadi atau akses akun.</i></p>`,
        { reply_markup: { inline_keyboard: [[{ text: "Batal", callback_data: "menu_tools", style: "danger" }]] } });
});

router.registerMessage("tool_osint_public_await", async (bot, msg, state, ctx) => {
    const target = String(msg.text || "").trim().replace(/^https?:\/\//i, "").split(/[/?#]/)[0];
    if (!target || target.startsWith("/")) { ctx.clearState(String(msg.from.id)); return; }
    ctx.clearState(String(msg.from.id));
    const loading = await bot.sendMessage(msg.chat.id, `<h2>⌕ ANALISIS PUBLIK</h2><p>Memeriksa <code>${escapeXml(target.slice(0,180))}</code>…</p>`);
    try {
        const isIp = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(target) || target.includes(":");
        if (isIp) {
            const r = await axios.get(`https://ipwho.is/${encodeURIComponent(target)}`, { timeout: 12000 });
            const d = r.data || {};
            if (d.success === false) throw new Error(d.message || "IP tidak valid atau tidak tersedia");
            const rows = [
                ["IP", d.ip], ["Tipe", d.type], ["Negara", d.country], ["Wilayah", d.region],
                ["Kota", d.city], ["ISP", d.connection?.isp], ["Organisasi", d.connection?.org],
                ["ASN", d.connection?.asn], ["Zona waktu", d.timezone?.id]
            ].filter(x => x[1] !== undefined && x[1] !== null && x[1] !== "");
            await safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌕ HASIL OSINT IP</h2><p><b>Target:</b> <code>${escapeXml(target)}</code></p><table>${rows.map(x=>`<tr><th>${escapeXml(x[0])}</th><td>${escapeXml(String(x[1]))}</td></tr>`).join("")}</table><p><i>Geolokasi IP bersifat perkiraan dan bukan alamat rumah.</i></p>`);
        } else {
            const domain = target.toLowerCase().replace(/\.$/, "");
            if (!/^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(domain)) throw new Error("Masukkan domain valid, misalnya example.com");
            const [dns, ip] = await Promise.all([
                axios.get(`https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=A`, { timeout: 12000 }),
                axios.get(`https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=MX`, { timeout: 12000 })
            ]);
            const a = (dns.data.Answer || []).map(x=>x.data).filter(Boolean).slice(0,8);
            const mx = (ip.data.Answer || []).map(x=>x.data).filter(Boolean).slice(0,8);
            await safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌕ HASIL OSINT DOMAIN</h2><p><b>Domain:</b> <code>${escapeXml(domain)}</code></p><h3>DNS A</h3>${a.length ? `<ul>${a.map(x=>`<li><code>${escapeXml(x)}</code></li>`).join("")}</ul>` : `<p>Tidak ada record A yang ditemukan.</p>`}<h3>DNS MX</h3>${mx.length ? `<ul>${mx.map(x=>`<li><code>${escapeXml(x)}</code></li>`).join("")}</ul>` : `<p>Tidak ada record MX yang ditemukan.</p>`}<p><a href="https://dns.google/query?name=${encodeURIComponent(domain)}">Buka Google DNS</a></p>`);
        }
    } catch (e) {
        await safeEdit(bot, msg.chat.id, loading.message_id, `<h2>⌕ OSINT GAGAL</h2><p>${escapeXml(errorMsg(e) || e.message)}</p>`);
    }
});
