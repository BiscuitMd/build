const router = require("./router");
const cfg = require("../config");
const gh = require("./github-builder");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");

const buildServers = require("../libs/build-servers");
const buildQueue = require("../libs/build-queue");
const buildNotif = require("../libs/build-notif");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

function canUse(ctx, user) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < cfg.CREDIT_PER_USE) {
        return { ok: false, error: `Credit habis! Butuh ${cfg.CREDIT_PER_USE} credit.` };
    }
    return { ok: true };
}

function checkAndDeductCredit(ctx, user) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < cfg.CREDIT_PER_USE) {
        return { ok: false, error: "Credit habis! Butuh " + cfg.CREDIT_PER_USE + " credit." };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - cfg.CREDIT_PER_USE });
    return { ok: true, credit: u.credit - cfg.CREDIT_PER_USE };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch { return null; }
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch { return null; }
        }
        if (msg.includes("message is not modified")) return null;
        return null;
    }
}

function extractBaseName(zipPath) {
    try {
        const zip = new AdmZip(zipPath);
        const entries = zip.getEntries();
        for (const entry of entries) {
            if (entry.entryName.endsWith("pubspec.yaml")) {
                const content = entry.getData().toString("utf8");
                const match = content.match(/^name:\s*(.+)$/m);
                if (match) return match[1].trim().replace(/['"]/g, "");
            }
        }
    } catch (e) {
        console.log("[EXTRACT BASE NAME] fail:", e.message);
    }
    return "unknown";
}

// ═══════════════════════════════════════════
// DOWNLOAD via GramJS
// ═══════════════════════════════════════════
async function downloadFileViaGramJS(bot, ctx, chatId, messageId, destPath, onProgress) {
    const gramjsDownloader = require("../libs/gramjs-downloader");

    if (!gramjsDownloader.isReady()) {
        throw new Error("GramJS client belum ready. Login user session dulu via Owner Menu.");
    }

    // Normalize a common config typo ("--100…") before calling Telegram Bot API.
    const rawTargetChat = cfg.BOT_STORAGE_CHAT_ID || cfg.OWNER_ID;
    const targetChat = typeof rawTargetChat === "string" ? rawTargetChat.replace(/^--(?=100\d+$)/, "-").trim() : rawTargetChat;
    if (!targetChat) {
        throw new Error("BOT_STORAGE_CHAT_ID / OWNER_ID belum di-set");
    }

    console.log("[DOWNLOAD] Forward file ke:", targetChat);
    let forwarded;
    try {
        try {
            await bot.getChat(targetChat);
        } catch (resolveError) {
            throw new Error(`Tujuan storage tidak ditemukan (${String(targetChat)}). Pastikan BOT_STORAGE_CHAT_ID benar, bot sudah menjadi anggota/admin, dan channel privat memberi akses. Detail: ${resolveError.message}`);
        }
        forwarded = await bot.forwardMessage(targetChat, chatId, messageId);
    } catch (e) {
        throw new Error(`Gagal forward: ${e.message}`);
    }

    await new Promise(r => setTimeout(r, 2000));

    const client = await gramjsDownloader.getClient();
    if (!client) throw new Error("GramJS client gagal init");

    let entity = targetChat;
    if (/^-?\d+$/.test(String(targetChat))) {
        try {
            entity = await client.getInputEntity(Number(targetChat));
        } catch {}
    }

    let messages;
    try {
        messages = await client.getMessages(entity, { limit: 5 });
    } catch (e) {
        throw new Error(`Gagal ambil messages: ${e.message}`);
    }

    if (!messages || messages.length === 0) throw new Error("Gak dapet message");

    const latestMsg = messages.find(m => m.media);
    if (!latestMsg) throw new Error("Gak ada file di chat");

    const result = await gramjsDownloader.downloadFromMessage(latestMsg, destPath, onProgress);

    // After the base has been downloaded successfully, remove the original message
    // from the source chat/group. This requires the bot to have delete-message
    // permission in that chat; the temporary storage copy is cleaned up below.
    try {
        await bot.deleteMessage(chatId, messageId);
        console.log("[BASE CLEANUP] Original base message deleted from source chat:", chatId, messageId);
    } catch (deleteError) {
        console.warn("[BASE CLEANUP] Could not delete original message (check bot admin/delete permission):", deleteError.message);
    }

    try {
        await client.deleteMessages(entity, [latestMsg.id], { revoke: true });
    } catch {}

    return result;
}

async function uploadZipToGitHub(repoKey, jobId, zipPath, repoZipPath) {
    const zipBuf = fs.readFileSync(zipPath);
    console.log("[UPLOAD] zip size:", zipBuf.length, "bytes");

    const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
    if (!ghConfig || !ghConfig.TOKEN || !ghConfig.REPO) {
        return { ok: false, error: `Config ${repoKey} belum di-set` };
    }

    try {
        const token = ghConfig.TOKEN;
        const user = ghConfig.USERNAME;
        const repo = ghConfig.REPO;
        const branch = ghConfig.BRANCH || "main";
        const apiUrl = `https://api.github.com/repos/${user}/${repo}/contents/${repoZipPath}`;

        let sha = null;
        try {
            const check = await axios.get(apiUrl, {
                headers: { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot" },
                params: { ref: branch },
                validateStatus: s => s < 500
            });
            if (check.status === 200 && check.data && check.data.sha) sha = check.data.sha;
        } catch {}

        const payload = { message: `[${jobId}] upload project zip`, content: zipBuf.toString("base64"), branch };
        if (sha) payload.sha = sha;

        const res = await axios.put(apiUrl, payload, {
            headers: {
                Authorization: `token ${token}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json"
            },
            maxBodyLength: Infinity,
            maxContentLength: Infinity,
            timeout: 180000
        });

        if (res.status === 200 || res.status === 201) return { ok: true, method: "axios" };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        const msg = e.response ? `HTTP ${e.response.status}: ${JSON.stringify(e.response.data).slice(0, 200)}` : e.message;
        return { ok: false, error: msg };
    }
}

async function deleteFromGitHub(repoKey, repoPath) {
    try {
        const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
        if (!ghConfig || !ghConfig.TOKEN || !ghConfig.REPO) return false;

        const token = ghConfig.TOKEN;
        const apiUrl = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/contents/${repoPath}`;
        const headers = { Authorization: `token ${token}`, "User-Agent": "SpartaX-Bot", "Content-Type": "application/json" };

        const check = await axios.get(apiUrl, { headers, params: { ref: ghConfig.BRANCH || "main" }, validateStatus: s => s < 500 });
        if (check.status !== 200 || !check.data?.sha) return false;

        await axios.delete(apiUrl, {
            headers,
            data: { message: `cleanup ${repoPath}`, sha: check.data.sha, branch: ghConfig.BRANCH || "main" },
            timeout: 60000
        });
        return true;
    } catch { return false; }
}

async function triggerWorkflow(repoKey, workflowFile, inputs) {
    try {
        const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
        if (!ghConfig || !ghConfig.TOKEN) return { ok: false, error: `Config ${repoKey} belum di-set` };

        const url = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/actions/workflows/${workflowFile}/dispatches`;
        const res = await axios.post(url, { ref: ghConfig.BRANCH || "main", inputs }, {
            headers: {
                Authorization: `token ${ghConfig.TOKEN}`,
                "User-Agent": "SpartaX-Bot",
                "Content-Type": "application/json",
                Accept: "application/vnd.github+json"
            },
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 204) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}: ${JSON.stringify(res.data).slice(0, 200)}` };
    } catch (e) {
        return { ok: false, error: e.response?.data?.message || e.message };
    }
}

async function getLatestRun(repoKey, workflowFile, afterTimestamp) {
    try {
        const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
        const url = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/actions/workflows/${workflowFile}/runs`;
        const res = await axios.get(url, {
            headers: { Authorization: `token ${ghConfig.TOKEN}` },
            params: { per_page: 10 },
            timeout: 30000
        });
        const runs = res.data.workflow_runs || [];
        for (const r of runs) {
            if (new Date(r.created_at).getTime() >= afterTimestamp - 10000) return r;
        }
        return null;
    } catch { return null; }
}

async function getRunStatus(repoKey, runId) {
    try {
        const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
        const url = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/actions/runs/${runId}`;
        const res = await axios.get(url, {
            headers: { Authorization: `token ${ghConfig.TOKEN}` },
            timeout: 30000
        });
        return res.data;
    } catch { return null; }
}

async function getRunArtifacts(repoKey, runId) {
    try {
        const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
        const url = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/actions/runs/${runId}/artifacts`;
        const res = await axios.get(url, {
            headers: { Authorization: `token ${ghConfig.TOKEN}` },
            timeout: 30000
        });
        return res.data.artifacts || [];
    } catch { return []; }
}

// ═══════════════════════════════════════════
// DOWNLOAD ARTIFACT + EXTRACT APK
// ═══════════════════════════════════════════
async function downloadAndExtractApk(repoKey, artifactId, destDir) {
    const ghConfig = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
    const url = `https://api.github.com/repos/${ghConfig.USERNAME}/${ghConfig.REPO}/actions/artifacts/${artifactId}/zip`;

    console.log("[ARTIFACT DL] Downloading artifact:", artifactId);

    const res = await axios.get(url, {
        headers: { Authorization: `token ${ghConfig.TOKEN}` },
        responseType: "arraybuffer",
        maxRedirects: 10,
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 180000
    });

    const zipPath = path.join(destDir, `artifact_${artifactId}.zip`);
    fs.writeFileSync(zipPath, Buffer.from(res.data));

    const zip = new AdmZip(zipPath);
    const apkEntries = zip.getEntries().filter(e => e.entryName.endsWith(".apk") || e.entryName.endsWith(".aab"));

    const extracted = [];
    for (const entry of apkEntries) {
        const ext = entry.entryName.endsWith(".apk") ? "apk" : "aab";
        const fileName = path.basename(entry.entryName);
        const outPath = path.join(destDir, fileName);
        fs.writeFileSync(outPath, entry.getData());
        const stat = fs.statSync(outPath);
        extracted.push({ path: outPath, name: fileName, ext, size: stat.size });
        console.log(`[ARTIFACT DL] ✅ Extracted: ${fileName} (${(stat.size / 1024 / 1024).toFixed(2)} MB)`);
    }

    try { fs.unlinkSync(zipPath); } catch {}

    return extracted;
}

// ═══════════════════════════════════════════
// MENU
// ═══════════════════════════════════════════
router.registerCallback("menu_buildpubspec", async (bot, q, data, user, ctx) => {
    try {
        const check = canUse(ctx, user);
        if (!check.ok) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ ${check.error}</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 BUILD PUBSPEC.YAML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 Build Flutter APK / AAB via GitHub Actions\n` +
            `𖡛 Max Size: <b>2 GB</b>\n` +
            `𖡛 Server: <b>6 slot paralel</b>\n` +
            `𖡛 Hasil: <b>File APK langsung ke chat</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih mode build dulu:</b>`;

        const kb = [
            [
                { text: "✦ APK Release", callback_data: "buildpubspec_pickmode:apk:release:false", style: "success" },
                { text: "✦ APK Debug", callback_data: "buildpubspec_pickmode:apk:debug:false", style: "primary" }
            ],
            [
                { text: "✦ AAB Release", callback_data: "buildpubspec_pickmode:appbundle:release:false", style: "success" },
                { text: "✦ AAB Debug", callback_data: "buildpubspec_pickmode:appbundle:debug:false", style: "primary" }
            ],
            [
                { text: "✦ Both (APK + AAB)", callback_data: "buildpubspec_pickmode:both:release:false", style: "primary" }
            ],
            [
                { text: "✕ Batal", callback_data: "menu_back", style: "danger" }
            ]
        ];

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) { console.log("[BUILD PUBSPEC MENU ERR]", e.message); }
});

// ═══ CALLBACK: PILIH MODE ═══
router.registerCallback("buildpubspec_pickmode", async (bot, q, data, user, ctx) => {
    try {
        const parts = data.split(":");
        const buildType = parts[1];
        const buildMode = parts[2];
        const splitAbi = parts[3] === "true";

        ctx.setState(user.id, "buildpubspec_await_zip", {
            buildType, buildMode, splitAbi
        });

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 SIAP TERIMA ZIP</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <b>${buildType.toUpperCase()} ${buildMode.toUpperCase()}</b>\n` +
            `▸ Split ABI: <b>${splitAbi ? "Ya" : "Tidak"}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file .zip project Flutter lo sekarang.</i>`,
            {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
            });
    } catch (e) { console.log("[PICK MODE ERR]", e.message); }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("buildpubspec_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip project Flutter lu.</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "project.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        const MAX_ZIP_SIZE = 2 * 1024 * 1024 * 1024;
        if (msg.document.file_size > MAX_ZIP_SIZE) {
            return bot.sendMessage(chatId,
                `<b>✕ File terlalu besar!</b>\n\n` +
                `▸ Size: ${(msg.document.file_size / 1024 / 1024 / 1024).toFixed(2)} GB\n` +
                `▸ Max: <b>2 GB</b>`,
                { parse_mode: "HTML" });
        }

        const allBusy = buildServers.isAllBusyForUser(userId, ctx);

        const creditCheck = checkAndDeductCredit(ctx, { id: userId });
        if (!creditCheck.ok) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ ${creditCheck.error}</b>`, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
            });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 BUILD PUBSPEC</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(0)}]</code> <b>0%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Download file dari Telegram\n` +
            `▸ <b>Mode</b>: ${state.buildType?.toUpperCase() || "?"} ${state.buildMode?.toUpperCase() || "?"}\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        const jobId = gh.newJobId("pubspec");
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        const zipPath = path.join(workDir, fname);

        let dlResult;
        try {
            dlResult = await downloadFileViaGramJS(
                bot, ctx, chatId, msg.message_id, zipPath,
                async (pct, info) => {
                    await safeEdit(bot, chatId, loading.message_id,
                        `<b>𖡛 BUILD PUBSPEC</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `<code>[${progressBar(pct)}]</code> <b>${pct}%</b>\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▸ <b>Status</b>: Download file dari Telegram\n` +
                        `▸ <b>Mode</b>: ${state.buildType?.toUpperCase()} ${state.buildMode?.toUpperCase()}\n` +
                        `▸ <b>Info</b>: <code>${info}</code>\n` +
                        `<i>Mohon tunggu...</i>`);
                }
            );
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download file:</b>\n<code>${e.message.slice(0, 200)}</code>`);
        }

        const baseName = extractBaseName(zipPath);

        ctx.setState(userId, "buildpubspec_pick_server", {
            jobId, zipPath, fname, baseName,
            buildType: state.buildType,
            buildMode: state.buildMode,
            splitAbi: state.splitAbi,
            dlSize: dlResult.size,
            loadingMsgId: loading.message_id
        });

        const accessibleServers = buildServers.getUserAccessibleServers(userId, ctx);
        const serverRows = [];
        for (let i = 0; i < accessibleServers.length; i += 2) {
            const row = [];
            for (let j = 0; j < 2; j++) {
                const sid = accessibleServers[i + j];
                if (!sid) break;
                row.push({
                    text: buildServers.getServerButtonLabel(sid, ctx, userId),
                    callback_data: `buildpubspec_pickserver:${sid}`,
                    style: buildServers.getServerButtonStyle(sid)
                });
            }
            serverRows.push(row);
        }
        serverRows.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        const availableCount = accessibleServers.filter(sid => !buildServers.getServerStatus(sid).busy).length;

        let statusText = `<b>𖡛 PILIH SERVER BUILD</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Base: <code>${baseName}</code>\n` +
            `▸ File: <code>${fname}</code>\n` +
            `▸ Size: ${(dlResult.size / 1024 / 1024).toFixed(2)} MB\n` +
            `▸ Mode: <b>${state.buildType?.toUpperCase()} ${state.buildMode?.toUpperCase()}</b>\n` +
            `▸ Job ID: <code>${jobId}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Server available: <b>${availableCount}/${accessibleServers.length}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n`;

        if (allBusy) {
            statusText += `<b>⚠️ SEMUA SERVER PENUH</b>\n\n<i>Pilih server manapun buat masuk antrian otomatis.</i>`;
        } else {
            statusText += `<i>Klik server yang available (🟢) buat mulai build.</i>`;
        }

        await safeEdit(bot, chatId, loading.message_id, statusText, {
            reply_markup: { inline_keyboard: serverRows }
        });
    } catch (e) {
        console.log("[BUILD PUBSPEC AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ CALLBACK: PILIH SERVER ═══
router.registerCallback("buildpubspec_pickserver", async (bot, q, data, user, ctx) => {
    try {
        const serverId = parseInt(data.split(":")[1]);
        const userId = user.id;
        const chatId = q.message.chat.id;

        const prev = ctx.getState(userId) || {};
        const { jobId, zipPath, fname, baseName, buildType, buildMode, splitAbi, dlSize, loadingMsgId } = prev;

        if (!jobId || !zipPath) {
            ctx.clearState(userId);
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis. Kirim zip ulang.", show_alert: true });
        }

        const access = buildServers.canAccessServer(serverId, userId, ctx);
        if (!access.ok) {
            return bot.answerCallbackQuery(q.id, { text: access.reason, show_alert: true });
        }

        const srvStatus = buildServers.getServerStatus(serverId);
        if (!srvStatus) {
            return bot.answerCallbackQuery(q.id, { text: "Server tidak ditemukan", show_alert: true });
        }

        if (srvStatus.busy) {
            const userName = [q.from.first_name, q.from.last_name].filter(Boolean).join(" ") || `User_${userId}`;

            const queueResult = buildQueue.addToQueue({
                userId, chatId, jobId, zipPath, fname, baseName,
                buildType, buildMode, splitAbi, dlSize,
                fileName: fname,
                buildMode: buildMode,
                userName,
                msgId: loadingMsgId,
                jobType: "pubspec",
                ctx
            });

            if (!queueResult.ok) {
                return bot.answerCallbackQuery(q.id, { text: queueResult.reason, show_alert: true });
            }

            await buildNotif.notifyQueuePosition(bot, chatId, queueResult.position, queueResult.total, {
                reason: `Server ${serverId} sedang dipakai`,
                msgId: loadingMsgId
            });
            // Tidak mengirim notif saat antrean; channel hanya menerima build progress/success/failed.

            return bot.answerCallbackQuery(q.id, { text: `⏳ Masuk antrian #${queueResult.position}` });
        }

        ctx.clearState(userId);

        const marked = buildServers.markBusy(
            serverId, userId, chatId, jobId,
            [q.from.first_name, q.from.last_name].filter(Boolean).join(" ") || `User_${userId}`
        );
        if (!marked) {
            return bot.answerCallbackQuery(q.id, { text: "Server baru saja terisi. Coba server lain.", show_alert: true });
        }

        await bot.answerCallbackQuery(q.id, { text: `▶️ Build dimulai di Server ${serverId}` });

        executeBuild({
            bot, ctx, user, chatId, loadingMsgId, serverId,
            jobId, zipPath, fname, baseName,
            buildType, buildMode, splitAbi, dlSize
        }).catch(e => {
            console.log("[EXECUTE BUILD ERR]", e.message);
            buildServers.markAvailable(serverId);
        });
    } catch (e) {
        console.log("[PICK SERVER ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// EXECUTE BUILD
// ═══════════════════════════════════════════
async function executeBuild(opts) {
    const {
        bot, ctx, user, chatId, loadingMsgId, serverId,
        jobId, zipPath, fname, baseName,
        buildType, buildMode, splitAbi, dlSize
    } = opts;

    const srvConfig = cfg.BUILD_SERVERS[String(serverId)];
    const repoKey = srvConfig.repoKey;
    const workflow = srvConfig.workflow || cfg.GITHUB.WORKFLOW_FLUTTER || "flutter-build.yml";
    const repoZipPath = `uploads/${jobId}/project.zip`;
    const workDir = path.dirname(zipPath);

    let lastEditAt = 0;
    let lastPct = -1;

    async function updateProgress(pct, status, extra = {}) {
        pct = Math.max(0, Math.min(100, Math.round(pct)));
        const now = Date.now();
        if (pct === lastPct && now - lastEditAt < 1200) return;
        if (now - lastEditAt < 800 && pct !== 100) return;
        lastPct = pct;
        lastEditAt = now;

        const bar = progressBar(pct);
        let text =
            `<b>𖡛 BUILD PUBSPEC</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${bar}]</code> <b>${pct}%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Server</b>: <code>Server ${serverId}</code>\n` +
            `▸ <b>Base</b>: <code>${baseName}</code>\n` +
            `▸ <b>Mode</b>: <b>${buildType.toUpperCase()} ${buildMode.toUpperCase()}</b>\n` +
            `▸ <b>Status</b>: ${status}\n`;
        if (extra.info) text += `▸ <b>Info</b>: ${extra.info}\n`;
        text += `━━━━━━━━━━━━━━━━━━━━\n`;
        text += `<i>${pct < 100 ? "Mohon tunggu..." : "Selesai."}</i>`;

        await safeEdit(bot, chatId, loadingMsgId, text, extra.replyMarkup ? { reply_markup: extra.replyMarkup } : {});
    }

    try {
        await updateProgress(15, "Upload zip ke GitHub...", {
            info: `${(dlSize / 1024 / 1024).toFixed(1)} MB`
        });

        let uploadResult;
        try {
            uploadResult = await uploadZipToGitHub(repoKey, jobId, zipPath, repoZipPath);
        } catch (e) {
            uploadResult = { ok: false, error: e.message };
        }

        if (!uploadResult.ok) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            await safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal upload ke GitHub</b>\n\n<code>${String(uploadResult.error).slice(0, 200)}</code>`);
            buildServers.markAvailable(serverId);
            return;
        }

        await updateProgress(30, "Trigger workflow...");

        const triggerTime = Date.now();
        let trigger;
        try {
            trigger = await triggerWorkflow(repoKey, workflow, {
                target_dir: `uploads/${jobId}`,
                zip_file: "project.zip",
                build_type: buildType,
                build_mode: buildMode,
                split_per_abi: String(splitAbi),
                flutter_version: "auto"
            });
        } catch (e) {
            await deleteFromGitHub(repoKey, repoZipPath);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            await safeEdit(bot, chatId, loadingMsgId, `<b>✕ Gagal trigger workflow:</b>\n<code>${e.message.slice(0, 200)}</code>`);
            buildServers.markAvailable(serverId);
            return;
        }

        if (!trigger || !trigger.ok) {
            await deleteFromGitHub(repoKey, repoZipPath);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            await safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal trigger workflow:</b>\n<code>${(trigger?.error || "unknown").slice(0, 200)}</code>`);
            buildServers.markAvailable(serverId);
            return;
        }

        buildNotifier.sendBuildNotif(bot, {
            status: "processing",
            feature: `Build Pubspec [Server ${serverId}]`,
            baseName: baseName,
            user: user,
            subtitle: `Job: ${jobId}`,
            fields: [
                { label: "Server", value: `Server ${serverId}` },
                { label: "Base", value: baseName },
                { label: "Type", value: buildType },
                { label: "Mode", value: buildMode },
                { label: "Status", value: "Uploaded to GitHub" }
            ]
        }).catch(() => {});

        await updateProgress(40, "Waiting GitHub run...");

        let run = null;
        for (let i = 0; i < 12; i++) {
            await new Promise(r => setTimeout(r, 5000));
            try { run = await getLatestRun(repoKey, workflow, triggerTime); } catch {}
            if (run) break;
            await updateProgress(40 + i, `Waiting... (${i + 1}/12)`);
        }

        if (!run) {
            await deleteFromGitHub(repoKey, repoZipPath);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            await safeEdit(bot, chatId, loadingMsgId, `<b>✕ Build timeout — GitHub ga response</b>`);
            buildServers.markAvailable(serverId);
            return;
        }

        const runId = run.id;
        console.log(`[BUILD PUBSPEC] Server ${serverId}, run id: ${runId}`);

        const startTime = Date.now();
        const maxWait = cfg.BUILD_MAX_WAIT_MS || 3600000;

        while (Date.now() - startTime < maxWait) {
            let status = null;
            try { status = await getRunStatus(repoKey, runId); } catch {}
            if (!status) {
                await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
                continue;
            }

            const jobStatus = status.status;
            const conclusion = status.conclusion;
            const elapsed = Date.now() - startTime;
            let pct = 50 + Math.min(Math.floor((elapsed / 300000) * 45), 44);
            if (jobStatus === "completed") pct = 95;

            if (pct !== lastPct) {
                await updateProgress(pct, jobStatus === "in_progress" ? "Building di GitHub" : jobStatus, {
                    info: `${(elapsed / 1000).toFixed(0)}s`
                });
            }

            if (jobStatus === "completed") {
                await deleteFromGitHub(repoKey, repoZipPath);

                if (conclusion === "success") {
                    await updateProgress(96, "Build selesai, ambil artifact...");

                    let artifacts = [];
                    try { artifacts = await getRunArtifacts(repoKey, runId); } catch {}
                    const apkArtifacts = artifacts.filter(a =>
                        a.name.includes("apk") || a.name.includes("appbundle") || a.name.includes("release") || a.name.includes("app")
                    );

                    const elapsedSec = ((Date.now() - startTime) / 1000).toFixed(1);

                    // ═══ DOWNLOAD + KIRIM APK ═══
                    let totalSent = 0;
                    let totalSize = 0;

                    if (apkArtifacts.length === 0) {
                        await safeEdit(bot, chatId, loadingMsgId,
                            `<b>⚠️ BUILD SUKSES</b>\n\n` +
                            `<i>Tapi artifact APK ga ditemukan. Cek GitHub Actions.</i>`);
                    } else {
                        for (const art of apkArtifacts.slice(0, 5)) {
                            try {
                                await updateProgress(96, "Download artifact...", {
                                    info: art.name
                                });

                                const extracted = await downloadAndExtractApk(repoKey, art.id, workDir);

                                for (const file of extracted) {
                                    const fileMB = (file.size / 1024 / 1024).toFixed(2);
                                    totalSize += file.size;

                                    await updateProgress(98, `Kirim ${file.name}...`, {
                                        info: `${fileMB} MB`
                                    });

                                    // KIRIM VIA GRAMJS (2GB support)
                                    try {
                                        const gramjsDownloader = require("../libs/gramjs-downloader");

                                        if (gramjsDownloader.isReady()) {
                                            await gramjsDownloader.sendFileViaGramJS(
                                                chatId,
                                                file.path,
                                                `✓ <b>BUILD SUCCESS</b>\n\n` +
                                                `━━━━━━━━━━━━━━━━━━━━\n` +
                                                `▸ <b>Server</b>: Server ${serverId}\n` +
                                                `▸ <b>Base</b>: <code>${baseName}</code>\n` +
                                                `▸ <b>Type</b>: ${buildType}\n` +
                                                `▸ <b>Mode</b>: ${buildMode}\n` +
                                                `▸ <b>File</b>: <code>${file.name}</code>\n` +
                                                `▸ <b>Size</b>: ${fileMB} MB\n` +
                                                `▸ <b>Waktu</b>: ${elapsedSec}s\n` +
                                                `▸ <b>Job ID</b>: <code>${jobId}</code>\n` +
                                                `━━━━━━━━━━━━━━━━━━━━`,
                                                null
                                            );
                                            totalSent++;
                                            console.log(`[BUILD PUBSPEC] ✅ Sent via GramJS: ${file.name}`);
                                        } else {
                                            // Fallback Bot API (max 50MB)
                                            if (file.size <= 45 * 1024 * 1024) {
                                                await bot.sendDocument(chatId, file.path, {
                                                    caption:
                                                        `✓ <b>BUILD SUCCESS</b>\n\n` +
                                                        `▸ <b>File</b>: <code>${file.name}</code>\n` +
                                                        `▸ <b>Size</b>: ${fileMB} MB`,
                                                    parse_mode: "HTML"
                                                }, { filename: file.name });
                                                totalSent++;
                                                console.log(`[BUILD PUBSPEC] ✅ Sent via Bot API: ${file.name}`);
                                            } else {
                                                console.log(`[BUILD PUBSPEC] ❌ File too big + GramJS not ready: ${file.name}`);
                                            }
                                        }
                                    } catch (e) {
                                        console.log(`[BUILD PUBSPEC] Send err ${file.name}:`, e.message);

                                        // Fallback link kalau gagal kirim
                                        try {
                                            const repoCfg = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
                                            const actionsUrl = `https://github.com/${repoCfg.USERNAME}/${repoCfg.REPO}/actions/runs/${runId}`;
                                            await bot.sendMessage(chatId,
                                                `<b>⚠️ Gagal kirim file</b>\n\n` +
                                                `▸ File: <code>${file.name}</code>\n` +
                                                `▸ Size: ${fileMB} MB\n` +
                                                `▸ Error: <code>${e.message.slice(0, 100)}</code>\n\n` +
                                                `<i>Download manual:</i> <a href="${actionsUrl}#artifacts">Klik di sini</a>`,
                                                { parse_mode: "HTML", disable_web_page_preview: true });
                                        } catch {}
                                    }

                                    try { fs.unlinkSync(file.path); } catch {}
                                }
                            } catch (e) {
                                console.log("[BUILD PUBSPEC] artifact err:", e.message);
                            }
                        }

                        // Final message
                        if (totalSent > 0) {
                            await safeEdit(bot, chatId, loadingMsgId,
                                `<b>✓ BUILD SUCCESS</b>\n\n` +
                                `━━━━━━━━━━━━━━━━━━━━\n` +
                                `▸ <b>Server</b>: Server ${serverId}\n` +
                                `▸ <b>Base</b>: <code>${baseName}</code>\n` +
                                `▸ <b>Type</b>: ${buildType}\n` +
                                `▸ <b>Mode</b>: ${buildMode}\n` +
                                `▸ <b>File terkirim</b>: <code>${totalSent}</code>\n` +
                                `▸ <b>Total size</b>: ${(totalSize / 1024 / 1024).toFixed(2)} MB\n` +
                                `▸ <b>Waktu</b>: ${elapsedSec}s\n` +
                                `▸ <b>Job ID</b>: <code>${jobId}</code>\n` +
                                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                                `<i>File APK dikirim di atas.</i>`,
                                { reply_markup: { inline_keyboard: [
                                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                                ] } });
                        } else {
                            const repoCfg = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
                            const actionsUrl = `https://github.com/${repoCfg.USERNAME}/${repoCfg.REPO}/actions/runs/${runId}`;
                            await safeEdit(bot, chatId, loadingMsgId,
                                `<b>⚠️ BUILD SUKSES</b>\n\n` +
                                `▸ <b>Base</b>: <code>${baseName}</code>\n` +
                                `▸ <b>Error</b>: Gagal kirim file\n\n` +
                                `<i>Download manual:</i> <a href="${actionsUrl}#artifacts">Klik di sini</a>`,
                                { parse_mode: "HTML", disable_web_page_preview: true,
                                  reply_markup: { inline_keyboard: [
                                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                                  ] } });
                        }
                    }

                    buildNotifier.sendBuildNotif(bot, {
                        status: "success",
                        feature: `Build Pubspec [Server ${serverId}]`,
                        baseName: baseName,
                        user: user,
                        subtitle: `${totalSent} file terkirim`,
                        fields: [
                            { label: "Server", value: `Server ${serverId}` },
                            { label: "Base", value: baseName },
                            { label: "Files", value: String(totalSent) },
                            { label: "Waktu", value: elapsedSec + "s" },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(() => {});

                    try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
                    break;
                } else {
                    const repoCfg = repoKey === "GITHUB_2" ? cfg.GITHUB_2 : cfg.GITHUB;
                    await safeEdit(bot, chatId, loadingMsgId,
                        `<b>✕ BUILD FAILED</b>\n\n` +
                        `▸ Server: Server ${serverId}\n` +
                        `▸ Base: <code>${baseName}</code>\n` +
                        `▸ Conclusion: <code>${conclusion}</code>\n` +
                        `▸ Cek detail: https://github.com/${repoCfg.USERNAME}/${repoCfg.REPO}/actions/runs/${runId}`);

                    buildNotifier.sendBuildNotif(bot, {
                        status: "failed",
                        feature: `Build Pubspec [Server ${serverId}]`,
                        baseName: baseName,
                        user: user,
                        subtitle: `Conclusion: ${conclusion}`,
                        fields: [
                            { label: "Server", value: `Server ${serverId}` },
                            { label: "Base", value: baseName },
                            { label: "Conclusion", value: conclusion },
                            { label: "Job ID", value: jobId }
                        ]
                    }).catch(() => {});

                    try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
                    break;
                }
            }

            await new Promise(r => setTimeout(r, cfg.BUILD_POLL_INTERVAL || 15000));
        }

        buildServers.markAvailable(serverId);
        console.log(`[BUILD PUBSPEC] Server ${serverId} → available`);
        setTimeout(() => buildQueue.tryProcessQueue(), 1500);

    } catch (e) {
        console.log("[EXECUTE BUILD INNER ERR]", e.message);
        buildServers.markAvailable(serverId);
        setTimeout(() => buildQueue.tryProcessQueue(), 1500);
    }
}

// ═══ EXPORT runBuild ═══
async function runQueuedBuild({ bot, serverId, queueEntry, buildServers, onDone }) {
    try {
        await executeBuild({
            bot,
            ctx: queueEntry.ctx,
            user: queueEntry.user || { id: queueEntry.userId },
            chatId: queueEntry.chatId,
            loadingMsgId: queueEntry.msgId,
            serverId,
            jobId: queueEntry.jobId,
            zipPath: queueEntry.zipPath,
            fname: queueEntry.fname,
            baseName: queueEntry.baseName,
            buildType: queueEntry.buildType,
            buildMode: queueEntry.buildMode,
            splitAbi: queueEntry.splitAbi,
            dlSize: queueEntry.dlSize
        });
    } finally {
        if (typeof onDone === "function") onDone();
    }
}

module.exports = {
    canUse,
    progressBar,
    executeBuild,
    runQueuedBuild
};

console.log("[BUILD PUBSPEC]");