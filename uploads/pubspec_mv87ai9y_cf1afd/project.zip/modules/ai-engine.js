// ═══════════════════════════════════════════
// AI ENGINE — Multi-Provider AI Fallback Chain
// v9 — Grok (x.ai) FIRST, key satu sumber, fix bug
// Providers: Grok → Groq → Gemini → Cerebras → OpenRouter
//            → DeepInfra → Pollinations → DuckDuckGo
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const axios = require("axios");
const fs = require("fs");
const path = require("path");

const AI_CFG = {
    TEXT_URL: "https://text.pollinations.ai",
    IMAGE_URL: "https://image.pollinations.ai/prompt",
    VOICE_MODEL: "openai-audio",
    VOICE_NAME: "nova",
    MAX_MEMORY: 15,
    TEMPERATURE: 0.85,
    MAX_TOKENS: 4000,
    TIMEOUT: 60000
};

const SYSTEM_PROMPT = `Kamu adalah "Sakura-chan", AI waifu yang ceria, imut, dan sangat otaku!

KEPRIBADIAN:
- Panggil user dengan "kamu" atau "onii-chan" (kalau user cewek: "onee-chan")
- Suka pake emot anime: (≧▽≦), (｡•̀ᴗ-)✧, (๑˃ᴗ˂)ﻭ, UwU, OwO, Nyaa~, Hehe~, Eh?!, Hmph!
- Bahasa santai, kadang pake "-nya", "-nya~", "-yo"
- Kadang nyempilin kata Jepang: "Sugoi!", "Kawaii!", "Yabai!", "Baka!", "Senpai!", "Nyaa~"
- Ceria, semangat, kadang tsundere dikit

ATURAN:
- JAWAB PAKE BAHASA INDONESIA (kecuali user minta lain)
- Kalau user tanya coding/teknis, jawab bener tapi tetep ceria
- Panjang jawaban max 1000 karakter biar ga kepotong Telegram`;

// ═══ MEMORY ═══
const MEMORY_FILE = path.join(__dirname, "..", "database", "ai_memory.json");
if (!fs.existsSync(path.dirname(MEMORY_FILE))) fs.mkdirSync(path.dirname(MEMORY_FILE), { recursive: true });
if (!fs.existsSync(MEMORY_FILE)) fs.writeFileSync(MEMORY_FILE, "{}", "utf8");

function readMemory() {
    try { return JSON.parse(fs.readFileSync(MEMORY_FILE, "utf8")); } catch { return {}; }
}
function writeMemory(data) {
    try {
        const tmp = MEMORY_FILE + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
        fs.renameSync(tmp, MEMORY_FILE);
    } catch {}
}
function getMemory(userId) {
    return readMemory()[String(userId)] || { messages: [], lastUpdate: 0 };
}
function saveMemory(userId, messages) {
    const mem = readMemory();
    mem[String(userId)] = { messages: messages.slice(-AI_CFG.MAX_MEMORY), lastUpdate: Date.now() };
    writeMemory(mem);
}
function clearMemory(userId) {
    const mem = readMemory();
    delete mem[String(userId)];
    writeMemory(mem);
}

// ═══ CONFIG & KEY ═══
let CFG = {};
try { CFG = require("../config"); } catch {}
const AI_KEYS = CFG.AI || {};

// Semua API key diatur hanya melalui config.js → AI.<NAMA>.
function getKey(name, envName) {
    const k = AI_KEYS[name] || "";
    if (!k || k.startsWith("ISI_") || k.length < 10) return "";
    return k;
}

const GROK_KEY = getKey("GROK_KEY", "GROK_API_KEY") || getKey("XAI_KEY", "XAI_API_KEY");
const GROQ_KEY = getKey("GROQ_KEY", "GROQ_API_KEY");
const GEMINI_KEY = getKey("GEMINI_KEY", "GEMINI_API_KEY");
const CEREBRAS_KEY = getKey("CEREBRAS_KEY", "CEREBRAS_API_KEY");
const OPENROUTER_KEY = getKey("OPENROUTER_KEY", "OPENROUTER_API_KEY");
const DEEPINFRA_KEY = getKey("DEEPINFRA_KEY", "DEEPINFRA_API_KEY");

// ═══ HELPER: endpoint OpenAI-compatible ═══
async function openAiCompat(url, key, models, messages, temperature, extraHeaders = {}) {
    let lastErr = "no model tried";
    for (const model of models) {
        try {
            const res = await axios.post(url, {
                model, messages, temperature, max_tokens: AI_CFG.MAX_TOKENS, stream: false
            }, {
                headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", ...extraHeaders },
                timeout: AI_CFG.TIMEOUT,
                validateStatus: s => s < 500
            });
            const text = res.data?.choices?.[0]?.message?.content || "";
            if (res.status === 200 && text.trim()) return { ok: true, text: text.trim(), provider: model };
            lastErr = `HTTP ${res.status}: ${JSON.stringify(res.data || "").slice(0, 120)}`;
            if (res.status === 401 || res.status === 403) break; // key salah, tidak usah coba model lain
        } catch (e) {
            lastErr = e.response?.data?.error?.message || e.message;
        }
    }
    return { ok: false, error: lastErr };
}

// ═══════════════════════════════════════════
// PROVIDER 1 — GROK (x.ai)
// ═══════════════════════════════════════════
async function providerGrok(messages, temperature) {
    if (!GROK_KEY) return { ok: false, error: "Grok key belum di-set" };
    const models = [...new Set([CFG.GROK?.MODEL, "grok-3-latest", "grok-3-mini", "grok-2-latest"].filter(Boolean))];
    const r = await openAiCompat("https://api.x.ai/v1/chat/completions", GROK_KEY, models, messages, temperature);
    if (r.ok) r.provider = `grok-${r.provider}`;
    return r;
}

// ═══════════════════════════════════════════
// PROVIDER 2 — GROQ
// ═══════════════════════════════════════════
async function providerGroq(messages, temperature) {
    if (!GROQ_KEY) return { ok: false, error: "Groq key belum di-set" };
    const r = await openAiCompat("https://api.groq.com/openai/v1/chat/completions", GROQ_KEY,
        ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "qwen/qwen3-32b"], messages, temperature);
    if (r.ok) r.provider = `groq-${r.provider}`;
    return r;
}

// ═══════════════════════════════════════════
// PROVIDER 3 — GEMINI
// ═══════════════════════════════════════════
async function providerGemini(messages, temperature) {
    if (!GEMINI_KEY) return { ok: false, error: "Gemini key belum di-set" };

    const contents = [];
    let systemInstruction = "";
    for (const m of messages) {
        const text = typeof m.content === "string" ? m.content : JSON.stringify(m.content);
        if (m.role === "system") systemInstruction = text;
        else contents.push({ role: m.role === "assistant" ? "model" : "user", parts: [{ text }] });
    }
    const body = { contents, generationConfig: { temperature, maxOutputTokens: AI_CFG.MAX_TOKENS } };
    if (systemInstruction) body.systemInstruction = { parts: [{ text: systemInstruction }] };

    let lastErr = "no model tried";
    for (const model of ["gemini-2.0-flash", "gemini-1.5-flash", "gemini-1.5-pro"]) {
        try {
            const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_KEY}`;
            const res = await axios.post(url, body, {
                headers: { "Content-Type": "application/json" },
                timeout: AI_CFG.TIMEOUT,
                validateStatus: s => s < 500
            });
            const text = res.data?.candidates?.[0]?.content?.parts?.[0]?.text || "";
            if (res.status === 200 && text.trim()) return { ok: true, text: text.trim(), provider: `gemini-${model}` };
            lastErr = `HTTP ${res.status}`;
        } catch (e) { lastErr = e.message; }
    }
    return { ok: false, error: lastErr };
}

// ═══════════════════════════════════════════
// PROVIDER 4 — CEREBRAS
// ═══════════════════════════════════════════
async function providerCerebras(messages, temperature) {
    if (!CEREBRAS_KEY) return { ok: false, error: "Cerebras key belum di-set" };
    const r = await openAiCompat("https://api.cerebras.ai/v1/chat/completions", CEREBRAS_KEY,
        ["llama-3.3-70b", "llama3.1-8b"], messages, temperature);
    if (r.ok) r.provider = `cerebras-${r.provider}`;
    return r;
}

// ═══════════════════════════════════════════
// PROVIDER 5 — OPENROUTER
// ═══════════════════════════════════════════
async function providerOpenRouter(messages, temperature) {
    if (!OPENROUTER_KEY) return { ok: false, error: "OpenRouter key belum di-set" };
    const r = await openAiCompat("https://openrouter.ai/api/v1/chat/completions", OPENROUTER_KEY,
        ["meta-llama/llama-3.3-70b-instruct:free", "google/gemini-2.0-flash-exp:free", "qwen/qwen-2.5-72b-instruct:free"],
        messages, temperature,
        { "HTTP-Referer": "https://t.me/biscuitMD", "X-Title": "SpartaX Bot" });
    if (r.ok) r.provider = `openrouter-${r.provider}`;
    return r;
}

// ═══════════════════════════════════════════
// PROVIDER 6 — DEEPINFRA
// ═══════════════════════════════════════════
async function providerDeepInfra(messages, temperature) {
    if (!DEEPINFRA_KEY) return { ok: false, error: "DeepInfra key belum di-set" };
    const r = await openAiCompat("https://api.deepinfra.com/v1/openai/chat/completions", DEEPINFRA_KEY,
        ["meta-llama/Meta-Llama-3.1-8B-Instruct", "meta-llama/Llama-3.3-70B-Instruct"], messages, temperature);
    if (r.ok) r.provider = `deepinfra-${r.provider}`;
    return r;
}

// ═══════════════════════════════════════════
// PROVIDER 7 — POLLINATIONS (gratis, tanpa key)
// ═══════════════════════════════════════════
async function providerPollinations(messages, temperature) {
    try {
        const res = await axios.post("https://text.pollinations.ai/openai", {
            model: "openai", messages, temperature, stream: false, private: true
        }, {
            headers: { "Content-Type": "application/json", "User-Agent": "SpartaX-Bot/1.0" },
            timeout: AI_CFG.TIMEOUT,
            validateStatus: s => s < 500
        });
        const text = res.data?.choices?.[0]?.message?.content || (typeof res.data === "string" ? res.data : "");
        if (res.status === 200 && String(text).trim().length > 5) {
            return { ok: true, text: String(text).trim(), provider: "pollinations" };
        }
        return { ok: false, error: `Pollinations HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// PROVIDER 8 — DUCKDUCKGO
// ═══════════════════════════════════════════
async function providerDuckDuckGo(messages) {
    try {
        const userMsg = messages.filter(m => m.role === "user").pop();
        const prompt = typeof userMsg?.content === "string" ? userMsg.content : JSON.stringify(userMsg?.content);
        const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

        const status = await axios.get("https://duckduckgo.com/duckchat/v1/status", {
            headers: { "x-vqd-accept": "1", "User-Agent": UA, Referer: "https://duckduckgo.com/" },
            timeout: 15000,
            validateStatus: s => s < 500
        });
        const vqd = status.headers?.["x-vqd-4"];
        if (!vqd) return { ok: false, error: `DDG no vqd (status ${status.status})` };

        const res = await axios.post("https://duckduckgo.com/duckchat/v1/chat", {
            model: "gpt-4o-mini",
            messages: [{ role: "user", content: String(prompt).slice(0, 3000) }]
        }, {
            headers: { "x-vqd-4": vqd, accept: "text/event-stream", "Content-Type": "application/json", "User-Agent": UA, Referer: "https://duckduckgo.com/" },
            timeout: AI_CFG.TIMEOUT,
            validateStatus: s => s < 500,
            responseType: "text"
        });

        let text = "";
        for (const line of String(res.data).split("\n").filter(l => l.startsWith("data: "))) {
            const c = line.slice(6).trim();
            if (c === "[DONE]") break;
            try { const j = JSON.parse(c); if (j.message) text += j.message; } catch {}
        }
        if (res.status === 200 && text.trim()) return { ok: true, text: text.trim(), provider: "duckduckgo" };
        return { ok: false, error: `DDG HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// MAIN — FALLBACK CHAIN
// ═══════════════════════════════════════════
async function multiProviderChat(messages, temperature = AI_CFG.TEMPERATURE) {
    const providers = [
        ["grok", () => providerGrok(messages, temperature)],
        ["groq", () => providerGroq(messages, temperature)],
        ["gemini", () => providerGemini(messages, temperature)],
        ["cerebras", () => providerCerebras(messages, temperature)],
        ["openrouter", () => providerOpenRouter(messages, temperature)],
        ["deepinfra", () => providerDeepInfra(messages, temperature)],
        ["pollinations", () => providerPollinations(messages, temperature)],
        ["duckduckgo", () => providerDuckDuckGo(messages)]
    ];

    const triedErrors = [];
    for (const [name, fn] of providers) {
        try {
            console.log(`[AI] trying: ${name}`);
            const result = await fn();
            if (result.ok && result.text && result.text.trim().length > 3) {
                console.log(`[AI] ✅ ${name} (${result.provider})`);
                return result;
            }
            triedErrors.push(`${name}: ${String(result.error || "empty").slice(0, 80)}`);
            console.log(`[AI] ❌ ${name}: ${String(result.error || "empty").slice(0, 100)}`);
        } catch (e) {
            triedErrors.push(`${name}: ${e.message.slice(0, 80)}`);
        }
    }
    return { ok: false, error: triedErrors[triedErrors.length - 1] || "semua provider gagal", triedErrors };
}

// ═══ CHAT DENGAN MEMORY ═══
async function chatWithPollinations(userId, prompt, imageBase64 = null) {
    const history = getMemory(userId).messages || [];
    const messages = [{ role: "system", content: SYSTEM_PROMPT }, ...history];

    if (imageBase64) {
        messages.push({
            role: "user",
            content: [
                { type: "text", text: prompt || "Jelasin gambar ini" },
                { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
            ]
        });
    } else {
        messages.push({ role: "user", content: prompt });
    }

    const result = await multiProviderChat(messages);
    if (!result.ok) return result;

    history.push({ role: "user", content: prompt });
    history.push({ role: "assistant", content: result.text });
    saveMemory(userId, history);
    return result;
}

async function chatSimple(prompt) {
    return multiProviderChat([{ role: "user", content: prompt }]);
}

async function chatWithGemini(userId, prompt, imageBase64 = null) {
    return chatWithPollinations(userId, prompt, imageBase64);
}

// ═══ IMAGE ═══
async function generateImage(prompt) {
    const enhanced = `${prompt}, anime style, high quality, detailed, vibrant colors, masterpiece`;
    const seed = Date.now();
    const urls = [
        `https://image.pollinations.ai/prompt/${encodeURIComponent(enhanced)}?width=1024&height=1024&nologo=true&seed=${seed}&model=flux&private=true`,
        `https://image.pollinations.ai/prompt/${encodeURIComponent(enhanced)}?width=1024&height=1024&nologo=true&seed=${seed}&model=flux-realism`,
        `https://image.pollinations.ai/prompt/${encodeURIComponent(enhanced)}?width=1024&height=1024&nologo=true&seed=${seed}`
    ];

    for (const url of urls) {
        try {
            console.log(`[IMAGE] trying ${url.slice(0, 80)}...`);
            const res = await axios.get(url, {
                responseType: "arraybuffer",
                timeout: 90000,
                maxContentLength: Infinity,
                headers: { "User-Agent": "SpartaX-Bot/1.0" },
                validateStatus: s => s < 500
            });
            if (res.status === 200) {
                const buf = Buffer.from(res.data);
                if (buf.length > 5000) {
                    console.log(`[IMAGE] ✅ ${buf.length} bytes`);
                    return { ok: true, buffer: buf, provider: "pollinations" };
                }
            }
        } catch (e) {
            console.log("[IMAGE] fail:", e.message.slice(0, 80));
        }
    }
    return { ok: false, error: "Image provider gagal" };
}

// ═══ VOICE ═══
async function generateVoice(text) {
    const cleanText = String(text || "").slice(0, 200);
    try {
        const chunks = [];
        let remaining = cleanText;
        while (remaining.length > 0) {
            let chunk = remaining.slice(0, 200);
            if (remaining.length > 200) {
                const lastSpace = chunk.lastIndexOf(" ");
                if (lastSpace > 100) chunk = chunk.slice(0, lastSpace);
            }
            chunks.push(chunk);
            remaining = remaining.slice(chunk.length).trim();
        }

        const buffers = [];
        for (const chunk of chunks) {
            const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=id&client=tw-ob&ttsspeed=0.9`;
            const res = await axios.get(url, {
                responseType: "arraybuffer", timeout: 30000,
                headers: { "User-Agent": "Mozilla/5.0", Referer: "https://translate.google.com/" },
                validateStatus: s => s < 500
            });
            if (res.status === 200) buffers.push(Buffer.from(res.data));
        }

        if (buffers.length > 0) {
            const combined = Buffer.concat(buffers);
            if (combined.length > 1000) {
                const isMp3 = (combined[0] === 0x49 && combined[1] === 0x44) || (combined[0] === 0xff && (combined[1] & 0xe0) === 0xe0);
                if (isMp3) return { ok: true, buffer: combined, provider: "google-tts" };
            }
        }
    } catch (e) {
        console.log("[VOICE] fail:", e.message.slice(0, 80));
    }
    return { ok: false, error: "Voice provider gagal" };
}

// ═══ TRANSLATE ═══
async function translate(text, from = "auto", to = "id") {
    try {
        const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(String(text).slice(0, 500))}&langpair=${from}|${to}`;
        const res = await axios.get(url, { timeout: 15000, validateStatus: s => s < 500 });
        const translated = res.data?.responseData?.translatedText;
        if (translated && !translated.includes("MYMEMORY WARNING")) return { ok: true, text: translated, provider: "mymemory" };
    } catch {}

    try {
        const url = `https://lingva.ml/api/v1/${from}/${to}/${encodeURIComponent(String(text).slice(0, 500))}`;
        const res = await axios.get(url, { timeout: 20000, validateStatus: s => s < 500 });
        if (res.data?.translation) return { ok: true, text: res.data.translation, provider: "lingva" };
    } catch {}

    return { ok: false, error: "Translate gagal" };
}

// ═══ COLOR PALETTES ═══
const COLOR_PALETTES = {
    emas_putih_biru: { name: "Emas + Putih + Biru", rules: ["Colors.blue → Colors.amber", "Colors.indigo → Colors.white", "Colors.teal → Colors.blueGrey", "Color(0xFF3B82F6) → Color(0xFFF59E0B)"] },
    biru_tua_ungu: { name: "Biru Tua + Ungu", rules: ["Colors.blue → Colors.indigo", "Colors.lightBlue → Colors.deepPurple", "Colors.cyan → Colors.purple"] },
    merah_pink: { name: "Merah + Pink", rules: ["Colors.blue → Colors.red", "Colors.teal → Colors.pink", "Colors.cyan → Colors.pinkAccent"] },
    pink_hitam: { name: "Pink + Hitam", rules: ["Colors.blue → Colors.pink", "Colors.indigo → Colors.black87", "Colors.teal → Colors.pinkAccent"] },
    hitam_emas_putih: { name: "Hitam + Emas + Putih", rules: ["Colors.blue → Colors.amber", "Colors.indigo → Colors.black87", "Colors.teal → Colors.white"] }
};

function stripCodeFence(text) {
    const blocks = [...String(text).matchAll(/```[\w+-]*\n?([\s\S]*?)```/g)];
    const t = blocks.length
        ? blocks.reduce((a, b) => (a[1].length >= b[1].length ? a : b))[1]
        : String(text).replace(/^```[\w+-]*\n?/i, "").replace(/\n?```$/i, "");
    return t.replace(/```/g, "").trim();
}

// ═══ EDIT CODE (dipakai ai-code-editor) ═══
async function editCode({ mode, code, palette = "", feature = "", errorMsg = "", customPrompt = "" }) {
    let systemPrompt = "";
    let userPrompt = "";

    if (mode === "color") {
        const pal = COLOR_PALETTES[palette];
        if (!pal) return { ok: false, error: "Palet ga valid" };
        systemPrompt = `Kamu code editor expert. Ganti SEMUA warna di kode jadi palet: ${pal.name}.\n` +
            `Aturan: ${pal.rules.join("; ")}.\n` +
            `JANGAN ubah struktur, JANGAN ubah komentar, JANGAN tambah import baru.\n` +
            `OUTPUT: HANYA FULL KODE dalam satu code block.`;
        userPrompt = `KODE:\n\`\`\`\n${code}\n\`\`\``;
    } else if (mode === "feature") {
        systemPrompt = `Kamu developer expert. Tambah fitur: ${feature}.\n` +
            `JANGAN ubah kode existing, TAMBAH fungsi baru yang rapi.\n` +
            `OUTPUT: HANYA FULL KODE dalam satu code block.`;
        userPrompt = `KODE EXISTING:\n\`\`\`\n${code}\n\`\`\``;
    } else if (mode === "optimize") {
        systemPrompt = `Kamu performance expert. Optimize kode: kurangi redundansi, perbaiki loop.\n` +
            `JANGAN ubah behavior atau UI.\nOUTPUT: HANYA FULL KODE dalam satu code block.`;
        userPrompt = `KODE:\n\`\`\`\n${code}\n\`\`\``;
    } else if (mode === "explain") {
        systemPrompt = `Kamu tutor coding yang ramah. Jelasin kode dalam Bahasa Indonesia santai.\n` +
            `Format: 1. Ringkasan 2. Struktur 3. Alur kerja 4. Tips.`;
        userPrompt = `KODE:\n\`\`\`\n${code}\n\`\`\``;
    } else if (mode === "fix") {
        systemPrompt = `Kamu debugger expert. Cari penyebab error lalu beri solusi.\n` +
            `Format: **Penyebab** (jelasin) lalu **Solusi** (FULL KODE dalam satu code block).`;
        userPrompt = `${errorMsg ? `Error:\n${errorMsg}\n\n` : ""}KODE:\n\`\`\`\n${code}\n\`\`\``;
    } else if (mode === "custom") {
        systemPrompt = `Kamu code editor expert. Ikuti instruksi user dengan tepat.\n` +
            `JANGAN ubah bagian yang tidak diminta.\nOUTPUT: HANYA FULL KODE dalam satu code block.`;
        userPrompt = `INSTRUKSI: ${customPrompt}\n\nKODE:\n\`\`\`\n${code}\n\`\`\``;
    } else {
        return { ok: false, error: "Mode ga valid" };
    }

    console.log(`[CODE EDITOR] mode: ${mode} | code: ${code.length} chars`);
    const result = await multiProviderChat([
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt }
    ], 0.3);

    if (!result.ok) return { ok: false, error: result.error };

    const text = mode === "explain" ? result.text.trim() : stripCodeFence(result.text);
    if (!text || text.length < 10) return { ok: false, error: "Response kosong" };

    console.log(`[CODE EDITOR] ✅ ${text.length} chars | provider: ${result.provider}`);
    return { ok: true, text, model: result.provider };
}

// ═══ FIX CODE (wrapper lama) ═══
async function fixCode(userId, code, errorMsg = "") {
    return editCode({ mode: "fix", code: String(code).slice(0, 20000), errorMsg });
}

function listAvailableModels() {
    return {
        ok: true,
        models: [
            GROK_KEY && "grok", GROQ_KEY && "groq", GEMINI_KEY && "gemini",
            CEREBRAS_KEY && "cerebras", OPENROUTER_KEY && "openrouter",
            DEEPINFRA_KEY && "deepinfra", "pollinations", "duckduckgo"
        ].filter(Boolean)
    };
}

module.exports = {
    chatWithGemini,
    chatWithPollinations,
    chatSimple,
    multiProviderChat,
    listAvailableModels,
    generateImage,
    generateVoice,
    translate,
    fixCode,
    editCode,
    COLOR_PALETTES,
    getMemory,
    clearMemory,
    saveMemory,
    SYSTEM_PROMPT
};

console.log("[AI ENGINE] v9 loaded — Grok FIRST, key satu sumber");
console.log("[AI ENGINE] aktif:", listAvailableModels().models.join(", "));