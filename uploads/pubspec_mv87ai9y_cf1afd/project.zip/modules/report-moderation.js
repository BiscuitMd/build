// Report moderation helper for the existing MULTI FUNGSI bot.
// Telegram Bot API does not expose identities of users who use Telegram's native Report action.
// This command lets the owner moderate a known user ID and provides an Unban button.
module.exports = function installReportModeration(bot, cfg) {
  const ownerId = String(cfg.OWNER_ID || '');
  const targetChat = cfg.REPORT_MODERATION_CHANNEL_ID;

  function ownerOnly(id) { return String(id) === ownerId; }
  function validChat() { return targetChat !== undefined && targetChat !== null && String(targetChat).trim() !== ''; }

  bot.onText(/^\/reportban(?:@\w+)?\s+(\d+)$/, async (msg, match) => {
    if (!ownerOnly(msg.from?.id)) {
      await bot.sendMessage(msg.chat.id, 'Perintah ini khusus owner.').catch(() => {});
      return;
    }
    if (!validChat()) {
      await bot.sendMessage(msg.chat.id, 'Atur REPORT_MODERATION_CHANNEL_ID di config.js terlebih dahulu.').catch(() => {});
      return;
    }
    const targetId = Number(match[1]);
    try {
      await bot.banChatMember(targetChat, targetId);
      await bot.sendMessage(msg.chat.id,
        '<b>🛡️ MODERASI CHANNEL</b>\n\nAkun yang dipilih telah diblokir dari channel. Identitas tidak diumumkan ke channel.',
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔓 Unban dari Channel', callback_data: `reportmod_unban:${targetId}` }]] } }
      );
    } catch (e) {
      console.error('[REPORT MODERATION BAN]', e.message);
      await bot.sendMessage(msg.chat.id, 'Gagal melakukan ban. Periksa ID akun, channel tujuan, dan izin admin bot.').catch(() => {});
    }
  });

  bot.on('callback_query', async (q) => {
    const match = String(q?.data || '').match(/^reportmod_unban:(\d+)$/);
    if (!match) return;
    if (!ownerOnly(q.from?.id)) {
      await bot.answerCallbackQuery(q.id, { text: 'Tombol ini khusus owner.', show_alert: true }).catch(() => {});
      return;
    }
    if (!validChat()) {
      await bot.answerCallbackQuery(q.id, { text: 'REPORT_MODERATION_CHANNEL_ID belum diatur.', show_alert: true }).catch(() => {});
      return;
    }
    const targetId = Number(match[1]);
    try {
      await bot.unbanChatMember(targetChat, targetId, { only_if_banned: true });
      await bot.answerCallbackQuery(q.id, { text: 'Ban berhasil dicabut.' }).catch(() => {});
      await bot.editMessageText(
        '<b>🔓 UNBAN BERHASIL</b>\n\nAkun tidak lagi diblokir dari channel dan dapat bergabung kembali.',
        { chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: 'HTML' }
      ).catch(() => {});
    } catch (e) {
      console.error('[REPORT MODERATION UNBAN]', e.message);
      await bot.answerCallbackQuery(q.id, { text: 'Unban gagal. Periksa izin admin dan status ban.', show_alert: true }).catch(() => {});
    }
  });
};
