// ═══════════════════════════════════════════
// PANEL — MERGED v15 FULL LENGKAP + FIX
// Panel + PanelPro + Pterodactyl Create Panel
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");

function panelHtmlEscape(value) {
    return String(value ?? "—").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

async function notifyPanelChannel(bot, kind, msg, details = {}) {
    const target = cfg.PANEL_NOTIF_CHANNEL || cfg.NOTIF_CHANNEL;
    if (!target) return;
    const fullName = [msg?.from?.first_name, msg?.from?.last_name].filter(Boolean).join(" ") || "User";
    const username = msg?.from?.username ? `@${msg.from.username}` : "—";
    const title = kind === "admin" ? "🛡️ ADMIN PANEL CREATED" : "✅ PANEL CREATED";
    const rows = Object.entries(details).map(([label, value]) => `<tr><td>${panelHtmlEscape(label)}</td><td>${panelHtmlEscape(value)}</td></tr>`).join("");
    const html = `<h2>${title}</h2><p><i>MULTI FUNGSI · PANEL MONITOR</i></p><hr/><table bordered compact><tr><td>Nama</td><td>${panelHtmlEscape(fullName)}</td></tr><tr><td>Username</td><td>${panelHtmlEscape(username)}</td></tr><tr><td>User ID</td><td><code>${panelHtmlEscape(msg?.from?.id)}</code></td></tr>${rows}</table><footer>Notifikasi otomatis saat panel berhasil dibuat.</footer>`;
    try { await bot.sendMessage(target, html, { parse_mode: "HTML" }); }
    catch (e) { console.log("[PANEL CHANNEL NOTIF ERR]", e.message); }
}
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const notify = require("./notify");

const PANEL_FILE = path.join(__dirname, "..", "database", "panel.json");
const SCRIPTS_DIR = path.join(__dirname, "..", "scripts");
const KEYS_DIR = path.join(__dirname, "..", "ssh_keys");

if (!fs.existsSync(SCRIPTS_DIR)) fs.mkdirSync(SCRIPTS_DIR, { recursive: true });
if (!fs.existsSync(KEYS_DIR)) fs.mkdirSync(KEYS_DIR, { recursive: true });

// ═══ CONFIG PANELPRO ═══
const CONFIG = {
    CLOUDFLARE: {
        API_TOKEN: "ISI_CF_API_TOKEN",
        ZONE_ID: "ISI_CF_ZONE_ID",
        DOMAIN_UTAMA: "ISI_DOMAIN_UTAMA"
    },
    DIGITALOCEAN: {
        API_KEY: "ISI_DO_API_KEY",
        DEFAULT_REGION: "sgp1",
        DEFAULT_IMAGE: "ubuntu-22-04-x64"
    },
    SSH: {
        USER_DEFAULT: "root",
        PORT_DEFAULT: 22,
        AUTH_MODE: "key",
        PRIVATE_KEY_PATH: path.join(KEYS_DIR, "id_rsa"),
        PRIVATE_KEY: "",
        PASSPHRASE: ""
    },
    SCRIPTS_URL: "https://raw.githubusercontent.com/BiscuitMd/Full-Sh-boy/main",
    PROTEC_BANNER: "Protec By @biscuitMD hanya untuk admin id 1 yang boleh akses"
};

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch {}
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ SAFE ANSWER — anti double ═══
function safeAnswer(bot, q, text = null, showAlert = false) {
    if (showAlert && text) {
        bot.answerCallbackQuery(q.id, { text, show_alert: true }).catch(() => {});
    }
}

// ═══ READ / WRITE PANEL.JSON ═══
function readPanel() {
    const DEFAULT = { users: {}, groups: [], servers: {}, adp: { "1": {}, "2": {} }, config: {} };
    try {
        const raw = JSON.parse(fs.readFileSync(PANEL_FILE, "utf8"));
        if (!raw.users || typeof raw.users !== "object") raw.users = {};
        if (!raw.groups || !Array.isArray(raw.groups)) raw.groups = [];
        if (!raw.servers || typeof raw.servers !== "object") raw.servers = {};
        if (!raw.adp || typeof raw.adp !== "object") raw.adp = { "1": {}, "2": {} };
        if (!raw.adp["1"]) raw.adp["1"] = {};
        if (!raw.adp["2"]) raw.adp["2"] = {};
        if (!raw.config || typeof raw.config !== "object") raw.config = {};
        try {
            if (cfg.MAIN_GROUP_ID && cfg.MAIN_GROUP_ID !== "-1001234567890") {
                const has = raw.groups.some(g => String(g) === String(cfg.MAIN_GROUP_ID));
                if (!has) {
                    raw.groups.push(cfg.MAIN_GROUP_ID);
                    fs.writeFileSync(PANEL_FILE, JSON.stringify(raw, null, 2), "utf8");
                }
            }
        } catch {}
        return raw;
    } catch {
        try { fs.writeFileSync(PANEL_FILE, JSON.stringify(DEFAULT, null, 2), "utf8"); } catch {}
        return DEFAULT;
    }
}

function writePanel(d) {
    if (!d.users) d.users = {};
    if (!d.groups) d.groups = [];
    if (!d.servers) d.servers = {};
    if (!d.adp) d.adp = { "1": {}, "2": {} };
    if (!d.config) d.config = {};
    try { fs.writeFileSync(PANEL_FILE, JSON.stringify(d, null, 2), "utf8"); return true; }
    catch { return false; }
}

// ═══ ROLE SYSTEM ═══
const ROLE_ORDER = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];

const ROLE_PERMS = {
    reseller: ["create_panel"],
    admin: ["create_panel", "add_reseller", "cadp"],
    owner: ["create_panel", "add_reseller", "add_admin", "cadp"],
    partner: ["create_panel", "add_reseller", "add_admin", "add_owner", "cadp"],
    tangankanann: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "cadp"],
    ceo: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "add_tangankanann", "cadp", "delete_offline"],
    developer: ["create_panel", "add_reseller", "add_admin", "add_owner", "add_partner", "add_tangankanann", "add_ceo", "cadp", "delete_offline"]
};

const ROLE_LABEL = {
    reseller: "𖡛 Reseller", admin: "𖡛 Admin", owner: "𖡛 Owner",
    partner: "𖡛 Partner", tangankanann: "𖡛 Tangan Kanan",
    ceo: "𖡛 CEO", developer: "𖡛 Developer"
};

function hasPerm(role, perm) { if (!role) return false; return (ROLE_PERMS[role] || []).includes(perm); }
function roleRank(role) { return ROLE_ORDER.indexOf(role); }
function canAddRole(actorRole, targetRole) {
    if (!actorRole || !targetRole) return false;
    const ar = roleRank(actorRole), tr = roleRank(targetRole);
    if (ar < 0 || tr < 0) return false;
    if (ar === 0) return false;
    return tr < ar;
}
function isOwnerBot(id, ctx) { return ctx.db.isOwner(id); }

function ensureUser(id, role, days, credit, scope = "illegal") {
    const p = readPanel();
    const key = String(id);
    const now = Date.now();
    p.users[key] = {
        id: key, role, scope,
        expiresAt: now + days * 24 * 60 * 60 * 1000,
        credit,
        createdAt: (p.users[key] && p.users[key].createdAt) || now,
        updatedAt: now
    };
    writePanel(p);
    return p.users[key];
}

function checkExpired() {
    const p = readPanel();
    let changed = false;
    const now = Date.now();
    for (const uid in p.users) {
        if (p.users[uid].expiresAt && now > p.users[uid].expiresAt) {
            delete p.users[uid];
            changed = true;
        }
    }
    if (changed) writePanel(p);
}

function generatePassword(len = 12) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
    let out = "";
    for (let i = 0; i < len; i++) out += chars.charAt(Math.floor(Math.random() * chars.length));
    return out;
}

function normalizeUrl(d) {
    if (!d || d === "belum diset") return "https://t.me/biscuitMD";
    if (d.startsWith("http://") || d.startsWith("https://")) return d;
    return "https://" + d;
}

function isGroupAllowed(chatId) {
    const p = readPanel();
    if (String(chatId) === String(cfg.MAIN_GROUP_ID)) return true;
    return (p.groups || []).some(g => String(g) === String(chatId));
}

setInterval(checkExpired, 60 * 1000);
checkExpired();

async function canDMUser(bot, userId) {
    try {
        const chat = await bot.getChat(userId);
        return chat && chat.type === "private";
    } catch { return false; }
}

// ═══ OWNER GUARD ═══
function requireOwner(bot, q, ctx) {
    if (!ctx.db.isOwner(q.from.id)) {
        bot.answerCallbackQuery(q.id, {
            text: "⚠️ OWNER ONLY! Fitur ini cuma buat owner bot.",
            show_alert: true
        }).catch(() => {});
        return false;
    }
    return true;
}

// ═══ SSH HELPER ═══
async function sshExec(ip, commands = [], user = CONFIG.SSH.USER_DEFAULT, port = CONFIG.SSH.PORT_DEFAULT) {
    const { Client } = require("ssh2");
    return new Promise((resolve) => {
        const conn = new Client();
        const results = [];

        const sshConfig = {
            host: ip, port, username: user,
            readyTimeout: 30000,
            keepaliveInterval: 10000
        };

        if (CONFIG.SSH.AUTH_MODE === "key") {
            let keyData = CONFIG.SSH.PRIVATE_KEY;
            if (!keyData && CONFIG.SSH.PRIVATE_KEY_PATH) {
                try { keyData = fs.readFileSync(CONFIG.SSH.PRIVATE_KEY_PATH, "utf8"); }
                catch (e) { return resolve({ ok: false, error: "✕ Gagal baca SSH key: " + e.message }); }
            }
            if (!keyData) return resolve({ ok: false, error: "✕ SSH key ga ada di config" });
            sshConfig.privateKey = keyData;
            if (CONFIG.SSH.PASSPHRASE) sshConfig.passphrase = CONFIG.SSH.PASSPHRASE;
        }

        conn.on("ready", async () => {
            try {
                for (const cmd of commands) {
                    const out = await new Promise((res) => {
                        let buf = "";
                        conn.exec(cmd, (err, stream) => {
                            if (err) return res({ ok: false, error: err.message, out: "" });
                            stream.on("data", (d) => buf += d.toString());
                            stream.on("stderr", (d) => buf += d.toString());
                            stream.on("close", (code) => res({ ok: code === 0, out: buf, code }));
                        });
                    });
                    results.push({ cmd: cmd.slice(0, 60), ok: out.ok, code: out.code });
                }
                conn.end();
                resolve({ ok: true, results });
            } catch (e) {
                conn.end();
                resolve({ ok: false, error: e.message });
            }
        });

        conn.on("error", (e) => resolve({ ok: false, error: e.message }));
        conn.connect(sshConfig);
    });
}

// ═══ PTERODACTYL CONFIG ═══
function resolvePanelKey(scope) {
    const s = String(scope || "").toLowerCase();
    const map = {
        plta: "PANEL_ILLEGAL", illegal: "PANEL_ILLEGAL", server1: "PANEL_ILLEGAL",
        pltc: "PANEL_LEGAL", legal: "PANEL_LEGAL", server2: "PANEL_LEGAL",
        adp1: "PANEL_ADP1", adp: "PANEL_ADP1",
        adp2: "PANEL_ADP2"
    };
    return map[s] || "PANEL_ILLEGAL";
}

function sanitizeDomain(rawDomain, rawUrl) {
    let domain = String(rawDomain || "").trim().toLowerCase();
    domain = domain.replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!domain || !domain.includes(".") || domain.endsWith(".local")) {
        try {
            if (rawUrl && rawUrl.startsWith("http")) {
                const u = new URL(rawUrl);
                domain = u.hostname.toLowerCase();
            }
        } catch {}
    }
    if (!domain || !domain.includes(".") || domain.endsWith(".local")) {
        domain = "biscuitmd.com";
    }
    return domain.replace(/^www\./, "");
}

function getPteroConfig(scope) {
    const p = readPanel();
    const dyn = p.config || {};
    const key = resolvePanelKey(scope);
    const keyLower = key.toLowerCase();
    const st = cfg[key] || {};
    const dy = dyn[keyLower] || {};

    const finalUrl = (dy.url || st.URL || "").replace(/\/$/, "");
    const finalDomain = sanitizeDomain(dy.domain || st.DOMAIN, finalUrl);

    const nestId = parseInt(dy.nestId || st.NEST_ID || 5);

    return {
        URL: finalUrl,
        API_KEY: dy.apiKey || st.API_KEY || "",
        NEST_ID: nestId,
        DOMAIN: finalDomain,
        DEFAULT_LOCATION: parseInt(dy.location || st.DEFAULT_LOCATION || 1),
        DEFAULT_MEMORY: parseInt(dy.memory || st.DEFAULT_MEMORY || 1024),
        DEFAULT_DISK: parseInt(dy.disk || st.DEFAULT_DISK || 2048),
        DEFAULT_CPU: parseInt(dy.cpu || st.DEFAULT_CPU || 50),
        DEFAULT_DATABASES: parseInt(st.DEFAULT_DATABASES || 1),
        DEFAULT_BACKUPS: parseInt(st.DEFAULT_BACKUPS || 1),
        DEFAULT_ALLOCATIONS: parseInt(st.DEFAULT_ALLOCATIONS || 0),
        LABEL: st.LABEL || key,
        TYPE: st.TYPE || "unknown",
        _key: keyLower
    };
}

function validateApiKey(apiKey) {
    if (!apiKey) return { ok: false, error: "API Key kosong" };
    if (apiKey.includes("GANTI") || apiKey.includes("ISI_")) return { ok: false, error: "API Key belum di-set" };
    if (!apiKey.startsWith("ptla_")) return { ok: false, error: "API Key harus mulai ptla_" };
    return { ok: true };
}

function buildHeaders(apiKey, isGet = false) {
    const h = {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
        "User-Agent": "SpartaX-Bot/15.0"
    };
    if (!isGet) h["Content-Type"] = "application/json";
    return h;
}

// ═══ UI HELPERS ═══
const L = "─", P = "│", TL = "╭", TR = "╮", BL = "╰", BR = "╯", T = "├";
const B = "▸", C = "◉", OK = "✓", X = "✕", AR = "→", ST = "✦", D = "◆";
function box(t) { return `${TL}${L.repeat(20)}${TR}\n${P} ${C} ${t}\n${T}${L.repeat(20)}`; }
function scopeToLabel(scope) {
    return {
        plta: "Server 1 (Ilegal)", illegal: "Server 1 (Ilegal)",
        pltc: "Server 2 (Legal)", legal: "Server 2 (Legal)",
        adp1: "ADP 1", adp: "ADP 1", adp2: "ADP 2"
    }[String(scope).toLowerCase()] || String(scope).toUpperCase();
}

// ═══ RAM LIST ═══
const RAM_LIST = [
    { label: "1 GB", mb: 1024 },
    { label: "2 GB", mb: 2048 },
    { label: "3 GB", mb: 3072 },
    { label: "4 GB", mb: 4096 },
    { label: "5 GB", mb: 5120 },
    { label: "6 GB", mb: 6144 },
    { label: "7 GB", mb: 7168 },
    { label: "8 GB", mb: 8192 },
    { label: "9 GB", mb: 9216 },
    { label: "10 GB", mb: 10240 },
    { label: "Unlimited", mb: 0 }
];

// ═══ AUTO-FETCH EGGS ═══
async function autoFetchEggs(scope) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return { ok: false, error: v.error, eggs: [], source: "none" };

    try {
        const res = await axios.get(
            `${pc.URL}/api/application/nests/${pc.NEST_ID}/eggs`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 20000, validateStatus: s => s < 500 }
        );

        console.log(`[autoFetchEggs] HTTP ${res.status} — nest ${pc.NEST_ID}`);

        if (res.status !== 200) {
            return { ok: false, error: `HTTP ${res.status}`, eggs: [], source: "none" };
        }

        const list = res.data?.data || [];
        console.log(`[autoFetchEggs] Total ${list.length} eggs dari nest ${pc.NEST_ID}`);

        const eggs = [];
        for (const e of list) {
            const a = e.attributes || {};
            if (!a.id || !a.name) continue;
            console.log(`[autoFetchEggs] → "${a.name}" id=${a.id} img=${a.docker_image || "-"}`);
            eggs.push({
                id: a.id,
                eggId: a.id,
                name: a.name,
                docker_image: a.docker_image || "",
                startup: a.startup || "",
                environment: {},
                type: "unknown"
            });
        }

        if (eggs.length === 0) {
            return { ok: false, error: `Nest ${pc.NEST_ID} kosong`, eggs: [], source: "none" };
        }

        return { ok: true, eggs, source: "api-all" };
    } catch (err) {
        console.log(`[autoFetchEggs] err: ${err.message}`);
        return { ok: false, error: err.message, eggs: [], source: "none" };
    }
}

// ═══ BUILD FULL ENV ═══
async function buildFullEnv(scope, eggId) {
    const pc = getPteroConfig(scope);
    const env = {};

    try {
        const res = await axios.get(
            `${pc.URL}/api/application/nests/${pc.NEST_ID}/eggs/${eggId}?include=variables`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 20000, validateStatus: s => s < 500 }
        );

        if (res.status === 200) {
            const vars = res.data?.attributes?.relationships?.variables?.data || [];
            console.log(`[buildFullEnv] egg ${eggId} → ${vars.length} variables`);

            for (const vv of vars) {
                const va = vv.attributes || {};
                const envName = va.env_variable;
                if (!envName) continue;

                let val = va.default_value;
                if (val === null || val === undefined || val === "") {
                    const lower = envName.toLowerCase();
                    if (lower.includes("version")) val = "20";
                    else if (lower.includes("jar")) val = "server.jar";
                    else if (lower.includes("file")) val = "index.js";
                    else if (lower.includes("branch")) val = "main";
                    else if (lower.includes("command")) val = "npm start";
                    else if (lower.includes("port")) val = "3000";
                    else if (lower.includes("memory")) val = "1024";
                    else val = "";
                }
                env[envName] = String(val);
            }
            console.log(`[buildFullEnv] FINAL: ${JSON.stringify(env)}`);
        }
    } catch (e) {
        console.log(`[buildFullEnv] err: ${e.message}`);
    }

    if (Object.keys(env).length === 0) {
        env.GIT_REPO_ADDRESS = "";
        env.INSTALL_BRANCH = "main";
        env.GIT_USERNAME = "";
        env.GIT_ACCESS_TOKEN = "";
        env.CMD_RUN = "npm start";
    }

    return env;
}

// ═══ PTERODACTYL API CALLS ═══
async function pteroGetUserByEmail(scope, email) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;
    try {
        const res = await axios.get(
            `${pc.URL}/api/application/users?filter[email]=${encodeURIComponent(email)}`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (res.status === 200) {
            const list = res.data?.data || [];
            if (list.length > 0) return { ok: true, user: list[0] };
            return { ok: false, error: "User tidak ditemukan" };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) { return { ok: false, error: e.message }; }
}

async function pteroCreateUser(scope, { email, username, firstName, lastName, password }) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;

    const cleanUser = String(username || "").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 30);
    let finalEmail = email && email.includes("@") ? email : `${cleanUser}@${sanitizeDomain(pc.DOMAIN, pc.URL)}`;

    try {
        const res = await axios.post(`${pc.URL}/api/application/users`, {
            email: finalEmail,
            username: cleanUser,
            first_name: String(firstName || cleanUser).slice(0, 30),
            last_name: String(lastName || "User").slice(0, 30),
            password,
            root_admin: false,
            language: "en"
        }, { headers: buildHeaders(pc.API_KEY), timeout: 30000, validateStatus: s => s < 500 });

        if (res.status === 200 || res.status === 201) {
            const attrs = res.data?.attributes || res.data;
            return { ok: true, user: { id: attrs.id, attributes: attrs } };
        }
        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 250);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

async function pteroGetAllocations(scope, nodeId = 1) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;
    try {
        const res = await axios.get(
            `${pc.URL}/api/application/nodes/${nodeId}/allocations?per_page=100`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (res.status === 200) {
            const list = res.data?.data || [];
            const free = list.filter(a => a.attributes && !a.attributes.assigned);
            if (free.length === 0) return { ok: false, error: `Node ${nodeId}: tidak ada allocation kosong` };
            return { ok: true, allocations: free };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) { return { ok: false, error: e.message }; }
}

// ═══════════════════════════════════════════
// PTERO — CREATE USER AS ROOT ADMIN
// ═══════════════════════════════════════════
async function pteroCreateAdminUser(scope, { email, username, firstName, lastName, password, rootAdmin = true }) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;

    const cleanUser = String(username || "").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 30);
    let finalEmail = email && email.includes("@") ? email : `${cleanUser}@${sanitizeDomain(pc.DOMAIN, pc.URL)}`;

    try {
        const payload = {
            email: finalEmail,
            username: cleanUser,
            first_name: String(firstName || cleanUser).slice(0, 30),
            last_name: String(lastName || "Admin").slice(0, 30),
            password: password,
            root_admin: !!rootAdmin,      // ⚡ KEY UTAMA
            language: "en"
        };

        console.log(`[pteroCreateAdminUser] POST ${pc.URL}/api/application/users`);
        console.log(`[pteroCreateAdminUser] payload:`, JSON.stringify({ ...payload, password: "***" }));

        const res = await axios.post(
            `${pc.URL}/api/application/users`,
            payload,
            {
                headers: buildHeaders(pc.API_KEY),
                timeout: 30000,
                validateStatus: s => s < 500
            }
        );

        if (res.status === 200 || res.status === 201) {
            const attrs = res.data?.attributes || res.data;
            console.log(`[pteroCreateAdminUser] ✓ Created user id=${attrs.id} root_admin=${attrs.root_admin}`);
            return { ok: true, user: { id: attrs.id, attributes: attrs } };
        }

        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 250);
        console.log(`[pteroCreateAdminUser] ✕ HTTP ${res.status}: ${errMsg}`);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        console.log(`[pteroCreateAdminUser] ✕ ERROR: ${errMsg}`);
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// PTERO — SET ROOT ADMIN (Update existing user)
// ═══════════════════════════════════════════
async function pteroSetRootAdmin(scope, userId, isRoot = true) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;

    try {
        // Step 1: Get user data dulu
        const getRes = await axios.get(
            `${pc.URL}/api/application/users/${userId}`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 15000, validateStatus: s => s < 500 }
        );

        if (getRes.status !== 200) {
            return { ok: false, error: `Get user HTTP ${getRes.status}` };
        }

        const attrs = getRes.data?.attributes || {};

        // Step 2: Update dengan root_admin: true
        const updatePayload = {
            email: attrs.email,
            username: attrs.username,
            first_name: attrs.first_name,
            last_name: attrs.last_name,
            language: attrs.language || "en",
            root_admin: !!isRoot     // ⚡ KEY UTAMA
        };

        console.log(`[pteroSetRootAdmin] PATCH user ${userId} root_admin=${isRoot}`);

        const patchRes = await axios.patch(
            `${pc.URL}/api/application/users/${userId}`,
            updatePayload,
            { headers: buildHeaders(pc.API_KEY), timeout: 15000, validateStatus: s => s < 500 }
        );

        if (patchRes.status === 200 || patchRes.status === 204) {
            console.log(`[pteroSetRootAdmin] ✓ User ${userId} now root_admin=${isRoot}`);
            return { ok: true };
        }

        const errMsg = patchRes.data?.errors?.[0]?.detail || `HTTP ${patchRes.status}`;
        return { ok: false, error: errMsg };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

async function pteroCreateServer(scope, {
    name, userId, nestId, eggId, dockerImage, startup,
    environment = {}, memory, disk, cpu, allocationId,
    databases = 0, backups = 0, allocations = 0, locationId = 1
}) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;

    try {
        const payload = {
            name: String(name).slice(0, 100),
            user: parseInt(userId),
            egg: parseInt(eggId),
            docker_image: dockerImage,
            startup,
            environment,
            limits: {
                memory: parseInt(memory) || 1024,
                swap: 0,
                disk: parseInt(disk) || 2048,
                io: 500,
                cpu: parseInt(cpu) || 100
            },
            feature_limits: {
                databases: parseInt(databases) || 0,
                backups: parseInt(backups) || 0,
                allocations: parseInt(allocations) || 0
            },
            deploy: { locations: [parseInt(locationId)], dedicated_ip: false, port_range: [] },
            start_on_completion: true,
            allocation: { default: parseInt(allocationId) }
        };

        console.log(`[ptero] POST egg=${eggId} img=${dockerImage} startup="${startup}"`);
        console.log(`[ptero] env=${JSON.stringify(environment)}`);

        const res = await axios.post(`${pc.URL}/api/application/servers`, payload,
            { headers: buildHeaders(pc.API_KEY), timeout: 60000, validateStatus: s => s < 500 });

        if (res.status === 200 || res.status === 201) {
            const attrs = res.data?.attributes || res.data;
            return { ok: true, server: { id: attrs.id, attributes: attrs } };
        }
        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 300);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

async function pteroUpdateStartup(scope, serverId, startup, dockerImage) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;
    try {
        const res = await axios.patch(
            `${pc.URL}/api/application/servers/${serverId}/startup`,
            { startup, environment: {}, image: dockerImage, skip_scripts: false },
            { headers: buildHeaders(pc.API_KEY), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (res.status === 200 || res.status === 204) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) { return { ok: false, error: e.message }; }
}

async function pteroUpdateVariable(scope, serverId, envName, value) {
    const pc = getPteroConfig(scope);
    const v = validateApiKey(pc.API_KEY);
    if (!v.ok) return v;
    try {
        const listRes = await axios.get(
            `${pc.URL}/api/application/servers/${serverId}?include=variables`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (listRes.status !== 200) return { ok: false, error: `HTTP ${listRes.status}` };

        const vars = listRes.data?.attributes?.relationships?.variables?.data || [];
        let found = null;
        for (const vv of vars) {
            const va = vv.attributes || {};
            if (va.env_variable === envName) { found = va.id; break; }
        }
        if (!found) return { ok: false, error: `Variable ${envName} gak ada` };

        const res = await axios.patch(
            `${pc.URL}/api/application/servers/${serverId}/variables/${found}`,
            { key: envName, value: String(value) },
            { headers: buildHeaders(pc.API_KEY), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (res.status === 200 || res.status === 204) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) { return { ok: false, error: e.message }; }
}

function saveConfigToPanel(scope, field, value) {
    try {
        const d = readPanel();
        d.config = d.config || {};
        const key = String(scope).toLowerCase();
        d.config[key] = d.config[key] || {};
        const map = { url: "url", apiKey: "apiKey", domain: "domain", nestId: "nestId", location: "location", memory: "memory", disk: "disk", cpu: "cpu" };
        d.config[key][map[field] || field] = value;
        return writePanel(d);
    } catch { return false; }
}


// ═══════════════════════════════════════════
// cp_srv — (FIX: HANDLER BARU)
// ═══════════════════════════════════════════
router.registerCallback("cp_srv", async (bot, q, data, user, ctx) => {
    try {
        const scope = data.split(":")[1] || "plta";
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;
        const userId = String(user.id);

        const scopeLabel = scopeToLabel(scope);

        await safeEdit(bot, chatId, msgId,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} CREATE PANEL ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +
            `▸ Server: <b>${scopeLabel}</b>\n` +
            `▸ Status: <i>Fetching eggs...</i>`,
            { parse_mode: "HTML" });

        const result = await autoFetchEggs(scope);

        if (!result.ok || !result.eggs || result.eggs.length === 0) {
            return safeEdit(bot, chatId, msgId,
                `${TL}${"═".repeat(15)}${TR}\n` +
                `${P}  ${X} GAGAL FETCH EGGS\n` +
                `${BL}${"═".repeat(15)}${BR}\n\n` +
                `▸ Server: <b>${scopeLabel}</b>\n` +
                `▸ Error: <code>${(result.error || "unknown").slice(0, 150)}</code>\n\n` +
                `<i>Set config dulu pakai /setconfig</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "𖡛 Set Config", callback_data: "setcfg_srv:" + scope, style: "primary" }],
                            [{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]
                        ]
                    }
                });
        }

        ctx.setState(userId, "cp_pick_egg", { scope, eggs: result.eggs });

        const rows = [];
        for (let i = 0; i < result.eggs.length; i += 2) {
            const row = [];
            for (let j = 0; j < 2 && i + j < result.eggs.length; j++) {
                const e = result.eggs[i + j];
                row.push({
                    text: `▸ ${e.name.slice(0, 20)}`,
                    callback_data: `cp_egg:${i + j}`
                });
            }
            rows.push(row);
        }
        rows.push([{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]);

        await safeEdit(bot, chatId, msgId,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} PILIH EGG ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +
            `<blockquote>` +
            `▸ Server: <b>${scopeLabel}</b>\n` +
            `▸ Total Egg: <code>${result.eggs.length}</code>\n` +
            `▸ Nest ID: <code>${getPteroConfig(scope).NEST_ID}</code>` +
            `</blockquote>\n\n` +
            `👉 <b>Pilih egg:</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) {
        console.log("[cp_srv ERR]", e.message);
        try {
            await safeEdit(bot, q.message.chat.id, q.message.message_id,
                `${X} Error: <code>${e.message.slice(0, 150)}</code>`,
                { parse_mode: "HTML" });
        } catch {}
    }
});


// ═══════════════════════════════════════════
// cadp:* — BUTTON CALLBACK (FIX: HANDLER BARU)
// ═══════════════════════════════════════════
router.registerCallback("cadp", async (bot, q, data, user, ctx) => {
    try {
        const serverNum = parseInt(data.split(":")[1]) || 1;
        const chatId = q.message.chat.id;
        const userId = String(user.id);
        const uid = String(userId);

        const p = readPanel();
        const actor = p.users[uid];
        const actorRole = actor?.role;
        const actorScope = actor?.scope || "illegal";
        const isOwner = ctx.db.isOwner(userId);

        if (!isOwner && !actorRole) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} <b>Akses Ditolak</b>\n\nLu belum punya role.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
        }

        if (serverNum === 2 && !isOwner && actorScope !== "legal" && actorScope !== "both") {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} Lu cuma akses Server 1.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
        }

        ctx.setState(uid, `cadp_${serverNum}_await`, { serverNum });

        const scopeLabel = serverNum === 2 ? "Server 2 (Legal)" : "Server 1 (Ilegal)";

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} CREATE ADP ${serverNum} ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +
            `<blockquote>` +
            `▸ Server: <b>${scopeLabel}</b>\n` +
            `▸ Role: <b>${isOwner ? "OWNER" : (ROLE_LABEL[actorRole] || actorRole)}</b>` +
            `</blockquote>\n\n` +
            `👉 <b>Kirim username</b> (3-20 char, a-z 0-9 _)\n` +
            `<i>Ketik <code>cancel</code> buat batal</i>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[
                        { text: "✕ Batal", callback_data: "menu_panelpro", style: "danger" }
                    ]]
                }
            });
    } catch (e) {
        console.log("[cadp callback ERR]", e.message);
    }
});


// ═══════════════════════════════════════════
// cp_pick_egg — STATE HANDLER (fallback via message)
// ═══════════════════════════════════════════
router.registerMessage("cp_pick_egg", async (bot, msg, state, ctx) => {
    try {
        await bot.sendMessage(msg.chat.id,
            `${AR} Pilih egg lewat button di atas ya.`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[cp_pick_egg msg ERR]", e.message); }
});


// ═══════════════════════════════════════════
// /create — BUTTON 2-2 + Validasi Role
// ═══════════════════════════════════════════
module.exports.handleCreate = async function (bot, msg, ctx) {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const isOwner = ctx.db.isOwner(msg.from.id);

        if (msg.chat.type === "private") {
            return bot.sendMessage(chatId,
                `<b>✕ Command /create cuma bisa di GROUP.</b>`,
                { parse_mode: "HTML" });
        }

        if (!isGroupAllowed(chatId) && !isOwner) {
            return bot.sendMessage(chatId,
                `<b>✕ Group belum terdaftar.</b>\n\n` +
                `<i>Owner kirim <code>/addgroup</code> dulu.</i>`,
                { parse_mode: "HTML" });
        }

        if (!isOwner) {
            const panelData = readPanel();
            const userRecord = panelData.users?.[userId];

            if (!userRecord) {
                return bot.sendMessage(chatId,
                    `<b>❌ AKSES DITOLAK</b>\n\n` +
                    `<blockquote>` +
                    `Kamu <b>belum punya role</b> di bot ini.\n\n` +
                    `Buat pake fitur <code>/create</code>, kamu harus:\n` +
                    `    1. Daftar ke owner\n` +
                    `    2. Owner kasih role\n` +
                    `    3. Baru bisa akses` +
                    `</blockquote>\n\n` +
                    `📞 Hubungi owner: <a href="tg://user?id=${cfg.OWNER_ID}">Chat Owner</a>`,
                    { parse_mode: "HTML" });
            }

            if (userRecord.credit < 1) {
                return bot.sendMessage(chatId,
                    `<b>✕ Credit habis!</b>\n\n` +
                    `<i>Credit kamu: <code>${userRecord.credit}</code></i>\n` +
                    `<i>Beli credit ke owner.</i>`,
                    { parse_mode: "HTML" });
            }
        }

        const kb = [
            [
                { text: "𖡛 Server 1", callback_data: "cp_srv:plta", style: "success" },
                { text: "𖡛 Server 2", callback_data: "cp_srv:pltc", style: "primary" },
                { text: "𖡛 ADP 1", callback_data: "cp_srv:adp1", style: "success" }
            ],
            [
                { text: "𖡛 ADP 2", callback_data: "cp_srv:adp2", style: "primary" },
                { text: "𖡛 Info Role", callback_data: "panel_info_role", style: "primary" }
            ],
            [
                { text: "𖡛 Menu Utama", callback_data: "menu_back", style: "danger" }
            ]
        ];

        if (!isOwner) {
            const panelData = readPanel();
            const userRecord = panelData.users?.[userId];
            const userScope = userRecord?.scope || "illegal";

            const kbScoped = [];

            if (userScope === "legal") {
                kbScoped.push([
                    { text: "𖡛 Server 2 (Legal)", callback_data: "cp_srv:pltc", style: "primary" }
                ]);
            } else if (userScope === "both") {
                kbScoped.push([
                    { text: "𖡛 Server 1 (Ilegal)", callback_data: "cp_srv:plta", style: "success" },
                    { text: "𖡛 Server 2 (Legal)", callback_data: "cp_srv:pltc", style: "primary" }
                ]);
            } else {
                kbScoped.push([
                    { text: "𖡛 Server 1 (Ilegal)", callback_data: "cp_srv:plta", style: "success" }
                ]);
            }

            kbScoped.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

            return bot.sendMessage(chatId,
                `${TL}${"═".repeat(15)}${TR}\n` +
                `${P}  ${ST} CREATE PANEL ${ST}  ${P}\n` +
                `${BL}${"═".repeat(15)}${BR}\n\n` +

                `<blockquote>` +
                `👤 <b>INFO USER</b>\n` +
                `    ▸ Role: <b>${ROLE_LABEL[userRecord.role] || userRecord.role}</b>\n` +
                `    ▸ Scope: <b>${userScope === "legal" ? "Server 2 (Legal)" : userScope === "both" ? "Semua Server" : "Server 1 (Ilegal)"}</b>\n` +
                `    ▸ Credit: <code>${userRecord.credit}</code>` +
                `</blockquote>\n\n` +

                `👉 <b><i>PILIH SERVER:</i></b>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: kbScoped } });
        }

        await bot.sendMessage(chatId,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} CREATE PANEL ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +

            `<blockquote>` +
            `👤 <b>INFO USER</b>\n` +
            `    ▸ Role: <b>👑 OWNER</b>\n` +
            `    ▸ Akses: <b>Semua Server</b>` +
            `</blockquote>\n\n` +

            `👉 <b><i>PILIH SERVER:</i></b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[handleCreate ERR]", e.message); }
};

// ═══ cp_egg ═══
router.registerCallback("cp_egg", async (bot, q, data, user, ctx) => {
    try {
        const eggIndex = parseInt(data.split(":")[1]);
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const st = ctx.getState(userId);
        if (!st || !st.eggs) return safeEdit(bot, chatId, q.message.message_id, `${X} Sesi habis`);

        const egg = st.eggs[eggIndex];
        if (!egg) return safeEdit(bot, chatId, q.message.message_id, `${X} Egg invalid`);

        ctx.setState(userId, "cp_pick_ram", { scope: st.scope, egg, eggs: st.eggs });

        const rows = [];
        for (let i = 0; i < RAM_LIST.length; i += 3) {
            const row = [];
            for (let j = 0; j < 3 && i + j < RAM_LIST.length; j++) {
                const r = RAM_LIST[i + j];
                row.push({ text: `▸ ${r.label}`, callback_data: `cp_ram:${r.mb}` });
            }
            rows.push(row);
        }
        rows.push([{ text: `${X} Batal`, callback_data: "menu_back" }]);

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} PILIH RAM ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            box("EGG") +
            `\n${P} ${B} Egg  ${AR}  <b>${egg.name}</b>\n` +
            `${P} ${B} ID   ${AR}  <code>${egg.eggId}</code>\n` +
            `${P} ${B} Image ${AR}  <code>${String(egg.docker_image).slice(0, 30)}</code>\n` +
            `${BL}${L.repeat(20)}${BR}\n\n` +
            `${AR} Pilih RAM:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[cp_egg ERR]", e.message); }
});

// ═══ cp_ram ═══
router.registerCallback("cp_ram", async (bot, q, data, user, ctx) => {
    try {
        const ramMb = parseInt(data.split(":")[1]);
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const st = ctx.getState(userId);
        if (!st || !st.egg) return safeEdit(bot, chatId, q.message.message_id, `${X} Sesi habis`);

        const ramLabel = RAM_LIST.find(r => r.mb === ramMb)?.label || `${ramMb} MB`;
        ctx.setState(userId, "cp_await_username", {
            scope: st.scope, egg: st.egg, eggs: st.eggs,
            ram: ramMb, ramLabel
        });

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} INPUT USERNAME ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            box("KONFIGURASI") +
            `\n${P} ${B} Egg  ${AR}  <b>${st.egg.name}</b>\n` +
            `${P} ${B} RAM  ${AR}  <b>${ramLabel}</b>\n` +
            `${BL}${L.repeat(20)}${BR}\n\n` +
            `${AR} Kirim username (3-20 char, a-z 0-9 _)`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${X} Batal`, callback_data: "menu_back" }]] } });
    } catch (e) { console.log("[cp_ram ERR]", e.message); }
});

// ═══ cp_await_username — proses CREATE ═══
router.registerMessage("cp_await_username", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const username = (msg.text || "").trim();

        if (!username || username.startsWith("/")) { ctx.clearState(userId); return; }
        if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
            return bot.sendMessage(chatId, `${X} Username invalid (3-20 char)`, { parse_mode: "HTML" });
        }

        const { scope, egg, ram, ramLabel } = state;
        ctx.clearState(userId);

        const loading = await bot.sendMessage(chatId,
            `${TL}${L.repeat(20)}${TR}\n${P} ${C} CREATING PANEL\n${T}${L.repeat(20)}\n` +
            `${P} ${B} User  ${AR}  <code>${username}</code>\n` +
            `${P} ${B} Egg   ${AR}  <b>${egg.name}</b>\n` +
            `${P} ${B} RAM   ${AR}  <b>${ramLabel}</b>\n` +
            `${P} ${B} Status ${AR}  Processing...\n${BL}${L.repeat(20)}${BR}`,
            { parse_mode: "HTML" });

        const upd = async (s) => {
            try {
                await safeEdit(bot, chatId, loading.message_id,
                    `${TL}${L.repeat(20)}${TR}\n${P} ${C} CREATING PANEL\n${T}${L.repeat(20)}\n` +
                    `${P} ${B} User  ${AR}  <code>${username}</code>\n` +
                    `${P} ${B} Egg   ${AR}  <b>${egg.name}</b>\n` +
                    `${P} ${B} RAM   ${AR}  <b>${ramLabel}</b>\n` +
                    `${P} ${B} Status ${AR}  ${s}\n${BL}${L.repeat(20)}${BR}`);
            } catch {}
        };

        try {
            const pc = getPteroConfig(scope);
            const email = `${username.toLowerCase().replace(/[^a-z0-9]/g, "")}@${sanitizeDomain(pc.DOMAIN, pc.URL)}`;
            const password = generatePassword(14);

            const memory = ram === 0 ? 0 : ram;
            const disk = ram === 0 ? 0 : ram * 2;
            const cpu = ram === 0 ? 0 : (pc.DEFAULT_CPU || 100);

            await upd("Build env...");
            const fullEnv = await buildFullEnv(scope, egg.eggId);
            console.log(`[cp] fullEnv: ${JSON.stringify(fullEnv)}`);

            await upd("1/4 Cek user");
            const exist = await pteroGetUserByEmail(scope, email);
            let panelUserId = null;
            if (exist.ok && exist.user) {
                panelUserId = exist.user.attributes.id;
            } else {
                await upd("2/4 Create user");
                const nu = await pteroCreateUser(scope, {
                    email, username, firstName: username, lastName: "User", password
                });
                if (!nu.ok) throw new Error(`Create user: ${nu.error}`);
                panelUserId = nu.user.id;
            }

            await upd("3/4 Cari allocation");
            const locId = pc.DEFAULT_LOCATION || 1;
            const alloc = await pteroGetAllocations(scope, locId);
            if (!alloc.ok) throw new Error(`Allocation: ${alloc.error}`);
            const allocation = alloc.allocations[0].attributes;

            await upd("4/4 Create server");

            const sv = await pteroCreateServer(scope, {
                name: `${username}-server`,
                userId: panelUserId,
                nestId: pc.NEST_ID || 5,
                eggId: egg.eggId,
                dockerImage: egg.docker_image || "ghcr.io/parkervcp/yolks:nodejs_20",
                startup: egg.startup || "npm start",
                environment: fullEnv,
                memory: memory, disk: disk, cpu: cpu,
                allocationId: allocation.id,
                locationId: locId,
                databases: pc.DEFAULT_DATABASES,
                backups: pc.DEFAULT_BACKUPS,
                allocations: pc.DEFAULT_ALLOCATIONS
            });
            if (!sv.ok) throw new Error(`Create server: ${sv.error}`);

            const p = readPanel();
            p.servers = p.servers || {};
            p.servers[username] = {
                username, password, email, scope,
                egg: egg.name, eggId: egg.eggId,
                ram: ramLabel, ramMb: ram,
                serverId: sv.server.id, panelUserId,
                domain: pc.URL, createdAt: Date.now(),
                createdBy: userId
            };
            if (!ctx.db.isOwner(userId) && p.users?.[userId]) {
                p.users[userId].credit = Math.max(0, (p.users[userId].credit || 0) - 1);
            }
            writePanel(p);

            const credMsg =
                `${TL}${"═".repeat(15)}${TR}\n${P}  ${OK} PANEL CREATED  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
                box("CREDENTIAL") +
                `\n${P} ${B} Username  ${AR}  <code>${username}</code>\n` +
                `${P} ${B} Password  ${AR}  <code>${password}</code>\n` +
                `${P} ${B} Email     ${AR}  <code>${email}</code>\n` +
                `${P} ${B} Login URL ${AR}  ${pc.URL}\n` +
                `${BL}${L.repeat(20)}${BR}\n\n` +
                box("SERVER INFO") +
                `\n${P} ${B} Server    ${AR}  ${pc.LABEL}\n` +
                `${P} ${B} Egg       ${AR}  ${egg.name}\n` +
                `${P} ${B} RAM       ${AR}  ${ramLabel}\n` +
                `${P} ${B} Disk      ${AR}  ${memory === 0 ? "Unlimited" : disk + " MB"}\n` +
                `${P} ${B} CPU       ${AR}  ${cpu === 0 ? "Unlimited" : cpu + "%"}\n` +
                `${BL}${L.repeat(20)}${BR}\n\n` +
                `${ST} <i>Simpan credential ini baik-baik</i>`;

            let sentDM = false;
            try { await bot.sendMessage(userId, credMsg, { parse_mode: "HTML" }); sentDM = true; }
            catch (e) { console.log("[cp DM fail]", e.message); }

            await safeEdit(bot, chatId, loading.message_id,
                `${TL}${L.repeat(22)}${TR}\n${P} ${OK} PANEL CREATED\n${T}${L.repeat(22)}\n` +
                `${P} ${B} User  ${AR}  <a href="tg://user?id=${userId}">${msg.from.first_name}</a>\n` +
                `${P} ${B} Panel ${AR}  <code>${username}</code>\n` +
                `${P} ${B} Server ${AR}  ${pc.LABEL}\n` +
                `${P} ${B} Egg   ${AR}  ${egg.name}\n` +
                `${P} ${B} RAM   ${AR}  ${ramLabel}\n${BL}${L.repeat(22)}${BR}\n\n` +
                `${AR} ${sentDM ? "Credential dikirim ke DM" : "⚠️ Buka DM bot & /start"}`);
            await notifyPanelChannel(bot, "panel", msg, {
                Panel: username, Server: pc.LABEL, Egg: egg.name, RAM: ramLabel, Status: "SUCCESS"
            });
        } catch (e) {
            console.log("[cp PROCESS ERR]", e.message);
            await safeEdit(bot, chatId, loading.message_id,
                `${X} Gagal create panel\n\n${B} ${e.message.slice(0, 250)}`,
                { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[cp USERNAME ERR]", e.message); }
});

// ═══════════════════════════════════════════
// SET CONFIG — /setconfig
// ═══════════════════════════════════════════
module.exports.handleSetConfig = async function (bot, msg, ctx) {
    try {
        const chatId = msg.chat.id;
        if (!ctx.db.isOwner(msg.from.id)) {
            return bot.sendMessage(chatId, `${X} Owner only`, { parse_mode: "HTML" });
        }

        const kb = [
            [{ text: `${B} Server 1 (Ilegal)`, callback_data: "setcfg_srv:plta" }],
            [{ text: `${B} Server 2 (Legal)`, callback_data: "setcfg_srv:pltc" }],
            [{ text: `${B} ADP 1`, callback_data: "setcfg_srv:adp1" }],
            [{ text: `${B} ADP 2`, callback_data: "setcfg_srv:adp2" }],
            [{ text: `${X} Batal`, callback_data: "menu_back" }]
        ];

        await bot.sendMessage(chatId,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} SET CONFIG ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            `${AR} Pilih server:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[setConfig ERR]", e.message); }
};

router.registerCallback("setcfg_srv", async (bot, q, data, user, ctx) => {
    try {
        const scope = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        if (!ctx.db.isOwner(user.id)) return;

        ctx.setState(userId, "setcfg_pick_field", { scope });

        const kb = [
            [{ text: `${B} Set URL`, callback_data: "setcfg_field:url" }],
            [{ text: `${B} Set API Key`, callback_data: "setcfg_field:apiKey" }],
            [{ text: `${B} Set Domain`, callback_data: "setcfg_field:domain" }],
            [{ text: `${B} Set Nest ID`, callback_data: "setcfg_field:nestId" }],
            [{ text: `${B} Set Location`, callback_data: "setcfg_field:location" }],
            [{ text: `${B} Set Memory`, callback_data: "setcfg_field:memory" }],
            [{ text: `${B} Set Disk`, callback_data: "setcfg_field:disk" }],
            [{ text: `${B} Set CPU`, callback_data: "setcfg_field:cpu" }],
            [{ text: `${B} Lihat Config`, callback_data: "setcfg_view" }],
            [{ text: `${X} Batal`, callback_data: "menu_back" }]
        ];

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} SET CONFIG ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            box("SERVER") + `\n${P} ${B} ${scopeToLabel(scope)}\n${BL}${L.repeat(20)}${BR}\n\n` +
            `${AR} Pilih field:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[setcfg_srv ERR]", e.message); }
});

router.registerCallback("setcfg_field", async (bot, q, data, user, ctx) => {
    try {
        const field = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const st = ctx.getState(userId);
        if (!st || !st.scope) return safeEdit(bot, chatId, q.message.message_id, `${X} Sesi habis`);

        const names = {
            url: "URL Panel (https://panel-lu.com)",
            apiKey: "API Key (ptla_xxx)",
            domain: "Domain email (biscuitmd.com)",
            nestId: "Nest ID (angka)",
            location: "Location ID (angka)",
            memory: "Memory MB (angka)",
            disk: "Disk MB (angka)",
            cpu: "CPU % (angka)"
        };

        ctx.setState(userId, "setcfg_await_value", { scope: st.scope, field });

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} INPUT VALUE ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            box("SETTING") +
            `\n${P} ${B} Server  ${AR}  <b>${scopeToLabel(st.scope)}</b>\n` +
            `${P} ${B} Field   ${AR}  <b>${field}</b>\n${BL}${L.repeat(20)}${BR}\n\n` +
            `${AR} Kirim value:\n${B} ${names[field] || field}\n${B} Ketik <code>cancel</code> buat batal`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${X} Batal`, callback_data: "menu_back" }]] } });
    } catch (e) { console.log("[setcfg_field ERR]", e.message); }
});

router.registerMessage("setcfg_await_value", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const value = (msg.text || "").trim();

        if (!value) return;
        if (value.toLowerCase() === "cancel" || value.startsWith("/")) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `${OK} Dibatalkan`, { parse_mode: "HTML" });
        }

        const { scope, field } = state;
        if (field === "url" && !value.startsWith("http")) {
            return bot.sendMessage(chatId, `${X} URL harus mulai http:// atau https://`, { parse_mode: "HTML" });
        }
        if (["nestId", "location", "memory", "disk", "cpu"].includes(field) && isNaN(parseInt(value))) {
            return bot.sendMessage(chatId, `${X} Field ${field} harus angka`, { parse_mode: "HTML" });
        }
        if (field === "apiKey" && !value.startsWith("ptla_")) {
            return bot.sendMessage(chatId, `${X} API Key harus mulai <code>ptla_</code>`, { parse_mode: "HTML" });
        }

        const saved = saveConfigToPanel(scope, field, value);
        ctx.clearState(userId);

        if (!saved) return bot.sendMessage(chatId, `${X} Gagal simpen config`, { parse_mode: "HTML" });

        await bot.sendMessage(chatId,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${OK} CONFIG SAVED  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            box("SAVED") +
            `\n${P} ${B} Server  ${AR}  <b>${scopeToLabel(scope)}</b>\n` +
            `${P} ${B} Field   ${AR}  <b>${field}</b>\n` +
            `${P} ${B} Value   ${AR}  <code>${value.slice(0, 60)}</code>\n${BL}${L.repeat(20)}${BR}`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[setcfg_value ERR]", e.message); }
});

router.registerCallback("setcfg_view", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;

        const p = readPanel();
        const conf = p.config || {};
        let text = `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} CONFIG NOW ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n`;

        ["plta", "pltc", "adp1", "adp2"].forEach(k => {
            const c = conf[k] || {};
            text += `${TL}${L.repeat(20)}${TR}\n${P} ${C} ${scopeToLabel(k)}\n${T}${L.repeat(20)}\n`;
            text += `${P} ${B} URL       ${AR}  <code>${c.url || "-"}</code>\n`;
            text += `${P} ${B} API Key   ${AR}  <code>${c.apiKey ? c.apiKey.slice(0, 20) + "..." : "-"}</code>\n`;
            text += `${P} ${B} Domain    ${AR}  <code>${c.domain || "-"}</code>\n`;
            text += `${P} ${B} Nest      ${AR}  <code>${c.nestId || "-"}</code>\n`;
            text += `${P} ${B} Location  ${AR}  <code>${c.location || "-"}</code>\n`;
            text += `${P} ${B} Memory    ${AR}  <code>${c.memory || "-"}</code>\n`;
            text += `${BL}${L.repeat(20)}${BR}\n\n`;
        });

        await safeEdit(bot, chatId, q.message.message_id, text,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${X} Batal`, callback_data: "menu_back" }]] } });
    } catch (e) { console.log("[setcfg_view ERR]", e.message); }
});

// ═══════════════════════════════════════════
// MENU PANELPRO — Layout 3-2-3 + Validasi Role
// ═══════════════════════════════════════════
router.registerCallback("menu_panelpro", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const panelData = readPanel();
        const userRecord = panelData.users?.[userId];

        if (!userRecord && String(userId) !== String(cfg.OWNER_ID)) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} <b>Akses Ditolak</b>\n\nLu belum punya role. Chat owner buat daftar.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]] } });
        }

        const isOwner = String(userId) === String(cfg.OWNER_ID);
        const roleLabel = isOwner ? "👑 OWNER" : (ROLE_LABEL[userRecord?.role] || userRecord?.role || "TIDAK ADA");
        const scopeLabel = isOwner ? "Semua Server" : (userRecord?.scope === "legal" ? "Server 2 (Legal)" : userRecord?.scope === "both" ? "Semua Server" : "Server 1 (Ilegal)");
        const credit = isOwner ? "∞" : (userRecord?.credit || 0);

        const kb = [
            [
                { text: "𖡛 Create Panel", callback_data: "cp_srv:plta", style: "success" },
                { text: "𖡛 List Panel", callback_data: "panelpro_list", style: "primary" },
                { text: "𖡛 Info Role", callback_data: "panel_info_role", style: "primary" }
            ],
            [
                { text: "𖡛 Set Config", callback_data: "setcfg_srv:plta", style: "primary" },
                { text: "𖡛 View Config", callback_data: "setcfg_view", style: "success" }
            ],
            [
                { text: "𖡛 Create ADP 1", callback_data: "cadp:1", style: "success" },
                { text: "𖡛 Create ADP 2", callback_data: "cadp:2", style: "success" },
                { text: "𖡛 Delete Panel", callback_data: "panel_del", style: "danger" }
            ]
        ];

        if (isOwner) {
            kb.push([{ text: "👑 Menu Owner", callback_data: "menu_owner", style: "primary" }]);
        }

        kb.push([{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]);

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} PANEL PRO ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +

            `<blockquote>` +
            `👤 <b>INFO USER</b>\n` +
            `    ▸ ID: <code>${userId}</code>\n` +
            `    ▸ Role: <b>${roleLabel}</b>\n` +
            `    ▸ Scope: <b>${scopeLabel}</b>\n` +
            `    ▸ Credit: <code>${credit}</code>` +
            `</blockquote>\n\n` +

            `👉 <b><i>PILIH MENU:</i></b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[MENU_PANELPRO ERR]", e.message); }
});

router.registerCallback("panelpro_list", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const p = readPanel();
        const servers = Object.values(p.servers || {});

        if (servers.length === 0) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} Belum ada panel yang dibuat.`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${X} Batal`, callback_data: "menu_back" }]] } });
        }

        let text = `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} LIST PANEL ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n`;
        servers.slice(-15).forEach(s => {
            text += `${P} ${C} <b>${s.username}</b>\n`;
            text += `${P} ${B} Server: ${scopeToLabel(s.scope)}\n`;
            text += `${P} ${B} Egg: ${s.egg || "-"}\n`;
            text += `${P} ${B} RAM: ${s.ram || "-"}\n`;
            text += `${P} ${B} Domain: <code>${s.domain || "-"}</code>\n\n`;
        });

        await safeEdit(bot, chatId, q.message.message_id, text,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: `${X} Batal`, callback_data: "menu_back" }]] } });
    } catch (e) { console.log("[panelpro_list ERR]", e.message); }
});


// ═══════════════════════════════════════════
// panel_del — HAPUS PANEL (FIX: HANDLER BARU)
// ═══════════════════════════════════════════
router.registerCallback("panel_del", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);
        const isOwner = ctx.db.isOwner(userId);

        if (!isOwner) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} Owner only!`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
        }

        const p = readPanel();
        const servers = Object.values(p.servers || {});

        if (servers.length === 0) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} Belum ada panel.`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
        }

        const rows = [];
        for (let i = 0; i < servers.length && i < 10; i++) {
            const s = servers[i];
            rows.push([{
                text: `▸ ${s.username} (${scopeToLabel(s.scope)})`,
                callback_data: `panel_del_do:${s.username}`
            }]);
        }
        rows.push([{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]);

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} DELETE PANEL ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +
            `👉 Pilih panel yang mau dihapus:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[panel_del ERR]", e.message); }
});

router.registerCallback("panel_del_do", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(user.id)) return;
        const username = data.split(":")[1];
        const p = readPanel();

        if (p.servers && p.servers[username]) {
            delete p.servers[username];
            writePanel(p);
        }

        await safeEdit(bot, q.message.chat.id, q.message.message_id,
            `${OK} Panel <code>${username}</code> dihapus.`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
    } catch (e) { console.log("[panel_del_do ERR]", e.message); }
});


// ═══════════════════════════════════════════
// ADD ROLE
// ═══════════════════════════════════════════
module.exports.handleAddRole = async function (bot, msg, ctx) {
    try {
        const userId = String(msg.from.id);
        const chatId = msg.chat.id;

        if (msg.chat.type === "private") {
            return bot.sendMessage(chatId, `${X} Cuma di group.`, { parse_mode: "HTML" });
        }
        if (!isGroupAllowed(chatId)) {
            return bot.sendMessage(chatId, `${X} Group belum terdaftar.`, { parse_mode: "HTML" });
        }

        const p = readPanel();
        const actor = p.users[userId];
        const actorRole = actor?.role;
        const isOwner = ctx.db.isOwner(userId);
        const target = msg.reply_to_message?.from;

        if (!target) {
            return bot.sendMessage(chatId,
                `<b>𖡛 ADD ROLE</b>\n\n1. Reply pesan user\n2. Ketik <code>/addrole</code>`,
                { parse_mode: "HTML" });
        }

        const roleMap = {
            reseller: [], admin: ["reseller"], owner: ["reseller", "admin"],
            partner: ["reseller", "admin", "owner"],
            tangankanann: ["reseller", "admin", "owner", "partner"],
            ceo: ["reseller", "admin", "owner", "partner", "tangankanann"],
            developer: ["reseller", "admin", "owner", "partner", "tangankanann", "ceo"]
        };
        let available = [];
        if (isOwner) available = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        else if (actorRole && roleMap[actorRole]) available = roleMap[actorRole];

        if (available.length === 0) {
            return bot.sendMessage(chatId, `${X} Akses Ditolak!`, { parse_mode: "HTML" });
        }

        const targetId = String(target.id);
        ctx.setState(userId, "addrole_pick_server", {
            targetId, targetName: target.first_name || "User", available, _ts: Date.now()
        });

        await bot.sendMessage(chatId,
    `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} ADD ROLE ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
    `${B} Target: <a href="tg://user?id=${targetId}">${target.first_name}</a>\n` +
    `${B} Lu: ${isOwner ? "Owner Bot" : (ROLE_LABEL[actorRole] || actorRole)}\n\n` +
    `<b>Pilih Server:</b>`,
    {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: `𖡛 Server 1 (Ilegal)`, callback_data: "addrole_srv:illegal", style: "success" },
                    { text: `𖡛 Server 2 (Legal)`, callback_data: "addrole_srv:legal", style: "primary" }
                ],
                [
                    { text: `✕ Batal`, callback_data: "menu_back", style: "danger" }
                ]
            ]
        }
    });
    } catch (e) { console.log("[addRole ERR]", e.message); }
};

router.registerCallback("addrole_srv", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        const scope = data.split(":")[1] || "illegal";
        let st = ctx.getState(userId);
        if (!st || !st.targetId) return bot.sendMessage(chatId, `${X} Sesi habis.`, { parse_mode: "HTML" });

        ctx.setState(userId, "addrole_pick_role", {
            targetId: st.targetId, targetName: st.targetName,
            available: st.available, scope, _ts: Date.now()
        });

        const rows = [];
const list = st.available || [];
for (let i = 0; i < list.length; i += 2) {
    const row = [];
    row.push({ text: ROLE_LABEL[list[i]] || list[i], callback_data: `addrole_do2:${list[i]}`, style: "success" });
    if (list[i + 1]) {
        row.push({ text: ROLE_LABEL[list[i + 1]] || list[i + 1], callback_data: `addrole_do2:${list[i + 1]}`, style: "primary" });
    }
    rows.push(row);
}
rows.push([{ text: `𖡛 Ganti Server`, callback_data: "addrole_back_srv", style: "primary" }]);
rows.push([{ text: `✕ Batal`, callback_data: "menu_back", style: "danger" }]);

        await safeEdit(bot, chatId, msgId,
            `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} ADD ROLE ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
            `${B} Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n` +
            `${B} Server: <b>${scope === "legal" ? "Server 2 (Legal)" : "Server 1 (Ilegal)"}</b>\n\n` +
            `<b>Pilih Role:</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } });
    } catch (e) { console.log("[addrole_srv ERR]", e.message); }
});

router.registerCallback("addrole_back_srv", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        const st = ctx.getState(userId);
        if (!st || !st.targetId) return bot.sendMessage(chatId, `${X} Sesi habis.`, { parse_mode: "HTML" });

        ctx.setState(userId, "addrole_pick_server", {
            targetId: st.targetId, targetName: st.targetName, available: st.available, _ts: Date.now()
        });

        await safeEdit(bot, chatId, msgId,
    `${TL}${"═".repeat(15)}${TR}\n${P}  ${ST} ADD ROLE ${ST}  ${P}\n${BL}${"═".repeat(15)}${BR}\n\n` +
    `${B} Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n\n` +
    `<b>Pilih Server:</b>`,
    {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [
                    { text: `𖡛 Server 1 (Ilegal)`, callback_data: "addrole_srv:illegal", style: "success" },
                    { text: `𖡛 Server 2 (Legal)`, callback_data: "addrole_srv:legal", style: "primary" }
                ],
                [
                    { text: `✕ Batal`, callback_data: "menu_back", style: "danger" }
                ]
            ]
        }
    });
    } catch (e) { console.log("[addrole_back ERR]", e.message); }
});

router.registerCallback("addrole_do2", async (bot, q, data, user, ctx) => {
    try {
        const userId = String(user.id);
        const chatId = q.message.chat.id;
        const msgId = q.message.message_id;

        const role = data.split(":")[1];
        const st = ctx.getState(userId);
        if (!st || !st.targetId || !st.scope) return bot.sendMessage(chatId, `${X} Sesi habis.`, { parse_mode: "HTML" });

        const p = readPanel();
        const actorRole = p.users[userId]?.role;
        const isOwner = ctx.db.isOwner(userId);
        const roleMap = {
            reseller: [], admin: ["reseller"], owner: ["reseller", "admin"],
            partner: ["reseller", "admin", "owner"],
            tangankanann: ["reseller", "admin", "owner", "partner"],
            ceo: ["reseller", "admin", "owner", "partner", "tangankanann"],
            developer: ["reseller", "admin", "owner", "partner", "tangankanann", "ceo"]
        };
        let available = [];
        if (isOwner) available = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        else if (actorRole && roleMap[actorRole]) available = roleMap[actorRole];

        if (!available.includes(role)) {
            return bot.answerCallbackQuery(q.id, { text: "Lu ga boleh add role ini!", show_alert: true }).catch(() => {});
        }

        ensureUser(st.targetId, role, 30, 10, st.scope);
        const scopeLabel = st.scope === "legal" ? "Server 2 (Legal)" : "Server 1 (Ilegal)";
        ctx.clearState(userId);

        try { await bot.deleteMessage(chatId, msgId).catch(() => {}); } catch {}

        await bot.sendMessage(chatId,
            `${OK} <b>ROLE DITAMBAHKAN</b>\n\n` +
            `${B} Target: <a href="tg://user?id=${st.targetId}">${st.targetName}</a>\n` +
            `${B} Role: <b>${ROLE_LABEL[role] || role}</b>\n` +
            `${B} Server: <b>${scopeLabel}</b>\n` +
            `${B} Durasi: 30 hari | 10 credit`,
            { parse_mode: "HTML" });

        await bot.sendMessage(st.targetId,
            `<b>ROLE BARU</b>\n\n${B} Role: <b>${ROLE_LABEL[role] || role}</b>\n${B} Server: <b>${scopeLabel}</b>\n${B} Durasi: 30 hari`,
            { parse_mode: "HTML" }).catch(() => {});
    } catch (e) { console.log("[addrole_do2 ERR]", e.message); }
});

module.exports.handleAddAll = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") return;
        if (!isGroupAllowed(msg.chat.id)) return;
        if (!ctx.db.isOwner(msg.from.id)) return;
        const target = msg.reply_to_message?.from;
        if (!target) return bot.sendMessage(msg.chat.id, `${X} Reply target dulu.`, { parse_mode: "HTML" });
        const roles = ["reseller", "admin", "owner", "partner", "tangankanann", "ceo", "developer"];
        for (const r of roles) ensureUser(target.id, r, 30, 10, "legal");
        await bot.sendMessage(msg.chat.id, `${OK} <b>ADD ALL</b>\n\n▸ ${target.first_name}`, { parse_mode: "HTML" });
    } catch (e) { console.log("[addAll ERR]", e.message); }
};

// ═══════════════════════════════════════════
// CADP — CREATE ADMIN PANEL (ROOT ADMIN)
// ═══════════════════════════════════════════
module.exports.handleCadp = async function (bot, msg, ctx, serverNum = 1) {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        if (msg.chat.type === "private") {
            return bot.sendMessage(chatId, `${X} Cuma di group.`, { parse_mode: "HTML" });
        }
        if (!isGroupAllowed(chatId)) {
            return bot.sendMessage(chatId, `${X} Group belum terdaftar.`, { parse_mode: "HTML" });
        }

        const p = readPanel();
        const actor = p.users[userId];
        const actorRole = actor?.role;
        const actorScope = actor?.scope || "illegal";
        const isOwner = ctx.db.isOwner(msg.from.id);

        if (!isOwner && !actorRole) {
            return bot.sendMessage(chatId, `${X} Akses Ditolak!`, { parse_mode: "HTML" });
        }
        if (serverNum === 2 && !isOwner && actorScope !== "legal" && actorScope !== "both") {
            return bot.sendMessage(chatId, `${X} Lu cuma akses Server 1.`, { parse_mode: "HTML" });
        }

        const args = (msg.text || "").split(/\s+/).slice(1);
        let username = args.join(" ").trim();

        if (!username) {
            ctx.setState(userId, `cadp_${serverNum}_await`, { serverNum });
            return bot.sendMessage(chatId,
                `${AR} Kirim username admin (3-20 char, a-z 0-9 _):\n` +
                `<i>Contoh: <code>admin1</code></i>`,
                { parse_mode: "HTML" });
        }

        if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
            return bot.sendMessage(chatId, `${X} Username invalid (3-20 char, a-z 0-9 _)`, { parse_mode: "HTML" });
        }

        username = username.toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20);

        // ⚡ CEK DM
        const dmOk = await canDMUser(bot, msg.from.id);
        if (!dmOk) {
            return bot.sendMessage(chatId,
                `⚠️ Buka DM bot & /start dulu biar bisa dapet credential!`,
                { parse_mode: "HTML" });
        }

        const scope = serverNum === 2 ? "pltc" : "plta";
        const pc = getPteroConfig(scope);
        const v = validateApiKey(pc.API_KEY);

        if (!v.ok) {
            return bot.sendMessage(chatId,
                `${X} <b>API Key Invalid</b>\n\n` +
                `<code>${v.error}</code>\n\n` +
                `<i>Set config dulu: <code>/setconfig</code></i>`,
                { parse_mode: "HTML" });
        }

        // ⚡ LOADING
        const loading = await bot.sendMessage(chatId,
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} CREATE ADMIN PANEL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Server  ${AR}  <b>${scopeToLabel(scope)}</b>\n` +
            `${P} ${B} User    ${AR}  <code>${username}</code>\n` +
            `${P} ${B} Status  ${AR}  <i>Processing...</i>\n` +
            `${BL}${L.repeat(22)}${BR}`,
            { parse_mode: "HTML" });

        const upd = async (status) => {
            try {
                await safeEdit(bot, chatId, loading.message_id,
                    `${TL}${L.repeat(22)}${TR}\n` +
                    `${P} ${C} CREATE ADMIN PANEL\n` +
                    `${T}${L.repeat(22)}\n` +
                    `${P} ${B} Server  ${AR}  <b>${scopeToLabel(scope)}</b>\n` +
                    `${P} ${B} User    ${AR}  <code>${username}</code>\n` +
                    `${P} ${B} Status  ${AR}  <i>${status}</i>\n` +
                    `${BL}${L.repeat(22)}${BR}`);
            } catch {}
        };

        // ⚡ GENERATE PASSWORD & EMAIL
        const password = generatePassword(14);
        const email = `${username}@${sanitizeDomain(pc.DOMAIN, pc.URL)}`;

        console.log(`[CADP] scope=${scope} username=${username} email=${email}`);

        await upd("Cek user existing...");

        // ═══════════════════════════════════════
        // STEP 1: CEK USER EXISTING
        // ═══════════════════════════════════════
        const exist = await pteroGetUserByEmail(scope, email);

        let panelUserId = null;
        let finalPassword = password;
        let alreadyExists = false;

        if (exist.ok && exist.user) {
            panelUserId = exist.user.attributes.id;
            alreadyExists = true;
            console.log(`[CADP] User ${email} UDAH ADA → id=${panelUserId}`);
            await upd("User sudah ada — pastiin root_admin...");
        } else {
            // ═══════════════════════════════════════
            // STEP 2: CREATE USER dengan root_admin: TRUE
            // ═══════════════════════════════════════
            await upd("1/2 Create user admin...");

            console.log(`[CADP] Create user baru dengan root_admin=true`);

            const nu = await pteroCreateAdminUser(scope, {
                email,
                username,
                firstName: username,
                lastName: "Admin",
                password,
                rootAdmin: true      // ⚡ INI KUNCINYA
            });

            if (!nu.ok) {
                console.log(`[CADP] Gagal create user: ${nu.error}`);
                await safeEdit(bot, chatId, loading.message_id,
                    `${X} <b>Gagal create admin panel</b>\n\n` +
                    `${B} Server: ${scopeToLabel(scope)}\n` +
                    `${B} Error: <code>${nu.error.slice(0, 200)}</code>`,
                    { parse_mode: "HTML" });
                return;
            }

            panelUserId = nu.user.id;
            console.log(`[CADP] ✓ User dibuat: id=${panelUserId}`);
        }

        // ═══════════════════════════════════════
        // STEP 3: VERIFIKASI ROOT ADMIN
        // ═══════════════════════════════════════
        await upd("2/2 Verifikasi admin status...");

        // Kalau user udah ada, pastiin root_admin = true
        if (alreadyExists) {
            const fixResult = await pteroSetRootAdmin(scope, panelUserId, true);
            if (!fixResult.ok) {
                console.log(`[CADP] ⚠️ Gagal set root_admin: ${fixResult.error}`);
            }
        }

        // ═══════════════════════════════════════
        // STEP 4: SIMPEN KE DB
        // ═══════════════════════════════════════
        const adpId = `ADP${serverNum}${Date.now().toString(36).toUpperCase()}`;
        const domainPanel = pc.URL || `https://${pc.DOMAIN}`;

        p.adp = p.adp || { "1": {}, "2": {} };
        p.adp[serverNum] = p.adp[serverNum] || {};
        p.adp[serverNum][username] = {
            id: adpId,
            username,
            password: finalPassword,
            email,
            server: serverNum,
            scope,
            panelUserId,
            domain: domainPanel,
            isAdmin: true,
            alreadyExists,
            createdAt: Date.now(),
            createdBy: msg.from.id
        };
        writePanel(p);

        // ═══════════════════════════════════════
        // STEP 5: KIRIM CREDENTIAL KE USER
        // ═══════════════════════════════════════
        const credMsg =
            `${TL}${"═".repeat(20)}${TR}\n` +
            `${P}  ${OK} ADMIN PANEL CREATED ${OK}  ${P}\n` +
            `${BL}${"═".repeat(20)}${BR}\n\n` +

            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} LOGIN CREDENTIAL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Panel URL  ${AR}  ${domainPanel}\n` +
            `${P} ${B} Email      ${AR}  <code>${email}</code>\n` +
            `${P} ${B} Username   ${AR}  <code>${username}</code>\n` +
            `${P} ${B} Password   ${AR}  <code>${password}</code>\n` +
            `${P} ${B} Access     ${AR}  <b>ROOT ADMIN</b>\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +

            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${C} DETAIL\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} Server     ${AR}  ${scopeToLabel(scope)}\n` +
            `${P} ${B} Admin ID   ${AR}  <code>${panelUserId}</code>\n` +
            `${P} ${B} Tipe       ${AR}  <b>Admin Panel (no server)</b>\n` +
            `${P} ${B} Created    ${AR}  ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n` +
            `${BL}${L.repeat(22)}${BR}\n\n` +

            `${ST} <i>Simpan credential ini baik-baik. Jangan share!</i>` +
            (alreadyExists ? `\n\n<i>⚠️ User udah ada di panel — status admin udah di-set ulang.</i>` : "");

        const kb = [
            [
                { text: "𖡛 Copy Email", copy_text: { text: email }, style: "primary" },
                { text: "𖡛 Copy Password", copy_text: { text: password }, style: "primary" }
            ],
            [
                { text: "𖡛 Buka Panel", url: domainPanel.startsWith("http") ? domainPanel : "https://" + domainPanel, style: "success" }
            ]
        ];

        let sentDM = false;
        try {
            await bot.sendMessage(msg.from.id, credMsg, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
            sentDM = true;
            console.log(`[CADP] ✓ Credential terkirim ke DM user ${userId}`);
        } catch (e) {
            console.log(`[CADP] ❌ Gagal DM user: ${e.message}`);
        }

        // ═══════════════════════════════════════
        // STEP 6: EDIT PESAN GROUP
        // ═══════════════════════════════════════
        await safeEdit(bot, chatId, loading.message_id,
            `${TL}${L.repeat(22)}${TR}\n` +
            `${P} ${OK} ADMIN PANEL CREATED\n` +
            `${T}${L.repeat(22)}\n` +
            `${P} ${B} User    ${AR}  <a href="tg://user?id=${userId}">${msg.from.first_name || "User"}</a>\n` +
            `${P} ${B} Admin   ${AR}  <code>${username}</code>\n` +
            `${P} ${B} Server  ${AR}  ${scopeToLabel(scope)}\n` +
            `${P} ${B} Access  ${AR}  <b>ROOT ADMIN</b>\n` +
            `${P} ${B} DM      ${AR}  ${sentDM ? "✓ Terkirim" : "⚠️ Gagal — buka /start"}\n` +
            `${BL}${L.repeat(22)}${BR}` +
            (sentDM ? "" : `\n\n${AR} <i>Buka DM bot & /start biar dapet credential!</i>`),
            { parse_mode: "HTML" });
        await notifyPanelChannel(bot, "admin", msg, {
            Admin: username, Server: scopeToLabel(scope), Access: "ROOT ADMIN", Status: "SUCCESS"
        });

    } catch (e) {
        console.log("[CADP ERR]", e.message);
        console.log("[CADP STACK]", e.stack);
        try {
            await bot.sendMessage(msg.chat.id,
                `${X} Error: <code>${e.message.slice(0, 200)}</code>`,
                { parse_mode: "HTML" });
        } catch {}
    }
};

// ═══════════════════════════════════════════
// SUBDOMAIN
// ═══════════════════════════════════════════
router.registerCallback("panelpro_subdomain", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_subdomain_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 SUBDOMAIN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>IPVPS|SUBDOMAIN</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>103.xxx.xxx.xxx|panel</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[SUBDOMAIN ERR]", e.message); }
});

router.registerMessage("panelpro_subdomain_await", async (bot, msg, state, ctx) => {
    try {
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 2) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [ip, subdomain] = parts;
        ctx.clearState(msg.from.id);

        const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Membuat subdomain...</b>`, { parse_mode: "HTML" });

        const c = CONFIG.CLOUDFLARE;
        if (!c.API_TOKEN || c.API_TOKEN === "ISI_CF_API_TOKEN") throw new Error("✕ CF API token belum di-set");

        const res = await axios.post(
            `https://api.cloudflare.com/client/v4/zones/${c.ZONE_ID}/dns_records`,
            { type: "A", name: subdomain, content: ip, ttl: 120, proxied: false },
            { headers: { Authorization: `Bearer ${c.API_TOKEN}`, "Content-Type": "application/json" }, timeout: 15000 }
        );
        if (!res.data.success) throw new Error(res.data.errors?.[0]?.message || "CF error");

        const fullDomain = `${subdomain}.${c.DOMAIN_UTAMA}`;
        await bot.editMessageText(
            `<b>✓ SUBDOMAIN DIBUAT</b>\n\n` +
            `𖡛 Subdomain: <code>${fullDomain}</code>\n` +
            `𖡛 IP: <code>${ip}</code>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[SUBDOMAIN AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// INSTALL PANEL
// ═══════════════════════════════════════════
router.registerCallback("panelpro_installpanel", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_installpanel_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 INSTALL PANEL</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>IPVPS|DOMAINPANEL|NODEDOMAIN|RAM</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>103.xxx.xxx.xxx|panel.domain.com|node.domain.com|8</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[INSTALLPANEL ERR]", e.message); }
});

router.registerMessage("panelpro_installpanel_await", async (bot, msg, state, ctx) => {
    try {
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 4) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [ip, domainPanel, nodeDomain, ram] = parts;
        ctx.clearState(msg.from.id);

        const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Installing Panel...</b>`, { parse_mode: "HTML" });

        const commands = [
            `cd /root && rm -f install-panel.sh`,
            `curl -sSL ${CONFIG.SCRIPTS_URL}/panel/install-panel.sh -o install-panel.sh || wget -q ${CONFIG.SCRIPTS_URL}/panel/install-panel.sh -O install-panel.sh`,
            `chmod +x install-panel.sh`,
            `bash install-panel.sh "${domainPanel}" "${nodeDomain}" "${ram}" 2>&1 | tail -30`
        ];

        const result = await sshExec(ip, commands);
        if (!result.ok) throw new Error(result.error || "SSH gagal");

        await bot.editMessageText(
            `<b>✓ PANEL INSTALLED</b>\n\n` +
            `▸ Panel: <code>${domainPanel}</code>\n` +
            `𖡛 Node: <code>${nodeDomain}</code>\n` +
            `𖡛 RAM: <code>${ram}GB</code>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[INSTALLPANEL AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// PROTEC
// ═══════════════════════════════════════════
const PROTEC_LIST = [
    { id: "anti_maling_plta", name: "▸ Anti Maling PLTA", file: "anti-maling-plta.sh" },
    { id: "anti_intip_server", name: "▸ Anti Intip Server", file: "anti-intip-server.sh" },
    { id: "anti_delete_server", name: "▸ Anti Delete Server", file: "anti-delete-server-offline.sh" },
    { id: "anti_admin_panel", name: "▸ Anti Admin Panel", file: "anti-admin-panel.sh" },
    { id: "anti_maling_pw", name: "▸ Anti Maling PW VPS", file: "anti-maling-pw-vps.sh" },
    { id: "anti_maling_username", name: "▸ Anti Maling Username", file: "anti-maling-username.sh" },
    { id: "anti_intip_node", name: "▸ Anti Intip Node", file: "anti-intip-node.sh" },
    { id: "anti_intip_manager", name: "▸ Anti Intip Manager", file: "anti-intip-manager.sh" },
    { id: "anti_intip_all", name: "▸ Anti Intip All Admin", file: "anti-intip-all-admin.sh" }
];

router.registerCallback("panelpro_protec", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_protec_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 INSTALL PROTEC</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>IPVPS|IDADMIN</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>103.xxx.xxx.xxx|1</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[PROTEC ERR]", e.message); }
});

router.registerMessage("panelpro_protec_await", async (bot, msg, state, ctx) => {
    try {
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 2) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [ip, idAdmin] = parts;

        ctx.setState(msg.from.id, "panelpro_protec_ready", { ip, idAdmin });

        const kb = PROTEC_LIST.map(p => [{ text: p.name, callback_data: `panelpro_protec_install:${p.id}` }]);
        kb.push([{ text: "𖡛 Install Semua", callback_data: "panelpro_protec_install:all" }]);
        kb.push([{ text: "✕ Batal", callback_data: "menu_panelpro" }]);

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 PILIH PROTEC</b>\n\nVPS: <code>${ip}</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[PROTEC AWAIT ERR]", e.message); }
});

router.registerCallback("panelpro_protec_install", async (bot, q, data, user, ctx) => {
    try {
        const protecId = data.split(":")[1];
        const st = ctx.getState(user.id);
        if (!st || !st.ip) return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });

        let files = [];
        if (protecId === "all") files = PROTEC_LIST.map(p => p.file);
        else {
            const p = PROTEC_LIST.find(x => x.id === protecId);
            if (p) files.push(p.file);
        }

        if (files.length === 0) return bot.answerCallbackQuery(q.id, { text: "Protec tidak valid", show_alert: true });

        const loading = await bot.sendMessage(q.message.chat.id, `<b>▸ Installing ${files.length} Protec...</b>`, { parse_mode: "HTML" });

        const commands = [`echo "${CONFIG.PROTEC_BANNER}" > /etc/protec_banner.txt`];
        for (const file of files) {
            commands.push(`cd /root && curl -sSL ${CONFIG.SCRIPTS_URL}/protec/${file} -o ${file} || wget -q ${CONFIG.SCRIPTS_URL}/protec/${file} -O ${file}`);
            commands.push(`chmod +x ${file} && bash ${file} "${st.idAdmin}" 2>&1 | tail -5`);
        }

        const result = await sshExec(st.ip, commands);
        if (!result.ok) throw new Error(result.error || "✕ SSH gagal");

        await bot.editMessageText(
            `<b>✓ PROTEC INSTALLED</b>\n\n` +
            `𖡛 Total: <code>${files.length}</code>\n` +
            `𖡛 VPS: <code>${st.ip}</code>\n` +
            `𖡛 Admin ID: <code>${st.idAdmin}</code>`,
            { chat_id: q.message.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        ctx.clearState(user.id);
    } catch (e) {
        console.log("[PROTEC INSTALL ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// THEME
// ═══════════════════════════════════════════
const THEME_LIST = [
    { id: "cream", name: "𖡛 Biscuit Cream", file: "biscuit-cream.css" },
    { id: "gold", name: "𖡛 Biscuit Gold", file: "biscuit-gold.css" }
];

router.registerCallback("panelpro_theme", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_theme_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 INSTALL THEME</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>IPVPS</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>103.xxx.xxx.xxx</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[THEME ERR]", e.message); }
});

router.registerMessage("panelpro_theme_await", async (bot, msg, state, ctx) => {
    try {
        const ip = msg.text?.trim();
        if (!ip || !ip.includes(".")) return bot.sendMessage(msg.chat.id, `<b>✕ IP tidak valid.</b>`, { parse_mode: "HTML" });

        ctx.setState(msg.from.id, "panelpro_theme_ready", { ip });

        const kb = THEME_LIST.map(t => [{ text: t.name, callback_data: `panelpro_theme_install:${t.id}` }]);
        kb.push([{ text: "✕ Batal", callback_data: "menu_panelpro" }]);

        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 PILIH THEME</b>\n\nVPS: <code>${ip}</code>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[THEME AWAIT ERR]", e.message); }
});

router.registerCallback("panelpro_theme_install", async (bot, q, data, user, ctx) => {
    try {
        const themeId = data.split(":")[1];
        const st = ctx.getState(user.id);
        if (!st || !st.ip) return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });

        const theme = THEME_LIST.find(t => t.id === themeId);
        if (!theme) return bot.answerCallbackQuery(q.id, { text: "Theme tidak valid", show_alert: true });

        const loading = await bot.sendMessage(q.message.chat.id, `<b>▸ Installing ${theme.name}...</b>`, { parse_mode: "HTML" });

        const commands = [
            `cd /root && curl -sSL ${CONFIG.SCRIPTS_URL}/theme/${theme.file} -o theme.css || wget -q ${CONFIG.SCRIPTS_URL}/theme/${theme.file} -O theme.css`,
            `mkdir -p /var/www/pterodactyl/public/themes`,
            `cp theme.css /var/www/pterodactyl/public/themes/${theme.file}`,
            `echo "=== Selesai ==="`
        ];

        const result = await sshExec(st.ip, commands);
        if (!result.ok) throw new Error(result.error || "✕ SSH gagal");

        await bot.editMessageText(
            `<b>✓ THEME INSTALLED</b>\n\n` +
            `𖡛 Theme: ${theme.name}\n` +
            `𖡛 VPS: <code>${st.ip}</code>`,
            { chat_id: q.message.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        ctx.clearState(user.id);
    } catch (e) {
        console.log("[THEME INSTALL ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// CREATE VPS DO
// ═══════════════════════════════════════════
router.registerCallback("panelpro_vpsdo", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_vpsdo_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 CREATE VPS DIGITALOCEAN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>NAME|RAM|REGION</code>\n\n` +
            `<b>RAM</b>: 1gb, 2gb, 4gb, 8gb\n` +
            `<b>Region</b>: sgp1, nyc1, sfo1, lon1\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>spartax-panel|2gb|sgp1</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[VPSDO ERR]", e.message); }
});

router.registerMessage("panelpro_vpsdo_await", async (bot, msg, state, ctx) => {
    try {
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 3) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [name, ram, region] = parts;
        ctx.clearState(msg.from.id);

        const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Creating VPS...</b>`, { parse_mode: "HTML" });

        const sizeMap = { "1gb": "s-1vcpu-1gb", "2gb": "s-1vcpu-2gb", "4gb": "s-2vcpu-4gb", "8gb": "s-4vcpu-8gb" };
        const res = await axios.post("https://api.digitalocean.com/v2/droplets", {
            name, region, size: sizeMap[ram] || "s-1vcpu-2gb", image: CONFIG.DIGITALOCEAN.DEFAULT_IMAGE
        }, {
            headers: { Authorization: `Bearer ${CONFIG.DIGITALOCEAN.API_KEY}` },
            timeout: 30000
        });

        await bot.editMessageText(
            `<b>✓ VPS DIBUAT</b>\n\n` +
            `𖡛 ID: <code>${res.data.droplet.id}</code>\n` +
            `𖡛 Nama: <code>${res.data.droplet.name}</code>\n` +
            `𖡛 Status: ${res.data.droplet.status}`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[VPSDO AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// INFO ROLE
// ═══════════════════════════════════════════
router.registerCallback("panel_info_role", async (bot, q, data, user, ctx) => {
    try {
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const panelData = readPanel();
        const userRecord = panelData.users?.[userId];
        const isOwner = String(userId) === String(cfg.OWNER_ID);

        if (!userRecord && !isOwner) {
            return safeEdit(bot, chatId, q.message.message_id,
                `${X} <b>Akses Ditolak</b>\n\n` +
                `<i>Kamu belum punya role di bot ini.</i>\n\n` +
                `📞 Chat owner: <a href="tg://user?id=${cfg.OWNER_ID}">Owner</a>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
        }

        const roleLabel = isOwner ? "👑 OWNER" : (ROLE_LABEL[userRecord?.role] || userRecord?.role);
        const scopeLabel = isOwner ? "Semua Server" : (userRecord?.scope === "legal" ? "Server 2 (Legal)" : userRecord?.scope === "both" ? "Semua Server" : "Server 1 (Ilegal)");
        const credit = isOwner ? "∞" : (userRecord?.credit || 0);
        const expired = userRecord?.expiresAt
            ? Math.ceil((userRecord.expiresAt - Date.now()) / 86400000) + " hari"
            : "∞";

        await safeEdit(bot, chatId, q.message.message_id,
            `${TL}${"═".repeat(15)}${TR}\n` +
            `${P}  ${ST} INFO ROLE ${ST}  ${P}\n` +
            `${BL}${"═".repeat(15)}${BR}\n\n` +

            `<blockquote>` +
            `👤 <b>IDENTITAS</b>\n` +
            `    ▸ ID: <code>${userId}</code>\n` +
            `    ▸ Nama: <b>${user.first_name || "User"}</b>\n` +
            `    ▸ Username: ${user.username ? "@" + user.username : "-"}` +
            `</blockquote>\n\n` +

            `<blockquote>` +
            `🎫 <b>ROLE & AKSES</b>\n` +
            `    ▸ Role: <b>${roleLabel}</b>\n` +
            `    ▸ Scope: <b>${scopeLabel}</b>\n` +
            `    ▸ Credit: <code>${credit}</code>\n` +
            `    ▸ Expired: <b>${expired}</b>` +
            `</blockquote>\n\n` +

            `<i>Semua data di atas read-only.</i>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: "✕ Kembali", callback_data: "menu_panelpro", style: "danger" }]] } });
    } catch (e) { console.log("[INFO_ROLE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// UBAH PW VPS
// ═══════════════════════════════════════════
router.registerCallback("panelpro_chpw", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_chpw_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 UBAH PASSWORD VPS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>IPVPS|PWBARU</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>103.xxx.xxx.xxx|newpass123</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[CHPW ERR]", e.message); }
});

router.registerMessage("panelpro_chpw_await", async (bot, msg, state, ctx) => {
    try {
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 2) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [ip, pwBaru] = parts;
        ctx.clearState(msg.from.id);

        const loading = await bot.sendMessage(msg.chat.id, `<b>𖡛 Ganti password...</b>`, { parse_mode: "HTML" });

        const result = await sshExec(ip, [`echo "root:${pwBaru}" | chpasswd`]);
        if (!result.ok) throw new Error(result.error || "✕ SSH gagal");

        await bot.editMessageText(
            `<b>✓ PASSWORD DIGANTI</b>\n\n` +
            `𖡛 IP: <code>${ip}</code>\n` +
            `𖡛 PW Baru: <code>${pwBaru}</code>`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[CHPW AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// OWNER ONLY: AUTO CPU 120%
// ═══════════════════════════════════════════
router.registerCallback("panelpro_cpu", async (bot, q, data, user, ctx) => {
    if (!requireOwner(bot, q, ctx)) return;

    try {
        ctx.setState(user.id, "panelpro_cpu_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 AUTO CPU 120%</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Format:</b>\n` +
            `<code>PTERO_URL|PTERO_KEY|LIMIT</code>\n\n` +
            `<b>Contoh:</b>\n` +
            `<code>https://panel.domain.com|ptla_xxxxx|120</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[CPU ERR]", e.message); }
});

router.registerMessage("panelpro_cpu_await", async (bot, msg, state, ctx) => {
    try {
        if (!ctx.db.isOwner(msg.from.id)) return;
        const parts = msg.text?.split("|").map(s => s.trim());
        if (!parts || parts.length < 3) return bot.sendMessage(msg.chat.id, `<b>✕ Format salah.</b>`, { parse_mode: "HTML" });
        const [url, key, limit] = parts;
        const settings = ctx.db.read("settings");
        settings.cpuLimit = { url, key, limit: parseInt(limit), enabled: true, updatedAt: Date.now() };
        ctx.db.write("settings", settings);
        ctx.clearState(msg.from.id);

        await bot.sendMessage(msg.chat.id,
            `<b>✓ AUTO CPU AKTIF</b>\n\n` +
            `𖡛 URL: <code>${url}</code>\n` +
            `𖡛 Limit: <code>${limit}%</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[CPU AWAIT ERR]", e.message); }
});

// ═══════════════════════════════════════════
// OWNER ONLY: AUTO DEL OFFLINE
// ═══════════════════════════════════════════
router.registerCallback("panelpro_deloffline", async (bot, q, data, user, ctx) => {
    if (!requireOwner(bot, q, ctx)) return;

    try {
        const p = readPanel();
        const servers = p.servers || {};
        let deleted = 0, kept = 0;
        const now = Date.now();

        for (const username in servers) {
            const s = servers[username];
            if (s.status !== "online" && s.lastCheck && (now - s.lastCheck) > 30 * 60 * 1000) {
                delete servers[username];
                deleted++;
            } else kept++;
        }

        p.servers = servers;
        writePanel(p);

        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 DELETE OFFLINE</b>\n\n` +
            `▸ Dihapus: <code>${deleted}</code>\n` +
            `▸ Dipertahankan: <code>${kept}</code>`,
            { parse_mode: "HTML" });
    } catch (e) {
        console.log("[DELOFFLINE ERR]", e.message);
        return bot.sendMessage(q.message.chat.id, `<b>✕ Coba lagi.</b>`, { parse_mode: "HTML" }).catch(() => {});
    }
});

// ═══════════════════════════════════════════
// DELETE ADMIN
// ═══════════════════════════════════════════
router.registerCallback("panelpro_deladmin", async (bot, q, data, user, ctx) => {
    if (!requireOwner(bot, q, ctx)) return;

    try {
        ctx.setState(user.id, "panelpro_deladmin_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 DELETE ADMIN</b>\n\nKirim ID admin:`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[DELADMIN ERR]", e.message); }
});

router.registerMessage("panelpro_deladmin_await", async (bot, msg, state, ctx) => {
    try {
        if (!ctx.db.isOwner(msg.from.id)) return;
        const adminId = msg.text?.trim();
        if (!adminId || !/^\d+$/.test(adminId)) return bot.sendMessage(msg.chat.id, `<b>✕ ID harus angka.</b>`, { parse_mode: "HTML" });
        ctx.clearState(msg.from.id);

        const loading = await bot.sendMessage(msg.chat.id, `<b>▸ Hapus admin ID ${adminId}...</b>`, { parse_mode: "HTML" });

        const pc = getPteroConfig("plta");
        const check = await axios.get(`${pc.URL}/api/application/users/${adminId}`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 10000,
            validateStatus: s => s < 500
        }).catch(() => null);

        if (!check || check.status !== 200) throw new Error(`Admin ID ${adminId} tidak ditemukan`);

        await axios.delete(`${pc.URL}/api/application/users/${adminId}`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 10000
        });

        await bot.editMessageText(
            `<b>✓ ADMIN DIHAPUS</b>\n\n` +
            `𖡛 ID: <code>${adminId}</code>\n` +
            `𖡛 Username: ${check.data.attributes.username}`,
            { chat_id: msg.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
    } catch (e) {
        console.log("[DELADMIN AWAIT ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// BOT ANTI-ADMIN
// ═══════════════════════════════════════════
router.registerCallback("panelpro_adminbot", async (bot, q, data, user, ctx) => {
    try {
        ctx.setState(user.id, "panelpro_adminbot_await", {});
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 BOT ANTI-ADMIN</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Kirim IP VPS:\n` +
            `Contoh: <code>103.xxx.xxx.xxx</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_panelpro" }]] } });
    } catch (e) { console.log("[ADMINBOT ERR]", e.message); }
});

router.registerMessage("panelpro_adminbot_await", async (bot, msg, state, ctx) => {
    try {
        const ip = msg.text?.trim();
        if (!ip || !ip.includes(".")) return bot.sendMessage(msg.chat.id, `<b>✕ IP tidak valid.</b>`, { parse_mode: "HTML" });

        ctx.setState(msg.from.id, "panelpro_adminbot_ready", { ip });

        await bot.sendMessage(msg.chat.id,
            `<b>✓ IP DITERIMA</b>\n\n▸ <code>${ip}</code>\n\n<i>Install sekarang?</i>`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Install", callback_data: "panelpro_adminbot_install" }],
                        [{ text: "✕ Batal", callback_data: "menu_panelpro" }]
                    ]
                }
            });
    } catch (e) { console.log("[ADMINBOT AWAIT ERR]", e.message); }
});

router.registerCallback("panelpro_adminbot_install", async (bot, q, data, user, ctx) => {
    try {
        const st = ctx.getState(user.id);
        if (!st || !st.ip) return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true });

        const loading = await bot.sendMessage(q.message.chat.id, `<b>▸ Installing Bot Anti-Admin...</b>`, { parse_mode: "HTML" });

        const commands = [
            `cd /root && curl -sSL ${CONFIG.SCRIPTS_URL}/protec/anti-admin-bot.sh -o anti-admin-bot.sh || wget -q ${CONFIG.SCRIPTS_URL}/protec/anti-admin-bot.sh -O anti-admin-bot.sh`,
            `chmod +x anti-admin-bot.sh`,
            `nohup bash anti-admin-bot.sh > /dev/null 2>&1 &`,
            `sleep 2 && pgrep -f anti-admin-bot.sh | head -1`
        ];

        const result = await sshExec(st.ip, commands);
        if (!result.ok) throw new Error(result.error || "SSH gagal");

        await bot.editMessageText(
            `<b>✓ BOT ANTI-ADMIN INSTALLED</b>\n\n▸ VPS: <code>${st.ip}</code>`,
            { chat_id: q.message.chat.id, message_id: loading.message_id, parse_mode: "HTML" });
        ctx.clearState(user.id);
    } catch (e) {
        console.log("[ADMINBOT INSTALL ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// MONITORING
// ═══════════════════════════════════════════
async function checkAllServers() {
    const p = readPanel();
    const servers = p.servers || {};
    const list = Object.values(servers);
    if (list.length === 0) return null;
    let online = 0, offline = 0;
    for (const s of list) { if (s.status === "online") online++; else offline++; }
    return {
        total: list.length, online, offline,
        avgCpu: "0.0", avgRam: "0.0",
        time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    };
}

router.registerCallback("panel_monitoring", async (bot, q, data, user, ctx) => {
    try {
        if (!ctx.db.isOwner(user.id)) return bot.answerCallbackQuery(q.id, { text: "Owner only!", show_alert: true });
        const stat = await checkAllServers();
        if (!stat) return bot.sendMessage(q.message.chat.id, `${X} Belum ada server.`, { parse_mode: "HTML" });
        await bot.sendMessage(q.message.chat.id,
            `<b>𖡛 MONITORING</b>\n\n${B} Total: <code>${stat.total}</code>\n${B} Online: <code>${stat.online}</code>\n${B} Offline: <code>${stat.offline}</code>\n${B} ${stat.time}`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[monitoring ERR]", e.message); }
});

// ═══════════════════════════════════════════
// HANDLE ADD / ADDGROUP / INFO
// ═══════════════════════════════════════════
module.exports.handleAdd = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") return;
        if (!isGroupAllowed(msg.chat.id)) return;
        const target = msg.reply_to_message?.from;
        if (!target) return bot.sendMessage(msg.chat.id, `${X} Reply target dulu.`, { parse_mode: "HTML" });
        ensureUser(target.id, "reseller", 30, 10, "illegal");
        await bot.sendMessage(msg.chat.id, `${OK} <b>RESELLER DITAMBAHKAN</b>\n\n▸ ${target.first_name}`, { parse_mode: "HTML" });
        await bot.sendMessage(target.id, `<b>ROLE BARU</b>\n\nReseller — Server 1`, { parse_mode: "HTML" }).catch(() => {});
    } catch (e) { console.log("[add ERR]", e.message); }
};

module.exports.handleAddGroup = async function (bot, msg, ctx) {
    try {
        if (!ctx.db.isOwner(msg.from.id)) return;
        const p = readPanel();
        if (String(msg.chat.id) === String(cfg.MAIN_GROUP_ID)) return bot.sendMessage(msg.chat.id, `${OK} Ini main group.`, { parse_mode: "HTML" });
        if (!p.groups.some(g => String(g) === String(msg.chat.id))) {
            p.groups.push(String(msg.chat.id));
            writePanel(p);
            await bot.sendMessage(msg.chat.id, `${OK} Group ditambah.`, { parse_mode: "HTML" });
        } else {
            await bot.sendMessage(msg.chat.id, `${OK} Group udah ada.`, { parse_mode: "HTML" });
        }
    } catch (e) { console.log("[addGroup ERR]", e.message); }
};

module.exports.handleInfoGroup = async function (bot, msg, ctx) {
    try {
        if (msg.chat.type === "private") return;
        if (!isGroupAllowed(msg.chat.id)) return;
        const p = readPanel();
        const target = msg.reply_to_message?.from || msg.from;
        const uid = String(target.id);
        const rec = p.users[uid] || null;
        await bot.sendMessage(msg.chat.id,
            `<b>𖡛 INFO USER</b>\n\n${B} ID: <code>${uid}</code>\n${B} Nama: ${target.first_name}\n${B} Role: <b>${rec ? ROLE_LABEL[rec.role] : "Tidak ada"}</b>\n${B} Credit: <code>${rec ? rec.credit : "-"}</code>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[info ERR]", e.message); }
};

// ═══════════════════════════════════════════
// MONITORING LOOP
// ═══════════════════════════════════════════
module.exports.startMonitoringLoop = function (bot) {
    console.log("[PANEL] startMonitoringLoop called");
    setInterval(async () => { try { await checkAllServers(); } catch (e) {} }, 5 * 60 * 1000);
};

// ═══════════════════════════════════════════
// EXPORT LENGKAP
// ═══════════════════════════════════════════
module.exports.ROLE_LABEL = ROLE_LABEL;
module.exports.readPanel = readPanel;
module.exports.writePanel = writePanel;
module.exports.ensureUser = ensureUser;
module.exports.checkAllServers = checkAllServers;
module.exports.generatePassword = generatePassword;
module.exports.normalizeUrl = normalizeUrl;
module.exports.hasPerm = hasPerm;
module.exports.canAddRole = canAddRole;
module.exports.isOwnerBot = isOwnerBot;
module.exports.getPteroConfig = getPteroConfig;
module.exports.saveConfigToPanel = saveConfigToPanel;
module.exports.autoFetchEggs = autoFetchEggs;
module.exports.buildFullEnv = buildFullEnv;
module.exports.CONFIG = CONFIG;
module.exports.sshExec = sshExec;

console.log("[PANEL] MERGED v15 FULL + FIX — Panel + PanelPro + Pterodactyl lengkap");