const router = require("./router");
const cfg = require("../config");

// ═══ HELPER TAMPILAN ═══
const LINE = "━━━━━━━━━━━━━━━━━━━━";

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;

        if (msg.includes("there is no text in the message to edit")) {
            try {
                return await bot.editMessageCaption(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch (e2) {
                const m2 = e2.message || "";
                if (m2.includes("message is not modified")) return null;
            }
        }

        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try {
                return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options });
            } catch { return null; }
        }
        return null;
    }
}

// ═══ SAFE SEND PHOTO ═══
async function sendPhoto(bot, chatId, url, caption, keyboard, q = null) {
    if (typeof bot.sendRichMenu === "function") {
        return bot.sendRichMenu(chatId, url, caption, keyboard, q);
    }
    const reply_markup = keyboard ? { inline_keyboard: keyboard } : undefined;
    return bot.sendPhoto(chatId, url, { caption, parse_mode: "HTML", reply_markup });
}

// ═══════════════════════════════════════════
// MENU BUILD
// ═══════════════════════════════════════════
router.registerCallback("menu_buildmenu", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        const role = ctx.db.isOwner(user.id)
            ? "✦ OWNER"
            : (u.premium ? "✦ PREMIUM" : "✦ FREE");

        const caption =
            `✦ <b>BUILD MENU</b>\n` +
            `${LINE}\n` +
            `<blockquote>✦ Role     <b>${role}</b>\n` +
            `✦ Credit   <b>${u.credit}</b>\n` +
            `✦ Biaya    <b>${cfg.CREDIT_PER_USE} credit</b> / fitur</blockquote>\n\n` +

            `<b>✦ BUILD</b>\n` +
            `▸ Build Pubspec — Flutter APK\n` +
            `▸ Build Yaml — Native APK\n` +
            `▸ Web to App — Web ke APK\n\n` +

            `<b>✦ RENAME</b>\n` +
            `▸ Base · API · Baileys · Function\n\n` +

            `<b>✦ CONVERT</b>\n` +
            `▸ HTML to JS · JS to HTML\n` +
            `▸ AI Code Editor\n\n` +

            `<b>✦ FIX</b>\n` +
            `▸ Fix Error Build\n` +
            `${LINE}\n` +
            `<i>Semua fitur butuh credit.</i>`;

        const kb = [
            // ═══ BUILD ═══
            [
                { text: "✦ Build Pubspec", callback_data: "menu_buildpubspec", style: "success" },
                { text: "✦ Build Yaml", callback_data: "menu_buildyml", style: "success" }
            ],
            [
                { text: "✦ Web to App", callback_data: "menu_webtoapp", style: "success" },
                { text: "✦ Prompt Rombak", callback_data: "buildprompt_rombak", style: "success" },
                { text: "✦ Prompt Fix", callback_data: "buildprompt_fix", style: "success" }
            ],

            // ═══ RENAME ═══
            [
                { text: "✦ Rename Base", callback_data: "menu_renamebase", style: "success" },
                { text: "✦ Rename API", callback_data: "menu_renameapi", style: "success" }
            ],
            [
                { text: "✦ Rename Baileys", callback_data: "menu_renamebaileys", style: "success" },
                { text: "✦ Rename Function", callback_data: "menu_renamefunc", style: "success" }
            ],

            // ═══ CONVERT ═══
            [
                { text: "✦ HTML to JS", callback_data: "menu_htmltojs", style: "success" },
                { text: "✦ JS to HTML", callback_data: "menu_jstohtml", style: "success" }
            ],
            [
                { text: "✦ AI Code Editor", callback_data: "menu_aicodeeditor", style: "success" }
            ],

            // ═══ FIX ERROR ═══
            [
                { text: "✦ Fix Error Build", callback_data: "menu_buildfix", style: "success" }
            ],

            // ═══ NAVIGASI ═══
            [
                { text: "✦ Buy Credit", callback_data: "menu_buycredit", style: "success" }
            ],
            [
                { text: "✕ Menu Utama", callback_data: "menu_back", style: "danger" }
            ]
        ];

        // PAKAI BANNER FOTO — kalau ga ada, fallback text
        const bannerUrl = (cfg.FOTO && (cfg.FOTO.BUILDMENU || cfg.FOTO.BUILD || cfg.FOTO.MENU)) || null;

        if (bannerUrl) {
            await sendPhoto(bot, q.message.chat.id, bannerUrl, caption, kb, q);
        } else {
            // Fallback tanpa foto
            if (q && q.message && q.message.message_id) {
                await safeEdit(bot, q.message.chat.id, q.message.message_id, caption, {
                    reply_markup: { inline_keyboard: kb }
                });
            } else {
                await bot.sendMessage(q.message.chat.id, caption, {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: kb }
                });
            }
        }
    } catch (e) {
        console.log("[BUILD MENU ERR]", e.message);
    }
});

// ═══════════════════════════════════════════
// ALIAS — menu_build (kalau ada handler lama pake ini)
// ═══════════════════════════════════════════
router.registerCallback("menu_build", async (bot, q, data, user, ctx) => {
    const handlers = require("./router.js").handlers;
    if (handlers["menu_buildmenu"]) {
        return handlers["menu_buildmenu"](bot, q, data, user, ctx);
    }
});

// ═══════════════════════════════════════════
// MENU BUILD PROMPT — alias ke build-prompt.js
// ═══════════════════════════════════════════
router.registerCallback("menu_buildprompt", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `✦ <b>BUILD PROMPT GENERATOR</b>\n` +
            `${LINE}\n` +
            `<blockquote>✦ <b>FITUR UTAMA</b>\n` +
            `▸ ✦ Prompt Rombak Base — generate prompt tema\n` +
            `▸ ✦ Prompt Fix Error — generate prompt fix\n` +
            `▸ ✦ Auto redirect ke GPT/Gemini/DeepSeek\n` +
            `▸ ✦ Copy paste langsung ke AI</blockquote>\n\n` +
            `✦ <b><i>PILIH TIPE PROMPT:</i></b>`;

        const kb = [
            [
                { text: "✦ Prompt Rombak Base", callback_data: "buildprompt_rombak", style: "success" },
                { text: "✦ Prompt Fix Error", callback_data: "buildprompt_fix", style: "danger" }
            ],
            [
                { text: "✕ Kembali", callback_data: "menu_buildmenu", style: "danger" }
            ]
        ];

        if (q && q.message && q.message.message_id) {
            await safeEdit(bot, q.message.chat.id, q.message.message_id, caption, {
                reply_markup: { inline_keyboard: kb }
            });
        } else {
            await bot.sendMessage(q.message.chat.id, caption, {
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: kb }
            });
        }
    } catch (e) { console.log("[MENU BUILDPROMPT ERR]", e.message); }
});

console.log("[BUILDMENU] module loaded — 11 fitur build (v3 RICH MESSAGE)");