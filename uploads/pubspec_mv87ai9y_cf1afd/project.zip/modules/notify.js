const cfg = require("../config");

const THEMES = {
    success: {
        label: "SUCCESS",
        brick: "#22C55E",
        brickDark: "#16A34A",
        brickLight: "#4ADE80",
        accent: "#86EFAC",
        text: "#052E16",
        iconSvg: "check"
    },
    failed: {
        label: "FAILED",
        brick: "#EF4444",
        brickDark: "#B91C1C",
        brickLight: "#F87171",
        accent: "#FCA5A5",
        text: "#450A0A",
        iconSvg: "cross"
    },
    info: {
        label: "INFO",
        brick: "#3B82F6",
        brickDark: "#1D4ED8",
        brickLight: "#60A5FA",
        accent: "#93C5FD",
        text: "#0C1E3E",
        iconSvg: "info"
    },
    warning: {
        label: "WARNING",
        brick: "#F59E0B",
        brickDark: "#B45309",
        brickLight: "#FBBF24",
        accent: "#FCD34D",
        text: "#451A03",
        iconSvg: "warn"
    },
    pending: {
        label: "PENDING",
        brick: "#A855F7",
        brickDark: "#7E22CE",
        brickLight: "#C084FC",
        accent: "#DDD6FE",
        text: "#2E1065",
        iconSvg: "clock"
    },
    user: {
        label: "NEW USER",
        brick: "#8B5CF6",
        brickDark: "#6D28D9",
        brickLight: "#A78BFA",
        accent: "#C4B5FD",
        text: "#2E1065",
        iconSvg: "user"
    }
};


function escXml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&apos;");
}


// ═══════════════════════════════════════════
// SVG ICON LIBRARY (vector, bukan emoji)
// ═══════════════════════════════════════════
function iconSvg(name, color = "#FFFFFF", size = 40) {
    const half = size / 2;
    const paths = {
        check: `<path d="M 8 22 L 18 32 L 34 12" stroke="${color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`,
        cross: `<path d="M 12 12 L 32 32 M 32 12 L 12 32" stroke="${color}" stroke-width="5" stroke-linecap="round" fill="none"/>`,
        info:  `<circle cx="22" cy="22" r="16" stroke="${color}" stroke-width="4" fill="none"/><circle cx="22" cy="14" r="2.8" fill="${color}"/><rect x="19.5" y="19" width="5" height="14" rx="2.5" fill="${color}"/>`,
        warn:  `<path d="M 22 8 L 38 34 L 6 34 Z" stroke="${color}" stroke-width="4" fill="none" stroke-linejoin="round"/><circle cx="22" cy="20" r="2.5" fill="${color}"/><rect x="19.8" y="24" width="4.4" height="7" rx="2.2" fill="${color}"/>`,
        clock: `<circle cx="22" cy="22" r="16" stroke="${color}" stroke-width="4" fill="none"/><path d="M 22 12 L 22 22 L 30 26" stroke="${color}" stroke-width="4" stroke-linecap="round" fill="none"/>`,
        user:  `<circle cx="22" cy="16" r="7" stroke="${color}" stroke-width="4" fill="none"/><path d="M 8 38 Q 8 26 22 26 Q 36 26 36 38" stroke="${color}" stroke-width="4" fill="none" stroke-linecap="round"/>`,
    };
    return `<g transform="translate(${-half},${-half})">${paths[name] || paths.info}</g>`;
}


// ═══════════════════════════════════════════
// INITIAL AVATAR (kalau user ga punya foto)
// ═══════════════════════════════════════════
function makeInitials(name) {
    const parts = String(name || "?").trim().split(/\s+/);
    const a = (parts[0] || "?").charAt(0).toUpperCase();
    const b = parts[1] ? parts[1].charAt(0).toUpperCase() : "";
    return a + b;
}


// ═══════════════════════════════════════════
// LEGO STUD ROW (bumps di atas & bawah)
// ═══════════════════════════════════════════
function studRow(y, count, spacing, cx, color, colorLight) {
    let out = "";
    const startX = cx - ((count - 1) * spacing) / 2;
    for (let i = 0; i < count; i++) {
        const x = startX + i * spacing;
        out += `<circle cx="${x}" cy="${y}" r="9" fill="${colorLight}"/>`;
        out += `<circle cx="${x}" cy="${y}" r="9" fill="none" stroke="${color}" stroke-width="1.5" opacity="0.6"/>`;
        out += `<ellipse cx="${x}" cy="${y - 3}" rx="7" ry="3" fill="#FFFFFF" opacity="0.35"/>`;
    }
    return out;
}


// ═══════════════════════════════════════════
// MAIN GENERATOR
// ═══════════════════════════════════════════
async function generateStatusImage({
    title = "NOTIFIKASI",
    subtitle = "",
    status = "info",
    fields = [],
    footer = "",
    user = null,        // { first_name, last_name, username, id }
    feature = "",       // nama fitur yang dipake
    time = null
}) {
    const sharp = require("sharp");
    const t = THEMES[status] || THEMES.info;

    const W = 1080;
    const H = 720;

    const brickX = 40;
    const brickY = 80;
    const brickW = W - 80;
    const brickH = H - 160;

    // ─── Avatar ─────────────────────────────
    const fullName = user
        ? [user.first_name, user.last_name].filter(Boolean).join(" ") || "Unknown"
        : "Anonymous";
    const uname = user?.username ? "@" + user.username : "-";
    const initials = makeInitials(fullName);
    const avatarCx = 160;
    const avatarCy = 200;
    const avatarR = 60;

    const avatarGroup = `
        <circle cx="${avatarCx}" cy="${avatarCy}" r="${avatarR + 8}" fill="${t.brickLight}" opacity="0.25"/>
        <circle cx="${avatarCx}" cy="${avatarCy}" r="${avatarR}" fill="${t.brick}" stroke="#FFFFFF" stroke-width="5"/>
        <text x="${avatarCx}" y="${avatarCy + 14}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="46" font-weight="900" fill="#FFFFFF" text-anchor="middle">${escXml(initials)}</text>
    `;

    // ─── Status badge ───────────────────────
    const badgeW = 320;
    const badgeH = 76;
    const badgeX = W - 60 - badgeW;
    const badgeY = 130;

    const statusBadge = `
        <rect x="${badgeX}" y="${badgeY}" width="${badgeW}" height="${badgeH}" rx="38" fill="${t.brick}" stroke="#FFFFFF" stroke-width="4"/>
        <rect x="${badgeX}" y="${badgeY}" width="${badgeW}" height="14" rx="7" fill="${t.brickLight}" opacity="0.6"/>
        <g transform="translate(${badgeX + 50},${badgeY + badgeH / 2})">
            ${iconSvg(t.iconSvg, "#FFFFFF", 40)}
        </g>
        <text x="${badgeX + 100}" y="${badgeY + badgeH / 2 + 12}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="30" font-weight="900" fill="#FFFFFF" letter-spacing="2">${t.label}</text>
    `;

    // ─── Fields ─────────────────────────────
    const cleanFields = [];
    if (user) {
        cleanFields.push({ label: "USERNAME", value: uname });
        cleanFields.push({ label: "NAMA", value: fullName });
        cleanFields.push({ label: "USER ID", value: String(user.id || "-") });
    }
    if (feature) cleanFields.push({ label: "FITUR", value: feature });
    cleanFields.push({
        label: "WAKTU",
        value: time || new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    });
    for (const f of fields) cleanFields.push(f);

    const visible = cleanFields.slice(0, 6);
    const startY = 320;
    const rowGap = 52;

    const fieldRows = visible.map((f, i) => {
        const y = startY + i * rowGap;
        return `
            <rect x="80" y="${y - 30}" width="${W - 160}" height="42" rx="10" fill="#FFFFFF" opacity="0.55"/>
            <text x="100" y="${y}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="18" font-weight="700" fill="${t.text}" opacity="0.75">${escXml(f.label)}</text>
            <text x="${W - 100}" y="${y}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="20" font-weight="900" fill="${t.text}" text-anchor="end">${escXml(String(f.value).slice(0, 42))}</text>
            <line x1="80" y1="${y + 12}" x2="${W - 80}" y2="${y + 12}" stroke="${t.brickDark}" stroke-width="1" opacity="0.15" stroke-dasharray="4 4"/>
        `;
    }).join("");

    // ─── Title + subtitle ───────────────────
    const titleBlock = `
        <text x="${W / 2}" y="${brickY + 55}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="34" font-weight="900" fill="${t.text}" text-anchor="middle" letter-spacing="2">${escXml(title).slice(0, 42)}</text>
        ${subtitle
            ? `<text x="${W / 2}" y="${brickY + 88}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="16" fill="${t.text}" opacity="0.7" text-anchor="middle">${escXml(subtitle).slice(0, 60)}</text>`
            : ""}
    `;

    // ─── Footer ─────────────────────────────
    const footerBlock = footer
        ? `<text x="${W / 2}" y="${H - 90}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="15" font-weight="700" fill="${t.text}" opacity="0.65" text-anchor="middle">${escXml(footer).slice(0, 90)}</text>`
        : `<text x="${W / 2}" y="${H - 90}" font-family="'Trebuchet MS', 'Comic Sans MS', sans-serif" font-size="15" font-weight="700" fill="${t.text}" opacity="0.55" text-anchor="middle">𖡛 SPARTAX ENGINE — POWERED BY XZOMBIES</text>`;

    // ─── Assemble SVG ───────────────────────
    const svg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${t.brickLight}"/>
      <stop offset="50%" stop-color="${t.brick}"/>
      <stop offset="100%" stop-color="${t.brickDark}"/>
    </linearGradient>
    <pattern id="dotPat" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
      <circle cx="20" cy="20" r="3" fill="#FFFFFF" opacity="0.18"/>
    </pattern>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000000" flood-opacity="0.35"/>
    </filter>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  <rect width="${W}" height="${H}" fill="url(#dotPat)"/>

  <g filter="url(#shadow)">
    <rect x="${brickX}" y="${brickY}" width="${brickW}" height="${brickH}" rx="32" fill="#FFFFFF" stroke="${t.brickDark}" stroke-width="3"/>
    <rect x="${brickX}" y="${brickY}" width="${brickW}" height="18" rx="9" fill="${t.brick}" opacity="0.9"/>
  </g>

  ${studRow(brickY - 6, 8, 90, W / 2, t.brickDark, t.brickLight)}
  ${studRow(brickY + brickH + 6, 8, 90, W / 2, t.brickDark, t.brickLight)}

  <rect x="${brickX + 20}" y="${brickY + 30}" width="${brickW - 40}" height="${brickH - 60}" rx="22" fill="${t.accent}" opacity="0.18"/>

  ${avatarGroup}
  ${statusBadge}
  ${titleBlock}
  ${fieldRows}
  ${footerBlock}
</svg>`;

    return await sharp(Buffer.from(svg)).png().toBuffer();
}


// ═══════════════════════════════════════════
// SEND STATUS
// ═══════════════════════════════════════════
async function sendStatus(bot, {
    title,
    subtitle,
    status = "info",
    fields = [],
    footer,
    caption,
    chatId,
    user = null,
    feature = "",
    time = null
}) {
    const target = chatId || cfg.NOTIF_CHANNEL;
    if (!target || target === "-1001234567890") {
        console.log("[NOTIFY] skip — NOTIF_CHANNEL default");
        return;
    }

    const t = THEMES[status] || THEMES.info;
    const esc = (v) => String(v ?? "—").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    const fullName = user ? ([user.first_name, user.last_name].filter(Boolean).join(" ") || "Unknown") : "—";
    const username = user?.username ? `@${user.username}` : "—";
    const stamp = time || new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    const statusLabel = ({ success: "SUCCESS", failed: "FAILED", pending: "PENDING", user: "USER BARU", info: "INFO", warning: "WARNING" })[status] || t.label;
    const detailLines = (fields || []).slice(0, 7).map(f => `• <b>${esc(f.label)}</b>: ${esc(String(f.value ?? "—").slice(0, 100))}`).join("\n");
    const generatedCaption =
        `<b>𖡛 ${statusLabel} · ${esc(title)}</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `👤 <b>Nama</b>: ${esc(fullName)}\n` +
        `🌐 <b>Username</b>: ${esc(username)}\n` +
        `🆔 <b>ID</b>: <code>${esc(user?.id || "—")}</code>\n` +
        `🧩 <b>Fitur</b>: ${esc(feature || title)}\n` +
        `🕒 <b>Waktu WIB</b>: <code>${esc(stamp)}</code>\n` +
        `📌 <b>Status</b>: <b>${statusLabel}</b>` +
        (detailLines ? `\n\n<b>Detail</b>\n${detailLines}` : "") +
        (subtitle ? `\n\n${esc(subtitle)}` : "") +
        (footer ? `\n\n<i>${esc(footer)}</i>` : "") +
        `\n━━━━━━━━━━━━━━━━━━━━`;
    const finalCaption = generatedCaption.length > 980 ? generatedCaption.slice(0, 960) + "…" : generatedCaption;

    try {
        const img = await generateStatusImage({
            title, subtitle, status, fields, footer, user, feature, time
        });
        // The adapter sends this as a native Rich Message with the generated image plus formatted detail text.
        await bot.sendPhoto(target, img, { caption: finalCaption, parse_mode: "HTML" });
        console.log("[NOTIFY]", status, "OK");
    } catch (e) {
        console.log("[NOTIFY] sendPhoto FAIL:", e.message);
        try {
            await bot.sendMessage(target, finalCaption, { parse_mode: "HTML" });
        } catch (e2) {
            console.log("[NOTIFY] sendMessage FAIL:", e2.message);
        }
    }
}


// ═══════════════════════════════════════════
// SHORTCUTS
// ═══════════════════════════════════════════
async function notifySuccess(bot, title, fields = [], caption, extra = {}) {
    return sendStatus(bot, { title, status: "success", fields, caption, ...extra });
}

async function notifyFailed(bot, title, fields = [], caption, extra = {}) {
    return sendStatus(bot, { title, status: "failed", fields, caption, ...extra });
}

async function notifyInfo(bot, title, fields = [], caption, extra = {}) {
    return sendStatus(bot, { title, status: "info", fields, caption, ...extra });
}

async function notifyPending(bot, title, fields = [], caption, extra = {}) {
    return sendStatus(bot, { title, status: "pending", fields, caption, ...extra });
}

async function notifyUser(bot, user, extra = {}) {
    const name = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Unknown";
    const uname = user.username ? "@" + user.username : "-";
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    return sendStatus(bot, {
        title: "USER BARU /START",
        status: "user",
        user,
        feature: "/start",
        time: waktu,
        fields: extra.fields || [],
        caption:
            `<b>𖡛 USER BARU</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `𖡛 <b>Nama</b>: ${name}\n` +
            `𖡛 <b>Username</b>: ${uname}\n` +
            `𖡛 <b>ID</b>: <code>${user.id}</code>\n` +
            `𖡛 <b>Waktu</b>: <code>${waktu}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
        footer: extra.footer || ""
    });
}

async function notifyFeature(bot, user, feature, status, extra = {}) {
    const statusMap = {
        success: notifySuccess,
        failed: notifyFailed,
        info: notifyInfo,
        pending: notifyPending
    };
    const fn = statusMap[status] || notifyInfo;

    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

    return fn(bot, `FITUR: ${feature}`, extra.fields || [], extra.caption, {
        user,
        feature,
        time: waktu,
        chatId: extra.chatId,
        footer: extra.footer
    });
}

module.exports = {
    sendStatus,
    notifySuccess,
    notifyFailed,
    notifyInfo,
    notifyPending,
    notifyUser,
    notifyFeature,
    generateStatusImage,
    THEMES,
    iconSvg
};