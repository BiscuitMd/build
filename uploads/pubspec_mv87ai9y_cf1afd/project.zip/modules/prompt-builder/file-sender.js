// modules/prompt-builder/file-sender.js
// Kirim file.txt ke user

const fs = require("fs");
const path = require("path");

const TMP_DIR = path.join(__dirname, "..", "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

async function sendPromptFile(bot, chatId, name, content, type = "prompt") {
    const safeName = String(name).replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 40);
    const ts = Date.now();
    const filename = `${type}-${safeName}-${ts}.txt`;
    const filepath = path.join(TMP_DIR, filename);

    // Write file
    fs.writeFileSync(filepath, content, "utf8");

    // Send document
    try {
        await bot.sendDocument(chatId, filepath, {
            caption:
                `<b>✦ File ${type === "fix" ? "FIXED PROMPT" : "PROMPT"}</b>\n\n` +
                `▸ Nama: <code>${filename}</code>\n` +
                `▸ Size: <b>${(Buffer.byteLength(content, "utf8") / 1024).toFixed(2)} KB</b>\n\n` +
                `<i>Download & copy isinya.</i>`,
            parse_mode: "HTML"
        }, {
            filename: filename,
            contentType: "text/plain"
        });
        console.log("[PROMPT-BUILDER/FILE] sent:", filename);
    } catch (e) {
        console.log("[PROMPT-BUILDER/FILE] send error:", e.message);
        // Fallback: kirim sebagai teks
        await bot.sendMessage(chatId,
            `<b>File gagal dikirim. Ini isinya:</b>\n\n<pre>${escapeHtml(content.slice(0, 3500))}</pre>`,
            { parse_mode: "HTML" });
    }

    // Cleanup after 5 minutes
    setTimeout(() => {
        try { if (fs.existsSync(filepath)) fs.unlinkSync(filepath); } catch {}
    }, 5 * 60 * 1000);
}

function escapeHtml(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

module.exports = {
    sendPromptFile
};