const path = require("path");
const router = require(path.join(__dirname, "..", "router.js"));

const menu = require("./menu");
const generator = require("./generator");
const fixer = require("./fixer");
const states = require("./states");

// ═══ REGISTER CALLBACKS ═══
router.registerCallback("pb_menu", menu.handleMain);
router.registerCallback("pb_gen", menu.handleGeneratorMenu);
router.registerCallback("pb_fix", menu.handleFixMenu);
router.registerCallback("pb_gen_start", generator.handleStart);
router.registerCallback("pb_fix_start", fixer.handleStart);
router.registerCallback("pb_cancel", menu.handleCancel);

// ═══ REGISTER STATE HANDLERS ═══
// State buat input auto generator (multi-step)
router.registerMessage("pb_gen_input", states.handleGeneratorInput);

// State buat input fix error
router.registerMessage("pb_fix_input", states.handleFixerInput);

console.log("[PROMPT-BUILDER] ✓ modules registered");