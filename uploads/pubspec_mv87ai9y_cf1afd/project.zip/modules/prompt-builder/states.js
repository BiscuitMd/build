// modules/prompt-builder/states.js
// State handler — input dari user (multi-step)

const generator = require("./generator");
const fixer = require("./fixer");

// ═══ AUTO GENERATOR INPUT ═══
async function handleGeneratorInput(bot, msg, state, ctx) {
    const text = (msg.text || "").trim();

    if (!text) {
        return bot.sendMessage(msg.chat.id, "Kirim data dalam bentuk teks.", { parse_mode: "HTML" });
    }

    if (text === "/cancel") {
        if (ctx && ctx.clearState) ctx.clearState(String(msg.from.id));
        return bot.sendMessage(msg.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    }

    // Parse 5 field
    const lines = text.split("\n").map(l => l.trim()).filter(Boolean);

    if (lines.length < 5) {
        return bot.sendMessage(msg.chat.id,
            `<b>✕ Format salah.</b>\n\n` +
            `Kirim 5 baris:\n` +
            `1. Nama script\n` +
            `2. Target bahasa\n` +
            `3. Fungsi utama\n` +
            `4. Fitur (pisah koma)\n` +
            `5. Output format\n\n` +
            `<i>Coba kirim ulang.</i>`,
            { parse_mode: "HTML" });
    }

    const spec = {
        nama: lines[0].slice(0, 50),
        bahasa: lines[1].slice(0, 50),
        fungsi: lines[2].slice(0, 200),
        fitur: lines[3].slice(0, 500),
        output: lines[4].slice(0, 50)
    };

    // Clear state sebelum process
    if (ctx && ctx.clearState) ctx.clearState(String(msg.from.id));

    // Process generate
    await generator.processGenerate(bot, msg, msg.from, spec);
}

// ═══ FIX ERROR INPUT ═══
async function handleFixerInput(bot, msg, state, ctx) {
    const text = (msg.text || "").trim();

    if (!text) {
        return bot.sendMessage(msg.chat.id, "✦ Kirim prompt yang mau di-fix.", { parse_mode: "HTML" });
    }

    if (text === "/cancel") {
        if (ctx && ctx.clearState) ctx.clearState(String(msg.from.id));
        return bot.sendMessage(msg.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    }

    // Parse [PROMPT] ... [ALASAN] ...
    let oldPrompt = text;
    let reason = "";

    const promptMatch = text.match(/\[PROMPT\]\s*([\s\S]*?)(?=\[ALASAN\]|$)/i);
    const reasonMatch = text.match(/\[ALASAN\]\s*([\s\S]*)/i);

    if (promptMatch) oldPrompt = promptMatch[1].trim();
    if (reasonMatch) reason = reasonMatch[1].trim();

    // Clear state sebelum process
    if (ctx && ctx.clearState) ctx.clearState(String(msg.from.id));

    // Process fix
    await fixer.processFix(bot, msg, msg.from, oldPrompt, reason);
}

module.exports = {
    handleGeneratorInput,
    handleFixerInput
};