// modules/prompt-builder/menu.js
// Menu utama BUILD PROM + sub-menu 2 fitur

const path = require("path");
const cfg = require(path.join(__dirname, "..", "..", "config.js"));

const LINE = "━━━━━━━━━━━━━━━━━━━━━━";
const esc = (s) => String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

// ═══ MENU UTAMA BUILD PROM ═══
const MAIN_TEXT =
    `<b>✦ BUILD PROM ✦</b>\n` +
    `${LINE}\n` +
    `Auto generator prompt untuk berbagai kebutuhan script.\n\n` +
    `<blockquote><b>Fitur Tersedia:</b>\n` +
    `▸ <b>Auto Generator Prompt</b>\n` +
    `   Bikin prompt lengkap dari spec user.\n` +
    `   Support: Node.js, Python, Termux, APK, Native, GitHub.\n\n` +
    `▸ <b>Fix Error Prompt</b>\n` +
    `   Perbaiki prompt yang ditolak AI target.</blockquote>\n\n` +
    `<i>Pilih salah satu fitur di bawah.</i>`;

const MAIN_KEYBOARD = {
    inline_keyboard: [
        [
            { text: "✦ Auto Generator Prompt", callback_data: "pb_gen", style: "success" },
            { text: "✦ Fix Error Prompt", callback_data: "pb_fix", style: "danger" }
        ],
        [
            { text: "✕ Tutup", callback_data: "menu_close", style: "danger" }
        ]
    ]
};

async function handleMain(bot, q, data, user, ctx) {
    const chatId = q.message.chat.id;
    const photoUrl = cfg.FOTO && cfg.FOTO.PROMPT_BUILDER ? cfg.FOTO.PROMPT_BUILDER : cfg.FOTO.MENU;

    try {
        if (typeof bot.sendRichMenu === "function") {
            await bot.sendRichMenu(chatId, photoUrl, MAIN_TEXT, MAIN_KEYBOARD.inline_keyboard, q);
        } else {
            await bot.sendPhoto(chatId, photoUrl, { caption: MAIN_TEXT, parse_mode: "HTML", reply_markup: MAIN_KEYBOARD });
        }
    } catch (e) {
        console.error("[BUILD PROM] Rich Message gagal:", e.message);
        await bot.sendMessage(chatId,
            "<b>Build Prom belum dapat dirender sebagai Rich Message.</b>\nSilakan cek log bot untuk detail API.",
            { parse_mode: "HTML" });
    }
}

// ═══ MENU AUTO GENERATOR ═══
const GEN_TEXT =
    `<b>✦ AUTO GENERATOR PROMPT ✦</b>\n` +
    `${LINE}\n` +
    `Bot bakal generate prompt lengkap sesuai spec kamu.\n\n` +
    `<blockquote><b>Cara pakai:</b>\n` +
    `1. Klik tombol MULAI\n` +
    `2. Isi data yang diminta (5 field)\n` +
    `3. Bot generate prompt → kirim file.txt</blockquote>\n\n` +
    `<i>Pastikan data yang kamu isi detail biar prompt-nya akurat.</i>`;

const GEN_KEYBOARD = {
    inline_keyboard: [
        [{ text: "✦ MULAI GENERATE", callback_data: "pb_gen_start", style: "success" }],
        [{ text: "✕ Kembali", callback_data: "pb_menu", style: "primary" }]
    ]
};

async function handleGeneratorMenu(bot, q, data, user, ctx) {
    const chatId = q.message.chat.id;

    try {
        await bot.editMessageText(GEN_TEXT, {
            chat_id: chatId,
            message_id: q.message.message_id,
            parse_mode: "HTML",
            reply_markup: GEN_KEYBOARD
        });
    } catch (e) {
        await bot.sendMessage(chatId, GEN_TEXT, {
            parse_mode: "HTML",
            reply_markup: GEN_KEYBOARD
        });
    }
}

// ═══ MENU FIX ERROR ═══
const FIX_TEXT =
    `<b>✦ FIX ERROR PROMPT ✦</b>\n` +
    `${LINE}\n` +
    `Prompt kamu ditolak AI target? Bot bakal bantu perbaiki.\n\n` +
    `<blockquote><b>Cara pakai:</b>\n` +
    `1. Klik tombol MULAI\n` +
    `2. Paste prompt lama kamu\n` +
    `3. Jelaskan alasan ditolak (opsional)\n` +
    `4. Bot generate versi fix → kirim file.txt</blockquote>\n\n` +
    `<i>Semakin detail alasan ditolak, semakin akurat fix-nya.</i>`;

const FIX_KEYBOARD = {
    inline_keyboard: [
        [{ text: "✦ MULAI FIX", callback_data: "pb_fix_start", style: "danger" }],
        [{ text: "✕ Kembali", callback_data: "pb_menu", style: "primary" }]
    ]
};

async function handleFixMenu(bot, q, data, user, ctx) {
    const chatId = q.message.chat.id;

    try {
        await bot.editMessageText(FIX_TEXT, {
            chat_id: chatId,
            message_id: q.message.message_id,
            parse_mode: "HTML",
            reply_markup: FIX_KEYBOARD
        });
    } catch (e) {
        await bot.sendMessage(chatId, FIX_TEXT, {
            parse_mode: "HTML",
            reply_markup: FIX_KEYBOARD
        });
    }
}

// ═══ CANCEL ═══
async function handleCancel(bot, q, data, user, ctx) {
    const chatId = q.message.chat.id;
    if (ctx && ctx.clearState) ctx.clearState(String(user.id));

    await bot.sendMessage(chatId, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
}

module.exports = {
    handleMain,
    handleGeneratorMenu,
    handleFixMenu,
    handleCancel
};