// modules/prompt-builder/notifier.js
// Notif ke channel dengan foto + metadata user

const path = require("path");
const cfg = require(path.join(__dirname, "..", "..", "config.js"));

function getWIBTime() {
    const now = new Date();
    const time = now.toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false
    });
    const date = now.toLocaleDateString("id-ID", {
        timeZone: "Asia/Jakarta",
        day: "2-digit",
        month: "long",
        year: "numeric"
    });
    return { time, date };
}

async function notifyChannel(bot, user, feature, scriptName) {
    const channelId = cfg.NOTIF_CHANNEL;
    if (!channelId) {
        console.log("[PROMPT-BUILDER/NOTIF] no NOTIF_CHANNEL configured");
        return;
    }

    const { time, date } = getWIBTime();
    const photoUrl = (cfg.FOTO && cfg.FOTO.PROMPT_NOTIF) || (cfg.FOTO && cfg.FOTO.MENU);

    const username = user.username ? `@${user.username}` : "—";
    const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ") || "—";
    const profileLink = `tg://user?id=${user.id}`;
    const userId = user.id;

    const caption =
        `<b>✦ PROMPT GENERATOR USAGE ✦</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Fitur</b>     : ${feature}\n` +
        `▸ <b>Script</b>    : <code>${escapeHtml(scriptName)}</code>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Nama</b>      : ${escapeHtml(fullName)}\n` +
        `▸ <b>Username</b>  : ${escapeHtml(username)}\n` +
        `▸ <b>User ID</b>   : <code>${userId}</code>\n` +
        `▸ <b>Profile</b>   : <a href="${profileLink}">Buka Profile</a>\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `▸ <b>Jam</b>       : ${time} WIB\n` +
        `▸ <b>Tanggal</b>   : ${date}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `<i>Auto-notif — Prompt Builder</i>`;

    try {
        if (photoUrl) {
            await bot.sendPhoto(channelId, photoUrl, {
                caption,
                parse_mode: "HTML"
            });
        } else {
            await bot.sendMessage(channelId, caption, { parse_mode: "HTML" });
        }
        console.log("[PROMPT-BUILDER/NOTIF] ✓ sent to", channelId);
    } catch (e) {
        console.log("[PROMPT-BUILDER/NOTIF] error:", e.message);
    }
}

function escapeHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

module.exports = {
    notifyChannel
};