const router = require("./router");
const cfg = require("../config");
const gh = require("./github-builder");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ MAX ZIP 2GB ═══
const MAX_ZIP_SIZE = 2 * 1024 * 1024 * 1024;

// ═══ HELPERS ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("EFATAL") || msg.includes("AggregateError")) {
            await new Promise(r => setTimeout(r, 3000));
            try {
                return await bot.editMessageText(text, {
                    chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
                });
            } catch { return null; }
        }
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); }
            catch { return null; }
        }
        if (msg.includes("message is not modified")) return null;
        return null;
    }
}

// ═══ SKIP DIRS ═══
const SKIP_DIRS = new Set([
    "node_modules", ".git", ".github", "build", "dist",
    ".gradle", "__pycache__", ".vscode", ".idea",
    "venv", "env", ".venv", "target", "out", "obj",
    ".dart_tool", ".flutter-plugins", ".flutter-plugins-dependencies"
]);

// ═══ SEMUA TEXT FILE EXT (UNIVERSAL) ═══
const TEXT_EXTS = new Set([
    ".dart", ".yaml", ".yml", ".xml", ".gradle", ".kts",
    ".json", ".txt", ".properties", ".env", ".js", ".ts",
    ".html", ".css", ".py", ".java", ".kt", ".kts",
    ".md", ".sh", ".bat", ".plist", ".pbxproj", ".xcconfig",
    ".res", ".dtd", ".svg", ".gitignore", ".lock",
    ".cfg", ".conf", ".ini", ".toml", ".rb", ".php",
    ".swift", ".m", ".h", ".cpp", ".c", ".cs",
    ".gradle.properties", ".pro", ".storyboard", ".xib"
]);

function findAllFiles(dir, results = []) {
    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); }
    catch { return results; }

    for (const item of items) {
        const full = path.join(dir, item.name);
        if (item.isDirectory()) {
            if (SKIP_DIRS.has(item.name)) continue;
            findAllFiles(full, results);
        } else {
            results.push(full);
        }
    }
    return results;
}

function isTextFile(file) {
    try {
        const stat = fs.statSync(file);
        if (stat.size > 5 * 1024 * 1024) return false;
        if (stat.size === 0) return false;

        const ext = path.extname(file).toLowerCase();
        const basename = path.basename(file).toLowerCase();
        if (TEXT_EXTS.has(ext)) return true;
        if (basename === ".gitignore" || basename === ".env" || basename === "gradle.properties") return true;

        const fd = fs.openSync(file, "r");
        const buf = Buffer.alloc(Math.min(8192, stat.size));
        const bytesRead = fs.readSync(fd, buf, 0, buf.length, 0);
        fs.closeSync(fd);
        for (let i = 0; i < bytesRead; i++) {
            if (buf[i] === 0) return false;
        }
        return true;
    } catch { return false; }
}

function escapeRegex(str) {
    return String(str).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// ═══════════════════════════════════════════
// DOWNLOAD FILE VIA GRAMJS (2GB support)
// ═══════════════════════════════════════════
async function downloadFileViaGramJS(bot, ctx, chatId, messageId, destPath, onProgress) {
    const gramjsDownloader = require("../libs/gramjs-downloader");

    if (!gramjsDownloader.isReady()) {
        throw new Error("GramJS client belum ready. Login user session dulu via Owner Menu.");
    }

    // Normalize a common config typo ("--100…") before calling Telegram Bot API.
    const rawTargetChat = cfg.BOT_STORAGE_CHAT_ID || cfg.OWNER_ID;
    const targetChat = typeof rawTargetChat === "string" ? rawTargetChat.replace(/^--(?=100\d+$)/, "-").trim() : rawTargetChat;
    if (!targetChat) {
        throw new Error("BOT_STORAGE_CHAT_ID / OWNER_ID belum di-set di config.js");
    }

    console.log("[RENAME-BASE DL] Forward file ke:", targetChat);
    let forwarded;
    try {
        // Fail early with a useful diagnosis when the configured storage chat is wrong
        // or the bot has not started/been added to the destination chat.
        try {
            await bot.getChat(targetChat);
        } catch (resolveError) {
            throw new Error(`Tujuan storage tidak ditemukan (${String(targetChat)}). Pastikan BOT_STORAGE_CHAT_ID adalah ID -100... yang benar atau @username channel, bot sudah menjadi anggota/admin, dan channel tidak privat tanpa akses. Detail: ${resolveError.message}`);
        }
        forwarded = await bot.forwardMessage(targetChat, chatId, messageId);
        console.log("[RENAME-BASE DL] Forwarded, msg_id:", forwarded.message_id);
    } catch (e) {
        throw new Error(`Gagal forward: ${e.message}`);
    }

    await new Promise(r => setTimeout(r, 2000));

    const client = await gramjsDownloader.getClient();
    if (!client) throw new Error("GramJS client gagal init");

    let entity = targetChat;
    if (/^-?\d+$/.test(String(targetChat))) {
        try {
            entity = await client.getInputEntity(Number(targetChat));
        } catch (e) {
            console.log("[RENAME-BASE DL] resolve fail:", e.message);
        }
    }

    let messages;
    try {
        messages = await client.getMessages(entity, { limit: 5 });
    } catch (e) {
        throw new Error(`Gagal ambil messages: ${e.message}`);
    }

    if (!messages || messages.length === 0) throw new Error("Gak dapet message");

    const latestMsg = messages.find(m => m.media);
    if (!latestMsg) throw new Error("Gak ada file di target chat");

    console.log("[RENAME-BASE DL] Download via GramJS...");
    const result = await gramjsDownloader.downloadFromMessage(latestMsg, destPath, onProgress);

    // After the base has been downloaded successfully, remove the original message
    // from the source chat/group. This requires the bot to have delete-message
    // permission in that chat; the temporary storage copy is cleaned up below.
    try {
        await bot.deleteMessage(chatId, messageId);
        console.log("[BASE CLEANUP] Original base message deleted from source chat:", chatId, messageId);
    } catch (deleteError) {
        console.warn("[BASE CLEANUP] Could not delete original message (check bot admin/delete permission):", deleteError.message);
    }

    try {
        await client.deleteMessages(entity, [latestMsg.id], { revoke: true });
    } catch {}

    return result;
}

// ═══ CASE-INSENSITIVE REPLACE ═══
function caseInsensitiveReplaceAll(content, oldValue, newValue) {
    if (!oldValue) return { content, count: 0 };
    const regex = new RegExp(escapeRegex(oldValue), "gi");
    let count = 0;
    const result = content.replace(regex, () => { count++; return newValue; });
    return { content: result, count };
}

// ═══ RENAME FILE / FOLDER NAME ═══
function renamePathWithValue(rootDir, oldValue, newValue) {
    if (!oldValue) return 0;
    let renamed = 0;
    const oldLower = oldValue.toLowerCase();

    const allPaths = [];

    function collect(dir) {
        let items;
        try { items = fs.readdirSync(dir, { withFileTypes: true }); }
        catch { return; }

        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                if (SKIP_DIRS.has(item.name)) continue;
                collect(full);
                allPaths.push({ full, isDir: true });
            } else {
                allPaths.push({ full, isDir: false });
            }
        }
    }
    collect(rootDir);

    allPaths.sort((a, b) => {
        if (a.isDir !== b.isDir) return a.isDir ? 1 : -1;
        return b.full.split(path.sep).length - a.full.split(path.sep).length;
    });

    for (const { full, isDir } of allPaths) {
        const base = path.basename(full);
        if (!base.toLowerCase().includes(oldLower)) continue;

        const newBase = base.replace(new RegExp(escapeRegex(oldValue), "gi"), newValue);
        if (newBase === base) continue;

        const parent = path.dirname(full);
        const newPath = path.join(parent, newBase);

        try {
            fs.renameSync(full, newPath);
            renamed++;
            console.log(`[RENAME] ${isDir ? "DIR" : "FILE"}: ${base} → ${newBase}`);
        } catch (e) {
            console.log(`[RENAME ERR] ${base}: ${e.message}`);
        }
    }

    return renamed;
}

// ═══ SCAN FILE ═══
function scanForOldValue(extractDir, oldValue) {
    const allFiles = findAllFiles(extractDir);
    const found = [];
    const oldLower = String(oldValue).toLowerCase();

    for (const file of allFiles) {
        try {
            if (!isTextFile(file)) continue;
            const content = fs.readFileSync(file, "utf8");
            const contentLower = content.toLowerCase();
            if (contentLower.includes(oldLower)) {
                found.push(path.relative(extractDir, file));
            }
        } catch {}
    }
    return found;
}

function scanFileNameForOldValue(extractDir, oldValue) {
    const allFiles = findAllFiles(extractDir);
    const oldLower = String(oldValue).toLowerCase();
    const found = [];

    for (const file of allFiles) {
        const rel = path.relative(extractDir, file);
        if (rel.toLowerCase().includes(oldLower)) found.push(rel);
    }
    return found;
}

// ═══ REPLACE SEMUA FILE ═══
function replaceInAllFiles(extractDir, oldValue, newValue) {
    const allFiles = findAllFiles(extractDir);
    const results = [];
    let totalMatch = 0;

    for (const file of allFiles) {
        try {
            if (!isTextFile(file)) continue;
            const content = fs.readFileSync(file, "utf8");
            const { content: newContent, count } = caseInsensitiveReplaceAll(content, oldValue, newValue);
            if (count > 0) {
                fs.writeFileSync(file, newContent, "utf8");
                results.push({ path: path.relative(extractDir, file), matches: count });
                totalMatch += count;
            }
        } catch (e) {
            console.log("[RENAME FILE ERR]", file, e.message);
        }
    }

    return { files: results, totalMatch };
}

// ═══ RENAME TYPES ═══
const RENAME_TYPES = {
    appname: {
        id: "appname",
        label: "Nama Aplikasi",
        desc: "Ubah nama aplikasi di semua file (dart, manifest, strings.xml, pubspec.yaml, gradle, dll)",
        hintLama: "Contoh: MyOldApp",
        hintBaru: "Contoh: MyNewApp"
    },
    domain: {
        id: "domain",
        label: "Domain",
        desc: "Ubah domain di semua file text",
        hintLama: "Contoh: olddomain.com",
        hintBaru: "Contoh: newdomain.com"
    },
    telegram: {
        id: "telegram",
        label: "Username Telegram",
        desc: "Ubah username telegram (@xxx) di semua file text",
        hintLama: "Contoh: @oldusername",
        hintBaru: "Contoh: @newusername"
    },
    username: {
        id: "username",
        label: "Username / ID",
        desc: "Ubah username / package name / bundle ID",
        hintLama: "Contoh: com.oldapp.name",
        hintBaru: "Contoh: com.newapp.name"
    },
    assets: {
        id: "assets",
        label: "Assets Path",
        desc: "Ubah referensi assets + nama file asset",
        hintLama: "Contoh: logo_lama.png",
        hintBaru: "Contoh: logo_baru.png"
    },
    custom: {
        id: "custom",
        label: "Custom (Bebas)",
        desc: "Ganti apapun yang lu mau — bebas, universal",
        hintLama: "Contoh: apapun yang mau diganti",
        hintBaru: "Contoh: penggantinya"
    }
};

// ═══ MENU ═══
router.registerCallback("menu_renamebase", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < cfg.CREDIT_PER_USE) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>▸ RENAME BASE</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Rename base Flutter/Android\n` +
            `▸ Support: <b>SEMUA TEXT FILE</b> (dart, yaml, xml, gradle, kt, java, json, dll)\n` +
            `▸ Case-insensitive — <code>MyApp</code> <code>myapp</code> <code>MYAPP</code> semua kena\n` +
            `▸ Auto rename <b>nama file</b> & <b>folder</b> juga\n` +
            `▸ Kirim: <b>file .zip</b> base yang mau di-rename\n` +
            `▸ Max File: <b>2 GB</b>\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Cara kerja:</b>\n` +
            `1. Upload base .zip\n` +
            `2. Pilih tipe rename\n` +
            `3. Kirim nilai LAMA\n` +
            `4. Kirim nilai BARU\n` +
            `5. Bot kirim file hasil\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mulai dengan kirim file .zip:</i>`;

        ctx.clearState(user.id);
        ctx.setState(user.id, "renamebase_await_zip", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renamebase_cancel", style: "danger" }]] }
        });
    } catch (e) {
        console.log("[RENAME BASE MENU ERR]", e.message);
    }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("renamebase_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "base.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        // ⚡ MAX ZIP 2GB
        if (msg.document.file_size > MAX_ZIP_SIZE) {
            return bot.sendMessage(chatId,
                `<b>✕ File terlalu besar!</b>\n\n` +
                `▸ Size: ${(msg.document.file_size / 1024 / 1024 / 1024).toFixed(2)} GB\n` +
                `▸ Max: <b>2 GB</b>`,
                { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>▸ Menerima base zip</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(1)}]</code> <b>1%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${fname}</code>\n` +
            `▸ Size: ${(msg.document.file_size / 1024 / 1024).toFixed(2)} MB\n` +
            `<i>Download via GramJS...</i>`,
            { parse_mode: "HTML" });

        const jobId = gh.newJobId("renamebase");
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        const zipPath = path.join(workDir, fname);

        // ═══ DOWNLOAD VIA GRAMJS ═══
        let dlResult;
        try {
            dlResult = await downloadFileViaGramJS(
                bot, ctx, chatId, msg.message_id, zipPath,
                async (pct, info) => {
                    await safeEdit(bot, chatId, loading.message_id,
                        `<b>▸ Menerima base zip</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `<code>[${progressBar(pct)}]</code> <b>${pct}%</b>\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▸ File: <code>${fname}</code>\n` +
                        `▸ Info: <code>${info}</code>\n` +
                        `<i>Download via GramJS...</i>`,
                        { parse_mode: "HTML" });
                }
            );
            console.log("[RENAME BASE] ✅ download:", dlResult.size, "bytes");
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download:</b>\n<code>${e.message.slice(0, 200)}</code>`);
        }

        ctx.clearState(userId);
        ctx.setState(userId, "renamebase_pick_type", { jobId, zipPath, fname });

        const types = Object.values(RENAME_TYPES);
        const kb = [];
        for (let i = 0; i < types.length; i += 2) {
            const row = [];
            row.push({ text: "▸ " + types[i].label, callback_data: `renamebase_type:${types[i].id}`, style: "primary" });
            if (i + 1 < types.length) {
                row.push({ text: "▸ " + types[i + 1].label, callback_data: `renamebase_type:${types[i + 1].id}`, style: "primary" });
            }
            kb.push(row);
        }
        kb.push([{ text: "✕ Batal", callback_data: "renamebase_cancel", style: "danger" }]);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ RENAME BASE — Pilih Tipe</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Job: <code>${jobId}</code>\n` +
            `▸ File: <code>${fname}</code>\n` +
            `▸ Size: ${(dlResult.size / 1024 / 1024).toFixed(2)} MB\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih tipe rename:</b>`,
            { reply_markup: { inline_keyboard: kb } });
    } catch (e) {
        console.log("[RENAME BASE AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ PILIH TIPE ═══
router.registerCallback("renamebase_type", async (bot, q, data, user, ctx) => {
    try {
        await bot.answerCallbackQuery(q.id, { text: "Memproses...", show_alert: false }).catch(() => {});

        const typeId = data.split(":")[1];
        const type = RENAME_TYPES[typeId];

        if (!type) {
            return bot.sendMessage(q.message.chat.id, `<b>✕ Tipe invalid</b>`, { parse_mode: "HTML" });
        }

        const prev = ctx.getState(user.id) || {};
        if (!prev.jobId || !prev.zipPath) {
            ctx.clearState(user.id);
            return bot.sendMessage(q.message.chat.id, `<b>✕ Sesi hilang.</b> Ulangi dari awal.`, { parse_mode: "HTML" });
        }

        ctx.setState(user.id, "renamebase_await_old", {
            typeId,
            jobId: prev.jobId,
            zipPath: prev.zipPath,
            fname: prev.fname
        });

        await bot.sendMessage(q.message.chat.id,
            `<b>▸ ${type.label.toUpperCase()}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Info: ${type.desc}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Langkah 1/2: Kirim nilai LAMA</b>\n\n` +
            `▸ Format: <code>${type.hintLama}</code>\n\n` +
            `<i>Ini nilai yang sekarang ada di base lu, yang mau diganti.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renamebase_cancel", style: "danger" }]] } });
    } catch (e) {
        console.log("[RENAME BASE TYPE ERR]", e.message);
    }
});

// ═══ TERIMA NILAI LAMA ═══
router.registerMessage("renamebase_await_old", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const oldValue = (msg.text || "").trim();

        if (!oldValue) {
            return bot.sendMessage(chatId, `<b>✕ Kirim nilai lama.</b>`, { parse_mode: "HTML" });
        }

        const type = RENAME_TYPES[state.typeId];
        const { jobId, zipPath, fname } = state;

        workDir = path.join(TMP_DIR, jobId);
        const extractDir = path.join(workDir, "extracted");
        if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir, { recursive: true });

        if (!fs.existsSync(path.join(extractDir, ".extracted"))) {
            try {
                const zip = new AdmZip(zipPath);
                zip.extractAllTo(extractDir, true);
                fs.writeFileSync(path.join(extractDir, ".extracted"), "1");
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal extract:</b>\n<code>${e.message.slice(0, 200)}</code>`, { parse_mode: "HTML" });
            }
        }

        const foundInFiles = scanForOldValue(extractDir, oldValue);
        const foundInNames = scanFileNameForOldValue(extractDir, oldValue);

        let reportText = `<b>🔍 VERIFIKASI NILAI LAMA</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Tipe: <b>${type.label}</b>\n` +
            `▸ Nilai lama: <code>${oldValue}</code>\n` +
            `▸ Ditemukan di <b>isi file</b>: <code>${foundInFiles.length}</code>\n` +
            `▸ Ditemukan di <b>nama file/folder</b>: <code>${foundInNames.length}</code>\n`;

        if (foundInFiles.length > 0) {
            reportText += `━━━━━━━━━━━━━━━━━━━━\n<b>Isi file:</b>\n`;
            for (const f of foundInFiles.slice(0, 8)) {
                reportText += `▸ <code>${f}</code>\n`;
            }
            if (foundInFiles.length > 8) {
                reportText += `▸ <i>...dan ${foundInFiles.length - 8} file lain</i>\n`;
            }
        }

        if (foundInNames.length > 0) {
            reportText += `\n<b>Nama file/folder:</b>\n`;
            for (const f of foundInNames.slice(0, 5)) {
                reportText += `▸ <code>${f}</code>\n`;
            }
            if (foundInNames.length > 5) {
                reportText += `▸ <i>...dan ${foundInNames.length - 5} lain</i>\n`;
            }
        }

        reportText += `━━━━━━━━━━━━━━━━━━━━\n\n`;

        const totalFound = foundInFiles.length + foundInNames.length;
        if (totalFound === 0) {
            reportText += `⚠️ <b>Nilai lama TIDAK ditemukan di base!</b>\n\n` +
                `<i>Cek lagi apakah nilai lama bener.</i>`;
        } else {
            reportText += `<b>Langkah 2/2: Kirim nilai BARU</b>\n\n` +
                `▸ Format: <code>${type.hintBaru}</code>\n\n` +
                `<i>Semua yang ada nilai lama bakal diganti jadi nilai ini.</i>`;
        }

        ctx.setState(userId, "renamebase_await_new", {
            typeId: state.typeId,
            jobId,
            zipPath,
            fname,
            oldValue
        });

        await bot.sendMessage(chatId, reportText, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "renamebase_cancel", style: "danger" }]] }
        });
    } catch (e) {
        console.log("[RENAME BASE OLD ERR]", e.message);
    }
});

// ═══ TERIMA NILAI BARU ═══
router.registerMessage("renamebase_await_new", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const newValue = (msg.text || "").trim();

        if (!newValue) {
            return bot.sendMessage(chatId, `<b>✕ Kirim nilai baru.</b>`, { parse_mode: "HTML" });
        }

        const { typeId, jobId, zipPath, fname, oldValue } = state;
        const type = RENAME_TYPES[typeId];

        if (!jobId || !zipPath || !typeId) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi hilang.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);

        const loading = await bot.sendMessage(chatId,
            `<b>▸ Memproses Rename</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(10)}]</code> <b>10%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Lama: <code>${oldValue}</code>\n` +
            `▸ Baru: <code>${newValue}</code>\n` +
            `<i>Processing...</i>`,
            { parse_mode: "HTML" });

        workDir = path.join(TMP_DIR, jobId);
        const extractDir = path.join(workDir, "extracted");

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ Memproses Rename</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(30)}]</code> <b>30%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Scan semua file + replace isi...</i>`);

        const { files: changedFiles, totalMatch } = replaceInAllFiles(extractDir, oldValue, newValue);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ Memproses Rename</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(60)}]</code> <b>60%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File diubah: <code>${changedFiles.length}</code>\n` +
            `<i>Rename nama file/folder...</i>`);

        const renamedCount = renamePathWithValue(extractDir, oldValue, newValue);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>▸ Memproses Rename</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(85)}]</code> <b>85%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Rename file: <code>${renamedCount}</code>\n` +
            `<i>Membuat zip baru...</i>`);

        if (changedFiles.length === 0 && renamedCount === 0) {
            await safeEdit(bot, chatId, loading.message_id,
                `<b>⚠️ GA ADA PERUBAHAN</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Tipe: <b>${type.label}</b>\n` +
                `▸ Lama: <code>${oldValue}</code>\n` +
                `▸ Baru: <code>${newValue}</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Ga nemu nilai lama di base. Cek lagi nilai lama lu.</i>`);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return;
        }

        const outputZipPath = path.join(workDir, `renamed_${fname}`);
        try {
            const newZip = new AdmZip();
            newZip.addLocalFolder(extractDir);
            newZip.deleteFile(".extracted");
            newZip.writeZip(outputZipPath);
        } catch (e) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal zip ulang:</b>\n<code>${e.message.slice(0, 200)}</code>`);
        }

        const stat = fs.statSync(outputZipPath);
        const preview = changedFiles.slice(0, 15).map(f => `▸ <code>${f.path}</code>`).join("\n");
        const more = changedFiles.length > 15 ? `\n▸ <i>...dan ${changedFiles.length - 15} file lain</i>` : "";

        try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

        try {
            await bot.sendDocument(chatId, outputZipPath, {
                caption:
                    `<b>✓ RENAME BASE SUCCESS</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Job: <code>${jobId}</code>\n` +
                    `▸ Tipe: <b>${type.label}</b>\n` +
                    `▸ Lama: <code>${oldValue}</code>\n` +
                    `▸ Baru: <code>${newValue}</code>\n` +
                    `▸ File isi diubah: <code>${changedFiles.length}</code>\n` +
                    `▸ File/folder di-rename: <code>${renamedCount}</code>\n` +
                    `▸ Total match: <code>${totalMatch}</code>\n` +
                    `▸ Size: ${(stat.size / 1024 / 1024).toFixed(2)} MB\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<b>File yang diubah isi:</b>\n${preview}${more}`,
                parse_mode: "HTML"
            }, { filename: `renamed_${fname}`, contentType: "application/zip" });
        } catch {
            await bot.sendMessage(chatId, `<b>✓ SUCCESS</b> tapi gagal kirim file.`, { parse_mode: "HTML" });
        }

        try {
            await buildNotifier.sendBuildNotif(bot, {
                status: "success",
                feature: `Rename Base — ${type.label}`,
                baseName: fname,
                user: { id: userId, first_name: msg.from.first_name || "User", username: msg.from.username },
                subtitle: `${changedFiles.length} file + ${renamedCount} rename`,
                fields: [
                    { label: "Tipe", value: type.label },
                    { label: "Lama", value: oldValue },
                    { label: "Baru", value: newValue },
                    { label: "Files", value: String(changedFiles.length) },
                    { label: "Renamed", value: String(renamedCount) }
                ]
            });
        } catch {}

        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    } catch (e) {
        console.log("[RENAME BASE NEW ERR]", e.message);
        console.log("[RENAME BASE NEW STACK]", e.stack);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ CANCEL ═══
router.registerCallback("renamebase_cancel", async (bot, q, data, user, ctx) => {
    try {
        const st = ctx.getState(user.id);
        if (st && st.jobId) {
            const workDir = path.join(TMP_DIR, st.jobId);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        }
        ctx.clearState(user.id);
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[RENAME BASE CANCEL ERR]", e.message); }
});

module.exports = { RENAME_TYPES, replaceInAllFiles, scanForOldValue, renamePathWithValue };
console.log("[RENAME BASE] v4 loaded — UNIVERSAL + MAX 2GB via GramJS");