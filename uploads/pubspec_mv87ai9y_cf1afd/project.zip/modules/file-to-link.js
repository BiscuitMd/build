const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const uploader = require("./upload-to-link");

const TMP_DIR = path.join(__dirname, "..", "tmp_upload");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ ESCAPE ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ FORMAT SIZE ═══
function formatSize(bytes) {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + " KB";
    return (bytes / 1024 / 1024).toFixed(2) + " MB";
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ MENU ═══
router.registerCallback("menu_filetolink", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>✦ FILE TO LINK</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `Ubah file / foto / video / audio\n` +
            `jadi <b>link download</b> yang bisa dishare!\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Support:</b>\n` +
            `▸  Foto: .jpg, .png, .gif, .webp\n` +
            `▸  Video: .mp4, .mkv, .mov\n` +
            `▸  Audio: .mp3, .wav, .ogg\n` +
            `▸  File: .pdf, .zip, .apk, dll\n\n` +
            `<b>Max size:</b> <code>200 MB</code>\n` +
            `<b>Biaya:</b> <b>GRATIS</b> ✦\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file/foto/video/audio sekarang~</i>`;

        ctx.clearState(user.id);
        ctx.setState(user.id, "file_to_link_wait", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[
                { text: "✕ Batal", callback_data: "file_to_link_cancel", style: "danger" }
            ]] }
        });
    } catch (e) { console.log("[FILE2LINK MENU ERR]", e.message); }
});

// ═══ HANDLE FILE ═══
router.registerMessage("file_to_link_wait", async (bot, msg, state, ctx) => {
    let filePath = null;
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(msg.from.id);
            return;
        }

        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // ─── Detect file ───
        let fileId = null;
        let fileName = null;
        let fileSize = 0;
        let isImage = false;

        if (msg.photo && msg.photo.length > 0) {
            const p = msg.photo[msg.photo.length - 1];
            fileId = p.file_id;
            fileSize = p.file_size || 0;
            fileName = `photo_${Date.now()}.jpg`;
            isImage = true;
        } else if (msg.video) {
            fileId = msg.video.file_id;
            fileSize = msg.video.file_size || 0;
            fileName = msg.video.file_name || `video_${Date.now()}.mp4`;
        } else if (msg.audio) {
            fileId = msg.audio.file_id;
            fileSize = msg.audio.file_size || 0;
            fileName = msg.audio.file_name || `audio_${Date.now()}.mp3`;
        } else if (msg.voice) {
            fileId = msg.voice.file_id;
            fileSize = msg.voice.file_size || 0;
            fileName = `voice_${Date.now()}.ogg`;
        } else if (msg.document) {
            fileId = msg.document.file_id;
            fileSize = msg.document.file_size || 0;
            fileName = msg.document.file_name || `file_${Date.now()}`;
            isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(fileName);
        } else {
            return bot.sendMessage(chatId,
                `<b>✕ Kirim file/foto/video/audio ya~</b>\n\n` +
                `<i>Yang bisa: foto, video, audio, document</i>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "file_to_link_cancel", style: "danger" }]] } });
        }

        // ─── Cek size (max 200MB) ───
        if (fileSize > 200 * 1024 * 1024) {
            return bot.sendMessage(chatId,
                `<b>✕ File terlalu besar!</b>\n\n` +
                `▸ Max: <code>200 MB</code>\n` +
                `▸ File lu: <code>${formatSize(fileSize)}</code>`,
                { parse_mode: "HTML" });
        }

        // ─── Loading ───
        const loading = await bot.sendMessage(chatId,
            `<b>✦ Uploading file...</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName.slice(0, 40))}</code>\n` +
            `▸ Size: <code>${formatSize(fileSize)}</code>\n` +
            `▸ Status: Download dari Telegram...\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        // ─── Download file ───
        filePath = path.join(TMP_DIR, `${userId}_${Date.now()}_${fileName}`);
        try {
            const fileLink = await bot.getFileLink(fileId);
            const res = await axios.get(fileLink, {
                responseType: "arraybuffer",
                timeout: 120000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            fs.writeFileSync(filePath, Buffer.from(res.data));
            console.log("[FILE2LINK] downloaded:", res.data.length, "bytes");
        } catch (e) {
            try { fs.unlinkSync(filePath); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download file</b>\n\n<code>${escHtml(e.message.slice(0, 150))}</code>`);
        }

        // ─── Update loading ───
        await safeEdit(bot, chatId, loading.message_id,
            `<b>✦ Uploading ke server...</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName.slice(0, 40))}</code>\n` +
            `▸ Size: <code>${formatSize(fileSize)}</code>\n` +
            `▸ Status: Uploading...\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mohon tunggu...</i>`);

        // ─── Upload ───
        const result = await uploader.uploadToLink(filePath, fileName, {
            prefer: "catbox_only",
            isImage
        });

        if (!result.ok) {
            try { fs.unlinkSync(filePath); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal upload</b>\n\n` +
                `<code>${escHtml(result.error.slice(0, 200))}</code>\n\n` +
                `<i>Coba lagi beberapa saat ya~</i>`);
        }

        const fileType = uploader.detectType(fileName);
        const typeEmoji = {
            image: "📷", video: "🎬", audio: "🎵",
            document: "📄", other: "📁"
        }[fileType] || "📁";

        // ─── Delete loading ───
        try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

        // ─── Kirim hasil ───
        const sizeText = formatSize(fileSize);

        const resultText =
            `<b>✓ LINK BERHASIL DIBUAT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `${typeEmoji} <b>File</b>: <code>${escHtml(fileName.slice(0, 40))}</code>\n` +
            `✦ <b>Size</b>: <code>${sizeText}</code>\n` +
            `✦ <b>Host</b>: <code>${result.host}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>✦ Link:</b>\n` +
            `<code>${escHtml(result.url)}</code>`;

        const keyboard = [
            [{ text: "✦ Copy Link", copy_text: { text: result.url } }],
            [{ text: "✦ Buka Link", url: result.url }],
            [
                { text: "✦ Upload Lagi", callback_data: "menu_filetolink", style: "success" },
                { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
            ]
        ];

        await bot.sendMessage(chatId, resultText, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: keyboard }
        });

        // ─── Cleanup ───
        try { fs.unlinkSync(filePath); } catch {}

        // ─── Update state biar bisa upload lagi ───
        ctx.setState(userId, "file_to_link_wait", {});
    } catch (e) {
        console.log("[FILE2LINK WAIT ERR]", e.message);
        if (filePath) try { fs.unlinkSync(filePath); } catch {}
        try {
            await bot.sendMessage(msg.chat.id,
                `<b>✕ Error:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        } catch {}
    }
});

// ═══ CANCEL ═══
router.registerCallback("file_to_link_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(user.id);
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id,
            `<b>✕ File to Link dibatalkan.</b>\n\nKetik /menu buat balik ke menu.`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[FILE2LINK CANCEL ERR]", e.message); }
});

module.exports = {};
console.log("[FILE TO LINK] module loaded");