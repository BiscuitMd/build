const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const sharp = require("sharp");

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══════════════════════════════════════════
// FETCH & INLINE ASSETS
// ═══════════════════════════════════════════
async function fetchWithTimeout(url, timeout = 30000, responseType = "text") {
    return await axios.get(url, {
        timeout,
        responseType,
        maxContentLength: Infinity,
        maxBodyLength: Infinity,
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9"
        },
        validateStatus: s => s < 500
    });
}

function isAbsolute(url) {
    return /^https?:\/\//i.test(url);
}

function resolveUrl(base, rel) {
    try {
        return new URL(rel, base).href;
    } catch {
        return null;
    }
}

function getMimeType(url, fallback = "application/octet-stream") {
    const ext = (url.split(".").pop() || "").toLowerCase().split("?")[0].split("#")[0];
    const map = {
        css: "text/css",
        js: "application/javascript",
        mjs: "application/javascript",
        png: "image/png",
        jpg: "image/jpeg",
        jpeg: "image/jpeg",
        gif: "image/gif",
        svg: "image/svg+xml",
        webp: "image/webp",
        ico: "image/x-icon",
        woff: "font/woff",
        woff2: "font/woff2",
        ttf: "font/ttf",
        eot: "application/vnd.ms-fontobject",
        otf: "font/otf"
    };
    return map[ext] || fallback;
}

async function inlineAssets(html, baseUrl, onProgress = null) {
    const stats = {
        css: 0,
        js: 0,
        img: 0,
        font: 0,
        failed: []
    };

    // ═══ 1. INLINE <link rel="stylesheet"> ═══
    const linkRegex = /<link([^>]*?)rel=["']stylesheet["']([^>]*?)>/gi;
    const linkMatches = [...html.matchAll(linkRegex)];

    for (const m of linkMatches) {
        const tag = m[0];
        const hrefMatch = tag.match(/href=["']([^"']+)["']/i);
        if (!hrefMatch) continue;

        const cssUrl = resolveUrl(baseUrl, hrefMatch[1]);
        if (!cssUrl) continue;

        try {
            const res = await fetchWithTimeout(cssUrl, 20000, "text");
            if (res.status === 200 && typeof res.data === "string") {
                // Also inline url() di dalam CSS
                let cssContent = res.data;
                const urlRegex = /url\(["']?([^"')]+)["']?\)/g;
                const urlMatches = [...cssContent.matchAll(urlRegex)];

                for (const um of urlMatches) {
                    if (um[1].startsWith("data:")) continue;
                    const assetUrl = resolveUrl(cssUrl, um[1]);
                    if (!assetUrl) continue;
                    try {
                        const aRes = await fetchWithTimeout(assetUrl, 20000, "arraybuffer");
                        if (aRes.status === 200) {
                            const b64 = Buffer.from(aRes.data).toString("base64");
                            const mime = getMimeType(assetUrl);
                            cssContent = cssContent.replace(um[0], `url("data:${mime};base64,${b64}")`);
                            stats.font++;
                        }
                    } catch {}
                }

                html = html.replace(tag, `<style>\n${cssContent}\n</style>`);
                stats.css++;
                if (onProgress) onProgress(stats);
            }
        } catch (e) {
            stats.failed.push(cssUrl);
        }
    }

    // ═══ 2. INLINE <script src="..."> ═══
    const scriptRegex = /<script([^>]*?)src=["']([^"']+)["']([^>]*?)>\s*<\/script>/gi;
    const scriptMatches = [...html.matchAll(scriptRegex)];

    for (const m of scriptMatches) {
        const tag = m[0];
        const srcUrl = resolveUrl(baseUrl, m[2]);
        if (!srcUrl) continue;

        try {
            const res = await fetchWithTimeout(srcUrl, 30000, "text");
            if (res.status === 200 && typeof res.data === "string") {
                const attrs = (m[1] + " " + m[3]).trim();
                html = html.replace(tag, `<script ${attrs}>\n${res.data}\n</script>`);
                stats.js++;
                if (onProgress) onProgress(stats);
            }
        } catch (e) {
            stats.failed.push(srcUrl);
        }
    }

    // ═══ 3. INLINE <img src="..."> ═══
    const imgRegex = /<img([^>]*?)src=["']([^"']+)["']([^>]*?)>/gi;
    const imgMatches = [...html.matchAll(imgRegex)];

    for (const m of imgMatches) {
        const tag = m[0];
        const srcRaw = m[2];
        if (srcRaw.startsWith("data:")) continue;

        const imgUrl = resolveUrl(baseUrl, srcRaw);
        if (!imgUrl) continue;

        try {
            const res = await fetchWithTimeout(imgUrl, 20000, "arraybuffer");
            if (res.status === 200) {
                const b64 = Buffer.from(res.data).toString("base64");
                const mime = getMimeType(imgUrl, "image/png");
                const newTag = tag.replace(srcRaw, `data:${mime};base64,${b64}`);
                html = html.replace(tag, newTag);
                stats.img++;
                if (onProgress) onProgress(stats);
            }
        } catch (e) {
            stats.failed.push(imgUrl);
        }
    }

    // ═══ 4. INLINE background-image url(...) di style inline ═══
    const bgRegex = /url\(["']?([^"')]+)["']?\)/g;
    const bgMatches = [...html.matchAll(bgRegex)];

    for (const m of bgMatches) {
        if (m[1].startsWith("data:")) continue;
        const assetUrl = resolveUrl(baseUrl, m[1]);
        if (!assetUrl) continue;

        try {
            const res = await fetchWithTimeout(assetUrl, 20000, "arraybuffer");
            if (res.status === 200) {
                const b64 = Buffer.from(res.data).toString("base64");
                const mime = getMimeType(assetUrl, "image/png");
                html = html.replace(m[0], `url("data:${mime};base64,${b64}")`);
                stats.img++;
            }
        } catch {}
    }

    // ═══ 5. INJECT SOURCE COMMENT ═══
    const sourceComment = `<!-- Grabbed from: ${baseUrl} | At: ${new Date().toISOString()} | By: SpartaX Bot -->`;
    if (html.includes("</head>")) {
        html = html.replace("</head>", `\n${sourceComment}\n</head>`);
    } else if (html.includes("<head>")) {
        html = html.replace("<head>", `<head>\n${sourceComment}`);
    } else {
        html = sourceComment + "\n" + html;
    }

    return { html, stats };
}

// ═══════════════════════════════════════════
// GENERATE NOTIF CARD (Sharp)
// ═══════════════════════════════════════════
async function generateGrabCard(data) {
    try {
        const W = 900;
        const H = 500;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0c4a6e"/>
      <stop offset="50%" stop-color="#0284c7"/>
      <stop offset="100%" stop-color="#0c4a6e"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#fef3c7"/>
      <stop offset="50%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  <rect x="10" y="10" width="${W-20}" height="${H-20}" rx="20" fill="none" stroke="url(#goldGrad)" stroke-width="3"/>

  <text x="${W/2}" y="65" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="36" fill="url(#goldGrad)" font-weight="900">𖡛 GRAB HTML 𖡛</text>
  <line x1="100" y1="85" x2="${W-100}" y2="85" stroke="url(#goldGrad)" stroke-width="2"/>

  <rect x="${W/2 - 200}" y="110" width="400" height="70" rx="35" fill="#22c55e" stroke="#ffffff" stroke-width="3"/>
  <text x="${W/2}" y="157" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="32" fill="#ffffff" font-weight="900">✦ SUCCESS ✦</text>

  <text x="80" y="240" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">User</text>
  <text x="220" y="240" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.userName)}</text>

  <text x="80" y="280" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">URL</text>
  <text x="220" y="280" font-family="Courier New, monospace" font-size="16" fill="#fbbf24" font-weight="700">${esc(data.url.slice(0, 55))}</text>

  <text x="80" y="320" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">File</text>
  <text x="220" y="320" font-family="Courier New, monospace" font-size="18" fill="#ffffff" font-weight="700">${esc(data.fileName)}</text>

  <text x="80" y="360" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Size</text>
  <text x="220" y="360" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${data.sizeKB} KB</text>

  <text x="80" y="400" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Assets</text>
  <text x="220" y="400" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">CSS: ${data.cssCount} • JS: ${data.jsCount} • IMG: ${data.imgCount}</text>

  <line x1="100" y1="440" x2="${W-100}" y2="440" stroke="url(#goldGrad)" stroke-width="2"/>
  <text x="${W/2}" y="475" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="18" fill="#94a3b8">${esc(cfg.OWNER_USERNAME || "@biscuitMD")} • SpartaX Bot</text>
</svg>`.trim();

        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch (e) {
        console.log("[GRAB CARD ERR]", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU GRAB HTML
// ═══════════════════════════════════════════
router.registerCallback("tool_grabhtml", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);

        // ⚡ PREMIUM ONLY
        if (!u.premium) {
            return bot.answerCallbackQuery(q.id, { text: "❌ Premium only!", show_alert: true }).catch(() => {});
            /* Juga kirim pesan */
        }

        const caption =
            `<b>𖡛 GRAB HTML</b> <code>PREMIUM</code>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Ambil code HTML dari URL\n` +
            `▸ Auto inline: CSS, JS, IMG, Font\n` +
            `▸ Output: File <code>.html</code> standalone\n` +
            `▸ Bisa dibuka offline di browser\n` +
            `▸ <b>Premium Only</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Format URL:</b>\n` +
            `<code>https://domain.com/dashboard.html</code>\n` +
            `<code>https://domain.com/page</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim URL sekarang:</i>`;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "grabhtml_await_url", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "grabhtml_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[GRAB MENU ERR]", e.message); }
});

// ═══ TERIMA URL ═══
router.registerMessage("grabhtml_await_url", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        if (!msg.text) return;

        const url = msg.text.trim();
        if (!/^https?:\/\//i.test(url)) {
            return bot.sendMessage(chatId, `<b>✕ URL harus mulai dengan http:// atau https://</b>`, { parse_mode: "HTML" });
        }

        // ⚡ CEK PREMIUM LAGI (double check)
        const u = ctx.db.getUser(userId);
        if (!u.premium) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId,
                `<b>✕ Fitur ini <u>Premium Only</u></b>\n\n` +
                `<i>Beli premium dulu buat pake fitur ini.</i>`,
                { parse_mode: "HTML",
                  reply_markup: { inline_keyboard: [[{ text: "▸ Buy Premium", callback_data: "menu_buypremium", style: "success" }]] } });
        }

        ctx.clearState(userId);

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 GRAB HTML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ URL: <code>${escHtml(url.slice(0, 60))}</code>\n` +
            `▸ Status: <i>Fetching HTML...</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        // ═══ FETCH HTML ═══
        let htmlContent = "";
        try {
            const res = await fetchWithTimeout(url, 30000, "text");
            if (res.status !== 200) {
                return safeEdit(bot, chatId, loading.message_id,
                    `<b>✕ HTTP ${res.status}</b>\n\nURL ga bisa diakses.`,
                    { parse_mode: "HTML" });
            }
            htmlContent = res.data;
        } catch (e) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal fetch URL</b>\n\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        }

        if (!htmlContent || htmlContent.length < 50) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ HTML kosong / invalid.</b>`,
                { parse_mode: "HTML" });
        }

        // ═══ INLINE ASSETS ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 GRAB HTML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ URL: <code>${escHtml(url.slice(0, 60))}</code>\n` +
            `▸ Status: <i>Inlining assets...</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        let inlined;
        try {
            inlined = await inlineAssets(htmlContent, url, async (stats) => {
                try {
                    await safeEdit(bot, chatId, loading.message_id,
                        `<b>𖡛 GRAB HTML</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `▸ URL: <code>${escHtml(url.slice(0, 50))}</code>\n` +
                        `▸ Status: <i>Inlining assets...</i>\n` +
                        `▸ CSS: ${stats.css} | JS: ${stats.js} | IMG: ${stats.img} | Font: ${stats.font}\n` +
                        `━━━━━━━━━━━━━━━━━━━━`,
                        { parse_mode: "HTML" });
                } catch {}
            });
        } catch (e) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal inline assets</b>\n\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        }

        // ═══ SIMPAN FILE ═══
        let fileName = "grabbed.html";
        try {
            const urlObj = new URL(url);
            const lastPart = urlObj.pathname.split("/").filter(Boolean).pop() || "index";
            const cleanName = lastPart.replace(/[^a-zA-Z0-9._-]/g, "_");
            fileName = cleanName.endsWith(".html") ? cleanName : `${cleanName}.html`;
            if (!fileName || fileName === ".html") fileName = `${urlObj.hostname.replace(/[^a-zA-Z0-9.-]/g, "_")}.html`;
        } catch {
            fileName = "grabbed.html";
        }

        const filePath = path.join(TMP_DIR, `${Date.now()}_${fileName}`);
        fs.writeFileSync(filePath, inlined.html, "utf8");

        const stat = fs.statSync(filePath);
        const sizeKB = (stat.size / 1024).toFixed(2);

        // ═══ UPDATE FINAL ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>✓ GRAB HTML SUKSES</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName)}</code>\n` +
            `▸ Size: ${sizeKB} KB\n` +
            `▸ CSS inline: ${inlined.stats.css}\n` +
            `▸ JS inline: ${inlined.stats.js}\n` +
            `▸ Image inline: ${inlined.stats.img}\n` +
            `▸ Font inline: ${inlined.stats.font}\n` +
            (inlined.stats.failed.length > 0 ? `▸ Failed: ${inlined.stats.failed.length}\n` : "") +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File siap buka offline.</i>`,
            { parse_mode: "HTML" });

        // ═══ KIRIM FILE ═══
        try {
            await bot.sendDocument(chatId, filePath, {
                caption:
                    `<b>𖡛 GRAB HTML RESULT</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Source: <code>${escHtml(url.slice(0, 60))}</code>\n` +
                    `▸ File: <code>${escHtml(fileName)}</code>\n` +
                    `▸ Size: ${sizeKB} KB\n` +
                    `▸ CSS: ${inlined.stats.css} | JS: ${inlined.stats.js} | IMG: ${inlined.stats.img}\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<i>Semua asset udah di-inline. Bisa dibuka offline.</i>`,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [
                    [{ text: "𖡛 Grab Lagi", callback_data: "tool_grabhtml", style: "success" }],
                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                ] }
            }, { filename: fileName, contentType: "text/html" });
        } catch (e) {
            console.log("[GRAB SEND ERR]", e.message);
            await safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal kirim file .html.</b>`,
                { parse_mode: "HTML" });
        }

        // ═══ NOTIF CHANNEL ═══
        try {
            const channelId = cfg.NOTIF_CHANNEL || cfg.ORDER?.ORDER_CHANNEL;
            if (channelId) {
                const cardBuf = await generateGrabCard({
                    userName: `${u.first_name || "User"}${u.last_name ? " " + u.last_name : ""}`,
                    userId: u.id,
                    url,
                    fileName,
                    sizeKB,
                    cssCount: inlined.stats.css,
                    jsCount: inlined.stats.js,
                    imgCount: inlined.stats.img
                });

                const caption =
                    `<b>𖡛 GRAB HTML SUCCESS</b>\n\n` +
                    `▸ User: ${escHtml(u.first_name || "User")}\n` +
                    `▸ ID: <code>${u.id}</code>\n` +
                    `▸ URL: <code>${escHtml(url.slice(0, 80))}</code>\n` +
                    `▸ File: <code>${escHtml(fileName)}</code>\n` +
                    `▸ Size: ${sizeKB} KB\n` +
                    `▸ Assets: CSS ${inlined.stats.css} • JS ${inlined.stats.js} • IMG ${inlined.stats.img}`;

                if (cardBuf) {
                    try {
                        await bot.sendPhoto(channelId, cardBuf, { caption, parse_mode: "HTML" });
                    } catch {
                        await bot.sendMessage(channelId, caption, { parse_mode: "HTML" });
                    }
                } else {
                    await bot.sendMessage(channelId, caption, { parse_mode: "HTML" });
                }
            }
        } catch (e) {
            console.log("[GRAB NOTIF ERR]", e.message);
        }

        // ═══ CLEANUP ═══
        try { fs.unlinkSync(filePath); } catch {}
    } catch (e) {
        console.log("[GRAB URL ERR]", e.message);
    }
});

// ═══ CANCEL ═══
router.registerCallback("grabhtml_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[GRAB CANCEL ERR]", e.message); }
});

module.exports = {};
console.log("[TOOL GRAB HTML] module loaded — PREMIUM ONLY");