const path = require("path");

const handlers = {};

// ═══════════════════════════════════════════
// SAFE REQUIRE
// ═══════════════════════════════════════════
const LOADED = [];
const SKIPPED = [];

function safeRequire(p) {
    const name = path.basename(p);
    try {
        require(p);
        LOADED.push(name);
        return true;
    } catch (e) {
        SKIPPED.push({ file: name, error: e.message.split("\n")[0].slice(0, 150) });
        console.log(`[SKIP REQUIRE] ${name} → ${e.message.split("\n")[0].slice(0, 120)}`);
        return false;
    }
}

// ═══════════════════════════════════════════
// REGISTER
// ═══════════════════════════════════════════
function registerCallback(prefix, fn) {
    if (handlers[prefix]) {
        console.log("[ROUTER] DUPLIKAT callback:", prefix, "— overwriting");
    }
    handlers[prefix] = fn;
}

function registerMessage(state, fn) {
    if (handlers["msg:" + state]) {
        console.log("[ROUTER] DUPLIKAT state:", state, "— overwriting");
    }
    handlers["msg:" + state] = fn;
}

// ═══════════════════════════════════════════
// WRAP & EXECUTE
// ═══════════════════════════════════════════
async function wrapAndExecute(handler, bot, q, data, user, ctx) {
    const originalSendMessage = bot.sendMessage.bind(bot);
    const originalSendPhoto = bot.sendPhoto.bind(bot);
    const originalSendDocument = bot.sendDocument.bind(bot);
    const originalEditMessageText = bot.editMessageText.bind(bot);
    const originalEditMessageCaption = bot.editMessageCaption.bind(bot);
    const originalEditMessageMedia = bot.editMessageMedia.bind(bot);
    const originalEditMessageReplyMarkup = bot.editMessageReplyMarkup.bind(bot);
    const originalAnswerCallbackQuery = bot.answerCallbackQuery.bind(bot);
    const originalDeleteMessage = bot.deleteMessage.bind(bot);

    const chatId = q.message.chat.id;
    const msgId = q.message.message_id;
    const hasPhoto = !!q.message.photo;
    const hasVideo = !!q.message.video;
    const hasDocument = !!q.message.document;

    let answered = false;
    bot.answerCallbackQuery = async (...args) => {
        if (answered) {
            console.log("[WRAP] answerCallbackQuery blocked (already answered)");
            return;
        }
        answered = true;
        try {
            return await originalAnswerCallbackQuery(...args);
        } catch (e) {
            const m = e.message || "";
            if (m.includes("query is too old") || m.includes("QUERY_ID_INVALID")) return;
            if (m.includes("message is not modified")) return;
            return;
        }
    };

    bot.sendMessage = async (targetChatId, text, options = {}) => {
        if (String(targetChatId) === String(chatId) && msgId) {
            try {
                return await originalEditMessageText(text, {
                    chat_id: chatId,
                    message_id: msgId,
                    parse_mode: options.parse_mode || "HTML",
                    ...(options.reply_markup ? { reply_markup: options.reply_markup } : {}),
                    ...(options.disable_web_page_preview ? { disable_web_page_preview: options.disable_web_page_preview } : {})
                });
            } catch (e) {
                const m = e.message || "";
                if (m.includes("message is not modified")) return { ok: true };

                if (m.includes("there is no text in the message to edit") && (hasPhoto || hasVideo || hasDocument)) {
                    try {
                        return await originalEditMessageCaption(text, {
                            chat_id: chatId,
                            message_id: msgId,
                            parse_mode: options.parse_mode || "HTML",
                            ...(options.reply_markup ? { reply_markup: options.reply_markup } : {})
                        });
                    } catch (e2) {
                        const m2 = e2.message || "";
                        if (m2.includes("message is not modified")) return { ok: true };
                    }
                }

                if (m.includes("message to edit not found") || m.includes("MESSAGE_ID_INVALID")) {
                    return originalSendMessage(targetChatId, text, options);
                }
                return originalSendMessage(targetChatId, text, options);
            }
        }
        return originalSendMessage(targetChatId, text, options);
    };

    bot.sendPhoto = async (targetChatId, photo, options = {}) => {
        if (String(targetChatId) === String(chatId) && msgId) {
            const caption = options.caption || "";
            const replyMarkup = options.reply_markup || {};

            if (hasPhoto) {
                try {
                    return await originalEditMessageCaption(caption, {
                        chat_id: chatId,
                        message_id: msgId,
                        parse_mode: options.parse_mode || "HTML",
                        reply_markup: replyMarkup
                    });
                } catch (e) {
                    const m = e.message || "";
                    if (m.includes("message is not modified")) return { ok: true };
                    try {
                        return await originalEditMessageReplyMarkup(replyMarkup, {
                            chat_id: chatId,
                            message_id: msgId
                        });
                    } catch (e2) {
                        const m2 = e2.message || "";
                        if (m2.includes("message is not modified")) return { ok: true };
                    }
                }
            } else {
                try {
                    return await originalEditMessageMedia({
                        type: "photo",
                        media: photo,
                        caption: caption,
                        parse_mode: options.parse_mode || "HTML"
                    }, {
                        chat_id: chatId,
                        message_id: msgId,
                        reply_markup: replyMarkup
                    });
                } catch (e) {
                    const m = e.message || "";
                    if (m.includes("message is not modified")) return { ok: true };
                }
            }
            return originalSendPhoto(targetChatId, photo, options);
        }
        return originalSendPhoto(targetChatId, photo, options);
    };

    bot.editMessageText = async (text, options = {}) => {
        try {
            return await originalEditMessageText(text, options);
        } catch (e) {
            const m = e.message || "";
            if (m.includes("message is not modified")) return { ok: true };

            if (m.includes("there is no text in the message to edit")) {
                try {
                    return await originalEditMessageCaption(text, {
                        chat_id: options.chat_id,
                        message_id: options.message_id,
                        parse_mode: options.parse_mode || "HTML",
                        ...(options.reply_markup ? { reply_markup: options.reply_markup } : {})
                    });
                } catch (e2) {
                    const m2 = e2.message || "";
                    if (m2.includes("message is not modified")) return { ok: true };
                }
            }

            return originalSendMessage(options.chat_id || chatId, text, {
                parse_mode: options.parse_mode || "HTML",
                ...(options.reply_markup ? { reply_markup: options.reply_markup } : {})
            });
        }
    };

    bot.editMessageCaption = async (caption, options = {}) => {
        try {
            return await originalEditMessageCaption(caption, options);
        } catch (e) {
            const m = e.message || "";
            if (m.includes("message is not modified")) return { ok: true };
            return null;
        }
    };

    bot.deleteMessage = async (targetChatId, targetMsgId, options = {}) => {
        try {
            return await originalDeleteMessage(targetChatId, targetMsgId, options);
        } catch (e) {
            const m = e.message || "";
            if (m.includes("message to delete not found") || m.includes("MESSAGE_ID_INVALID")) return null;
            return null;
        }
    };

    try {
        return await handler(bot, q, data, user, ctx);
    } catch (err) {
        console.log("[CB WRAPPED ERR]", err.message);
        throw err;
    } finally {
        bot.sendMessage = originalSendMessage;
        bot.sendPhoto = originalSendPhoto;
        bot.sendDocument = originalSendDocument;
        bot.editMessageText = originalEditMessageText;
        bot.editMessageCaption = originalEditMessageCaption;
        bot.editMessageMedia = originalEditMessageMedia;
        bot.editMessageReplyMarkup = originalEditMessageReplyMarkup;
        bot.answerCallbackQuery = originalAnswerCallbackQuery;
        bot.deleteMessage = originalDeleteMessage;
    }
}

// ═══════════════════════════════════════════
// ROUTE CALLBACK QUERY
// ═══════════════════════════════════════════
async function routeCallback(bot, q, data, user, ctx) {
    if (!q || !q.from) {
        console.log("[ROUTER] invalid callback query");
        try { await bot.answerCallbackQuery(q?.id || ""); } catch {}
        return;
    }

    if (!q.message) {
        q.message = {
            chat: { id: q.from.id, type: "private" },
            message_id: 0
        };
    }

    if (!ctx || !ctx.db) {
        console.log("[ROUTER] ctx.db MISSING!");
        try {
            await bot.answerCallbackQuery(q.id, { text: "Internal error: ctx.db missing", show_alert: true });
        } catch {}
        return;
    }

    if (typeof data !== "string") {
        console.log("[ROUTER] invalid data type:", typeof data);
        try {
            await bot.answerCallbackQuery(q.id, { text: "Invalid callback", show_alert: true });
        } catch {}
        return;
    }

    const chatId = q.message.chat?.id;
    if (!chatId) {
        console.log("[ROUTER] no chatId in q.message");
        try {
            await bot.answerCallbackQuery(q.id, { text: "Chat context hilang", show_alert: true });
        } catch {}
        return;
    }

    // ANSWER SEKALI DI SINI — SPINNER ILANG
    bot.answerCallbackQuery(q.id).catch(() => {});

    // CARI HANDLER
    const keys = Object.keys(handlers)
        .filter(k => !k.startsWith("msg:"))
        .sort((a, b) => b.length - a.length);

    let handlerKey = null;
    for (const key of keys) {
        if (data === key || data.startsWith(key + ":")) {
            handlerKey = key;
            break;
        }
    }

    if (!handlerKey) {
        console.log("[ROUTER] no handler for callback:", data);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Handler tidak ditemukan: " + data,
                show_alert: true
            });
        } catch {}
        return;
    }

    const isNavigation = /^(menu_|check_join|queue_refresh|queue_cancel|copy_username|copy_password)/.test(data);
    const activityUser = q.from;
    const activityFeature = String(data).split(":")[0].replace(/[_-]+/g, " ").toUpperCase();
    let activityNotify = null;
    if (!isNavigation) {
        try { activityNotify = require("./notify"); } catch {}
        if (activityNotify?.notifyFeature) {
            activityNotify.notifyFeature(bot, activityUser, activityFeature, "pending", {
                fields: [{ label: "Callback", value: data }],
                footer: "Aksi diterima dan sedang diproses."
            }).catch(e => console.log("[ACTIVITY NOTIFY PENDING]", e.message));
        }
    }

    try {
        console.log("[ROUTER] → callback:", data, "→ handler:", handlerKey);

        const SKIP_DELETE = [
            "menu_back", "check_join", "redeem_claim",
            "copy_username", "copy_password", "menu_close",
            "syntax_fix", "scriptstore_cancel",
            "panel_create", "panel_egg", "panel_pick_egg",
            "panel_create_type", "addrole_srv", "addrole_do2",
            "addrole_back_srv", "buildpubspec_build", "buildyml_build",
            "w2a_build", "w2a_cancel",
            "menu_buildfix",
            "order_acc",
            "order_rej"
        ];

        const SKIP_DELETE_PREFIX = [
            "addrole_", "panel_setcfg", "panel_setrole",
            "guard_", "tool_hd_level", "textstyler_",
            "gategroup_check", "copy_",
            "panel_egg", "panel_create", "cadp_",
            "buildpubspec_", "buildyml_", "panelpro_",
            "menu_", "tool_", "dev_", "prem_",
            "music_", "scriptstore_", "ai_", "w2a_",
            "renamebase_", "renameapi_", "syntax_", "deploy_",
            "ubot_menu_", "userbot_", "setcfg_", "createpanel_",
            "cp_", "order_",
            "buildfix_",
            "encrypt_",
            "grabhtml_",
            "htmltojs_",
            "jstohtml_",
            "renamebaileys_",
            "renamefunc_",
            "payment_",
            "owner_",           // ⚡ TAMBAHAN: buat login user session
            "pb_",              // ⚡ TAMBAHAN: prompt builder
            "prompt_",          // ⚡ TAMBAHAN: prompt builder
            "queue_"            // ⚡ TAMBAHAN: queue refresh/cancel
        ];

        const shouldDelete = !SKIP_DELETE.includes(data) &&
                             !SKIP_DELETE_PREFIX.some(p => data.startsWith(p));

        if (shouldDelete && q.message.message_id) {
            try { await bot.deleteMessage(chatId, q.message.message_id); } catch {}
        }

        if (q.message.message_id && typeof wrapAndExecute === "function") {
            await wrapAndExecute(handlers[handlerKey], bot, q, data, user, ctx);
        } else {
            await handlers[handlerKey](bot, q, data, user, ctx);
        }
        if (!isNavigation && activityNotify?.notifyFeature) {
            activityNotify.notifyFeature(bot, activityUser, activityFeature, "success", {
                fields: [{ label: "Callback", value: data }, { label: "Handler", value: handlerKey }],
                footer: "Handler selesai tanpa melempar error."
            }).catch(e => console.log("[ACTIVITY NOTIFY SUCCESS]", e.message));
        }
    } catch (e) {
        if (!isNavigation && activityNotify?.notifyFeature) {
            activityNotify.notifyFeature(bot, activityUser, activityFeature, "failed", {
                fields: [{ label: "Callback", value: data }, { label: "Error", value: String(e.message || e).slice(0, 250) }],
                footer: "Handler melempar error."
            }).catch(err => console.log("[ACTIVITY NOTIFY FAILED]", err.message));
        }
        console.log("[CB ERR]", handlerKey, e.message);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Error: " + e.message.slice(0, 100),
                show_alert: true
            });
        } catch {}
    }
}

// ═══════════════════════════════════════════
// ROUTE MESSAGE
// ═══════════════════════════════════════════
async function routeMessage(bot, msg, state, ctx) {
    if (!msg || !msg.from || !msg.chat) {
        console.log("[ROUTER] invalid message");
        return;
    }

    if (!ctx || !ctx.db) {
        console.log("[ROUTER] ctx.db MISSING (message)");
        return;
    }

    if (!state || !state.state) {
        console.log("[ROUTER] invalid state");
        return;
    }

    if (msg.text && msg.text.startsWith("/")) {
        console.log("[ROUTER] skip command (JANGAN clear state):", state.state);
        return;
    }

    const key = "msg:" + state.state;
    console.log("[ROUTER] → message state:", state.state);

    if (!handlers[key]) {
        console.log("[ROUTER] no handler for state:", state.state);
        if (ctx.clearState) ctx.clearState(String(msg.from.id));
        return;
    }

    try {
        return await handlers[key](bot, msg, state, ctx);
    } catch (e) {
        console.log("[MSG ERR]", key, e.message);
        return bot.sendMessage(msg.chat.id,
            "Error: " + e.message.slice(0, 200),
            { parse_mode: "HTML" }).catch(() => {});
    }
}

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports = routeCallback;
module.exports.message = routeMessage;
module.exports.registerCallback = registerCallback;
module.exports.registerMessage = registerMessage;
module.exports.handlers = handlers;
module.exports.loaded = LOADED;
module.exports.skipped = SKIPPED;
module.exports.safeRequire = safeRequire;

// ═══════════════════════════════════════════
// LOAD SEMUA MODUL
// ═══════════════════════════════════════════
console.log("[ROUTER] ═══════════════════════════════════");
console.log("[ROUTER] Loading modules...");
console.log("[ROUTER] ═══════════════════════════════════");

safeRequire(path.join(__dirname, "menu.js"));
safeRequire(path.join(__dirname, "bugtest.js"));
safeRequire(path.join(__dirname, "sender.js"));
safeRequire(path.join(__dirname, "payment.js"));
safeRequire(path.join(__dirname, "report.js"));
safeRequire(path.join(__dirname, "chatdev.js"));
safeRequire(path.join(__dirname, "developer.js"));
safeRequire(path.join(__dirname, "premium.js"));
safeRequire(path.join(__dirname, "syntax.js"));
safeRequire(path.join(__dirname, "deploy.js"));
safeRequire(path.join(__dirname, "tools.js"));
safeRequire(path.join(__dirname, "music.js"));
safeRequire(path.join(__dirname, "guard.js"));

safeRequire(path.join(__dirname, "panel.js"));
safeRequire(path.join(__dirname, "order.js"));
safeRequire(path.join(__dirname, "scriptstore.js"));
safeRequire(path.join(__dirname, "groupgate.js"));
safeRequire(path.join(__dirname, "textstyle.js"));
safeRequire(path.join(__dirname, "owner.js"));
safeRequire(path.join(__dirname, "userpremium.js"));

safeRequire(path.join(__dirname, "build-pubspec.js"));
safeRequire(path.join(__dirname, "build-yml.js"));
safeRequire(path.join(__dirname, "buildmenu.js"));
safeRequire(path.join(__dirname, "build-html-to-js.js"));
safeRequire(path.join(__dirname, "build-js-to-html.js"));
safeRequire(path.join(__dirname, "build-fix-error.js"));

safeRequire(path.join(__dirname, "rename-base.js"));
safeRequire(path.join(__dirname, "rename-api.js"));
safeRequire(path.join(__dirname, "rename-baileys.js"));
safeRequire(path.join(__dirname, "rename-func.js"));

safeRequire(path.join(__dirname, "github-builder.js"));
safeRequire(path.join(__dirname, "ai-engine.js"));
safeRequire(path.join(__dirname, "ai-chat.js"));
safeRequire(path.join(__dirname, "ai-code-editor.js"));
safeRequire(path.join(__dirname, "upload-to-link.js"));
safeRequire(path.join(__dirname, "file-to-link.js"));
safeRequire(path.join(__dirname, "web-to-app.js"));
safeRequire(path.join(__dirname, "build-prompt.js"));

safeRequire(path.join(__dirname, "tool-encrypt.js"));
safeRequire(path.join(__dirname, "tool-grabhtml.js"));

safeRequire(path.join(__dirname, "..", "handlers", "userbot", "index.js"));
safeRequire(path.join(__dirname, "..", "handlers", "userbot", "menu-callback.js"));
safeRequire(path.join(__dirname, "..", "handlers", "userbot", "module-loader.js"));

safeRequire(path.join(__dirname, "prompt-builder", "index.js"));

// ═══════════════════════════════════════════
// LOG SUMMARY
// ═══════════════════════════════════════════
console.log("[ROUTER] ═══════════════════════════════════");
console.log("[ROUTER] all modules loaded");
console.log("[ROUTER] total loaded :", LOADED.length);
console.log("[ROUTER] total skipped:", SKIPPED.length);
console.log("[ROUTER] total callbacks:", Object.keys(handlers).filter(k => !k.startsWith("msg:")).length);
console.log("[ROUTER] total messages:", Object.keys(handlers).filter(k => k.startsWith("msg:")).length);
console.log("[ROUTER] ═══════════════════════════════════");

if (SKIPPED.length > 0) {
    console.log("[ROUTER] ═══════════════════════════════════");
    console.log("[ROUTER] SKIPPED FILES (perlu di-fix):");
    for (const s of SKIPPED) {
        console.log(`[ROUTER]   ❌ ${s.file}`);
        console.log(`[ROUTER]      → ${s.error}`);
    }
    console.log("[ROUTER] ═══════════════════════════════════");
}