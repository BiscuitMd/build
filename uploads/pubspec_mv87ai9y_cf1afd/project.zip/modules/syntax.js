// ═══════════════════════════════════════════
// SYNTAX ERROR CHECKER + AUTO FIX
// v2 — FIXED: anti double-answer + non-blocking + smart fix
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const vm = require("vm");
const notify = require("./notify");
const fs = require("fs");
const path = require("path");

// ═══════════════════════════════════════════
// PENDING FIX — FILE BASED (NON-BLOCKING)
// ═══════════════════════════════════════════
const PENDING_FILE = path.join(__dirname, "..", "database", "pending_fix.json");
const PENDING_TMP = PENDING_FILE + ".tmp";

function readPending() {
    try {
        if (!fs.existsSync(PENDING_FILE)) return {};
        const raw = fs.readFileSync(PENDING_FILE, "utf8").trim();
        if (!raw) return {};
        return JSON.parse(raw);
    } catch { return {}; }
}

function writePendingSafe(data) {
    try {
        // Atomic write: tulis ke .tmp dulu, baru rename
        // rename() di POSIX itu atomic — ga ada race condition
        fs.writeFileSync(PENDING_TMP, JSON.stringify(data, null, 2), "utf8");
        fs.renameSync(PENDING_TMP, PENDING_FILE);
    } catch (e) {
        console.log("[PENDING WRITE ERR]", e.message);
    }
}

function setPending(userId, payload) {
    const data = readPending();
    data[String(userId)] = { ...payload, savedAt: Date.now() };
    writePendingSafe(data);
}

function getPending(userId) {
    const data = readPending();
    return data[String(userId)] || null;
}

function deletePending(userId) {
    const data = readPending();
    delete data[String(userId)];
    writePendingSafe(data);
}

// Auto-cleanup expired (30 menit)
setInterval(() => {
    try {
        const data = readPending();
        const now = Date.now();
        let changed = false;
        for (const uid in data) {
            if (now - (data[uid].savedAt || 0) > 30 * 60 * 1000) {
                delete data[uid];
                changed = true;
            }
        }
        if (changed) writePendingSafe(data);
    } catch {}
}, 5 * 60 * 1000);


// ═══════════════════════════════════════════
// HELPER
// ═══════════════════════════════════════════
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function safeUser(msg) {
    if (!msg || !msg.from) return "Unknown";
    return msg.from.first_name || msg.from.username || "User";
}

function safeUserId(msg) {
    if (!msg || !msg.from) return null;
    return msg.from.id || null;
}


// ═══════════════════════════════════════════
// STRIP STRINGS & COMMENTS
// ═══════════════════════════════════════════
function stripStringsAndComments(code) {
    let out = "";
    let i = 0;
    const n = code.length;
    while (i < n) {
        const c = code[i];

        if (c === "/" && code[i + 1] === "/") {
            while (i < n && code[i] !== "\n") i++;
            continue;
        }

        if (c === "/" && code[i + 1] === "*") {
            i += 2;
            while (i < n && !(code[i] === "*" && code[i + 1] === "/")) i++;
            i += 2;
            continue;
        }

        if (c === "'" || c === '"') {
            const q = c;
            i++;
            while (i < n && code[i] !== q) {
                if (code[i] === "\\") i++;
                i++;
            }
            i++;
            continue;
        }

        if (c === "`") {
            i++;
            while (i < n && code[i] !== "`") {
                if (code[i] === "\\") i++;
                i++;
            }
            i++;
            continue;
        }

        out += c;
        i++;
    }
    return out;
}


// ═══════════════════════════════════════════
// COUNT BALANCE
// ═══════════════════════════════════════════
function countBalance(code) {
    const stripped = stripStringsAndComments(code);
    let curly = 0, paren = 0, bracket = 0;
    for (const ch of stripped) {
        if (ch === "{") curly++;
        else if (ch === "}") curly--;
        else if (ch === "(") paren++;
        else if (ch === ")") paren--;
        else if (ch === "[") bracket++;
        else if (ch === "]") bracket--;
    }
    return { curly, paren, bracket };
}


// ═══════════════════════════════════════════
// CHECK TRY WITHOUT CATCH
// ═══════════════════════════════════════════
function checkTryWithoutCatch(code) {
    const errors = [];
    const lines = code.split("\n");

    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (!/\btry\s*\{/.test(line)) continue;

        const restLines = lines.slice(i);
        const restCode = restLines.join("\n");
        const tryIdx = restCode.indexOf("try");
        const braceStart = restCode.indexOf("{", tryIdx);
        if (braceStart === -1) continue;

        let depth = 0;
        let endIdx = -1;
        let inString = false;
        let stringChar = "";

        for (let j = braceStart; j < restCode.length; j++) {
            const ch = restCode[j];

            if (inString) {
                if (ch === "\\") { j++; continue; }
                if (ch === stringChar) inString = false;
                continue;
            }

            if (ch === "'" || ch === '"' || ch === "`") {
                inString = true;
                stringChar = ch;
                continue;
            }

            if (ch === "{") depth++;
            else if (ch === "}") {
                depth--;
                if (depth === 0) { endIdx = j; break; }
            }
        }

        if (endIdx === -1) continue;

        let after = restCode.slice(endIdx + 1);
        after = after.replace(/\/\/[^\n]*/g, "");
        after = after.replace(/\/\*[\s\S]*?\*\//g, "");
        after = after.trimStart();

        if (!/^catch\b/.test(after) && !/^finally\b/.test(after)) {
            errors.push({
                type: "TryWithoutCatch",
                message: `try { } di line ${i + 1} tidak punya catch/finally.`,
                line: i + 1
            });
        }
    }

    return errors;
}


// ═══════════════════════════════════════════
// CHECK SYNTAX — NO DUPLICATE
// ═══════════════════════════════════════════
function checkSyntax(code) {
    const errors = [];
    let vmError = null;

    try {
        new vm.Script(code, { filename: "user_input.js" });
    } catch (e) {
        vmError = e;
    }

    if (vmError) {
        errors.push({
            type: "SyntaxError",
            message: vmError.message,
            line: vmError.lineNumber || 0
        });
    }

    const braceBalance = countBalance(code);

    const msgLower = (vmError?.message || "").toLowerCase();
    const isBraceMsg = msgLower.includes("brace") ||
                       msgLower.includes("unexpected token }") ||
                       msgLower.includes("unexpected end of input");

    if (braceBalance.curly !== 0 && !isBraceMsg) {
        errors.push({
            type: "CurlyBrace",
            message: `Curly brace tidak seimbang (${braceBalance.curly > 0 ? "+" : ""}${braceBalance.curly}). Cek pembuka/penutup { }`
        });
    }
    if (braceBalance.paren !== 0) {
        errors.push({
            type: "Parenthesis",
            message: `Kurung tidak seimbang (${braceBalance.paren > 0 ? "+" : ""}${braceBalance.paren}). Cek ( )`
        });
    }
    if (braceBalance.bracket !== 0) {
        errors.push({
            type: "Bracket",
            message: `Square bracket tidak seimbang (${braceBalance.bracket > 0 ? "+" : ""}${braceBalance.bracket}). Cek [ ]`
        });
    }

    errors.push(...checkTryWithoutCatch(code));

    return errors;
}


// ═══════════════════════════════════════════
// AUTO FIX
// ═══════════════════════════════════════════
function autoFix(code) {
    let fixed = code;

    // Normalize quote & punctuation
    fixed = fixed.replace(/[""]/g, '"').replace(/['']/g, "'");
    fixed = fixed.replace(/；/g, ";").replace(/，/g, ",");
    fixed = fixed.replace(/（/g, "(").replace(/）/g, ")");
    fixed = fixed.replace(/｛/g, "{").replace(/｝/g, "}");
    fixed = fixed.replace(/：/g, ":");

    // Fix try tanpa catch
    fixed = fixTryWithoutCatch(fixed);

    // Fix brace / bracket kurang
    let bal = countBalance(fixed);
    if (bal.curly > 0) {
        fixed += "\n" + "}".repeat(bal.curly);
    }
    if (bal.bracket > 0) {
        fixed += "\n" + "]".repeat(bal.bracket);
    }
    if (bal.paren > 0) {
        fixed = addMissingParens(fixed, bal.paren);
    }

    return fixed;
}


function addMissingParens(code, count) {
    const lines = code.split("\n");
    let remaining = count;
    for (let i = lines.length - 1; i >= 0 && remaining > 0; i--) {
        const openCount = (lines[i].match(/\(/g) || []).length;
        const closeCount = (lines[i].match(/\)/g) || []).length;
        if (openCount > closeCount) {
            const need = Math.min(remaining, openCount - closeCount);
            lines[i] = lines[i] + ")".repeat(need);
            remaining -= need;
        }
    }
    if (remaining > 0) {
        lines[lines.length - 1] = (lines[lines.length - 1] || "") + ")".repeat(remaining);
    }
    return lines.join("\n");
}


function fixTryWithoutCatch(code) {
    const lines = code.split("\n");
    const out = [];
    let i = 0;

    while (i < lines.length) {
        const line = lines[i];
        out.push(line);

        if (!/\btry\s*\{/.test(line)) {
            i++;
            continue;
        }

        const restLines = lines.slice(i);
        const restCode = restLines.join("\n");
        const tryIdx = restCode.indexOf("try");
        const braceStart = restCode.indexOf("{", tryIdx);
        if (braceStart === -1) { i++; continue; }

        let depth = 0;
        let endIdx = -1;
        let inString = false;
        let stringChar = "";

        for (let j = braceStart; j < restCode.length; j++) {
            const ch = restCode[j];
            if (inString) {
                if (ch === "\\") { j++; continue; }
                if (ch === stringChar) inString = false;
                continue;
            }
            if (ch === "'" || ch === '"' || ch === "`") {
                inString = true;
                stringChar = ch;
                continue;
            }
            if (ch === "{") depth++;
            else if (ch === "}") {
                depth--;
                if (depth === 0) { endIdx = j; break; }
            }
        }

        if (endIdx === -1) { i++; continue; }

        let after = restCode.slice(endIdx + 1);
        after = after.replace(/\/\/[^\n]*/g, "");
        after = after.replace(/\/\*[\s\S]*?\*\//g, "");
        after = after.trimStart();

        if (/^catch\b/.test(after) || /^finally\b/.test(after)) {
            i++;
            continue;
        }

        const beforeEnd = restCode.slice(0, endIdx + 1);
        const linesBeforeEnd = beforeEnd.split("\n").length - 1;
        const endLineIdx = i + linesBeforeEnd;

        while (out.length > endLineIdx) out.pop();
        const endLine = lines[endLineIdx];
        out.push(endLine + " catch (e) { console.error(e); }");

        i = endLineIdx + 1;
    }

    return out.join("\n");
}


// ═══════════════════════════════════════════
// MENU: CEK SYNTAX ERROR
// ═══════════════════════════════════════════
router.registerCallback("menu_cekerror", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>𖡛 CEK SYNTAX ERROR</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<i>Kirim file .txt / .js atau ketik langsung.</i>\n\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━`;

        ctx.setState(user.id, "syntax_await", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
        });
    } catch (e) {
        console.log("[SYNTAX MENU ERR]", e.message);
    }
});


// ═══════════════════════════════════════════
// HANDLE INPUT
// ═══════════════════════════════════════════
router.registerMessage("syntax_await", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = safeUserId(msg);
        if (!userId) return;

        let loading = null;
        try {
            loading = await bot.sendMessage(chatId, `<b>𖡛 Menerima input...</b>`, { parse_mode: "HTML" });
        } catch (e) {
            console.log("[SYNTAX] loading send fail:", e.message);
        }

        let code = "";

        if (msg.document) {
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const axios = require("axios");
                const res = await axios.get(fileLink, { responseType: "text", timeout: 15000 });
                code = res.data;
            } catch (e) {
                ctx.clearState(userId);
                if (loading) {
                    try {
                        return bot.editMessageText(
                            `<b>✕ Gagal baca file:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                            { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                    } catch {}
                }
                return;
            }
        } else if (msg.text && msg.text.toLowerCase() !== "batal") {
            code = msg.text;
        } else {
            return;
        }

        if (code.length < 10) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    return bot.editMessageText(
                        `<b>✕ Code terlalu pendek.</b>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch {}
            }
            return;
        }

        const user = ctx.db.getUser(userId);
        if (user.credit < 1) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    return bot.editMessageText(
                        `<b>✕ Credit habis!</b>`,
                        { chat_id: chatId, message_id: loading.message_id, parse_mode: "HTML" });
                } catch {}
            }
            return;
        }

        ctx.db.saveUser(userId, { credit: user.credit - 1 });

        const errors = checkSyntax(code);
        const waktu = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
        const username = safeUser(msg);

        if (errors.length === 0) {
            ctx.clearState(userId);
            if (loading) {
                try {
                    await bot.editMessageText(
                        `<b>✓ SYNTAX VALID</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `𖡛 Baris: <code>${code.split("\n").length}</code>\n` +
                        `𖡛 Sisa Credit: <code>${ctx.db.getUser(userId).credit}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━`,
                        {
                            chat_id: chatId,
                            message_id: loading.message_id,
                            parse_mode: "HTML",
                            reply_markup: { inline_keyboard: [[{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]] }
                        });
                } catch {}
            }

            try {
                await notify.notifySuccess(bot, "SYNTAX VALID", [
                    { label: "User", value: username },
                    { label: "Baris", value: String(code.split("\n").length) },
                    { label: "Waktu", value: waktu }
                ]).catch(() => {});
            } catch {}
            return;
        }

        const errList = errors.map((e, i) =>
            `<b>${i + 1}. ${escHtml(e.type)}</b>\n` +
            `<code>${escHtml(e.message.slice(0, 150))}</code>` +
            (e.line ? `\n▸ Line: <b>${e.line}</b>` : "")
        ).join("\n\n");

        setPending(userId, { code, errors });
        ctx.clearState(userId);

        if (loading) {
            try {
                await bot.editMessageText(
                    `<b>✕ ${errors.length} ERROR DITEMUKAN</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `${errList}\n` +
                    `━━━━━━━━━━━━━━━━━━━━`,
                    {
                        chat_id: chatId,
                        message_id: loading.message_id,
                        parse_mode: "HTML",
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "𖡛 AUTO FIX", callback_data: "syntax_fix", style: "success" }],
                                [{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]
                            ]
                        }
                    });
            } catch {}
        }

        try {
            await notify.notifyFailed(bot, "SYNTAX ERROR", [
                { label: "User", value: username },
                { label: "Error", value: errors.length + " error" },
                { label: "Waktu", value: waktu }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[SYNTAX AWAIT ERR]", e.message);
        console.log("[SYNTAX AWAIT STACK]", e.stack);
    }
});


// ═══════════════════════════════════════════
// AUTO FIX — SMART MULTI-PASS
// ═══════════════════════════════════════════
router.registerCallback("syntax_fix", async (bot, q, data, user, ctx) => {
    try {
        const pend = getPending(user.id);

        if (!pend) {
            // Alert via answerCallbackQuery (langsung return)
            return bot.answerCallbackQuery(q.id, {
                text: "Sesi expired. Cek ulang syntax lu.",
                show_alert: true
            }).catch(() => {});
        }

        // ⚡ FIX: answerCallbackQuery DIHAPUS — router yang handle
        // Cukup jalanin proses fix

        let fixed = pend.code;
        let iteration = 0;
        const maxIter = 5;
        let finalErrors = checkSyntax(fixed);
        let lastErrorCount = finalErrors.length;

        while (iteration < maxIter && finalErrors.length > 0) {
            iteration++;
            const nextFixed = autoFix(fixed);
            const nextErrors = checkSyntax(nextFixed);

            // Kalau ga ada progress (error sama atau nambah) → stop
            if (nextErrors.length >= lastErrorCount && iteration > 1) {
                // Cek apakah ada perubahan teks
                if (nextFixed === fixed) break;
                // Kalau berubah tapi ga ngurangin error → tetap coba sekali lagi
                if (nextErrors.length === lastErrorCount && iteration >= 3) break;
            }

            fixed = nextFixed;
            finalErrors = nextErrors;
            lastErrorCount = nextErrors.length;

            if (finalErrors.length === 0) break;
        }

        const status = finalErrors.length === 0
            ? `<b>✓ FIXED — NO ERROR</b>`
            : `<b>⚠️ MASIH ${finalErrors.length} ERROR</b>\n\n<i>Auto fix ga bisa handle. Perlu manual.</i>`;

        const buf = Buffer.from(fixed, "utf8");

        try {
            await bot.sendDocument(q.message.chat.id, buf, {
                caption:
                    `${status}\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `𖡛 File: <code>fixed_function.js</code>\n` +
                    `𖡛 Size: ${buf.length} bytes\n` +
                    `𖡛 Baris: ${fixed.split("\n").length}\n` +
                    `𖡛 Iterasi: ${iteration}x\n` +
                    `━━━━━━━━━━━━━━━━━━━━`,
                parse_mode: "HTML",
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "𖡛 Cek Ulang", callback_data: "menu_cekerror", style: "success" }],
                        [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                    ]
                }
            }, { filename: "fixed_function.js", contentType: "text/javascript" });
        } catch (e) {
            console.log("[SYNTAX FIX] sendDocument FAIL:", e.message);
            try {
                const preview = escHtml(fixed.slice(0, 3500));
                await bot.sendMessage(q.message.chat.id,
                    `<b>${status}</b>\n\n<pre>${preview}</pre>`,
                    { parse_mode: "HTML" });
            } catch (e2) {
                console.log("[SYNTAX FIX] fallback fail:", e2.message);
            }
        }

        deletePending(user.id);

        try {
            await notify.notifySuccess(bot, "SYNTAX FIXED", [
                { label: "User", value: safeUser(q) },
                { label: "File", value: "fixed_function.js" },
                { label: "Iterasi", value: iteration + "x" }
            ]).catch(() => {});
        } catch {}
    } catch (e) {
        console.log("[SYNTAX FIX ERR]", e.message);
        console.log("[SYNTAX FIX STACK]", e.stack);

        try {
            await bot.sendMessage(q.message.chat.id,
                `<b>✕ Gagal:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" }).catch(() => {});
        } catch {}
    }
});


module.exports = { checkSyntax, autoFix };
console.log("[SYNTAX] module loaded (v2 fixed — non-blocking + smart multi-pass)");