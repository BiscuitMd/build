// ═══════════════════════════════════════════
// JS TO HTML — Konversi JS (HTML content) jadi HTML siap deploy
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ CREDIT CHECK ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══════════════════════════════════════════
// EXTRACT STRING FROM JS (backtick / quote)
// ═══════════════════════════════════════════
function extractTemplateString(jsCode, varName) {
    // Pattern: const/let/var VARNAME = `...` / "..." / '...'
    const patterns = [
        new RegExp(`(?:const|let|var|export\\s+const)\\s+${varName}\\s*=\\s*\`([\\s\\S]*?)\``, "m"),
        new RegExp(`(?:const|let|var|export\\s+const)\\s+${varName}\\s*=\\s*"((?:[^"\\\\]|\\\\.)*)"`, "m"),
        new RegExp(`(?:const|let|var|export\\s+const)\\s+${varName}\\s*=\\s*'((?:[^'\\\\]|\\\\.)*)'`, "m")
    ];

    for (const pattern of patterns) {
        const match = jsCode.match(pattern);
        if (match) {
            let content = match[1];
            // Unescape backtick template literal
            content = content
                .replace(/\\`/g, "`")
                .replace(/\\\$\{/g, "${")
                .replace(/\\\\/g, "\\");
            return content;
        }
    }
    return null;
}

// ═══════════════════════════════════════════
// EXTRACT OBJECT (META)
// ═══════════════════════════════════════════
function extractObject(jsCode, varName) {
    // Pattern: const META = { ... }
    const regex = new RegExp(`(?:const|let|var|export\\s+const)\\s+${varName}\\s*=\\s*\\{([\\s\\S]*?)\\};`, "m");
    const match = jsCode.match(regex);
    if (!match) return null;

    const body = match[1];
    const obj = {};

    // Extract fields
    const fieldRegex = /(\w+)\s*:\s*(?:`([\s\S]*?)`|"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)')/g;
    let m;
    while ((m = fieldRegex.exec(body)) !== null) {
        const key = m[1];
        let value = m[2] || m[3] || m[4] || "";
        value = value
            .replace(/\\`/g, "`")
            .replace(/\\\$\{/g, "${")
            .replace(/\\\\/g, "\\");
        obj[key] = value;
    }

    return obj;
}

// ═══════════════════════════════════════════
// PARSE JS FILE → struktur HTML
// ═══════════════════════════════════════════
function parseJsFile(jsCode) {
    const result = {
        htmlContent: "",
        cssContent: "",
        inlineScript: "",
        meta: {},
        bodyAttributes: "",
        htmlAttributes: "",
        detected: []
    };

    // Extract HTML_CONTENT / HTML / TEMPLATE
    const htmlVars = ["HTML_CONTENT", "HTML", "TEMPLATE", "BODY_CONTENT", "bodyHtml", "body"];
    for (const v of htmlVars) {
        const val = extractTemplateString(jsCode, v);
        if (val) {
            result.htmlContent = val;
            result.detected.push(`HTML from: ${v}`);
            break;
        }
    }

    // Extract CSS_CONTENT / CSS / STYLE
    const cssVars = ["CSS_CONTENT", "CSS", "STYLE", "STYLES", "styles"];
    for (const v of cssVars) {
        const val = extractTemplateString(jsCode, v);
        if (val) {
            result.cssContent = val;
            result.detected.push(`CSS from: ${v}`);
            break;
        }
    }

    // Extract INLINE_SCRIPT / SCRIPT / JS
    const scriptVars = ["INLINE_SCRIPT", "SCRIPT", "JS", "SCRIPT_CONTENT", "code"];
    for (const v of scriptVars) {
        const val = extractTemplateString(jsCode, v);
        if (val) {
            result.inlineScript = val;
            result.detected.push(`Script from: ${v}`);
            break;
        }
    }

    // Extract META
    const metaObj = extractObject(jsCode, "META");
    if (metaObj) {
        result.meta = metaObj;
        result.detected.push(`Meta from: META`);
    }

    // Kalo gak ada variabel, coba cari tag HTML langsung di code
    if (!result.htmlContent) {
        const tagMatch = jsCode.match(/`([\s\S]*?<[a-z][^>]*>[\s\S]*?)`/i);
        if (tagMatch) {
            result.htmlContent = tagMatch[1];
            result.detected.push("HTML from: raw tag");
        }
    }

    // Kalo gak ada CSS, cari <style> di html content
    if (!result.cssContent && result.htmlContent) {
        const styleMatch = result.htmlContent.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
        if (styleMatch) {
            result.cssContent = styleMatch[1];
            result.htmlContent = result.htmlContent.replace(/<style[^>]*>[\s\S]*?<\/style>/i, "");
            result.detected.push("CSS from: <style> tag");
        }
    }

    // Kalo gak ada script, cari <script> di html content
    if (!result.inlineScript && result.htmlContent) {
        const scriptMatch = result.htmlContent.match(/<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/i);
        if (scriptMatch) {
            result.inlineScript = scriptMatch[1];
            result.htmlContent = result.htmlContent.replace(/<script(?![^>]*src=)[^>]*>[\s\S]*?<\/script>/i, "");
            result.detected.push("Script from: <script> tag");
        }
    }

    return result;
}

// ═══════════════════════════════════════════
// CONVERT JS → HTML LENGKAP
// ═══════════════════════════════════════════
function convertJsToHtml(jsCode, fileName = "app.js") {
    const parsed = parseJsFile(jsCode);

    const title = parsed.meta.title || path.basename(fileName, ".js") || "App";
    const metaTags = parsed.meta.metaTags || `<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">`;
    const links = parsed.meta.links || "";

    // Build HTML
    const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
${metaTags}
${links}
<style>
${parsed.cssContent}
</style>
</head>
<body>
${parsed.htmlContent}
${parsed.inlineScript ? `<script>
${parsed.inlineScript}
</script>` : ""}
</body>
</html>`;

    return {
        html,
        stats: {
            title,
            htmlLength: parsed.htmlContent.length,
            cssLength: parsed.cssContent.length,
            scriptLength: parsed.inlineScript.length,
            metaCount: (metaTags.match(/<meta/g) || []).length,
            linkCount: (links.match(/<link/g) || []).length,
            detected: parsed.detected
        }
    };
}

// ═══════════════════════════════════════════
// MENU JS TO HTML
// ═══════════════════════════════════════════
router.registerCallback("menu_jstohtml", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < 1) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 JS TO HTML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Konversi file <b>.js</b> jadi <b>.html</b>\n` +
            `▸ Support: HTML_CONTENT, CSS_CONTENT, INLINE_SCRIPT, META\n` +
            `▸ Output: <b>HTML siap deploy</b>\n` +
            `▸ Biaya: <b>1 credit</b>\n` +
            `▸ Max File: <b>500 KB</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Cara kerja:</b>\n` +
            `1. Kirim file <code>.js</code>\n` +
            `2. Bot extract HTML + CSS + Script\n` +
            `3. Bot kirim file <code>.html</code> lengkap\n` +
            `4. Deploy langsung (drag ke browser / hosting)\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Format JS yang di-support:</b>\n` +
            `<code>export const HTML_CONTENT = \\\`...\\\`;</code>\n` +
            `<code>export const CSS_CONTENT = \\\`...\\\`;</code>\n` +
            `<code>export const INLINE_SCRIPT = \\\`...\\\`;</code>\n` +
            `<code>export const META = { title: \\\`...\\\` };</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file .js sekarang:</i>`;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "jstohtml_await_file", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "jstohtml_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[JS TO HTML MENU ERR]", e.message); }
});

// ═══ TERIMA FILE JS ═══
router.registerMessage("jstohtml_await_file", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        let jsContent = "";
        let fname = "app.js";

        // Support kirim file atau ketik langsung
        if (msg.document) {
            fname = msg.document.file_name || "app.js";
            if (!fname.toLowerCase().endsWith(".js") && !fname.toLowerCase().endsWith(".mjs")) {
                return bot.sendMessage(chatId, `<b>✕ File harus .js</b>`, { parse_mode: "HTML" });
            }
            if (msg.document.file_size > 500 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 500KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                jsContent = res.data;
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            jsContent = msg.text;
            fname = "input.js";
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .js</b>`, { parse_mode: "HTML" });
        }

        if (!jsContent || jsContent.length < 10) {
            return bot.sendMessage(chatId, `<b>✕ File JS kosong.</b>`, { parse_mode: "HTML" });
        }

        const c = checkAndDeductCredit(ctx, { id: userId }, 1);
        if (!c.ok) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ ${c.error}</b>`, { parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] } });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 JS TO HTML</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fname)}</code>\n` +
            `▸ Size: ${(jsContent.length / 1024).toFixed(2)} KB\n` +
            `▸ Status: <i>Parse JS...</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        // Konversi
        let converted;
        try {
            converted = convertJsToHtml(jsContent, fname);
        } catch (e) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal konversi:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        }

        if (!converted.html || converted.html.length < 50) {
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Hasil HTML kosong.</b>\n\n` +
                `<i>Cek file .js lu punya variabel:</i>\n` +
                `<code>HTML_CONTENT</code> / <code>CSS_CONTENT</code> / <code>INLINE_SCRIPT</code>`,
                { parse_mode: "HTML" });
        }

        // Tulis file HTML
        const baseName = path.basename(fname, path.extname(fname)).replace(/[^a-zA-Z0-9_]/g, "_") || "app";
        const htmlFileName = `${baseName}.html`;
        const htmlFilePath = path.join(TMP_DIR, `${Date.now()}_${htmlFileName}`);
        fs.writeFileSync(htmlFilePath, converted.html, "utf8");

        const detectedText = converted.stats.detected.map(d => `▸ <code>${escHtml(d)}</code>`).join("\n");

        await safeEdit(bot, chatId, loading.message_id,
            `<b>✓ KONVERSI BERHASIL</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Input: <code>${escHtml(fname)}</code>\n` +
            `▸ Output: <code>${escHtml(htmlFileName)}</code>\n` +
            `▸ Size: ${(converted.html.length / 1024).toFixed(2)} KB\n` +
            `▸ Credit sisa: ${c.credit}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Statistik:</b>\n` +
            `▸ Title: <code>${escHtml(converted.stats.title)}</code>\n` +
            `▸ HTML: ${(converted.stats.htmlLength / 1024).toFixed(2)} KB\n` +
            `▸ CSS: ${(converted.stats.cssLength / 1024).toFixed(2)} KB\n` +
            `▸ Script: ${(converted.stats.scriptLength / 1024).toFixed(2)} KB\n` +
            `▸ Meta: ${converted.stats.metaCount} tag\n` +
            `▸ Links: ${converted.stats.linkCount} stylesheet\n` +
            (detectedText ? `\n<b>Detected:</b>\n${detectedText}\n` : "") +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File .html siap deploy.</i>`,
            { parse_mode: "HTML" });

        // Kirim file HTML
        let sent = false;
        try {
            await bot.sendDocument(chatId, htmlFilePath, {
                caption:
                    `<b>𖡛 JS → HTML RESULT</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Output: <code>${escHtml(htmlFileName)}</code>\n` +
                    `▸ Size: ${(converted.html.length / 1024).toFixed(2)} KB\n` +
                    `▸ Credit sisa: ${c.credit}\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<b>Cara pakai:</b>\n` +
                    `1. Download file .html\n` +
                    `2. Buka langsung di browser\n` +
                    `3. Atau upload ke hosting\n` +
                    `4. Siap deploy! 🚀\n\n` +
                    `<i>Fungsi 100% sama seperti HTML asli.</i>`,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [
                    [{ text: "𖡛 Konversi Lagi", callback_data: "menu_jstohtml", style: "success" }],
                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                ] }
            }, { filename: htmlFileName, contentType: "text/html" });
            sent = true;
        } catch (e) {
            console.log("[JS TO HTML SEND ERR]", e.message);
        }

        // Cleanup
        try { fs.unlinkSync(htmlFilePath); } catch {}

        if (!sent) {
            await safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal kirim file .html.</b>`,
                { parse_mode: "HTML" });
        }

        ctx.clearState(userId);
    } catch (e) {
        console.log("[JS TO HTML FILE ERR]", e.message);
    }
});

// ═══ CANCEL ═══
router.registerCallback("jstohtml_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[JS TO HTML CANCEL ERR]", e.message); }
});

module.exports = { convertJsToHtml, parseJsFile };
console.log("[JS TO HTML] module loaded");