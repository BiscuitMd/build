// ═══════════════════════════════════════════
// PANEL API — Pterodactyl Application API
// v4 — FIXED: email validation + domain fallback
// Support: PANEL_ILLEGAL / PANEL_LEGAL / PANEL_ADP1 / PANEL_ADP2
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const axios = require("axios");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");

const PANEL_FILE = path.join(__dirname, "..", "database", "panel.json");

// ═══════════════════════════════════════════
// READ / WRITE PANEL.JSON
// ═══════════════════════════════════════════
function readPanelRaw() {
    try {
        return JSON.parse(fs.readFileSync(PANEL_FILE, "utf8"));
    } catch {
        return {};
    }
}

function writePanelRaw(d) {
    try {
        fs.writeFileSync(PANEL_FILE, JSON.stringify(d, null, 2), "utf8");
        return true;
    } catch (e) {
        console.log("[PANEL-API] write err:", e.message);
        return false;
    }
}

// ═══════════════════════════════════════════
// RESOLVE KEY — map scope ke section config
// ═══════════════════════════════════════════
function resolveKey(scope) {
    const s = String(scope || "").toLowerCase();
    const map = {
        plta: "PANEL_ILLEGAL",
        s1: "PANEL_ILLEGAL",
        server1: "PANEL_ILLEGAL",
        illegal: "PANEL_ILLEGAL",

        pltc: "PANEL_LEGAL",
        s2: "PANEL_LEGAL",
        server2: "PANEL_LEGAL",
        legal: "PANEL_LEGAL",

        adp1: "PANEL_ADP1",
        adp: "PANEL_ADP1",
        admin1: "PANEL_ADP1",

        adp2: "PANEL_ADP2",
        admin2: "PANEL_ADP2"
    };
    return map[s] || "PANEL_ILLEGAL";
}

// ═══════════════════════════════════════════
// VALIDATE DOMAIN — pastiin valid TLD
// ═══════════════════════════════════════════
function sanitizeDomain(rawDomain, rawUrl) {
    let domain = String(rawDomain || "").trim().toLowerCase();

    // Kalau domain kosong / gak ada titik / TLD .local → coba dari URL
    if (!domain || !domain.includes(".") || domain.endsWith(".local")) {
        try {
            if (rawUrl && rawUrl.startsWith("http")) {
                const u = new URL(rawUrl);
                domain = u.hostname.toLowerCase();
            }
        } catch {}
    }

    // Kalau masih invalid → fallback terakhir
    if (!domain || !domain.includes(".") || domain.endsWith(".local")) {
        domain = "biscuitmd.com";
    }

    // Strip www.
    domain = domain.replace(/^www\./, "");

    return domain;
}

// ═══════════════════════════════════════════
// GET PANEL CONFIG — dari section PANEL_*
// ═══════════════════════════════════════════
function getPanelConfig(scope) {
    const dyn = readPanelRaw().config || {};
    const key = resolveKey(scope);
    const keyLower = key.toLowerCase();
    const st = cfg[key] || {};
    const dy = dyn[keyLower] || {};

    const finalUrl = dy.url || st.URL || "";
    const finalDomain = sanitizeDomain(dy.domain || st.DOMAIN, finalUrl);

    return {
        URL: finalUrl,
        API_KEY: dy.apiKey || st.API_KEY || "",
        NEST_ID: parseInt(dy.nestId || st.NEST_ID || 1),
        DOMAIN: finalDomain,
        DEFAULT_LOCATION: parseInt(dy.location || st.DEFAULT_LOCATION || 1),
        DEFAULT_MEMORY: parseInt(dy.memory || st.DEFAULT_MEMORY || 1024),
        DEFAULT_DISK: parseInt(dy.disk || st.DEFAULT_DISK || 2048),
        DEFAULT_CPU: parseInt(dy.cpu || st.DEFAULT_CPU || 50),
        DEFAULT_DATABASES: parseInt(st.DEFAULT_DATABASES || 1),
        DEFAULT_BACKUPS: parseInt(st.DEFAULT_BACKUPS || 1),
        DEFAULT_ALLOCATIONS: parseInt(st.DEFAULT_ALLOCATIONS || 0),
        LABEL: st.LABEL || key,
        TYPE: st.TYPE || "unknown",
        GROUP_LINK: st.GROUP_LINK || "",
        _key: keyLower,
        _source: dy.url ? "panel.json" : "config.js"
    };
}

// ═══════════════════════════════════════════
// SAVE CONFIG TO PANEL.JSON
// ═══════════════════════════════════════════
function saveConfigToPanel(scope, field, value) {
    try {
        const d = readPanelRaw();
        d.config = d.config || {};
        const key = String(scope).toLowerCase();
        d.config[key] = d.config[key] || {};

        const map = {
            url: "url",
            apiKey: "apiKey",
            domain: "domain",
            nestId: "nestId",
            location: "location",
            memory: "memory",
            disk: "disk",
            cpu: "cpu"
        };
        const k = map[field] || field;
        d.config[key][k] = value;
        return writePanelRaw(d);
    } catch (e) {
        console.log("[PANEL-API] saveConfig err:", e.message);
        return false;
    }
}

// ═══════════════════════════════════════════
// BUILD HEADERS
// ═══════════════════════════════════════════
function buildHeaders(apiKey, isGet = false) {
    const h = {
        Authorization: `Bearer ${apiKey}`,
        Accept: "application/json",
        "User-Agent": "SpartaX-Bot/4.0"
    };
    if (!isGet) h["Content-Type"] = "application/json";
    return h;
}

// ═══════════════════════════════════════════
// VALIDATE API KEY
// ═══════════════════════════════════════════
function validateApiKey(apiKey, type = "application") {
    if (!apiKey) return { ok: false, error: "API Key kosong" };
    if (typeof apiKey !== "string") return { ok: false, error: "API Key harus string" };
    if (apiKey.includes("GANTI") || apiKey.includes("ISI_")) {
        return { ok: false, error: "API Key belum di-set (masih placeholder)" };
    }
    if (type === "application" && !apiKey.startsWith("ptla_")) {
        return { ok: false, error: "API Key Application harus mulai ptla_" };
    }
    if (type === "client" && !apiKey.startsWith("ptlc_")) {
        return { ok: false, error: "API Key Client harus mulai ptlc_" };
    }
    return { ok: true };
}

// ═══════════════════════════════════════════
// GENERATE EMAIL — FIXED anti error 422
// ═══════════════════════════════════════════
function generateEmail(username, domain) {
    // 1. Strip karakter aneh dari username
    let cleanUser = String(username || "")
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "")
        .slice(0, 30);

    // 2. Pastiin gak kosong
    if (!cleanUser || cleanUser.length < 3) {
        cleanUser = `user${Date.now().toString(36)}`;
    }

    // 3. Sanitize domain
    let cleanDomain = sanitizeDomain(domain, "");

    // 4. Gabung jadi email valid
    const email = `${cleanUser}@${cleanDomain}`;

    // 5. Validasi regex basic
    const emailRegex = /^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,}$/i;
    if (!emailRegex.test(email)) {
        // Fallback kalau masih invalid
        return `${cleanUser}@biscuitmd.com`;
    }

    return email;
}

// ═══════════════════════════════════════════
// GENERATE PASSWORD
// ═══════════════════════════════════════════
function generatePassword(len = 14) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%";
    let out = "";
    for (let i = 0; i < len; i++) {
        out += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return out;
}

// ═══════════════════════════════════════════
// GET USER BY EMAIL
// ═══════════════════════════════════════════
async function getUserByEmail(scope, email) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;
    if (!pc.URL) return { ok: false, error: "URL panel kosong" };

    try {
        const res = await axios.get(
            `${pc.URL}/api/application/users?filter[email]=${encodeURIComponent(email)}`,
            {
                headers: buildHeaders(pc.API_KEY, true),
                timeout: 30000,
                validateStatus: s => s < 500
            }
        );
        if (res.status === 200) {
            const list = res.data?.data || [];
            if (list.length > 0) return { ok: true, user: list[0], raw: res.data };
            return { ok: false, error: "User tidak ditemukan" };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// GET USER BY ID
// ═══════════════════════════════════════════
async function getUserById(scope, userId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(`${pc.URL}/api/application/users/${userId}`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 200) {
            return { ok: true, user: res.data?.attributes || res.data };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// CREATE USER
// ═══════════════════════════════════════════
async function createUser(scope, { email, username, firstName, lastName, password, rootAdmin = false }) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;
    if (!pc.URL) return { ok: false, error: "URL panel kosong" };

    // ⚡ FIX: sanitize sebelum kirim
    const cleanUser = String(username || "").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 30);
    let finalEmail = email;
    if (!finalEmail || !finalEmail.includes("@")) {
        finalEmail = generateEmail(cleanUser, pc.DOMAIN);
    }

    try {
        const res = await axios.post(`${pc.URL}/api/application/users`, {
            email: finalEmail,
            username: cleanUser,
            first_name: String(firstName || cleanUser).slice(0, 30),
            last_name: String(lastName || "User").slice(0, 30),
            password,
            root_admin: !!rootAdmin,
            language: "en"
        }, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });

        if (res.status === 200 || res.status === 201) {
            const attrs = res.data?.attributes || res.data?.data?.attributes || res.data;
            return { ok: true, user: { id: attrs.id, attributes: attrs }, raw: res.data };
        }

        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 250);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// UPDATE USER
// ═══════════════════════════════════════════
async function updateUser(scope, userId, patch) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.patch(`${pc.URL}/api/application/users/${userId}`, patch, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 200) return { ok: true, user: res.data?.attributes };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// DELETE USER
// ═══════════════════════════════════════════
async function deleteUser(scope, userId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.delete(`${pc.URL}/api/application/users/${userId}`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 204 || res.status === 200) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// LIST NODES
// ═══════════════════════════════════════════
async function listNodes(scope) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(`${pc.URL}/api/application/nodes`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 200) return { ok: true, nodes: res.data?.data || [] };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// GET ALLOCATIONS (port kosong)
// ═══════════════════════════════════════════
async function getAllocations(scope, nodeId = 1) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(
            `${pc.URL}/api/application/nodes/${nodeId}/allocations?per_page=100`,
            {
                headers: buildHeaders(pc.API_KEY, true),
                timeout: 30000,
                validateStatus: s => s < 500
            }
        );
        if (res.status === 200) {
            const list = res.data?.data || [];
            const free = list.filter(a => a.attributes && !a.attributes.assigned);
            if (free.length === 0) {
                return { ok: false, error: `Node ${nodeId}: tidak ada allocation kosong` };
            }
            return { ok: true, allocations: free, raw: res.data };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// LIST NESTS
// ═══════════════════════════════════════════
async function listNests(scope) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(`${pc.URL}/api/application/nests`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 200) return { ok: true, nests: res.data?.data || [] };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// LIST EGGS FROM NEST
// ═══════════════════════════════════════════
async function listEggs(scope, nestId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(`${pc.URL}/api/application/nests/${nestId}/eggs`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 200) return { ok: true, eggs: res.data?.data || [] };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// GET EGG DETAIL
// ═══════════════════════════════════════════
async function getEggDetail(scope, nestId, eggId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.get(
            `${pc.URL}/api/application/nests/${nestId}/eggs/${eggId}?include=variables`,
            {
                headers: buildHeaders(pc.API_KEY, true),
                timeout: 30000,
                validateStatus: s => s < 500
            }
        );
        if (res.status === 200) {
            const attrs = res.data?.attributes || {};
            return {
                ok: true,
                egg: attrs,
                variables: attrs.relationships?.variables?.data || []
            };
        }
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// CREATE SERVER
// ═══════════════════════════════════════════
async function createServer(scope, {
    name, userId, nestId, eggId,
    dockerImage, startup, environment = {},
    memory, disk, cpu, allocationId,
    databases = 0, backups = 0, allocations = 0,
    locationId = 1
}) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    if (!userId || !eggId || !dockerImage || !startup || !allocationId) {
        return {
            ok: false,
            error: `Field kurang: userId=${userId}, eggId=${eggId}, img=${!!dockerImage}, startup=${!!startup}, alloc=${allocationId}`
        };
    }

    try {
        const res = await axios.post(`${pc.URL}/api/application/servers`, {
            name: String(name).slice(0, 100),
            user: parseInt(userId),
            egg: parseInt(eggId),
            docker_image: dockerImage,
            startup,
            environment,
            limits: {
                memory: parseInt(memory) || 512,
                swap: 0,
                disk: parseInt(disk) || 1024,
                io: 500,
                cpu: parseInt(cpu) || 100
            },
            feature_limits: {
                databases: parseInt(databases) || 0,
                backups: parseInt(backups) || 0,
                allocations: parseInt(allocations) || 0
            },
            deploy: {
                locations: [parseInt(locationId)],
                dedicated_ip: false,
                port_range: []
            },
            start_on_completion: true,
            allocation: { default: parseInt(allocationId) }
        }, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 60000,
            validateStatus: s => s < 500
        });

        if (res.status === 200 || res.status === 201) {
            const attrs = res.data?.attributes || res.data?.data?.attributes || res.data;
            return { ok: true, server: { id: attrs.id, attributes: attrs }, raw: res.data };
        }

        const errMsg = res.data?.errors?.[0]?.detail || JSON.stringify(res.data).slice(0, 300);
        return { ok: false, error: `HTTP ${res.status}: ${errMsg}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// UPDATE STARTUP COMMAND
// ═══════════════════════════════════════════
async function updateStartup(scope, serverId, startup, dockerImage) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.patch(
            `${pc.URL}/api/application/servers/${serverId}/startup`,
            {
                startup,
                environment: {},
                egg: undefined,
                image: dockerImage,
                skip_scripts: false
            },
            { headers: buildHeaders(pc.API_KEY), timeout: 30000, validateStatus: s => s < 500 }
        );
        if (res.status === 200 || res.status === 204) return { ok: true };
        const errMsg = res.data?.errors?.[0]?.detail || `HTTP ${res.status}`;
        return { ok: false, error: errMsg };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// UPDATE VARIABLE SERVER
// ═══════════════════════════════════════════
async function updateServerVariable(scope, serverId, envName, value) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        // Cari variable ID dulu
        const listRes = await axios.get(
            `${pc.URL}/api/application/servers/${serverId}?include=variables`,
            { headers: buildHeaders(pc.API_KEY, true), timeout: 30000, validateStatus: s => s < 500 }
        );

        if (listRes.status !== 200) return { ok: false, error: `HTTP ${listRes.status}` };

        const vars = listRes.data?.attributes?.relationships?.variables?.data || [];
        let found = null;

        for (const vv of vars) {
            const va = vv.attributes || {};
            if (va.env_variable === envName) {
                found = va.id;
                break;
            }
        }

        if (!found) return { ok: false, error: `Variable ${envName} gak ditemukan` };

        const res = await axios.patch(
            `${pc.URL}/api/application/servers/${serverId}/variables/${found}`,
            { key: envName, value: String(value) },
            { headers: buildHeaders(pc.API_KEY), timeout: 30000, validateStatus: s => s < 500 }
        );

        if (res.status === 200 || res.status === 204) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        const errMsg = e.response?.data?.errors?.[0]?.detail || e.message;
        return { ok: false, error: errMsg };
    }
}

// ═══════════════════════════════════════════
// FIX SERVER JADI NODE.JS — panggil setelah create
// ═══════════════════════════════════════════
async function fixServerToNodeJS(scope, serverId, eggType = "node") {
    console.log(`[fixServerToNodeJS] server=${serverId} type=${eggType}`);

    const isPython = eggType === "python";
    const startup = isPython
        ? "python {{PY_FILE}}"
        : "node {{MAIN_FILE}}";
    const image = isPython
        ? "ghcr.io/parkervcp/yolks:python_3.11"
        : "ghcr.io/parkervcp/yolks:nodejs_20";

    // 1. Update startup & image
    const startupRes = await updateStartup(scope, serverId, startup, image);
    console.log(`[fixServerToNodeJS] startup: ${startupRes.ok ? "OK" : startupRes.error}`);

    // 2. Kosongin variable SPONGE_VERSION & SERVER_JARFILE
    const varsToEmpty = ["SPONGE_VERSION", "SERVER_JARFILE", "MINECRAFT_VERSION",
                          "BUNGEE_VERSION", "FORGE_VERSION", "JAVA_VERSION"];

    for (const varName of varsToEmpty) {
        const r = await updateServerVariable(scope, serverId, varName, "");
        console.log(`[fixServerToNodeJS] ${varName}: ${r.ok ? "OK" : r.error || "skip"}`);
    }

    return { ok: true };
}

// ═══════════════════════════════════════════
// SUSPEND / UNSUSPEND SERVER
// ═══════════════════════════════════════════
async function suspendServer(scope, serverId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.post(`${pc.URL}/api/application/servers/${serverId}/suspend`, {}, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 204 || res.status === 200) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

async function unsuspendServer(scope, serverId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.post(`${pc.URL}/api/application/servers/${serverId}/unsuspend`, {}, {
            headers: buildHeaders(pc.API_KEY),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 204 || res.status === 200) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// DELETE SERVER
// ═══════════════════════════════════════════
async function deleteServer(scope, serverId) {
    const pc = getPanelConfig(scope);
    const v = validateApiKey(pc.API_KEY, "application");
    if (!v.ok) return v;

    try {
        const res = await axios.delete(`${pc.URL}/api/application/servers/${serverId}?force=true`, {
            headers: buildHeaders(pc.API_KEY, true),
            timeout: 30000,
            validateStatus: s => s < 500
        });
        if (res.status === 204 || res.status === 200) return { ok: true };
        return { ok: false, error: `HTTP ${res.status}` };
    } catch (e) {
        return { ok: false, error: e.message };
    }
}

// ═══════════════════════════════════════════
// EXPORT
// ═══════════════════════════════════════════
module.exports = {
    getPanelConfig,
    saveConfigToPanel,
    validateApiKey,
    resolveKey,
    sanitizeDomain,
    listUsers: null,
    getUserByEmail,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    listNodes,
    getAllocations,
    listNests,
    listEggs,
    getEggDetail,
    createServer,
    suspendServer,
    unsuspendServer,
    deleteServer,
    updateStartup,            // ← TAMBAH
    updateServerVariable,     // ← TAMBAH
    fixServerToNodeJS,        // ← TAMBAH
    generateEmail,
    generatePassword
};

console.log("[PANEL API] v4 FIXED loaded — email validation + domain fallback");