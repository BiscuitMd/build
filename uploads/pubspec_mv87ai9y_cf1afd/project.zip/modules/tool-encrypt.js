const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const crypto = require("crypto");
const sharp = require("sharp");

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ CREDIT CHECK ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══════════════════════════════════════════
// ENCRYPTION ENGINE — 4 LEVEL
// ═══════════════════════════════════════════

// ═══════════════════════════════════════════
// LEVEL 1 — EASY: XOR + Base64
// ═══════════════════════════════════════════
function encryptEasy(code) {
    const key = crypto.randomBytes(32);
    const buf = Buffer.from(code, "utf8");
    const xor = Buffer.alloc(buf.length);
    for (let i = 0; i < buf.length; i++) {
        xor[i] = buf[i] ^ key[i % key.length];
    }
    const payload = JSON.stringify({
        k: key.toString("base64"),
        d: xor.toString("base64")
    });
    const wrapper = `// ═══════════════════════════════════════════
// PROTECTED — Easy Encryption (XOR + Base64)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════
(function(){
    const p = ${JSON.stringify(payload)};
    const o = JSON.parse(p);
    const k = Buffer.from(o.k, "base64");
    const d = Buffer.from(o.d, "base64");
    const r = Buffer.alloc(d.length);
    for (let i = 0; i < d.length; i++) r[i] = d[i] ^ k[i % k.length];
    eval(r.toString("utf8"));
})();
`;
    return wrapper;
}

// ═══════════════════════════════════════════
// LEVEL 2 — MEDIUM: AES-256-CBC + Base64
// ═══════════════════════════════════════════
function encryptMedium(code) {
    const key = crypto.randomBytes(32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
    let encrypted = cipher.update(code, "utf8", "base64");
    encrypted += cipher.final("base64");
    const payload = JSON.stringify({
        k: key.toString("base64"),
        i: iv.toString("base64"),
        d: encrypted
    });
    const wrapper = `// ═══════════════════════════════════════════
// PROTECTED — Medium Encryption (AES-256-CBC)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════
(function(){
    const c = require("crypto");
    const p = ${JSON.stringify(payload)};
    const o = JSON.parse(p);
    const k = Buffer.from(o.k, "base64");
    const i = Buffer.from(o.i, "base64");
    const dec = c.createDecipheriv("aes-256-cbc", k, i);
    let s = dec.update(o.d, "base64", "utf8");
    s += dec.final("utf8");
    eval(s);
})();
`;
    return wrapper;
}

// ═══════════════════════════════════════════
// LEVEL 3 — HARD: AES-256-GCM + Multi-Layer Base64
// ═══════════════════════════════════════════
function encryptHard(code) {
    const key = crypto.randomBytes(32);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
    let encrypted = cipher.update(code, "utf8", "base64");
    encrypted += cipher.final("base64");
    const authTag = cipher.getAuthTag();

    // Layer 2: Base64 obfuscation
    const layer2 = Buffer.from(encrypted, "utf8").toString("base64");

    const payload = JSON.stringify({
        k: key.toString("base64"),
        i: iv.toString("base64"),
        t: authTag.toString("base64"),
        d: layer2
    });

    const wrapper = `// ═══════════════════════════════════════════
// PROTECTED — Hard Encryption (AES-256-GCM Multi-Layer)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════
(function(){
    "use strict";
    const c = require("crypto");
    const p = ${JSON.stringify(payload)};
    try {
        const o = JSON.parse(p);
        const k = Buffer.from(o.k, "base64");
        const i = Buffer.from(o.i, "base64");
        const t = Buffer.from(o.t, "base64");
        const decoded = Buffer.from(o.d, "base64").toString("utf8");
        const dec = c.createDecipheriv("aes-256-gcm", k, i);
        dec.setAuthTag(t);
        let s = dec.update(decoded, "base64", "utf8");
        s += dec.final("utf8");
        eval(s);
    } catch (e) {
        console.error("[PROTECTED] Decrypt failed");
        process.exit(1);
    }
})();
`;
    return wrapper;
}

// ═══════════════════════════════════════════
// LEVEL 4 — HARD 2: AES-GCM + RC4 + XOR + Anti-Debug + Integrity
// ═══════════════════════════════════════════
function encryptHard2(code) {
    // Layer 1: AES-256-GCM
    const key = crypto.randomBytes(32);
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
    let enc1 = cipher.update(code, "utf8", "base64");
    enc1 += cipher.final("base64");
    const authTag = cipher.getAuthTag();

    // Layer 2: RC4
    const rc4Key = crypto.randomBytes(16);
    const rc4 = (data, key) => {
        const S = Array.from({ length: 256 }, (_, i) => i);
        let j = 0;
        for (let i = 0; i < 256; i++) {
            j = (j + S[i] + key[i % key.length]) & 0xff;
            [S[i], S[j]] = [S[j], S[i]];
        }
        const out = Buffer.alloc(data.length);
        let i = 0; j = 0;
        for (let n = 0; n < data.length; n++) {
            i = (i + 1) & 0xff;
            j = (j + S[i]) & 0xff;
            [S[i], S[j]] = [S[j], S[i]];
            out[n] = data[n] ^ S[(S[i] + S[j]) & 0xff];
        }
        return out;
    };
    const enc2 = rc4(Buffer.from(enc1, "utf8"), rc4Key);

    // Layer 3: XOR
    const xorKey = crypto.randomBytes(32);
    const enc3 = Buffer.alloc(enc2.length);
    for (let i = 0; i < enc2.length; i++) {
        enc3[i] = enc2[i] ^ xorKey[i % xorKey.length];
    }

    // Layer 4: Base64
    const layer4 = enc3.toString("base64");

    // Hash integrity
    const hash = crypto.createHash("sha256").update(code).digest("hex").slice(0, 32);

    const payload = JSON.stringify({
        k: key.toString("base64"),
        i: iv.toString("base64"),
        t: authTag.toString("base64"),
        r: rc4Key.toString("base64"),
        x: xorKey.toString("base64"),
        d: layer4,
        h: hash
    });

    const wrapper = `// ═══════════════════════════════════════════
// PROTECTED — Hard 2 (AES-GCM + RC4 + XOR + Anti-Debug + Integrity)
// Powered by SpartaX BOT
// ═══════════════════════════════════════════
(function(){
    "use strict";
    const c = require("crypto");

    // Anti-debug trap
    try {
        if (typeof process === "undefined" || typeof Buffer === "undefined") {
            throw new Error("env invalid");
        }
    } catch (e) {
        process.exit(1);
    }

    const p = ${JSON.stringify(payload)};

    try {
        const o = JSON.parse(p);
        if (!o.k || !o.i || !o.t || !o.r || !o.x || !o.d || !o.h) {
            throw new Error("payload invalid");
        }

        // Layer 4: Base64 decode
        const layer3 = Buffer.from(o.d, "base64");
        const xorKey = Buffer.from(o.x, "base64");

        // Layer 3: XOR decode
        const layer2 = Buffer.alloc(layer3.length);
        for (let i = 0; i < layer3.length; i++) {
            layer2[i] = layer3[i] ^ xorKey[i % xorKey.length];
        }

        // Layer 2: RC4 decode
        const rc4Key = Buffer.from(o.r, "base64");
        const rc4 = (data, key) => {
            const S = Array.from({ length: 256 }, (_, i) => i);
            let j = 0;
            for (let i = 0; i < 256; i++) {
                j = (j + S[i] + key[i % key.length]) & 0xff;
                const t = S[i]; S[i] = S[j]; S[j] = t;
            }
            const out = Buffer.alloc(data.length);
            let i = 0; j = 0;
            for (let n = 0; n < data.length; n++) {
                i = (i + 1) & 0xff;
                j = (j + S[i]) & 0xff;
                const t = S[i]; S[i] = S[j]; S[j] = t;
                out[n] = data[n] ^ S[(S[i] + S[j]) & 0xff];
            }
            return out;
        };
        const layer1 = rc4(layer2, rc4Key);
        const enc1 = layer1.toString("utf8");

        // Layer 1: AES-256-GCM decrypt
        const k = Buffer.from(o.k, "base64");
        const i = Buffer.from(o.i, "base64");
        const t = Buffer.from(o.t, "base64");
        const dec = c.createDecipheriv("aes-256-gcm", k, i);
        dec.setAuthTag(t);
        let s = dec.update(enc1, "base64", "utf8");
        s += dec.final("utf8");

        // Integrity check
        const hash = c.createHash("sha256").update(s).digest("hex").slice(0, 32);
        if (hash !== o.h) {
            console.error("[PROTECTED] Integrity failed");
            process.exit(1);
        }

        eval(s);
    } catch (e) {
        process.exit(1);
    }
})();
`;
    return wrapper;
}

// ═══════════════════════════════════════════
// DISPATCHER
// ═══════════════════════════════════════════
function encryptCode(code, level) {
    switch (level) {
        case "easy": return encryptEasy(code);
        case "medium": return encryptMedium(code);
        case "hard": return encryptHard(code);
        case "hard2": return encryptHard2(code);
        default: return encryptMedium(code);
    }
}

// ═══ LEVEL INFO ═══
const LEVEL_INFO = {
    easy: {
        label: "Easy",
        emoji: "🟢",
        desc: "XOR + Base64",
        difficulty: 1,
        desc2: "Gampang dibobol"
    },
    medium: {
        label: "Medium",
        emoji: "🟡",
        desc: "AES-256-CBC + Base64",
        difficulty: 2,
        desc2: "Lumayan sulit"
    },
    hard: {
        label: "Hard",
        emoji: "🔴",
        desc: "AES-256-GCM + Multi-Layer",
        difficulty: 3,
        desc2: "Susah dibobol"
    },
    hard2: {
        label: "Hard 2",
        emoji: "💀",
        desc: "AES-GCM + RC4 + XOR + Anti-Debug + Integrity",
        difficulty: 4,
        desc2: "Sangat sulit dibobol"
    }
};

// ═══════════════════════════════════════════
// NOTIF CARD (Sharp)
// ═══════════════════════════════════════════
async function generateEncryptCard(data) {
    try {
        const W = 900;
        const H = 500;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const levelColor = {
            easy: "#22c55e",
            medium: "#eab308",
            hard: "#ef4444",
            hard2: "#7c3aed"
        }[data.level] || "#eab308";

        const levelEmoji = {
            easy: "🟢",
            medium: "🟡",
            hard: "🔴",
            hard2: "💀"
        }[data.level] || "🟡";

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0f172a"/>
      <stop offset="50%" stop-color="#1e293b"/>
      <stop offset="100%" stop-color="#0f172a"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#fef3c7"/>
      <stop offset="50%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
  </defs>

  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  <rect x="10" y="10" width="${W-20}" height="${H-20}" rx="20" fill="none" stroke="url(#goldGrad)" stroke-width="3"/>

  <text x="${W/2}" y="65" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="36" fill="url(#goldGrad)" font-weight="900">ENCRYPT CODE</text>
  <line x1="100" y1="85" x2="${W-100}" y2="85" stroke="url(#goldGrad)" stroke-width="2"/>

  <rect x="${W/2 - 180}" y="110" width="360" height="80" rx="40" fill="${levelColor}" stroke="#ffffff" stroke-width="3"/>
  <text x="${W/2}" y="160" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="36" fill="#ffffff" font-weight="900">${data.levelLabel.toUpperCase()}</text>

  <text x="80" y="245" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">User</text>
  <text x="240" y="245" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.userName)}</text>

  <text x="80" y="285" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">File</text>
  <text x="240" y="285" font-family="Courier New, monospace" font-size="20" fill="#fbbf24" font-weight="700">${esc(data.fileName.slice(0, 40))}</text>

  <text x="80" y="325" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Size</text>
  <text x="240" y="325" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${data.sizeKB} KB</text>

  <text x="80" y="365" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Type</text>
  <text x="240" y="365" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.encType)}</text>

  <text x="80" y="405" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Waktu</text>
  <text x="240" y="405" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.time)}</text>

  <line x1="100" y1="440" x2="${W-100}" y2="440" stroke="url(#goldGrad)" stroke-width="2"/>
  <text x="${W/2}" y="475" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="18" fill="#94a3b8">${esc(cfg.OWNER_USERNAME || "@biscuitMD")} - SpartaX Bot</text>
</svg>`.trim();

        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch (e) {
        console.log("[ENCRYPT CARD ERR]", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU ENCRYPT CODE
// ═══════════════════════════════════════════
router.registerCallback("tool_encrypt", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < 1) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 ENCRYPT CODE</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Encrypt FULL code biar gak bisa dibaca\n` +
            `▸ Support: <b>.js .py .txt .php .json .dll dll</b>\n` +
            `▸ Biaya: <b>1 credit</b>\n` +
            `▸ Max File: <b>500 KB</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>4 LEVEL ENKRIPSI:</b>\n\n` +
            `🟢 <b>EASY</b> (Level 1)\n` +
            `   ▸ XOR + Base64\n` +
            `   ▸ <i>Gampang dibobol</i>\n\n` +
            `🟡 <b>MEDIUM</b> (Level 2)\n` +
            `   ▸ AES-256-CBC + Base64\n` +
            `   ▸ <i>Lumayan sulit</i>\n\n` +
            `🔴 <b>HARD</b> (Level 3)\n` +
            `   ▸ AES-256-GCM + Multi-Layer\n` +
            `   ▸ <i>Susah dibobol</i>\n\n` +
            `💀 <b>HARD 2</b> (Level 4)\n` +
            `   ▸ AES-GCM + RC4 + XOR + Anti-Debug + Integrity\n` +
            `   ▸ <i>Sangat sulit dibobol</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file code lu dulu (max 500KB):</i>`;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "encrypt_await_file", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "encrypt_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[ENCRYPT MENU ERR]", e.message); }
});

// ═══ TERIMA FILE ═══
router.registerMessage("encrypt_await_file", async (bot, msg, state, ctx) => {
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        let code = "";
        let fileName = "code.txt";

        if (msg.document) {
            if (msg.document.file_size > 500 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 500KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                code = res.data;
                fileName = msg.document.file_name || "code.txt";
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            code = msg.text;
            fileName = "input.txt";
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim file code.</b>`, { parse_mode: "HTML" });
        }

        if (!code || code.length < 5) {
            return bot.sendMessage(chatId, `<b>✕ Code terlalu pendek.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);
        ctx.setState(userId, "encrypt_pick_level", { code, fileName });

        const kb = [
            [
                { text: "🟢 Easy", callback_data: "encrypt_level:easy", style: "success" },
                { text: "🟡 Medium", callback_data: "encrypt_level:medium", style: "primary" }
            ],
            [
                { text: "🔴 Hard", callback_data: "encrypt_level:hard", style: "danger" },
                { text: "💀 Hard 2", callback_data: "encrypt_level:hard2", style: "danger" }
            ],
            [{ text: "✕ Batal", callback_data: "encrypt_cancel", style: "danger" }]
        ];

        await bot.sendMessage(chatId,
            `<b>✓ CODE DITERIMA</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName)}</code>\n` +
            `▸ Size: ${(code.length / 1024).toFixed(2)} KB\n` +
            `▸ Baris: ${code.split("\n").length}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih level enkripsi:</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[ENCRYPT FILE ERR]", e.message); }
});

// ═══ PILIH LEVEL ═══
router.registerCallback("encrypt_level", async (bot, q, data, user, ctx) => {
    try {
        const level = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        const st = ctx.getState(userId);
        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis, kirim file ulang", show_alert: true });
        }

        const info = LEVEL_INFO[level];
        if (!info) {
            return bot.answerCallbackQuery(q.id, { text: "Level invalid", show_alert: true });
        }

        await bot.answerCallbackQuery(q.id, { text: `${info.emoji} ${info.label}...`, show_alert: false }).catch(() => {});

        // CEK CREDIT
        const c = checkAndDeductCredit(ctx, { id: userId }, 1);
        if (!c.ok) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ ${c.error}</b>`, { parse_mode: "HTML",
                reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] } });
        }

        await safeEdit(bot, chatId, q.message.message_id,
            `<b>𖡛 ENCRYPT CODE</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(st.fileName)}</code>\n` +
            `▸ Level: ${info.emoji} <b>${info.label}</b>\n` +
            `▸ Tipe: ${info.desc}\n` +
            `▸ Status: <i>Encrypting...</i>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        // ENCRYPT
        let encrypted;
        try {
            encrypted = encryptCode(st.code, level);
        } catch (e) {
            console.log("[ENCRYPT ERR]", e.message);
            return safeEdit(bot, chatId, q.message.message_id,
                `<b>✕ Gagal encrypt:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        }

        // NAMA FILE OUTPUT
        const ext = path.extname(st.fileName) || ".txt";
        const baseName = path.basename(st.fileName, ext).replace(/[^a-zA-Z0-9_]/g, "_") || "code";
        const levelSuffix = level === "hard2" ? "hard2" : level;
        const outFileName = `${baseName}_${levelSuffix}_encrypted.js`;
        const outFilePath = path.join(TMP_DIR, `${Date.now()}_${outFileName}`);
        fs.writeFileSync(outFilePath, encrypted, "utf8");

        const stat = fs.statSync(outFilePath);
        const sizeKB = (stat.size / 1024).toFixed(2);

        await safeEdit(bot, chatId, q.message.message_id,
            `<b>✓ ENCRYPT SUCCESS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File input: <code>${escHtml(st.fileName)}</code>\n` +
            `▸ File output: <code>${escHtml(outFileName)}</code>\n` +
            `▸ Level: ${info.emoji} <b>${info.label}</b>\n` +
            `▸ Size: ${sizeKB} KB\n` +
            `▸ Credit sisa: ${c.credit}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File dikirim di bawah.</i>`,
            { parse_mode: "HTML" });

        try {
            await bot.sendDocument(chatId, outFilePath, {
                caption:
                    `<b>𖡛 ENCRYPT CODE RESULT</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ Output: <code>${escHtml(outFileName)}</code>\n` +
                    `▸ Level: ${info.emoji} <b>${info.label}</b> (${info.desc2})\n` +
                    `▸ Tipe: ${info.desc}\n` +
                    `▸ Size: ${sizeKB} KB\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<i>File siap di-deploy. Kode di dalamnya udah terenkripsi.</i>`,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [
                    [{ text: "𖡛 Encrypt Lagi", callback_data: "tool_encrypt", style: "success" }],
                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                ] }
            }, { filename: outFileName, contentType: "application/javascript" });
        } catch (e) {
            console.log("[ENCRYPT SEND ERR]", e.message);
        }

        // NOTIF CHANNEL
        try {
            const channelId = cfg.NOTIF_CHANNEL || (cfg.ORDER && cfg.ORDER.ORDER_CHANNEL);
            if (channelId) {
                const cardBuf = await generateEncryptCard({
                    userName: `${user.first_name || "User"}${user.last_name ? " " + user.last_name : ""}`,
                    userId: user.id,
                    fileName: st.fileName,
                    sizeKB,
                    levelLabel: info.label,
                    level,
                    encType: info.desc,
                    time: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
                });

                const caption =
                    `<b>𖡛 ENCRYPT CODE SUCCESS</b>\n\n` +
                    `▸ User: ${escHtml(user.first_name || "User")}\n` +
                    `▸ ID: <code>${user.id}</code>\n` +
                    `▸ File: <code>${escHtml(st.fileName)}</code>\n` +
                    `▸ Level: ${info.emoji} <b>${info.label}</b>\n` +
                    `▸ Tipe: ${info.desc}\n` +
                    `▸ Size: ${sizeKB} KB`;

                if (cardBuf) {
                    try {
                        await bot.sendPhoto(channelId, cardBuf, { caption, parse_mode: "HTML" });
                    } catch (e) {
                        await bot.sendMessage(channelId, caption, { parse_mode: "HTML" });
                    }
                } else {
                    await bot.sendMessage(channelId, caption, { parse_mode: "HTML" });
                }
            }
        } catch (e) {
            console.log("[ENCRYPT NOTIF ERR]", e.message);
        }

        try { fs.unlinkSync(outFilePath); } catch {}
        ctx.clearState(userId);
    } catch (e) {
        console.log("[ENCRYPT LEVEL ERR]", e.message);
    }
});

// ═══ CANCEL ═══
router.registerCallback("encrypt_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[ENCRYPT CANCEL ERR]", e.message); }
});

module.exports = {
    encryptCode,
    encryptEasy,
    encryptMedium,
    encryptHard,
    encryptHard2,
    LEVEL_INFO
};

console.log("[TOOL ENCRYPT] v2 loaded — 4 level encryption (Easy/Medium/Hard/Hard2)");