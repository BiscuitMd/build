// ═══════════════════════════════════════════
// RENAME BAILEYS — Ganti versi baileys di package.json
// v2 — NO BUILD, kirim balik .zip ke user
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const buildNotifier = require("./build-notifier");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");

const TMP_DIR = path.join(__dirname, "..", cfg.BUILD_TMP_DIR || "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ HELPERS ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); }
            catch { return null; }
        }
        if (msg.includes("message is not modified")) return null;
        return null;
    }
}

// ═══════════════════════════════════════════
// DAFTAR VERSI BAILEYS YANG TERSEDIA
// ═══════════════════════════════════════════
const BAILEYS_VERSIONS = [
    { label: "Latest", value: "latest" },
    { label: "6.7.18", value: "^6.7.18" },
    { label: "6.7.17", value: "^6.7.17" },
    { label: "6.7.16", value: "^6.7.16" },
    { label: "6.7.15", value: "^6.7.15" },
    { label: "6.7.14", value: "^6.7.14" },
    { label: "6.7.13", value: "^6.7.13" },
    { label: "6.7.12", value: "^6.7.12" },
    { label: "6.7.11", value: "^6.7.11" },
    { label: "6.7.10", value: "^6.7.10" },
    { label: "6.7.9", value: "^6.7.9" },
    { label: "6.7.8", value: "^6.7.8" },
    { label: "6.7.7", value: "^6.7.7" },
    { label: "6.7.6", value: "^6.7.6" },
    { label: "6.7.5", value: "^6.7.5" },
    { label: "6.6.0", value: "^6.6.0" },
    { label: "6.5.0", value: "^6.5.0" },
    { label: "6.4.0", value: "^6.4.0" },
    { label: "WhiskeySockets", value: "github:WhiskeySockets/Baileys" },
    { label: "NtedBitch/bail", value: "github:NtedBitch/bail" }
];

// ═══ SCAN package.json UNTUK VERSI BAILEYS ═══
function scanBaileysVersion(extractDir) {
    const results = [];
    const pkgFiles = [];

    function walk(dir) {
        let items;
        try { items = fs.readdirSync(dir, { withFileTypes: true }); }
        catch { return; }

        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                if (["node_modules", ".git", "build", "dist", ".github"].includes(item.name)) continue;
                walk(full);
            } else if (item.name === "package.json") {
                pkgFiles.push(full);
            }
        }
    }
    walk(extractDir);

    const baileysKeys = [
        "@whiskeysockets/baileys",
        "baileys",
        "@adiwajshing/baileys"
    ];

    for (const pkgPath of pkgFiles) {
        try {
            const content = fs.readFileSync(pkgPath, "utf8");
            const pkg = JSON.parse(content);
            const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };

            for (const key of baileysKeys) {
                if (deps[key]) {
                    results.push({
                        package: key,
                        version: deps[key],
                        path: path.relative(extractDir, pkgPath),
                        fullPath: pkgPath,
                        depType: (pkg.dependencies && pkg.dependencies[key]) ? "dependencies" : "devDependencies"
                    });
                }
            }
        } catch (e) {
            console.log("[BAILEYS SCAN] skip:", pkgPath, e.message);
        }
    }

    return results;
}

// ═══ REPLACE VERSI BAILEYS DI SEMUA package.json ═══
function replaceBaileysVersion(extractDir, newVersion) {
    const results = [];
    const pkgFiles = [];

    function walk(dir) {
        let items;
        try { items = fs.readdirSync(dir, { withFileTypes: true }); }
        catch { return; }

        for (const item of items) {
            const full = path.join(dir, item.name);
            if (item.isDirectory()) {
                if (["node_modules", ".git", "build", "dist", ".github"].includes(item.name)) continue;
                walk(full);
            } else if (item.name === "package.json") {
                pkgFiles.push(full);
            }
        }
    }
    walk(extractDir);

    const baileysKeys = [
        "@whiskeysockets/baileys",
        "baileys",
        "@adiwajshing/baileys"
    ];

    for (const pkgPath of pkgFiles) {
        try {
            const content = fs.readFileSync(pkgPath, "utf8");
            const pkg = JSON.parse(content);
            let changed = false;
            const changes = [];

            for (const key of baileysKeys) {
                if (pkg.dependencies && pkg.dependencies[key]) {
                    const oldVer = pkg.dependencies[key];
                    pkg.dependencies[key] = newVersion;
                    changes.push(`${key}: ${oldVer} → ${newVersion}`);
                    changed = true;
                }
                if (pkg.devDependencies && pkg.devDependencies[key]) {
                    const oldVer = pkg.devDependencies[key];
                    pkg.devDependencies[key] = newVersion;
                    changes.push(`${key} (dev): ${oldVer} → ${newVersion}`);
                    changed = true;
                }
            }

            if (changed) {
                // ⚡ Tulis ulang package.json (format rapi)
                fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2), "utf8");
                results.push({
                    path: path.relative(extractDir, pkgPath),
                    changes
                });
                console.log("[BAILEYS REPLACE]", pkgPath, changes.join(", "));
            }
        } catch (e) {
            console.log("[BAILEYS REPLACE] skip:", pkgPath, e.message);
        }
    }

    return results;
}

// ═══ ZIP ULANG FOLDER ═══
function rezipFolder(sourceDir, destZipPath) {
    const zip = new AdmZip();
    zip.addLocalFolder(sourceDir);
    zip.writeZip(destZipPath);
    return destZipPath;
}

// ═══════════════════════════════════════════
// MENU RENAME BAILEYS
// ═══════════════════════════════════════════
router.registerCallback("menu_renamebaileys", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < cfg.CREDIT_PER_USE) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Ganti versi <code>@whiskeysockets/baileys</code>\n` +
            `▸ Kirim: <b>file .zip</b> project lu\n` +
            `▸ Biaya: <b>${cfg.CREDIT_PER_USE} credit</b>\n` +
            `▸ Hasil: <b>File .zip baru</b> dengan versi baileys yang lu pilih\n` +
            `▸ Gak perlu build — cuma rename package.json\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Versi Baileys yang tersedia:</b>\n` +
            BAILEYS_VERSIONS.slice(0, 8).map(v => `• <code>${v.label}</code>`).join("\n") +
            `\n• ...dan ${BAILEYS_VERSIONS.length - 8} lainnya\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mulai dengan kirim file .zip project lu:</i>`;

        ctx.clearState(user.id);
        ctx.setState(user.id, "renamebaileys_await_zip", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]] }
        });
    } catch (e) { console.log("[RENAME BAILEYS MENU ERR]", e.message); }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("renamebaileys_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip project lu.</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "project.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        if (msg.document.file_size > 20 * 1024 * 1024) {
            return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 20MB.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(5)}]</code> <b>5%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Download file dari Telegram\n` +
            `<i>Mohon tunggu...</i>`,
            { parse_mode: "HTML" });

        const jobId = `baileys_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        let zipPath;
        try {
            const fileLink = await bot.getFileLink(msg.document.file_id);
            const res = await axios.get(fileLink, {
                responseType: "arraybuffer",
                timeout: 60000,
                maxContentLength: Infinity,
                maxBodyLength: Infinity
            });
            zipPath = path.join(workDir, fname);
            fs.writeFileSync(zipPath, Buffer.from(res.data));
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download file:</b>\n<code>${e.message}</code>`);
        }

        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(30)}]</code> <b>30%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Extract & scan package.json\n` +
            `<i>Mohon tunggu...</i>`);

        const extractDir = path.join(workDir, "extracted");
        fs.mkdirSync(extractDir, { recursive: true });

        try {
            const zip = new AdmZip(zipPath);
            zip.extractAllTo(extractDir, true);
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal extract zip:</b>\n<code>${e.message}</code>`);
        }

        const found = scanBaileysVersion(extractDir);
        console.log("[RENAME BAILEYS] found:", JSON.stringify(found));

        if (found.length === 0) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Baileys tidak ditemukan di package.json</b>\n\n` +
                `Cek: <code>@whiskeysockets/baileys</code>, <code>baileys</code>, atau <code>@adiwajshing/baileys</code>`);
        }

        ctx.setState(userId, "renamebaileys_pick_version", {
            jobId, zipPath, fname, extractDir, workDir,
            loadingMsgId: loading.message_id,
            found
        });

        const foundText = found.map(f =>
            `• <code>${f.package}</code>: <b>${f.version}</b>\n  <i>${f.path} (${f.depType})</i>`
        ).join("\n");

        // ⚡ BUTTON 2-2 WARNA
        const versionButtons = [];
        for (let i = 0; i < BAILEYS_VERSIONS.length; i += 2) {
            const row = [];
            for (let j = 0; j < 2; j++) {
                if (i + j < BAILEYS_VERSIONS.length) {
                    const v = BAILEYS_VERSIONS[i + j];
                    row.push({
                        text: `▸ ${v.label}`,
                        callback_data: `renamebaileys_pick:${i + j}`,
                        style: "primary"
                    });
                }
            }
            versionButtons.push(row);
        }
        versionButtons.push([{ text: "✕ Batal", callback_data: "menu_back", style: "danger" }]);

        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 PILIH VERSI BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Job ID: <code>${jobId}</code>\n` +
            `▸ File: <code>${fname}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Versi Baileys yang ketemu:</b>\n${foundText}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<b>Pilih versi baru:</b>`,
            { reply_markup: { inline_keyboard: versionButtons } });
    } catch (e) {
        console.log("[RENAME BAILEYS AWAIT ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══ CALLBACK: PILIH VERSI — PROSES RENAME + KIRIM ZIP ═══
router.registerCallback("renamebaileys_pick", async (bot, q, data, user, ctx) => {
    let workDir = null;
    try {
        const idx = parseInt(data.split(":")[1], 10);
        const picked = BAILEYS_VERSIONS[idx];
        if (!picked) {
            return bot.answerCallbackQuery(q.id, { text: "Versi tidak valid", show_alert: true });
        }

        await bot.answerCallbackQuery(q.id, { text: `Pilih: ${picked.label}`, show_alert: false }).catch(() => {});

        const prev = ctx.getState(user.id) || {};
        const { jobId, zipPath, fname, extractDir } = prev;
        workDir = prev.workDir;

        if (!jobId || !zipPath || !extractDir) {
            ctx.clearState(user.id);
            return bot.sendMessage(q.message.chat.id, `<b>✕ Sesi habis. Kirim zip ulang.</b>`, { parse_mode: "HTML" });
        }

        // ⚡ CEK CREDIT
        const creditCheck = checkAndDeductCredit(ctx, { id: user.id }, cfg.CREDIT_PER_USE);
        if (!creditCheck.ok) {
            ctx.clearState(user.id);
            return bot.sendMessage(q.message.chat.id, `<b>✕ ${creditCheck.error}</b>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] } });
        }

        const chatId = q.message.chat.id;
        const loadingMsgId = prev.loadingMsgId || q.message.message_id;

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(50)}]</code> <b>50%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Replace versi di package.json\n` +
            `▸ <b>Versi baru</b>: <code>${picked.label}</code>\n` +
            `▸ <b>Value</b>: <code>${picked.value}</code>\n` +
            `<i>Mohon tunggu...</i>`);

        const changes = replaceBaileysVersion(extractDir, picked.value);
        console.log("[RENAME BAILEYS] changes:", JSON.stringify(changes));

        if (changes.length === 0) {
            ctx.clearState(user.id);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Tidak ada package.json yang diubah</b>`);
        }

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(75)}]</code> <b>75%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Re-zip project\n` +
            `<i>Mohon tunggu...</i>`);

        const newZipName = `baileys_${picked.value.replace(/[^a-z0-9]/gi, "_")}_${fname}`;
        const newZipPath = path.join(workDir, newZipName);

        try {
            rezipFolder(extractDir, newZipPath);
        } catch (e) {
            ctx.clearState(user.id);
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal re-zip:</b>\n<code>${e.message}</code>`);
        }

        const newSize = fs.statSync(newZipPath).size;
        console.log("[RENAME BAILEYS] new zip:", newZipPath, newSize, "bytes");

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 RENAME BAILEYS</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(95)}]</code> <b>95%</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ <b>Status</b>: Kirim file ke Telegram\n` +
            `<i>Mohon tunggu...</i>`);

        // ⚡ HAPUS PESAN LOADING
        await bot.deleteMessage(chatId, loadingMsgId).catch(() => {});

        // ⚡ SIAPIN PREVIEW CHANGES
        const preview = changes.slice(0, 10).map(c =>
            `▸ <code>${c.path}</code>\n  ${c.changes.join("\n  ")}`
        ).join("\n\n");
        const more = changes.length > 10 ? `\n\n<i>...dan ${changes.length - 10} package.json lain</i>` : "";

        // ⚡ KIRIM ZIP KE USER
        try {
            await bot.sendDocument(chatId, newZipPath, {
                caption:
                    `<b>✓ RENAME BAILEYS SUCCESS</b>\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `▸ <b>File</b>: <code>${fname}</code>\n` +
                    `▸ <b>Versi Baru</b>: <code>${picked.label}</code>\n` +
                    `▸ <b>Value</b>: <code>${picked.value}</code>\n` +
                    `▸ <b>Package diubah</b>: <code>${changes.length}</code>\n` +
                    `▸ <b>Size</b>: ${(newSize / 1024).toFixed(2)} KB\n` +
                    `▸ <b>Job ID</b>: <code>${jobId}</code>\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n\n` +
                    `<b>Detail perubahan:</b>\n${preview}${more}\n\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `<i>File .zip hasil rename siap dipake. Extract dan build sendiri.</i>`,
                parse_mode: "HTML"
            }, {
                filename: newZipName,
                contentType: "application/zip"
            });

            // ⚡ NOTIF CHANNEL
            try {
                await buildNotifier.sendBuildNotif(bot, {
                    status: "success",
                    feature: `Rename Baileys — ${picked.label}`,
                    baseName: fname,
                    user: user,
                    subtitle: `${changes.length} package.json diubah`,
                    fields: [
                        { label: "Versi Baru", value: picked.label },
                        { label: "Value", value: picked.value },
                        { label: "Changes", value: String(changes.length) },
                        { label: "Size", value: (newSize / 1024).toFixed(2) + " KB" },
                        { label: "Job ID", value: jobId }
                    ]
                });
            } catch (e) { console.log("[NOTIF RENAME BAILEYS ERR]", e.message); }
        } catch (e) {
            console.log("[RENAME BAILEYS SEND ERR]", e.message);
            await bot.sendMessage(chatId,
                `<b>✕ Gagal kirim file .zip ke Telegram</b>\n\n<code>${e.message.slice(0, 200)}</code>`,
                { parse_mode: "HTML" });
        }

        // ⚡ CLEANUP
        ctx.clearState(user.id);
        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    } catch (e) {
        console.log("[RENAME BAILEYS PICK ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        try { ctx.clearState(user.id); } catch {}
    }
});

module.exports = {
    checkAndDeductCredit,
    progressBar,
    BAILEYS_VERSIONS,
    scanBaileysVersion,
    replaceBaileysVersion
};

console.log("[RENAME BAILEYS] v2 loaded — NO BUILD, kirim balik .zip");