// Auto Reach Channel: user submits a channel username; no channel notifications are sent.
// Telegram Bot API permits a non-premium bot to apply ONE reaction per post, so one emoji
// is chosen randomly from a pool of 12. It cannot place 12 separate reactions as one bot.
const fs = require('fs');
const path = require('path');
const router = require('./router');
const cfg = require('../config');
const axios = require('axios');
const FILE = path.join(__dirname, '..', 'data', 'react-emoji.json');
const EMOJIS = ['🔥','❤️','👍','😍','🎉','👏','😁','🤩','💯','⚡','🥰','✨'];
function load(){ try { return JSON.parse(fs.readFileSync(FILE,'utf8')); } catch { return { enabled: true, channels: [] }; } }
function save(d){ fs.mkdirSync(path.dirname(FILE),{recursive:true}); fs.writeFileSync(FILE,JSON.stringify(d,null,2)); }
function esc(s){ return String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function normalizeChannel(input){
  let v=String(input||'').trim();
  v=v.replace(/^https?:\/\/(www\.)?t\.me\//i,'').replace(/^@/,'').replace(/\/$/,'');
  if (v.includes('/') || !/^[A-Za-z][A-Za-z0-9_]{4,31}$/.test(v)) return null;
  return '@'+v;
}
router.registerCallback('menu_reactemoji', async(bot,q,data,user,ctx)=>{
  ctx.setState(String(user.id),'reach_channel_wait',{});
  await bot.sendMessage(q.message.chat.id,
    '<h2>📣 AUTO REACH CHANNEL</h2><p>Kirim username channel publik, contoh <code>@namachannel</code> atau <code>https://t.me/namachannel</code>.</p><p>Bot harus menjadi admin channel dan memiliki izin memberi reaksi. Tidak ada notifikasi yang dikirim ke channel.</p><p><i>Catatan: Bot API membatasi bot biasa ke satu reaksi per postingan. Sistem memilih acak satu emoji dari 12 pilihan.</i></p>',
    {parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✕ Batal',callback_data:'menu_tools',style:'danger'}]]}});
});
router.registerMessage('reach_channel_wait', async(bot,msg,state,ctx)=>{
  const channel=normalizeChannel(msg.text);
  if(!channel) return bot.sendMessage(msg.chat.id,'Username channel tidak valid. Kirim contoh <code>@namachannel</code> atau <code>https://t.me/namachannel</code>.',{parse_mode:'HTML'});
  try {
    const chat=await bot.getChat(channel);
    if(chat.type!=='channel') return bot.sendMessage(msg.chat.id,'Username tersebut bukan channel Telegram. Coba kirim username channel publik.');
    const me=await bot.getMe();
    const member=await bot.getChatMember(chat.id,me.id);
    if(!['administrator','creator'].includes(member.status)) return bot.sendMessage(msg.chat.id,'Bot belum menjadi admin di channel itu. Jadikan bot admin dengan izin reaksi, lalu kirim username lagi.');
    const d=load(); d.enabled=true; d.channels=Array.isArray(d.channels)?d.channels:[];
    const item={id:String(chat.id),username:chat.username?('@'+chat.username):channel,title:chat.title||channel};
    d.channels=d.channels.filter(x=>String(typeof x==='object'?x.id:x)!==String(chat.id)); d.channels.push(item); save(d);
    ctx.clearState(String(msg.from.id));
    await bot.sendMessage(msg.chat.id,`<h2>✅ AUTO REACH AKTIF</h2><p>Channel: <b>${esc(item.title)}</b></p><p>Username: <code>${esc(item.username)}</code></p><p>Postingan baru akan diberi satu emoji acak dari 12 pilihan. Tidak ada notifikasi channel.</p>`,{parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'‹ Kembali ke Tools',callback_data:'menu_tools',style:'primary'}]]}});
  } catch(e) { await bot.sendMessage(msg.chat.id,`Gagal memverifikasi channel. Pastikan channel publik dan bot admin. <code>${esc(e.message||'API error')}</code>`,{parse_mode:'HTML'}); }
});
function register(bot){
  bot.on('channel_post', async post=>{
    const d=load(); if(!d.enabled || !Array.isArray(d.channels)) return;
    const enabled=d.channels.some(x=>String(typeof x==='object'?x.id:x)===String(post.chat.id)); if(!enabled) return;
    const emoji=EMOJIS[Math.floor(Math.random()*EMOJIS.length)];
    try {
      const r=await axios.post(`https://api.telegram.org/bot${cfg.BOT_TOKEN}/setMessageReaction`,{chat_id:post.chat.id,message_id:post.message_id,reaction:[{type:'emoji',emoji}],is_big:false},{timeout:15000});
      if(!r.data?.ok) throw new Error(r.data?.description||'Telegram menolak reaksi');
    } catch(e){ console.warn('[AUTO REACH] reaction failed:',e.response?.data?.description||e.message); }
  });
}
module.exports={register};
