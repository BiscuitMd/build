// ═══════════════════════════════════════════
// AI CODE EDITOR — Grok (xAI)
// v7 — Grok langsung via API xAI, timeout + retry, respon jelas
// Powered by SpartaX BOT
// ═══════════════════════════════════════════

const router = require("./router");
const cfg = require("../config");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

// ═══ GITHUB BUILDER — safe require ═══
let gh = null;
try {
    gh = require("./github-builder");
    console.log("[AI CODE EDITOR] github-builder loaded");
} catch (e) {
    console.log("[AI CODE EDITOR] github-builder gaada, notif disabled:", e.message);
    gh = { sendBuildNotif: async () => {} };
}
if (typeof gh.sendBuildNotif !== "function") {
    gh.sendBuildNotif = async () => {};
}

// ═══ KONFIG GROK ═══
const GROK_API_URL = "https://api.x.ai/v1/chat/completions";
const GROK_MODEL = (cfg.GROK && cfg.GROK.MODEL) || "grok-3-latest";
const GROK_API_KEY = (cfg.GROK && cfg.GROK.API_KEY) || cfg.GROK_API_KEY || "";
const GROK_TIMEOUT_MS = 120000;

const TMP_DIR = path.join(__dirname, "..", "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ CREDIT CHECK ═══
function checkAndDeductCredit(ctx, user, amount = 1) {
    const u = ctx.db.getUser(user.id);
    if (u.credit < amount) {
        return { ok: false, error: `Credit habis! Butuh ${amount} credit.` };
    }
    ctx.db.saveUser(user.id, { credit: u.credit - amount });
    return { ok: true, credit: u.credit - amount };
}

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ CLEAN AI RESPONSE ═══
function cleanAIResponse(text) {
    let t = String(text || "");
    t = t.replace(/<thinking>[\s\S]*?<\/thinking>/gi, "");
    t = t.replace(/<reasoning>[\s\S]*?<\/reasoning>/gi, "");

    const codeBlocks = [...t.matchAll(/```(?:[\w+-]+)?\n?([\s\S]*?)```/g)];
    if (codeBlocks.length >= 1) {
        // ambil code block terpanjang (biasanya hasil edit lengkap)
        t = codeBlocks.reduce((a, b) => (a[1].length >= b[1].length ? a : b))[1];
    } else {
        t = t.replace(/^```(?:[\w+-]+)?\n?/i, "").replace(/\n?```$/i, "");
    }
    return t.replace(/```/g, "").trim();
}

// ═══ PANGGIL GROK (xAI) ═══
async function callGrok(messages) {
    if (!GROK_API_KEY) {
        return { ok: false, error: "GROK_API_KEY belum diisi di config.js" };
    }

    for (let attempt = 1; attempt <= 2; attempt++) {
        try {
            const res = await axios.post(
                GROK_API_URL,
                {
                    model: GROK_MODEL,
                    messages,
                    temperature: 0.2,
                    stream: false
                },
                {
                    headers: {
                        Authorization: `Bearer ${GROK_API_KEY}`,
                        "Content-Type": "application/json"
                    },
                    timeout: GROK_TIMEOUT_MS
                }
            );

            const content = res.data?.choices?.[0]?.message?.content;
            if (!content) return { ok: false, error: "Grok ga ngasih jawaban" };
            return { ok: true, text: content, model: GROK_MODEL };
        } catch (e) {
            const status = e.response?.status;
            const apiMsg = e.response?.data?.error?.message || e.response?.data?.error || e.message;
            console.log(`[GROK] attempt ${attempt} gagal (${status || "no-status"}):`, String(apiMsg).slice(0, 150));

            // 401/403 = key salah, ga usah retry
            if (status === 401 || status === 403) {
                return { ok: false, error: "API key Grok tidak valid / tidak punya akses" };
            }
            if (attempt === 2) {
                return { ok: false, error: `Grok error${status ? " " + status : ""}: ${String(apiMsg).slice(0, 150)}` };
            }
            await new Promise(r => setTimeout(r, 3000));
        }
    }
    return { ok: false, error: "Grok gagal" };
}

// ═══ BUILD PROMPT + PANGGIL GROK ═══
async function callEditCode(params) {
    let instruction = "";
    if (params.mode === "color") {
        instruction = `Rombak SEMUA warna di code jadi palet: ${params.palette}. Ganti background, text, button, card, dll biar konsisten. JANGAN ubah logic.`;
    } else if (params.mode === "feature") {
        instruction = `Tambahin fitur "${params.feature}" ke code. Bikin function baru yang rapi + integrasi ke UI existing. JANGAN rusak function lama.`;
    } else if (params.mode === "fix") {
        instruction = `Fix error di code berikut.${params.errorMsg ? ` Error: ${params.errorMsg}` : ""} Kasih FULL code yang sudah diperbaiki.`;
    } else if (params.mode === "optimize") {
        instruction = `Optimize code berikut: perbaiki performance, kurangi redundansi. JANGAN ubah behavior/UI.`;
    } else if (params.mode === "explain") {
        instruction = `Jelaskan code berikut: fungsinya, cara kerja, dan struktur utama. Bahasa Indonesia santai.`;
    } else if (params.mode === "custom") {
        instruction = params.customPrompt || "Edit code ini.";
    }

    const system =
        "Kamu adalah AI coding expert. Balas dalam Bahasa Indonesia. " +
        "Untuk mode edit, balas HANYA dengan FULL code hasil edit di dalam satu code block. " +
        "Jangan dipotong, jangan pakai pembuka/penutup.";

    const user =
        `${instruction}\n\n` +
        `Code:\n\`\`\`\n${params.code}\n\`\`\``;

    const result = await callGrok([
        { role: "system", content: system },
        { role: "user", content: user }
    ]);
    return result;
}

// ═══════════════════════════════════════════
// MENU AI CODE EDITOR
// ═══════════════════════════════════════════
router.registerCallback("menu_aicodeeditor", async (bot, q, data, user, ctx) => {
    try {
        const u = ctx.db.getUser(user.id);
        if (u.credit < 1) {
            return bot.sendMessage(q.message.chat.id,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu buat pake fitur ini.</i>`,
                {
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] }
                });
        }

        const caption =
            `<b>𖡛 AI CODE EDITOR</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Provider: <b>Grok AI</b> (xAI)\n` +
            `▸ Model: <b>${escHtml(GROK_MODEL)}</b>\n` +
            `▸ Biaya: <code>1 credit</code> / edit\n` +
            `▸ Max File: <b>50 KB</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Mode:</b>\n` +
            `▸ ✦ Rombak Warna\n` +
            `▸ ✦ Tambah Fitur\n` +
            `▸ ✦ Fix Error\n` +
            `▸ ✦ Optimize\n` +
            `▸ ✦ Jelasin Code\n` +
            `▸ ✦ Custom Prompt\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file code lu dulu (max 50KB).</i>`;

        ctx.clearState(String(user.id));
        ctx.setState(String(user.id), "aicode_await_file", {});

        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] }
        });
    } catch (e) { console.log("[AICODE MENU ERR]", e.message); }
});

// ═══════════════════════════════════════════
// STEP 1: TERIMA FILE
// ═══════════════════════════════════════════
router.registerMessage("aicode_await_file", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const chatId = msg.chat.id;
        const userId = String(msg.from.id);

        let code = "";
        let fileName = "code.txt";

        if (msg.document) {
            if ((msg.document.file_size || 0) > 50 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 50KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                code = res.data;
                fileName = msg.document.file_name || "code.txt";
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            code = msg.text;
            fileName = "input.txt";
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim file code (.dart / .js / .py) atau ketik langsung.</b>`, { parse_mode: "HTML" });
        }

        if (!code || code.length < 10) {
            return bot.sendMessage(chatId, `<b>✕ Code terlalu pendek.</b>`, { parse_mode: "HTML" });
        }
        if (code.length > 50000) {
            return bot.sendMessage(chatId, `<b>✕ Code terlalu panjang! Max 50KB.</b>`, { parse_mode: "HTML" });
        }

        ctx.clearState(userId);
        ctx.setState(userId, "aicode_pick_mode", { code, fileName });

        const kb = [
            [
                { text: "✦ Rombak Warna", callback_data: "aicode_mode:color", style: "primary" },
                { text: "✦ Tambah Fitur", callback_data: "aicode_mode:feature", style: "success" }
            ],
            [
                { text: "✦ Fix Error", callback_data: "aicode_mode:fix", style: "danger" },
                { text: "✦ Optimize", callback_data: "aicode_mode:optimize", style: "success" }
            ],
            [
                { text: "✦ Jelasin Code", callback_data: "aicode_mode:explain", style: "primary" },
                { text: "✦ Custom Prompt", callback_data: "aicode_mode:custom", style: "primary" }
            ],
            [{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]
        ];

        await bot.sendMessage(chatId,
            `<b>✓ CODE DITERIMA</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fileName)}</code>\n` +
            `▸ Size: ${(code.length / 1024).toFixed(2)} KB\n` +
            `▸ Baris: ${code.split("\n").length}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih mode:</b>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    } catch (e) { console.log("[AICODE FILE ERR]", e.message); }
});

// ═══════════════════════════════════════════
// STEP 2: PILIH MODE
// ═══════════════════════════════════════════
router.registerCallback("aicode_mode", async (bot, q, data, user, ctx) => {
    try {
        const mode = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);

        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis, kirim file ulang", show_alert: true }).catch(() => {});
        }

        if (mode === "color") {
            ctx.setState(userId, "aicode_pick_color", { code: st.code, fileName: st.fileName });
            const kb = [
                [{ text: "✦ Emas + Putih + Biru", callback_data: "aicode_palette:emas_putih_biru", style: "success" }],
                [{ text: "✦ Biru Tua + Ungu", callback_data: "aicode_palette:biru_tua_ungu", style: "primary" }],
                [{ text: "✦ Merah + Pink", callback_data: "aicode_palette:merah_pink", style: "danger" }],
                [{ text: "✦ Pink + Hitam", callback_data: "aicode_palette:pink_hitam", style: "primary" }],
                [{ text: "✦ Hitam + Emas + Putih", callback_data: "aicode_palette:hitam_emas_putih", style: "success" }],
                [{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]
            ];
            return bot.sendMessage(q.message.chat.id,
                `<b>✦ ROMBAK WARNA</b>\n\nPilih palet warna baru:`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }

        if (mode === "feature") {
            ctx.setState(userId, "aicode_pick_feature", { code: st.code, fileName: st.fileName });
            const features = [
                { id: "weather", label: "✦ Cek Cuaca" },
                { id: "prayer", label: "✦ Jam Sholat" },
                { id: "puzzle", label: "✦ Game Puzzle" },
                { id: "chess", label: "♟️ Game Catur" },
                { id: "billiard", label: "✦ Game Billiard" },
                { id: "chat", label: "✦ Chat Public" },
                { id: "savings", label: "✦ Menabung QRIS" },
                { id: "ai_helper", label: "✦ AI Helper" },
                { id: "bug_test", label: "✦ Test Function Bug" }
            ];
            const kb = [];
            for (let i = 0; i < features.length; i += 2) {
                const row = [{ text: features[i].label, callback_data: `aicode_feature:${features[i].id}`, style: "primary" }];
                if (features[i + 1]) row.push({ text: features[i + 1].label, callback_data: `aicode_feature:${features[i + 1].id}`, style: "primary" });
                kb.push(row);
            }
            kb.push([{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]);
            return bot.sendMessage(q.message.chat.id,
                `<b>✦ TAMBAH FITUR</b>\n\nPilih fitur yang mau ditambahin:`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
        }

        if (mode === "fix") {
            ctx.setState(userId, "aicode_fix_error", { code: st.code, fileName: st.fileName });
            return bot.sendMessage(q.message.chat.id,
                `<b>✦ FIX ERROR</b>\n\n` +
                `Kirim <b>error message</b> atau <b>file log error</b>.\n\n` +
                `<i>Kalau tidak ada error, ketik "skip".</i>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] } });
        }

        if (mode === "custom") {
            ctx.setState(userId, "aicode_custom_prompt", { code: st.code, fileName: st.fileName });
            return bot.sendMessage(q.message.chat.id,
                `<b>✦ CUSTOM PROMPT</b>\n\n` +
                `Kirim instruksi lu ke AI.\n\n` +
                `<b>Contoh:</b>\n` +
                `▸ <code>Tambah dark mode di seluruh app</code>\n` +
                `▸ <code>Ubah semua button jadi rounded</code>`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "aicode_cancel", style: "danger" }]] } });
        }

        if (mode === "optimize" || mode === "explain") {
            const loading = await bot.sendMessage(q.message.chat.id,
                `<b>𖡛 Processing...</b>\n\n<i>Mode: ${mode}</i>`,
                { parse_mode: "HTML" });
            return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
                mode, code: st.code, fileName: st.fileName
            });
        }

        return bot.answerCallbackQuery(q.id, { text: "Mode tidak valid", show_alert: true }).catch(() => {});
    } catch (e) {
        console.log("[AICODE MODE ERR]", e.message);
    }
});

// ═══ PALET ═══
router.registerCallback("aicode_palette", async (bot, q, data, user, ctx) => {
    try {
        const palette = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);
        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true }).catch(() => {});
        }
        const loading = await bot.sendMessage(q.message.chat.id,
            `<b>✦ Rombak Warna...</b>\n\n<i>Palet: ${escHtml(palette)}</i>`,
            { parse_mode: "HTML" });
        return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
            mode: "color", code: st.code, palette, fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE PALETTE ERR]", e.message); }
});

// ═══ FITUR ═══
router.registerCallback("aicode_feature", async (bot, q, data, user, ctx) => {
    try {
        const feature = data.split(":")[1];
        const userId = String(user.id);
        const st = ctx.getState(userId);
        if (!st || !st.code) {
            return bot.answerCallbackQuery(q.id, { text: "Sesi habis", show_alert: true }).catch(() => {});
        }
        const loading = await bot.sendMessage(q.message.chat.id,
            `<b>✦ Tambah Fitur...</b>\n\n<i>Fitur: ${escHtml(feature)}</i>`,
            { parse_mode: "HTML" });
        return processEdit(bot, q.message.chat.id, loading.message_id, userId, ctx, {
            mode: "feature", code: st.code, feature, fileName: st.fileName
        });
    } catch (e) { console.log("[AICODE FEATURE ERR]", e.message); }
});

// ═══ FIX ERROR (pesan) ═══
router.registerMessage("aicode_fix_error", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const userId = String(msg.from.id);
        const chatId = msg.chat.id;

        if (!state || !state.code) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi habis, kirim ulang code lu.</b>`, { parse_mode: "HTML" });
        }

        let errorMsg = "";
        if (msg.document) {
            if (msg.document.file_size > 200 * 1024) {
                return bot.sendMessage(chatId, `<b>✕ File terlalu besar! Max 200KB.</b>`, { parse_mode: "HTML" });
            }
            try {
                const fileLink = await bot.getFileLink(msg.document.file_id);
                const res = await axios.get(fileLink, { responseType: "text", timeout: 30000 });
                errorMsg = String(res.data).slice(0, 5000);
            } catch (e) {
                return bot.sendMessage(chatId, `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`, { parse_mode: "HTML" });
            }
        } else if (msg.text) {
            errorMsg = msg.text.trim();
        } else {
            return bot.sendMessage(chatId, `<b>✕ Kirim error message atau file log error.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId, `<b>✦ Fix Error...</b>`, { parse_mode: "HTML" });
        return processEdit(bot, chatId, loading.message_id, userId, ctx, {
            mode: "fix", code: state.code,
            errorMsg: errorMsg.toLowerCase() === "skip" ? "" : errorMsg,
            fileName: state.fileName
        });
    } catch (e) { console.log("[AICODE FIX ERROR ERR]", e.message); }
});

// ═══ CUSTOM PROMPT (pesan) ═══
router.registerMessage("aicode_custom_prompt", async (bot, msg, state, ctx) => {
    try {
        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(String(msg.from.id));
            return;
        }

        const userId = String(msg.from.id);
        const chatId = msg.chat.id;
        const customPrompt = (msg.text || "").trim();

        if (!state || !state.code) {
            ctx.clearState(userId);
            return bot.sendMessage(chatId, `<b>✕ Sesi habis, kirim ulang code lu.</b>`, { parse_mode: "HTML" });
        }
        if (customPrompt.length < 3) {
            return bot.sendMessage(chatId, `<b>✕ Prompt terlalu pendek.</b>`, { parse_mode: "HTML" });
        }

        const loading = await bot.sendMessage(chatId,
            `<b>✦ Custom Prompt...</b>\n\n<i>${escHtml(customPrompt.slice(0, 100))}</i>`,
            { parse_mode: "HTML" });
        return processEdit(bot, chatId, loading.message_id, userId, ctx, {
            mode: "custom", code: state.code, customPrompt, fileName: state.fileName
        });
    } catch (e) { console.log("[AICODE CUSTOM ERR]", e.message); }
});

// ═══ CANCEL ═══
router.registerCallback("aicode_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[AICODE CANCEL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// PROCESS EDIT — CORE
// ═══════════════════════════════════════════
async function processEdit(bot, chatId, loadingMsgId, userId, ctx, params) {
    try {
        console.log(`[AICODE PROCESS] mode: ${params.mode} | code: ${params.code.length} chars`);

        // Cek credit sebelum panggil AI, potong setelah berhasil
        const u = ctx.db.getUser(userId);
        if (u.credit < 1) {
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Credit habis!</b>\n\n<i>Beli credit dulu ya.</i>`,
                { reply_markup: { inline_keyboard: [[{ text: "▸ Buy Credit", callback_data: "menu_buycredit", style: "success" }]] } });
        }

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>𖡛 Grok sedang kerja...</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <code>${escHtml(params.mode)}</code>\n` +
            `▸ Code: ${(params.code.length / 1024).toFixed(2)} KB\n` +
            `▸ Model: <code>${escHtml(GROK_MODEL)}</code>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Mohon tunggu 10-60 detik...</i>`);

        const result = await callEditCode(params);

        if (!result || !result.ok) {
            const errMsg = (result?.error || "Unknown error").slice(0, 300);
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Gagal process</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n` +
                `▸ Error: <code>${escHtml(errMsg)}</code>\n` +
                `━━━━━━━━━━━━━━━━━━━━\n\n` +
                `<i>Credit TIDAK dipotong.</i>`,
                { reply_markup: { inline_keyboard: [[
                    { text: "✦ Coba Lagi", callback_data: "menu_aicodeeditor", style: "primary" },
                    { text: "✕ Menu", callback_data: "menu_back", style: "danger" }
                ]] } });
        }

        const cleanText = cleanAIResponse(result.text);
        if (!cleanText || cleanText.length < 10) {
            return safeEdit(bot, chatId, loadingMsgId,
                `<b>✕ Response Grok kosong.</b>\n\n<i>Credit TIDAK dipotong. Coba lagi.</i>`,
                { reply_markup: { inline_keyboard: [[
                    { text: "✦ Coba Lagi", callback_data: "menu_aicodeeditor", style: "primary" }
                ]] } });
        }

        // Potong credit hanya setelah Grok berhasil
        const c = checkAndDeductCredit(ctx, { id: userId }, 1);
        if (!c.ok) {
            return safeEdit(bot, chatId, loadingMsgId, `<b>✕ ${c.error}</b>`);
        }

        const ext = path.extname(params.fileName) || ".txt";
        const baseName = path.basename(params.fileName, ext) || "code";
        const newFileName = `${baseName}_edited${ext}`;
        const newFilePath = path.join(TMP_DIR, `${Date.now()}_${newFileName}`);
        fs.writeFileSync(newFilePath, cleanText, "utf8");

        await safeEdit(bot, chatId, loadingMsgId,
            `<b>✓ HASIL EDIT</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <code>${escHtml(params.mode)}</code>\n` +
            `▸ File: <code>${escHtml(newFileName)}</code>\n` +
            `▸ Model: <code>${escHtml(result.model)}</code>\n` +
            `▸ Credit sisa: ${c.credit}\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File dikirim di bawah.</i>`);

        let sendOk = false;
        try {
            await bot.sendDocument(chatId, newFilePath, {
                caption:
                    `<b>𖡛 AI CODE EDITOR RESULT</b>\n\n` +
                    `▸ Mode: <code>${escHtml(params.mode)}</code>\n` +
                    `▸ File: <code>${escHtml(newFileName)}</code>\n` +
                    `▸ Model: <code>${escHtml(result.model)}</code>\n\n` +
                    `<i>Copy isi file lalu timpa file lama di project lu.</i>`,
                parse_mode: "HTML"
            });
            sendOk = true;
        } catch (e) {
            console.log("[AICODE SEND FILE ERR]", e.message);
            const preview = cleanText.slice(0, 3500);
            try {
                await bot.sendMessage(chatId,
                    `<b>𖡛 HASIL (fallback teks)</b>\n\n<b>File:</b> <code>${escHtml(newFileName)}</code>\n\n` +
                    `<pre>${escHtml(preview)}</pre>` +
                    (cleanText.length > 3500 ? `\n\n<i>...dipotong, file asli ${(cleanText.length / 1024).toFixed(2)} KB</i>` : ""),
                    { parse_mode: "HTML" });
                sendOk = true;
            } catch (e2) {
                console.log("[AICODE SEND TEXT ERR]", e2.message);
            }
        }

        try { fs.unlinkSync(newFilePath); } catch {}

        if (!sendOk) {
            return safeEdit(bot, chatId, loadingMsgId, `<b>✕ Gagal kirim hasil.</b>\n\n<i>Coba lagi.</i>`);
        }

        try {
            await gh.sendBuildNotif(bot, {
                status: "success",
                title: `AI Code Editor — ${params.mode}`,
                subtitle: params.fileName,
                fields: [
                    { label: "Mode", value: params.mode },
                    { label: "File", value: String(params.fileName).slice(0, 30) },
                    { label: "Model", value: result.model },
                    { label: "Credit", value: String(c.credit) }
                ],
                footer: `User: ${userId}`
            });
        } catch (e) {
            console.log("[AICODE NOTIF ERR]", (e.message || "").slice(0, 100));
        }

        console.log(`[AICODE PROCESS] ✓ done | model: ${result.model}`);
    } catch (e) {
        console.log("[AICODE PROCESS ERR]", e.message);
        await safeEdit(bot, chatId, loadingMsgId, `<b>✕ Error:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`);
    }
}

module.exports = {};
console.log("[AI CODE EDITOR] v7 loaded — Grok (xAI) langsung");