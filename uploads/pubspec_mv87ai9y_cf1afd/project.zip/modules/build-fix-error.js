const router = require("./router");
const cfg = require("../config");
const fs = require("fs");
const path = require("path");
const axios = require("axios");
const AdmZip = require("adm-zip");
const sharp = require("sharp");

const TMP_DIR = path.join(__dirname, "..", "tmp_build");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

// ═══ MAX ZIP 2GB ═══
const MAX_ZIP_SIZE = 2 * 1024 * 1024 * 1024;

// ═══ SKIP DIRS ═══
const SKIP_DIRS = new Set([
    "node_modules", ".git", ".github_backup", "build", "dist",
    ".gradle", "__pycache__", ".vscode", ".idea",
    ".dart_tool", ".flutter-plugins"
]);

// ═══ ESCAPE HTML ═══
function escHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

// ═══ SAFE EDIT ═══
async function safeEdit(bot, chatId, msgId, text, options = {}) {
    if (!msgId) return null;
    try {
        return await bot.editMessageText(text, {
            chat_id: chatId, message_id: msgId, parse_mode: "HTML", ...options
        });
    } catch (e) {
        const msg = e.message || "";
        if (msg.includes("message is not modified")) return null;
        if (msg.includes("message to edit not found") || msg.includes("MESSAGE_ID_INVALID")) {
            try { return await bot.sendMessage(chatId, text, { parse_mode: "HTML", ...options }); } catch { return null; }
        }
        return null;
    }
}

// ═══ FIND FILES ═══
function findAllFiles(dir, results = []) {
    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); }
    catch { return results; }
    for (const item of items) {
        const full = path.join(dir, item.name);
        if (item.isDirectory()) {
            if (SKIP_DIRS.has(item.name)) continue;
            findAllFiles(full, results);
        } else {
            results.push(full);
        }
    }
    return results;
}

// ═══ PROGRESS BAR ═══
function progressBar(pct) {
    const total = 16;
    const filled = Math.round((pct / 100) * total);
    return "■".repeat(filled) + "□".repeat(total - filled);
}

// ═══════════════════════════════════════════
// DOWNLOAD FILE VIA GRAMJS (2GB support)
// ═══════════════════════════════════════════
async function downloadFileViaGramJS(bot, ctx, chatId, messageId, destPath, onProgress) {
    const gramjsDownloader = require("../libs/gramjs-downloader");

    if (!gramjsDownloader.isReady()) {
        throw new Error("GramJS client belum ready. Login user session dulu via Owner Menu.");
    }

    // Target chat: grup storage atau owner
    // Normalize a common config typo ("--100…") before calling Telegram Bot API.
    const rawTargetChat = cfg.BOT_STORAGE_CHAT_ID || cfg.OWNER_ID;
    const targetChat = typeof rawTargetChat === "string" ? rawTargetChat.replace(/^--(?=100\d+$)/, "-").trim() : rawTargetChat;
    if (!targetChat) {
        throw new Error("BOT_STORAGE_CHAT_ID / OWNER_ID belum di-set di config.js");
    }

    console.log("[BUILDFIX DL] Forward file ke:", targetChat);
    let forwarded;
    try {
        try { await bot.getChat(targetChat); }
        catch (resolveError) {
            throw new Error(`Tujuan storage tidak ditemukan (${String(targetChat)}). Periksa BOT_STORAGE_CHAT_ID, pastikan bot sudah menjadi anggota/admin, dan pastikan channel privat memberi akses. Detail: ${resolveError.message}`);
        }
        forwarded = await bot.forwardMessage(targetChat, chatId, messageId);
        console.log("[BUILDFIX DL] Forwarded, msg_id:", forwarded.message_id);
    } catch (e) {
        throw new Error(`Gagal forward: ${e.message}`);
    }

    // Tunggu sync MTProto
    await new Promise(r => setTimeout(r, 2000));

    const client = await gramjsDownloader.getClient();
    if (!client) throw new Error("GramJS client gagal init");

    // Resolve entity
    let entity = targetChat;
    if (/^-?\d+$/.test(String(targetChat))) {
        try {
            entity = await client.getInputEntity(Number(targetChat));
            console.log("[BUILDFIX DL] Entity resolved");
        } catch (e) {
            console.log("[BUILDFIX DL] resolve fail:", e.message);
        }
    }

    // Ambil messages terbaru
    let messages;
    try {
        messages = await client.getMessages(entity, { limit: 5 });
    } catch (e) {
        throw new Error(`Gagal ambil messages: ${e.message}`);
    }

    if (!messages || messages.length === 0) {
        throw new Error("Gak dapet message di target chat");
    }

    const latestMsg = messages.find(m => m.media);
    if (!latestMsg) throw new Error("Gak ada file di target chat");

    console.log("[BUILDFIX DL] Download via GramJS...");
    const result = await gramjsDownloader.downloadFromMessage(latestMsg, destPath, onProgress);

    // After the base has been downloaded successfully, remove the original message
    // from the source chat/group. This requires the bot to have delete-message
    // permission in that chat; the temporary storage copy is cleaned up below.
    try {
        await bot.deleteMessage(chatId, messageId);
        console.log("[BASE CLEANUP] Original base message deleted from source chat:", chatId, messageId);
    } catch (deleteError) {
        console.warn("[BASE CLEANUP] Could not delete original message (check bot admin/delete permission):", deleteError.message);
    }

    // Cleanup
    try {
        await client.deleteMessages(entity, [latestMsg.id], { revoke: true });
    } catch {}

    return result;
}

// ═══════════════════════════════════════════
// DETECT ERROR — PUBSPEC.YAML
// ═══════════════════════════════════════════
function fixPubspec(extractDir) {
    const issues = [];
    const fixes = [];
    const pubspecPath = path.join(extractDir, "pubspec.yaml");

    if (!fs.existsSync(pubspecPath)) {
        issues.push({
            file: "pubspec.yaml",
            type: "missing",
            desc: "File pubspec.yaml tidak ditemukan",
            severity: "high"
        });
        return { issues, fixes };
    }

    let content = fs.readFileSync(pubspecPath, "utf8");
    const original = content;

    // 1. CHECK NAME
    const nameMatch = content.match(/^name:\s*(.+)$/m);
    if (nameMatch) {
        const name = nameMatch[1].trim();
        if (!/^[a-z][a-z0-9_]*$/.test(name)) {
            const fixedName = name.toLowerCase().replace(/[^a-z0-9_]/g, "_").replace(/^[^a-z]/, "a");
            content = content.replace(/^name:\s*.+$/m, `name: ${fixedName}`);
            fixes.push({
                file: "pubspec.yaml", type: "fix",
                desc: `Fix name: "${name}" → "${fixedName}"`
            });
            issues.push({
                file: "pubspec.yaml", type: "invalid_name",
                desc: `Nama package "${name}" tidak valid`,
                severity: "high"
            });
        }
    } else {
        content = `name: app\n${content}`;
        fixes.push({ file: "pubspec.yaml", type: "add", desc: "Tambah name: app" });
        issues.push({ file: "pubspec.yaml", type: "missing_name", desc: "Field 'name' tidak ada", severity: "high" });
    }

    // 2. CHECK SDK VERSION
    if (!content.match(/environment:\s*[\s\S]*?sdk:/)) {
        content = content.replace(
            /^(version:.*)$/m,
            "$1\n\nenvironment:\n  sdk: '>=3.0.0 <4.0.0'"
        );
        if (!content.includes("environment:")) {
            content += `\n\nenvironment:\n  sdk: '>=3.0.0 <4.0.0'\n`;
        }
        fixes.push({ file: "pubspec.yaml", type: "add", desc: "Tambah environment.sdk" });
        issues.push({ file: "pubspec.yaml", type: "missing_sdk", desc: "Field 'environment.sdk' tidak ada", severity: "medium" });
    }

    // 3. CHECK DEPENDENCIES
    if (!content.match(/dependencies:\s*[\s\S]*?flutter:/)) {
        if (!content.includes("flutter:")) {
            content += `\ndependencies:\n  flutter:\n    sdk: flutter\n  cupertino_icons: ^1.0.6\n`;
            fixes.push({ file: "pubspec.yaml", type: "add", desc: "Tambah dependencies dasar" });
            issues.push({ file: "pubspec.yaml", type: "missing_deps", desc: "Dependencies dasar tidak ada", severity: "high" });
        }
    }

    // 4. flutter section
    if (!content.includes("flutter:") || !content.match(/flutter:\s*\n\s+uses-material-design/)) {
        content += `\nflutter:\n  uses-material-design: true\n`;
        fixes.push({ file: "pubspec.yaml", type: "add", desc: "Tambah flutter.uses-material-design" });
    }

    // 5. assets check
    const assetsMatches = content.match(/^\s*-\s+(assets\/[^\s]+)$/gm);
    if (assetsMatches) {
        for (const m of assetsMatches) {
            const assetPath = m.replace(/^\s*-\s+/, "").trim();
            const fullAssetPath = path.join(extractDir, assetPath);
            if (!fs.existsSync(fullAssetPath)) {
                content = content.replace(new RegExp(`^\\s*-\\s+${assetPath.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*$\\n?`, "gm"), "");
                fixes.push({ file: "pubspec.yaml", type: "remove", desc: `Hapus asset gak ada: ${assetPath}` });
                issues.push({ file: "pubspec.yaml", type: "missing_asset", desc: `Asset "${assetPath}" gak ada`, severity: "medium" });
            }
        }
    }

    if (content !== original) {
        fs.writeFileSync(pubspecPath, content, "utf8");
    }

    return { issues, fixes };
}

// ═══════════════════════════════════════════
// DETECT ERROR — DART FILES
// ═══════════════════════════════════════════
function fixDartFiles(extractDir) {
    const issues = [];
    const fixes = [];
    const allFiles = findAllFiles(extractDir);
    const dartFiles = allFiles.filter(f => f.endsWith(".dart"));

    for (const file of dartFiles) {
        try {
            const content = fs.readFileSync(file, "utf8");
            const relPath = path.relative(extractDir, file);
            const fixed = content;

            // Check import paths
            const importRegex = /import\s+['"]([^'"]+)['"]/g;
            let m;
            while ((m = importRegex.exec(content)) !== null) {
                const importPath = m[1];
                if (importPath.startsWith("package:") || importPath.startsWith("dart:")) continue;
                if (importPath.startsWith("./") || importPath.startsWith("../")) {
                    const resolvedPath = path.resolve(path.dirname(file), importPath);
                    if (!fs.existsSync(resolvedPath)) {
                        issues.push({
                            file: relPath, type: "missing_import",
                            desc: `Import "${importPath}" tidak ada`,
                            severity: "high"
                        });
                    }
                }
            }

            // Check @override
            if (/Widget\s+build\s*\([^)]*\)\s*\{/.test(content) && !content.includes("@override")) {
                issues.push({
                    file: relPath, type: "missing_override",
                    desc: "build() method gak ada @override",
                    severity: "low"
                });
            }

            // Check semicolon
            const lines = content.split("\n");
            const semicolonIssues = lines.filter((l, i) => {
                const trim = l.trim();
                if (!trim) return false;
                if (trim.endsWith(";") || trim.endsWith("{") || trim.endsWith("}")) return false;
                if (trim.endsWith(",") || trim.endsWith(":")) return false;
                if (trim.startsWith("//") || trim.startsWith("*")) return false;
                if (trim.endsWith("(")) return false;
                if (trim.endsWith(")")) {
                    const next = lines[i + 1]?.trim() || "";
                    if (next.startsWith(";") || next.startsWith(".")) return false;
                    return true;
                }
                return false;
            });

            if (semicolonIssues.length > 0) {
                issues.push({
                    file: relPath, type: "possible_missing_semicolon",
                    desc: `${semicolonIssues.length} baris mungkin kurang ;`,
                    severity: "medium", sample: semicolonIssues.slice(0, 3)
                });
            }

            if (fixed !== content) {
                fs.writeFileSync(file, fixed, "utf8");
            }
        } catch (e) {
            console.log("[FIX DART] skip:", file, e.message);
        }
    }

    return { issues, fixes };
}

// ═══════════════════════════════════════════
// DETECT ERROR — NATIVE
// ═══════════════════════════════════════════
function fixNative(extractDir) {
    const issues = [];
    const fixes = [];

    const buildGradle = path.join(extractDir, "android", "app", "build.gradle");
    if (fs.existsSync(buildGradle)) {
        let content = fs.readFileSync(buildGradle, "utf8");
        const original = content;

        if (!content.match(/minSdkVersion\s+\d+/)) {
            if (content.includes("minSdkVersion")) {
                content = content.replace(/minSdkVersion\s+flutter\.minSdkVersion/, "minSdkVersion 21");
            } else {
                content = content.replace(/defaultConfig\s*\{/, "defaultConfig {\n        minSdkVersion 21");
            }
            fixes.push({ file: "android/app/build.gradle", type: "fix", desc: "Fix minSdkVersion ke 21" });
        }

        if (!content.match(/compileSdkVersion\s+\d+/)) {
            content = content.replace(/defaultConfig\s*\{/, "defaultConfig {\n        compileSdkVersion 34");
            fixes.push({ file: "android/app/build.gradle", type: "fix", desc: "Fix compileSdkVersion ke 34" });
        }

        if (!content.match(/targetSdkVersion\s+\d+/)) {
            content = content.replace(/defaultConfig\s*\{/, "defaultConfig {\n        targetSdkVersion 34");
            fixes.push({ file: "android/app/build.gradle", type: "fix", desc: "Fix targetSdkVersion ke 34" });
        }

        if (content !== original) {
            fs.writeFileSync(buildGradle, content, "utf8");
        }
    } else {
        issues.push({
            file: "android/app/build.gradle", type: "missing",
            desc: "File build.gradle Android tidak ada", severity: "high"
        });
    }

    const manifest = path.join(extractDir, "android", "app", "src", "main", "AndroidManifest.xml");
    if (fs.existsSync(manifest)) {
        let content = fs.readFileSync(manifest, "utf8");
        const original = content;

        if (!content.match(/package\s*=\s*["'][^"']+["']/)) {
            issues.push({
                file: "android/app/src/main/AndroidManifest.xml",
                type: "missing_package", desc: "Package declaration hilang", severity: "high"
            });
        }

        if (!content.includes('android.permission.INTERNET') && !content.includes('uses-permission')) {
            content = content.replace(/<manifest([^>]*)>/, `<manifest$1>\n    <uses-permission android:name="android.permission.INTERNET" />`);
            fixes.push({ file: "android/app/src/main/AndroidManifest.xml", type: "add", desc: "Tambah INTERNET permission" });
        }

        if (content !== original) {
            fs.writeFileSync(manifest, content, "utf8");
        }
    }

    const gradleProps = path.join(extractDir, "android", "gradle.properties");
    if (!fs.existsSync(gradleProps)) {
        const props = `org.gradle.jvmargs=-Xmx4G -XX:MaxMetaspaceSize=2G -XX:+HeapDumpOnOutOfMemoryError
android.useAndroidX=true
android.enableJetifier=true
`;
        const propsDir = path.join(extractDir, "android");
        if (fs.existsSync(propsDir)) {
            fs.writeFileSync(gradleProps, props, "utf8");
            fixes.push({ file: "android/gradle.properties", type: "add", desc: "Bikin gradle.properties default" });
            issues.push({ file: "android/gradle.properties", type: "missing", desc: "gradle.properties gak ada", severity: "medium" });
        }
    }

    const gradleWrapper = path.join(extractDir, "android", "gradle", "wrapper", "gradle-wrapper.properties");
    if (fs.existsSync(gradleWrapper)) {
        let content = fs.readFileSync(gradleWrapper, "utf8");
        const original = content;

        if (!content.includes("distributionUrl")) {
            content += `\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.0-all.zip\n`;
            fixes.push({ file: "android/gradle/wrapper/gradle-wrapper.properties", type: "add", desc: "Tambah distributionUrl" });
        }

        if (content !== original) {
            fs.writeFileSync(gradleWrapper, content, "utf8");
        }
    }

    return { issues, fixes };
}

// ═══════════════════════════════════════════
// DETECT ERROR — WORKFLOWS
// ═══════════════════════════════════════════
function fixWorkflows(extractDir) {
    const issues = [];
    const fixes = [];

    const workflowsDir = path.join(extractDir, ".github", "workflows");

    if (!fs.existsSync(workflowsDir)) {
        fs.mkdirSync(workflowsDir, { recursive: true });

        const defaultWorkflow = `name: Build APK
on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.16.0'
          channel: 'stable'
      - run: flutter pub get
      - run: flutter build apk --release
      - uses: actions/upload-artifact@v4
        with:
          name: release-apk
          path: build/app/outputs/flutter-apk/app-release.apk
`;
        fs.writeFileSync(path.join(workflowsDir, "build.yml"), defaultWorkflow, "utf8");
        fixes.push({ file: ".github/workflows/build.yml", type: "add", desc: "Bikin workflow default" });
        issues.push({ file: ".github/workflows/", type: "missing", desc: "Folder workflows gak ada", severity: "high" });
    } else {
        const files = fs.readdirSync(workflowsDir).filter(f => f.endsWith(".yml") || f.endsWith(".yaml"));

        if (files.length === 0) {
            issues.push({ file: ".github/workflows/", type: "empty", desc: "Folder workflows kosong", severity: "high" });
        }

        for (const f of files) {
            const wfPath = path.join(workflowsDir, f);
            let content = fs.readFileSync(wfPath, "utf8");
            const original = content;
            const relPath = `.github/workflows/${f}`;

            if (content.match(/actions\/upload-artifact@v[1-3]/)) {
                content = content.replace(/actions\/upload-artifact@v[1-3]/g, "actions/upload-artifact@v4");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade upload-artifact ke v4" });
            }

            if (content.match(/actions\/checkout@v[1-3]/)) {
                content = content.replace(/actions\/checkout@v[1-3]/g, "actions/checkout@v4");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade checkout ke v4" });
            }

            if (content.match(/actions\/setup-java@v[1-3]/)) {
                content = content.replace(/actions\/setup-java@v[1-3]/g, "actions/setup-java@v4");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade setup-java ke v4" });
            }

            if (content.match(/actions\/setup-node@v[1-3]/)) {
                content = content.replace(/actions\/setup-node@v[1-3]/g, "actions/setup-node@v4");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade setup-node ke v4" });
            }

            if (content.match(/java-version:\s*['"]?(?:[1-9]|1[0-1])['"]?/)) {
                content = content.replace(/java-version:\s*['"]?(?:[1-9]|1[0-1])['"]?/g, "java-version: '17'");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade Java ke 17" });
            }

            if (content.includes("upload-artifact") && !content.includes("permissions:")) {
                content = content.replace(/^on:/m, "permissions:\n  contents: write\n\non:");
                fixes.push({ file: relPath, type: "add", desc: "Tambah permissions" });
            }

            if (content.includes("runs-on: ubuntu-18.04") || content.includes("runs-on: ubuntu-20.04")) {
                content = content.replace(/runs-on:\s*ubuntu-(?:18\.04|20\.04)/g, "runs-on: ubuntu-latest");
                fixes.push({ file: relPath, type: "upgrade", desc: "Upgrade ubuntu-latest" });
            }

            if (content !== original) {
                fs.writeFileSync(wfPath, content, "utf8");
            }
        }
    }

    return { issues, fixes };
}

// ═══════════════════════════════════════════
// GENERATE NOTIF CARD
// ═══════════════════════════════════════════
async function generateFixCard(data) {
    try {
        const W = 900;
        const H = 500;

        const esc = (s) => String(s || "").replace(/[<>&'"]/g, ch => ({
            "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
        }[ch]));

        const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#1e1b4b"/>
      <stop offset="50%" stop-color="#4c1d95"/>
      <stop offset="100%" stop-color="#1e1b4b"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#fef3c7"/>
      <stop offset="50%" stop-color="#fbbf24"/>
      <stop offset="100%" stop-color="#d97706"/>
    </linearGradient>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#bgGrad)"/>
  <rect x="10" y="10" width="${W-20}" height="${H-20}" rx="20" fill="none" stroke="url(#goldGrad)" stroke-width="3"/>
  <text x="${W/2}" y="65" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="32" fill="url(#goldGrad)" font-weight="900">𖡛 FIX ERROR BUILD 𖡛</text>
  <line x1="100" y1="85" x2="${W-100}" y2="85" stroke="url(#goldGrad)" stroke-width="2"/>
  <rect x="${W/2 - 200}" y="110" width="400" height="70" rx="35" fill="${data.status === 'success' ? '#22c55e' : '#ef4444'}" stroke="#ffffff" stroke-width="3"/>
  <text x="${W/2}" y="157" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="30" fill="#ffffff" font-weight="900">${data.status === 'success' ? '✓ FIXED' : '✕ PARTIAL'}</text>
  <text x="80" y="240" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">User</text>
  <text x="220" y="240" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.userName)}</text>
  <text x="80" y="280" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Base</text>
  <text x="220" y="280" font-family="Courier New, monospace" font-size="18" fill="#fbbf24" font-weight="700">${esc(data.fileName.slice(0, 50))}</text>
  <text x="80" y="320" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Mode</text>
  <text x="220" y="320" font-family="Arial, sans-serif" font-size="20" fill="#ffffff" font-weight="700">${esc(data.mode)}</text>
  <text x="80" y="360" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Issues</text>
  <text x="220" y="360" font-family="Arial, sans-serif" font-size="20" fill="#ef4444" font-weight="700">${data.issueCount}</text>
  <text x="80" y="400" font-family="Arial, sans-serif" font-size="20" fill="#94a3b8">Fixed</text>
  <text x="220" y="400" font-family="Arial, sans-serif" font-size="20" fill="#22c55e" font-weight="700">${data.fixCount}</text>
  <line x1="100" y1="440" x2="${W-100}" y2="440" stroke="url(#goldGrad)" stroke-width="2"/>
  <text x="${W/2}" y="475" text-anchor="middle" font-family="Arial Black, sans-serif" font-size="18" fill="#94a3b8">${esc(cfg.OWNER_USERNAME || "@biscuitMD")} • SpartaX Bot</text>
</svg>`.trim();

        return await sharp(Buffer.from(svg)).png().toBuffer();
    } catch (e) {
        console.log("[FIX CARD ERR]", e.message);
        return null;
    }
}

// ═══════════════════════════════════════════
// MENU BUILD FIX ERROR
// ═══════════════════════════════════════════
router.registerCallback("menu_buildfix", async (bot, q, data, user, ctx) => {
    try {
        const caption =
            `<b>𖡛 BUILD FIX ERROR</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Fitur: Fix error base biar siap di-build\n` +
            `▸ Kirim: File <b>.zip</b> base yang error\n` +
            `▸ Output: <b>.zip fixed + error.txt</b>\n` +
            `▸ Max File: <b>2 GB</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<b>Pilih mode:</b>`;
        const kb = [
            [
                { text: "✦ Fix Pubspec/Dart", callback_data: "buildfix_mode:pubspec", style: "success" },
                { text: "✦ Fix Native+Workflows", callback_data: "buildfix_mode:native", style: "primary" }
            ],
            [
                { text: "✦ Fix All (Rekomendasi)", callback_data: "buildfix_mode:all", style: "danger" }
            ],
            [
                { text: "✕ Kembali", callback_data: "menu_buildmenu", style: "danger" }
            ]
        ];
        await bot.sendMessage(q.message.chat.id, caption, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: kb }
        });
    } catch (e) { console.log("[BUILD FIX MENU ERR]", e.message); }
});

// ═══ CALLBACK: PILIH MODE ═══
router.registerCallback("buildfix_mode", async (bot, q, data, user, ctx) => {
    try {
        const mode = data.split(":")[1];
        const chatId = q.message.chat.id;
        const userId = String(user.id);

        await bot.answerCallbackQuery(q.id, { text: "OK", show_alert: false }).catch(() => {});

        const modeInfo = {
            pubspec: { label: "Pubspec/Dart Fix", desc: "Fix error pubspec.yaml & file .dart" },
            native: { label: "Native + Workflows Fix", desc: "Fix error Android native & .github/workflows" },
            all: { label: "Full Fix", desc: "Fix semua error (pubspec + dart + native + workflows)" }
        };

        const info = modeInfo[mode] || modeInfo.all;

        ctx.clearState(userId);
        ctx.setState(userId, "buildfix_await_zip", { mode });

        await bot.sendMessage(chatId,
            `<b>𖡛 BUILD FIX — ${escHtml(info.label)}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ Mode: <b>${escHtml(info.label)}</b>\n` +
            `▸ Info: ${escHtml(info.desc)}\n` +
            `▸ Max: <b>2 GB</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>Kirim file .zip base yang mau di-fix:</i>`,
            { parse_mode: "HTML",
              reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "buildfix_cancel", style: "danger" }]] } });
    } catch (e) { console.log("[BUILDFIX MODE ERR]", e.message); }
});

// ═══ TERIMA ZIP ═══
router.registerMessage("buildfix_await_zip", async (bot, msg, state, ctx) => {
    let workDir = null;
    try {
        const chatId = msg.chat.id;
        const userId = String(msg.from.id);
        const mode = state.mode || "all";

        if (msg.text && msg.text.startsWith("/")) {
            ctx.clearState(userId);
            return;
        }

        if (!msg.document) {
            return bot.sendMessage(chatId, `<b>✕ Kirim file .zip</b>`, { parse_mode: "HTML" });
        }

        const fname = msg.document.file_name || "base.zip";
        if (!fname.endsWith(".zip")) {
            return bot.sendMessage(chatId, `<b>✕ File harus .zip</b>`, { parse_mode: "HTML" });
        }

        // ⚡ MAX ZIP 2GB
        if (msg.document.file_size > MAX_ZIP_SIZE) {
            return bot.sendMessage(chatId,
                `<b>✕ File terlalu besar!</b>\n\n` +
                `▸ Size: ${(msg.document.file_size / 1024 / 1024 / 1024).toFixed(2)} GB\n` +
                `▸ Max: <b>2 GB</b>`,
                { parse_mode: "HTML" });
        }

        const jobId = `fix_${Date.now().toString(36)}`;
        workDir = path.join(TMP_DIR, jobId);
        if (!fs.existsSync(workDir)) fs.mkdirSync(workDir, { recursive: true });

        const loading = await bot.sendMessage(chatId,
            `<b>𖡛 BUILD FIX</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(5)}]</code> <b>5%</b>\n` +
            `▸ File: <code>${escHtml(fname)}</code>\n` +
            `▸ Status: Download via GramJS...\n` +
            `▸ Size: ${(msg.document.file_size / 1024 / 1024).toFixed(2)} MB\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        // ═══ DOWNLOAD VIA GRAMJS ═══
        const zipPath = path.join(workDir, fname);
        let dlResult;
        try {
            dlResult = await downloadFileViaGramJS(
                bot, ctx, chatId, msg.message_id, zipPath,
                async (pct, info) => {
                    await safeEdit(bot, chatId, loading.message_id,
                        `<b>𖡛 BUILD FIX</b>\n\n` +
                        `━━━━━━━━━━━━━━━━━━━━\n` +
                        `<code>[${progressBar(pct)}]</code> <b>${pct}%</b>\n` +
                        `▸ File: <code>${escHtml(fname)}</code>\n` +
                        `▸ Status: Download via GramJS\n` +
                        `▸ Info: <code>${info}</code>\n` +
                        `━━━━━━━━━━━━━━━━━━━━`,
                        { parse_mode: "HTML" });
                }
            );
            console.log("[BUILD FIX] ✅ download:", dlResult.size, "bytes");
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal download:</b>\n<code>${escHtml(e.message.slice(0, 200))}</code>`,
                { parse_mode: "HTML" });
        }

        // ═══ EXTRACT ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 BUILD FIX</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(25)}]</code> <b>25%</b>\n` +
            `▸ File: <code>${escHtml(fname)}</code>\n` +
            `▸ Status: Extract zip...\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        const extractDir = path.join(workDir, "extracted");
        fs.mkdirSync(extractDir, { recursive: true });
        try {
            const zip = new AdmZip(zipPath);
            zip.extractAllTo(extractDir, true);
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal extract:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`,
                { parse_mode: "HTML" });
        }

        // ═══ SCAN & FIX ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 BUILD FIX</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(50)}]</code> <b>50%</b>\n` +
            `▸ Status: Scan error & fix...\n` +
            `▸ Mode: <b>${escHtml(mode)}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        const allIssues = [];
        const allFixes = [];

        if (mode === "pubspec" || mode === "all") {
            const pubResult = fixPubspec(extractDir);
            allIssues.push(...pubResult.issues);
            allFixes.push(...pubResult.fixes);

            const dartResult = fixDartFiles(extractDir);
            allIssues.push(...dartResult.issues);
            allFixes.push(...dartResult.fixes);
        }

        if (mode === "native" || mode === "all") {
            const nativeResult = fixNative(extractDir);
            allIssues.push(...nativeResult.issues);
            allFixes.push(...nativeResult.fixes);

            const wfResult = fixWorkflows(extractDir);
            allIssues.push(...wfResult.issues);
            allFixes.push(...wfResult.fixes);
        }

        console.log(`[BUILD FIX] ${allIssues.length} issues, ${allFixes.length} fixes`);

        // ═══ GENERATE ERROR.TXT ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 BUILD FIX</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(75)}]</code> <b>75%</b>\n` +
            `▸ Status: Generate report...\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        const errorTxt = generateErrorReport({
            fileName: fname, mode,
            issues: allIssues, fixes: allFixes,
            timestamp: new Date().toISOString()
        });

        const errorTxtPath = path.join(workDir, "error.txt");
        fs.writeFileSync(errorTxtPath, errorTxt, "utf8");

        // ═══ RE-ZIP ═══
        await safeEdit(bot, chatId, loading.message_id,
            `<b>𖡛 BUILD FIX</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `<code>[${progressBar(90)}]</code> <b>90%</b>\n` +
            `▸ Status: Re-zip...\n` +
            `━━━━━━━━━━━━━━━━━━━━`,
            { parse_mode: "HTML" });

        const outZipPath = path.join(workDir, `fixed_${fname}`);
        try {
            const newZip = new AdmZip();
            newZip.addLocalFolder(extractDir);
            newZip.writeZip(outZipPath);
        } catch (e) {
            try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
            return safeEdit(bot, chatId, loading.message_id,
                `<b>✕ Gagal re-zip:</b>\n<code>${escHtml(e.message.slice(0, 150))}</code>`,
                { parse_mode: "HTML" });
        }

        const stat = fs.statSync(outZipPath);
        const sizeMB = (stat.size / 1024 / 1024).toFixed(2);

        // ═══ KIRIM FILE ═══
        try { await bot.deleteMessage(chatId, loading.message_id); } catch {}

        const status = allFixes.length > 0 ? "success" : "partial";
        const statusEmoji = status === "success" ? "✓" : "⚠️";

        const caption =
            `<b>${statusEmoji} BUILD FIX ${status === "success" ? "SUCCESS" : "PARTIAL"}</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n` +
            `▸ File: <code>${escHtml(fname)}</code>\n` +
            `▸ Mode: <b>${escHtml(mode)}</b>\n` +
            `▸ Size: ${sizeMB} MB\n` +
            `▸ Issues: <b>${allIssues.length}</b>\n` +
            `▸ Fixed: <b>${allFixes.length}</b>\n` +
            `━━━━━━━━━━━━━━━━━━━━\n\n` +
            `<i>File .zip + error.txt dikirim di bawah.</i>`;

        try {
            await bot.sendDocument(chatId, outZipPath, {
                caption,
                parse_mode: "HTML",
                reply_markup: { inline_keyboard: [
                    [{ text: "✦ Fix Lagi", callback_data: "menu_buildfix", style: "success" }],
                    [{ text: "✕ Menu", callback_data: "menu_back", style: "danger" }]
                ] }
            }, { filename: `fixed_${fname}`, contentType: "application/zip" });
        } catch (e) {
            console.log("[FIX SEND ERR]", e.message);
        }

        try {
            await bot.sendDocument(chatId, errorTxtPath, {
                caption:
                    `<b>✕ ERROR REPORT</b>\n\n` +
                    `▸ Total issues: <b>${allIssues.length}</b>\n` +
                    `▸ Total fixed: <b>${allFixes.length}</b>\n` +
                    `▸ Prompt AI included: <b>Ya</b>\n\n` +
                    `<i>Pake prompt ini di ChatGPT/Claude kalo masih error.</i>`,
                parse_mode: "HTML"
            }, { filename: "error.txt", contentType: "text/plain" });
        } catch (e) {
            console.log("[FIX ERROR.TXT SEND ERR]", e.message);
        }

        // ═══ NOTIF CHANNEL ═══
        try {
            const channelId = cfg.NOTIF_CHANNEL || (cfg.ORDER && cfg.ORDER.ORDER_CHANNEL);
            if (channelId) {
                const cardBuf = await generateFixCard({
                    userName: `${user.first_name || "User"}${user.last_name ? " " + user.last_name : ""}`,
                    userId: user.id, fileName: fname, mode,
                    issueCount: allIssues.length, fixCount: allFixes.length,
                    status
                });

                const notifCaption =
                    `<b>𖡛 BUILD FIX ${status.toUpperCase()}</b>\n\n` +
                    `▸ User: ${escHtml(user.first_name || "User")}\n` +
                    `▸ ID: <code>${user.id}</code>\n` +
                    `▸ File: <code>${escHtml(fname)}</code>\n` +
                    `▸ Mode: <b>${escHtml(mode)}</b>\n` +
                    `▸ Issues: <b>${allIssues.length}</b> | Fixed: <b>${allFixes.length}</b>`;

                if (cardBuf) {
                    try {
                        await bot.sendPhoto(channelId, cardBuf, { caption: notifCaption, parse_mode: "HTML" });
                    } catch {
                        await bot.sendMessage(channelId, notifCaption, { parse_mode: "HTML" });
                    }
                } else {
                    await bot.sendMessage(channelId, notifCaption, { parse_mode: "HTML" });
                }
            }
        } catch (e) {
            console.log("[FIX NOTIF ERR]", e.message);
        }

        try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
        ctx.clearState(userId);
    } catch (e) {
        console.log("[BUILDFIX ERR]", e.message);
        if (workDir) try { fs.rmSync(workDir, { recursive: true, force: true }); } catch {}
    }
});

// ═══════════════════════════════════════════
// GENERATE ERROR REPORT + AI PROMPT
// ═══════════════════════════════════════════
function generateErrorReport({ fileName, mode, issues, fixes, timestamp }) {
    const lines = [];
    lines.push("═".repeat(60));
    lines.push("           ERROR REPORT — BUILD FIX");
    lines.push("           Powered by SpartaX Bot");
    lines.push("═".repeat(60));
    lines.push("");
    lines.push(`File   : ${fileName}`);
    lines.push(`Mode   : ${mode}`);
    lines.push(`Date   : ${timestamp}`);
    lines.push(`Issues : ${issues.length}`);
    lines.push(`Fixed  : ${fixes.length}`);
    lines.push("");
    lines.push("─".repeat(60));
    lines.push("ISSUES FOUND:");
    lines.push("─".repeat(60));
    if (issues.length === 0) {
        lines.push("(Ga ada issue yang terdeteksi)");
    } else {
        issues.forEach((iss, i) => {
            lines.push(`${i + 1}. [${(iss.severity || "info").toUpperCase()}] ${iss.file || "?"}`);
            lines.push(`   Type: ${iss.type || "?"}`);
            lines.push(`   Desc: ${iss.desc || "?"}`);
            if (iss.sample) {
                lines.push(`   Sample: ${JSON.stringify(iss.sample).slice(0, 100)}`);
            }
            lines.push("");
        });
    }
    lines.push("");
    lines.push("─".repeat(60));
    lines.push("FIXES APPLIED:");
    lines.push("─".repeat(60));
    if (fixes.length === 0) {
        lines.push("(Ga ada fix yang bisa diterapin otomatis)");
    } else {
        fixes.forEach((fix, i) => {
            lines.push(`${i + 1}. ${fix.file || "?"}`);
            lines.push(`   Type: ${fix.type || "?"}`);
            lines.push(`   Desc: ${fix.desc || "?"}`);
            lines.push("");
        });
    }
    lines.push("");
    lines.push("═".repeat(60));
    lines.push("           PROMPT UNTUK AI LAIN");
    lines.push("           (ChatGPT / Claude / Gemini)");
    lines.push("═".repeat(60));
    lines.push("");
    lines.push("Copy paste prompt di bawah ini ke AI lain buat fix error yang");
    lines.push("masih tersisa (kalo ada):");
    lines.push("");
    lines.push("─".repeat(60));
    lines.push("");
    lines.push("Tolong fix error build Flutter/Dart ini. Aku punya file:");
    lines.push(`- Nama: ${fileName}`);
    lines.push(`- Jumlah issue: ${issues.length}`);
    lines.push("");
    lines.push("Detail error yang ke-detect:");
    issues.slice(0, 10).forEach((iss, i) => {
        lines.push(`${i + 1}. [${iss.severity || "info"}] ${iss.file || "?"} — ${iss.desc || "?"}`);
    });
    lines.push("");
    lines.push("FIX YANG DIBUTUHKAN:");
    lines.push("1. Perbaiki semua error di atas");
    lines.push("2. Pastiin code bisa di-build tanpa error");
    lines.push("3. Kasih kode fixed lengkap per file");
    lines.push("");
    lines.push("FORMAT RESPON:");
    lines.push("📄 file_path.dart");
    lines.push("```dart");
    lines.push("(kode fixed lengkap)");
    lines.push("```");
    lines.push("");
    lines.push("─".repeat(60));
    lines.push("");
    lines.push("Sekian. Salam SpartaX 🪐");
    lines.push("");
    lines.push("═".repeat(60));

    return lines.join("\n");
}

// ═══ CANCEL ═══
router.registerCallback("buildfix_cancel", async (bot, q, data, user, ctx) => {
    try {
        ctx.clearState(String(user.id));
        await bot.answerCallbackQuery(q.id, { text: "✓ Dibatalkan", show_alert: false });
        await bot.sendMessage(q.message.chat.id, `<b>✕ Dibatalkan.</b>`, { parse_mode: "HTML" });
    } catch (e) { console.log("[BUILDFIX CANCEL ERR]", e.message); }
});

module.exports = { fixPubspec, fixDartFiles, fixNative, fixWorkflows };
console.log("[BUILD FIX ERROR] v2 loaded — MAX 2GB via GramJS");