const { TelegramClient } = require("telegram");
const { StringSession } = require("telegram/sessions");
const input = require("input");
const fs = require("fs");

const userConfig = require("./config");
const API_ID = Number(userConfig.API_ID || 0);
const API_HASH = userConfig.API_HASH || "";

(async () => {
    console.log("═══════════════════════════════════════════");
    console.log("  LOGIN GRAMJS SEBAGAI USER");
    console.log("═══════════════════════════════════════════");
    console.log("API_ID:", API_ID);
    console.log("API_HASH:", API_HASH ? API_HASH.slice(0, 8) + "****" : "(kosong)");
    console.log("");

    if (!API_ID || !API_HASH) {
        console.log("❌ API_ID / API_HASH belum di-set!");
        console.log("   Jalanin: API_ID=xxx API_HASH=yyy node login-user.js");
        process.exit(1);
    }

    const client = new TelegramClient(
        new StringSession(""),
        API_ID,
        API_HASH,
        { connectionRetries: 5 }
    );

    await client.start({
        phoneNumber: async () => await input.text("📱 Nomor HP (format +628xxx): "),
        password: async () => await input.text("🔑 Password 2FA (kalau ada, else enter): "),
        phoneCode: async () => await input.text("📨 Kode OTP dari Telegram: "),
        onError: (err) => console.log("❌ Error:", err.message)
    });

    const session = client.session.save();
    fs.writeFileSync("./user-session.txt", session, "utf8");

    console.log("");
    console.log("═══════════════════════════════════════════");
    console.log("  ✅ LOGIN BERHASIL");
    console.log("═══════════════════════════════════════════");
    console.log("Session disimpen ke: user-session.txt");
    console.log("Session:", session);
    console.log("");

    try {
        const me = await client.getMe();
        console.log("Login sebagai:", me.firstName || me.username || me.id);
    } catch {}

    await client.disconnect();
    process.exit(0);
})();