let lastErrorMsg = "";
let lastErrorTime = 0;
const ERROR_SPAM_GUARD_MS = 5000;

function shouldLogError(msg) {
    const now = Date.now();
    if (msg === lastErrorMsg && now - lastErrorTime < ERROR_SPAM_GUARD_MS) return false;
    lastErrorMsg = msg;
    lastErrorTime = now;
    return true;
}

process.on("uncaughtException", (e) => {
    const msg = e.message || "";
    if (msg.includes("EFATAL") || msg.includes("AggregateError")) return;
    if (msg.includes("instanceof")) return;
    if (!shouldLogError(msg)) return;
    console.log("[UNCAUGHT]", msg);
});

process.on("unhandledRejection", (e) => {
    const msg = (e && e.message) ? e.message : String(e);
    if (msg.includes("EFATAL") || msg.includes("AggregateError")) return;
    if (msg.includes("instanceof")) return;
    if (!shouldLogError(msg)) return;
    console.log("[UNHANDLED]", msg);
});

const fs = require("fs");
const path = require("path");
const axios = require("axios");

const ROOT = __dirname;
const DB_DIR = path.join(ROOT, "database");
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const FILES = {
    users: path.join(DB_DIR, "users.json"),
    senders: path.join(DB_DIR, "senders.json"),
    redeem: path.join(DB_DIR, "redeem.json"),
    reports: path.join(DB_DIR, "reports.json"),
    settings: path.join(DB_DIR, "settings.json"),
    guard: path.join(DB_DIR, "guard.json"),
    panel: path.join(DB_DIR, "panel.json"),
    orders: path.join(DB_DIR, "orders.json"),
    groupgate: path.join(DB_DIR, "groupgate.json"),
    scripts: path.join(DB_DIR, "scripts.json"),
    script_orders: path.join(DB_DIR, "script_orders.json"),
    pending_fix: path.join(DB_DIR, "pending_fix.json"),
    ai_memory: path.join(DB_DIR, "ai_memory.json"),
    user_state: path.join(DB_DIR, "user_state.json")
};

for (const key in FILES) {
    if (!fs.existsSync(FILES[key])) fs.writeFileSync(FILES[key], "{}", "utf8");
}

function readDB(key) {
    try { return JSON.parse(fs.readFileSync(FILES[key], "utf8")); } catch { return {}; }
}

function writeDB(key, data) {
    try {
        const tmp = FILES[key] + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
        fs.renameSync(tmp, FILES[key]);
    } catch (e) {
        console.log("[DB WRITE ERR]", key, e.message);
    }
}

const cfg = require(path.join(ROOT, "config.js"));

// ═══ HELPER TAMPILAN ═══
const LINE = "━━━━━━━━━━━━━━━━━━━━";
const esc = (s) => String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

// ═══ DB WRAPPER ═══
const db = {
    getUser(id) {
        const users = readDB("users");
        const uid = String(id);
        if (!users[uid]) {
            users[uid] = {
                id: uid,
                role: "free",
                credit: 20,
                premium: false,
                banned: false,
                banUntil: 0,
                createdAt: Date.now()
            };
            writeDB("users", users);
        }
        return users[uid];
    },
    saveUser(id, data) {
        const users = readDB("users");
        users[String(id)] = { ...users[String(id)], ...data };
        writeDB("users", users);
    },
    allUsers() { return readDB("users"); },
    isBanned(id) {
        const u = this.getUser(id);
        if (!u.banned) return false;
        if (u.banUntil && Date.now() > u.banUntil) {
            this.saveUser(id, { banned: false, banUntil: 0 });
            return false;
        }
        return true;
    },
    isPremium(id) { return !!this.getUser(id).premium; },
    isOwner(id) { return String(id) === String(cfg.OWNER_ID); },
    addCredit(id, amount) {
        const u = this.getUser(id);
        const total = Math.min(u.credit + amount, 500);
        this.saveUser(id, { credit: total });
        return total;
    },
    delCredit(id) { this.saveUser(id, { credit: 0 }); },
    setPremium(id, status) {
        this.saveUser(id, { premium: !!status, role: status ? "premium" : "free" });
    },
    banUser(id, duration) { this.saveUser(id, { banned: true, banUntil: Date.now() + duration }); },
    unbanUser(id) { this.saveUser(id, { banned: false, banUntil: 0 }); },
    deductCredit(id, amount = 1) {
        const u = this.getUser(id);
        if (u.credit < amount) return false;
        this.saveUser(id, { credit: u.credit - amount });
        return true;
    },
    read: readDB,
    write: writeDB,
    FILES
};

global.db = db;
global.readDB = readDB;
global.writeDB = writeDB;

// ═══ TELEGRAM BOT (Bot API) ═══
const TelegramBot = require("node-telegram-bot-api");
const bot = new TelegramBot(cfg.BOT_TOKEN, {
    polling: {
        interval: 1000,
        autoStart: true,
        params: { timeout: 30, allowed_updates: ["message", "callback_query", "channel_post", "chat_member", "my_chat_member"] }
    },
});

// Channel moderation: explicit admin/owner action + Unban button.
// Telegram Bot API does not expose native Telegram channel Report events.
try {
    require(path.join(ROOT, "modules", "report-moderation.js"))(bot, cfg);
    console.log("[REPORT MODERATION] module installed");
} catch (e) {
    console.log("[REPORT MODERATION] module unavailable:", e.message);
}

// Native Telegram Rich Message adapter: applies to text/photo messages across modules.
// Existing callback_data values are preserved so the current router keeps working.
try {
    const { installRichMessageAdapter } = require(path.join(ROOT, "libs", "rich-message-adapter.js"));
    installRichMessageAdapter(bot, cfg.BOT_TOKEN, { logFallbacks: true });
    console.log("[RICH MESSAGE] adapter installed for bot text/photo outputs");
} catch (e) {
    console.log("[RICH MESSAGE] adapter unavailable; legacy messaging retained:", e.message);
}

// ═══ MODULES ═══
const gate = require(path.join(ROOT, "modules", "gate.js"));
const guard = require(path.join(ROOT, "modules", "guard.js"));
const panel = require(path.join(ROOT, "modules", "panel.js"));
const notify = require(path.join(ROOT, "modules", "notify.js"));
const groupgate = require(path.join(ROOT, "modules", "groupgate.js"));
const panelpro = panel;
const router = require(path.join(ROOT, "modules", "router.js"));

// React Emoji channel automation (one Bot API reaction per post limitation applies).
try {
    const reactEmoji = require(path.join(ROOT, "modules", "react-emoji.js"));
    reactEmoji.register(bot, {});
    console.log("[REACT EMOJI] channel listener registered");
} catch (e) {
    console.error("[REACT EMOJI] module failed to load:", e.message);
}

// ═══ LIBS BARU (GramJS + Queue) ═══
let gramjsDownloader = null;
let buildQueue = null;
let ownerModule = null;
try {
    gramjsDownloader = require(path.join(ROOT, "libs", "gramjs-downloader.js"));
    buildQueue = require(path.join(ROOT, "libs", "build-queue.js"));
    ownerModule = require(path.join(ROOT, "modules", "owner.js"));
    console.log("[INDEX] ✅ libs loaded");
} catch (e) {
    console.log("[INDEX] ⚠️ libs belum ready:", e.message);
}

// ═══ INIT GRAMJS (delay 5 detik) ═══
setTimeout(async () => {
    if (!gramjsDownloader) return;
    try {
        const client = await gramjsDownloader.initGramJS();
        if (client) {
            console.log("[INDEX] ✅ GramJS client ready");
        } else {
            console.log("[INDEX] ⚠️ GramJS client gagal init (belum login user session?)");
        }
    } catch (e) {
        console.log("[INDEX] GramJS init error:", e.message);
    }
}, 5000);

// ═══ TMP CLEANUP ═══
const TMP_DIR = path.join(ROOT, "tmp");
if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR, { recursive: true });

setInterval(() => {
    try {
        const files = fs.readdirSync(TMP_DIR);
        const now = Date.now();
        let deleted = 0;
        for (const f of files) {
            const p = path.join(TMP_DIR, f);
            try {
                const stat = fs.statSync(p);
                if (now - stat.mtimeMs > 60 * 60 * 1000) {
                    if (stat.isDirectory()) fs.rmSync(p, { recursive: true, force: true });
                    else fs.unlinkSync(p);
                    deleted++;
                }
            } catch {}
        }
        if (deleted > 0) console.log(`[TMP CLEANUP] Deleted ${deleted} files`);
    } catch (e) {}
}, 60 * 60 * 1000);

const TMP_BUILD_DIR = path.join(ROOT, "tmp_build");
if (!fs.existsSync(TMP_BUILD_DIR)) fs.mkdirSync(TMP_BUILD_DIR, { recursive: true });

setInterval(() => {
    try {
        const files = fs.readdirSync(TMP_BUILD_DIR);
        const now = Date.now();
        let deleted = 0;
        for (const f of files) {
            const p = path.join(TMP_BUILD_DIR, f);
            try {
                const stat = fs.statSync(p);
                if (now - stat.mtimeMs > 2 * 60 * 60 * 1000) {
                    if (stat.isDirectory()) fs.rmSync(p, { recursive: true, force: true });
                    else fs.unlinkSync(p);
                    deleted++;
                }
            } catch {}
        }
        if (deleted > 0) console.log(`[TMP_BUILD CLEANUP] Deleted ${deleted} items`);
    } catch (e) {}
}, 2 * 60 * 60 * 1000);

try { panel.startMonitoringLoop(bot); } catch (e) { console.log("[MONITOR START ERR]", e.message); }

try {
    const userbotLogin = require(path.join(ROOT, "handlers", "userbot", "login.js"));
    setTimeout(() => {
        userbotLogin.restoreAllSessions(bot).catch(e => console.log("[USERBOT RESTORE ERR]", e.message));
    }, 5000);
    console.log("[USERBOT] restore scheduled");
} catch (e) {
    console.log("[USERBOT LOAD ERR]", e.message);
}

let autoBackup = null;
try {
    autoBackup = require(path.join(ROOT, "modules", "auto-backup.js"));
    autoBackup.registerCommands(bot, cfg);
    autoBackup.startAutoBackup(bot, cfg);
    console.log("[AUTO BACKUP] service started");
} catch (e) {
    console.log("[AUTO BACKUP LOAD ERR]", e.message);
}

// ═══════════════════════════════════════════
// STATE — IN-MEMORY + FILE PERSIST
// ═══════════════════════════════════════════
const STATE_FILE = FILES.user_state;
const stateCache = {};
let stateDirty = false;

function loadStateCache() {
    try {
        const raw = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
        Object.assign(stateCache, raw);
    } catch {}
}
loadStateCache();

function persistState() {
    if (!stateDirty) return;
    try {
        const tmp = STATE_FILE + ".tmp";
        fs.writeFileSync(tmp, JSON.stringify(stateCache, null, 2), "utf8");
        fs.renameSync(tmp, STATE_FILE);
        stateDirty = false;
    } catch (e) {
        console.log("[STATE SAVE ERR]", e.message);
    }
}

setInterval(persistState, 5000);

function setState(id, state, data = {}) {
    const key = String(id);
    stateCache[key] = { ...data, state, _updatedAt: Date.now() };
    stateDirty = true;
    console.log("[STATE] set:", key, "→", state);
}

function getState(id) {
    const key = String(id);
    const s = stateCache[key] || null;
    if (s) console.log("[STATE] get:", key, "→", s.state);
    return s;
}

function clearState(id) {
    const key = String(id);
    if (stateCache[key]) {
        delete stateCache[key];
        stateDirty = true;
        console.log("[STATE] clear:", key);
    }
}

setInterval(() => {
    const now = Date.now();
    let changed = false;
    for (const uid in stateCache) {
        if (stateCache[uid]._updatedAt && now - stateCache[uid]._updatedAt > 10 * 60 * 1000) {
            console.log("[STATE] auto-cleanup expired:", uid);
            delete stateCache[uid];
            changed = true;
        }
    }
    if (changed) stateDirty = true;
}, 60 * 1000);

// ═══ BUILDPANELCTX ═══
function buildPanelCtx() {
    return {
        db, gate, panel, notify, groupgate,
        setState, getState, clearState, sendMenu
    };
}

// ═══ SAPAAN SESUAI WAKTU WIB ═══
function greetingWIB() {
    const h = parseInt(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta", hour: "numeric", hour12: false }), 10);
    if (h >= 4 && h < 11) return "🌅 Selamat Pagi";
    if (h >= 11 && h < 15) return "☀️ Selamat Siang";
    if (h >= 15 && h < 18) return "🌇 Selamat Sore";
    return "🌙 Selamat Malam";
}

// ═══ TEKS MENU UTAMA ═══


function menuText(user) {
    const isOwner = String(user.id) === String(cfg.OWNER_ID);
    const role = isOwner ? "OWNER" : (user.premium ? "PREMIUM" : "FREE");
    const name = esc(user.first_name || user.username || "Pengguna");
    const bio = esc(String(user.bio || "Belum diatur").slice(0, 35));
    const credit = Number(user.credit) || 0;
    const status = user.banned ? "🔴 LIMITED" : "🟢 ACTIVE";
    return (
        `<h1>✦ MULTI FUNGSI</h1>\n` +
        `<p><i>SMART TOOLS · AI · BUILDER · GROUP GUARD</i></p>\n` +
        `<hr/>\n` +
        `<p>${greetingWIB()}, <b>${name}</b> 👋</p>\n` +
        `<p>Selamat datang di pusat kontrol. Pilih fitur yang ingin kamu gunakan.</p>\n` +
        `<h2>◈ ACCOUNT OVERVIEW</h2>\n` +
        `<table bordered compact><tr><th>INFO</th><th>DETAIL</th></tr>` +
        `<tr><td>🆔 ID</td><td><code>${esc(user.id)}</code></td></tr>` +
        `<tr><td>👑 ROLE</td><td>${role}</td></tr>` +
        `<tr><td>🪙 CREDIT</td><td>${credit}</td></tr>` +
        `<tr><td>📡 STATUS</td><td>${status}</td></tr>` +
        `<tr><td>📝 BIO</td><td>${bio}</td></tr></table>\n` +
        `<h2>⚡ QUICK ACCESS</h2>\n` +
        `<p>Semua fitur utama tersedia melalui tombol di bawah. Pilih menu untuk membuka fungsi yang tersedia.</p>\n` +
        `<footer> MULTI FUNGSI · Your tools, one place.</footer>`
    );
}


// ═══ KEYBOARD MENU UTAMA ═══


function getMainKeyboard(userId, expanded = true) {
    const isOwnerUser = String(userId) === String(cfg.OWNER_ID);
    const user = db.getUser(userId);
    if (!expanded) {
        return { inline_keyboard: [
            [{ text: "▸ Show Menu", callback_data: "menu_show_all", style: "primary" }],
            [{ text: "▸ Testi Channel", url: "https://t.me/testilyd", style: "success" }]
        ] };
    }
    const kb = [
        [{ text: "◆ AI SAKURA", callback_data: "menu_ai", style: "primary" }, { text: "◆ TOOLS", callback_data: "menu_tools", style: "success" }],
        [{ text: "▣ BUILD MENU", callback_data: "menu_buildmenu" }, { text: "➤ BUILD PROMPT", callback_data: "pb_menu" }],
        [{ text: "▤ SCRIPT STORE", callback_data: "menu_scriptstore" }, { text: "▸ ORDER", callback_data: "menu_order" }],
        [{ text: "♫ MUSIC", callback_data: "menu_music", style: "success" }, { text: "◆ ENCRYPT", callback_data: "tool_encrypt" }],
        [{ text: "✍️ BUAT TEKS PROMOSI", callback_data: "menu_promotext", style: "primary" }],
        [{ text: "🧩 CREATE SCRIPT RICH MESSAGE", callback_data: "menu_create_script_prompt", style: "success" }],
        [{ text: "🧪 TESTI CHANNEL", url: "https://t.me/testilyd", style: "success" }],
        [{ text: "◎ GRAB HTML", callback_data: "tool_grabhtml" }, { text: "⌘ FILE TO LINK", callback_data: "menu_filetolink" }],
        [{ text: "⚙ CEK ERROR", callback_data: "menu_cekerror" }],
        [{ text: "× CLEAR SENDER", callback_data: "menu_clearsender" }, { text: "◈ PUSH CHANNEL", callback_data: "menu_pushchannel" }],
        [{ text: "◇ BUY CREDIT", callback_data: "menu_buycredit" }, { text: "♛ PREMIUM", callback_data: "menu_buypremium" }],
        [{ text: "⬟ GROUP GUARD", callback_data: "menu_guard" }, { text: "▣ CREATE PANEL", callback_data: "menu_panelpro" }],
        [{ text: "➤ USERBOT", callback_data: "menu_userbot" }, { text: "↻ REFRESH MENU", callback_data: "menu_back" }],
        [{ text: "📡 ADD CHANNEL NOTIFICATION", callback_data: "channel_notify_add", style: "primary" }],
        [{ text: "🛡️ REP AKUN TELEGRAM", callback_data: "menu_rep_account", style: "danger" }]
    ];
    if (user.premium) kb.push([{ text: "♛ MENU PREMIUM", callback_data: "menu_userpremium" }]);
    if (isOwnerUser) kb.push([{ text: "⚙ MENU OWNER", callback_data: "menu_owner", style: "danger" }]);
    return { inline_keyboard: kb };
}


// ═══ KIRIM MENU ═══
async function sendMenu(chatId, user, q = null, msg = null, expanded = false) {
    const keyboard = getMainKeyboard(user.id, expanded);
    const caption = menuText(user);
    const photoUrl = cfg.FOTO && cfg.FOTO.MENU;
    // Use a static photo banner. Telegram captions support inline keyboards reliably;
    // avoid MP4 URL failures that previously caused the menu buttons to disappear.
    try {
        if (photoUrl) {
            const sent = await bot.sendPhoto(chatId, photoUrl, {
                caption, parse_mode: "HTML", reply_markup: keyboard,
                disable_notification: true
            });
            if (q?.message?.message_id) await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
            return sent;
        }
    } catch (e) {
        console.error("[MENU PHOTO] failed:", e.message);
    }
    const sent = await bot.sendMessage(chatId, caption, {
        parse_mode: "HTML", reply_markup: keyboard, disable_notification: true
    });
    if (q?.message?.message_id) await bot.deleteMessage(chatId, q.message.message_id).catch(() => {});
    return sent;
}

// ═══ REQUIRE JOIN ═══
async function requireJoin(msgOrQ, isCallback = false) {
    const id = msgOrQ.from.id;
    if (String(id) === String(cfg.OWNER_ID)) return true;

    try {
        const join = await gate.checkJoin(bot, id);
        if (join.ok) return true;

        const chatId = isCallback ? msgOrQ.message.chat.id : msgOrQ.chat.id;
        const missing = Array.isArray(join.missing) ? join.missing : cfg.CHANNELS;
        const text = `<b>✦ WAJIB JOIN CHANNEL</b>\n\n` +
            `Kamu belum bergabung ke ${missing.length} channel berikut:\n` +
            missing.map((c) => `• ${c.name}`).join("\n") +
            `\n\nJoin channel yang tercantum, lalu tekan <b>Saya Sudah Join</b>.`;
        const keyboard = missing.map(c => [{ text: `Join ${c.name}`, url: c.url }]);
        keyboard.push([{ text: "✓ Saya Sudah Join", callback_data: "check_join", style: "success" }]);
        await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } });
        return false;
    } catch (e) {
        console.log("[REQUIRE JOIN ERR]", e.message);
        return true;
    }
}

// ═══ LOADING ═══
const loadingLocks = new Set();

const LOADING_STEPS = [
    { pct: 20, text: "Initializing bot core" },
    { pct: 45, text: "Verifying credentials" },
    { pct: 70, text: "Loading plugins" },
    { pct: 90, text: "Almost ready" },
    { pct: 100, text: "Complete" }
];

function makeProgressBar(pct) {
    const total = 18;
    const filled = Math.max(0, Math.min(total, Math.round((pct / 100) * total)));
    return "▰".repeat(filled) + "▱".repeat(total - filled);
}

function loadingText(username, userId, pct, status) {
    const icon = pct >= 100 ? "✅" : pct >= 70 ? "⚡" : pct >= 35 ? "◈" : "✦";
    const pctLabel = String(Math.max(0, Math.min(100, pct))).padStart(3, " ");
    return `<b>╭━━━ ✦ MULTI FUNGSI ✦ ━━━╮</b>\n` +
        `<i>SMART BOT INTERFACE · INITIALIZING</i>\n\n` +
        `Halo, <a href="tg://user?id=${userId}">${esc(username)}</a> 👋\n` +
        `<blockquote>${icon} <b>${esc(status)}</b>\n` +
        `<code>${makeProgressBar(pct)}</code>\n` +
        `<b>PROGRESS ${pctLabel}%</b></blockquote>\n` +
        `<i>${pct >= 100 ? "Dashboard siap dibuka." : "Menyiapkan pengalaman yang lebih baik..."}</i>\n` +
        `<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>`;
}

async function showLoading(bot, chatId, user, finalMenuText = "") {
    const key = String(user.id);
    if (loadingLocks.has(key)) return null;
    loadingLocks.add(key);
    const username = user.first_name || "User";
    let message = null;
    try {
        message = await bot.sendMessage(chatId,
            loadingText(username, user.id, 1, "Menyiapkan sesi"), { parse_mode: "HTML" });
    } catch (e) {
        console.log("[LOADING] send fail:", e.message);
        loadingLocks.delete(key);
        return null;
    }
    const steps = [
        { pct: 12, text: "Membangunkan sistem" },
        { pct: 24, text: "Memeriksa akses akun" },
        { pct: 36, text: "Menyiapkan konfigurasi" },
        { pct: 48, text: "Memuat modul fitur" },
        { pct: 60, text: "Menyinkronkan dashboard" },
        { pct: 72, text: "Mengoptimalkan tampilan" },
        { pct: 84, text: "Menyelesaikan antarmuka" },
        { pct: 94, text: "Hampir siap" },
        { pct: 100, text: "Selesai · dashboard siap" }
    ];
    for (const step of steps) {
        await new Promise(resolve => setTimeout(resolve, 220));
        try {
            await bot.editMessageText(loadingText(username, user.id, step.pct, step.text), {
                chat_id: chatId, message_id: message.message_id, parse_mode: "HTML"
            });
        } catch (e) {
            if (!String(e.message || "").includes("message is not modified")) console.log("[LOADING] progress update:", e.message);
        }
    }
    // Efek "lembaran terbuka": setelah 100%, blok menu muncul berurutan dari atas
    // ke bawah. Tiap tahap memakai blok HTML yang utuh supaya format Rich Message
    // tidak rusak karena tag HTML terpotong di tengah animasi.
    if (finalMenuText) {
        const sections = String(finalMenuText).split(/\n\s*\n/).filter(Boolean);
        let visible = [];
        for (const section of sections) {
            visible.push(section);
            await new Promise(resolve => setTimeout(resolve, 220));
            try {
                await bot.editMessageText(visible.join("\n\n"), {
                    chat_id: chatId,
                    message_id: message.message_id,
                    parse_mode: "HTML",
                    disable_web_page_preview: true
                });
            } catch (e) {
                if (!String(e.message || "").includes("message is not modified")) {
                    console.log("[LOADING] reveal update:", e.message);
                }
            }
        }
    }
    loadingLocks.delete(key);
    return message;
}

// ═══════════════════════════════════════════
// QUEUE PROCESSOR
// ═══════════════════════════════════════════
if (buildQueue) {
    buildQueue.registerProcessor(async (queueEntry) => {
        try {
            const buildServers = require(path.join(ROOT, "libs", "build-servers.js"));
            const buildNotif = require(path.join(ROOT, "libs", "build-notif.js"));

            const serverId = buildServers.findAvailableServerForUser(
                queueEntry.userId,
                buildPanelCtx()
            );

            if (serverId === null) return false;

            const access = buildServers.canAccessServer(serverId, queueEntry.userId, buildPanelCtx());
            if (!access.ok) {
                console.log(`[QUEUE] Access denied for server ${serverId}:`, access.reason);
                return false;
            }

            const marked = buildServers.markBusy(
                serverId,
                queueEntry.userId,
                queueEntry.chatId,
                queueEntry.jobId,
                queueEntry.userName
            );
            if (!marked) return false;

            await buildNotif.notifyTurnArrived(bot, queueEntry.chatId, {
                serverName: `Server ${serverId}`,
                fileName: queueEntry.fileName || "project.zip",
                buildMode: queueEntry.buildMode || "release",
                msgId: queueEntry.msgId
            });

            const jobType = queueEntry.jobType;
            let runBuild;
            if (jobType === "pubspec") {
                const b = require(path.join(ROOT, "modules", "build-pubspec.js"));
                runBuild = b.runQueuedBuild;
            } else if (jobType === "yml") {
                const b = require(path.join(ROOT, "modules", "build-yml.js"));
                runBuild = b.runQueuedBuild;
            }

            if (typeof runBuild === "function") {
                runBuild({
                    bot,
                    serverId,
                    queueEntry,
                    buildServers,
                    onDone: async () => {
                        buildServers.markAvailable(serverId);
                        console.log(`[QUEUE] Server ${serverId} available lagi`);
                        setTimeout(() => buildQueue.tryProcessQueue(), 1000);
                    }
                }).catch(e => {
                    console.log("[QUEUE] Run build error:", e.message);
                    buildServers.markAvailable(serverId);
                });
            } else {
                console.log(`[QUEUE] runBuild untuk ${jobType} tidak ditemukan`);
                buildServers.markAvailable(serverId);
                return false;
            }

            return true;
        } catch (e) {
            console.log("[QUEUE] Processor error:", e.message);
            return false;
        }
    });
    console.log("[INDEX] ✅ Queue processor registered");
}

// ═══ SET BOT_SELF_ID ═══
setTimeout(async () => {
    try {
        const me = await bot.getMe();
        const settings = readDB("settings") || {};
        if (!settings.bot_self_id) {
            settings.bot_self_id = me.id;
            writeDB("settings", settings);
            console.log("[INDEX] ✅ bot_self_id saved:", me.id);
        } else {
            console.log("[INDEX] bot_self_id:", settings.bot_self_id);
        }
    } catch (e) {
        console.log("[INDEX] getMe err:", e.message);
    }
}, 3000);

// ═══ /start ═══
bot.onText(/^\/start$/, async (msg) => {
    const id = msg.from.id;
    const userBefore = db.getUser(id);
    const isNewUser = userBefore.createdAt && Date.now() - userBefore.createdAt < 5000 && !userBefore.startNotified;


    if (db.isBanned(id)) {
        return bot.sendMessage(msg.chat.id,
            `<b>MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!</b>`,
            { parse_mode: "HTML" });
    }

    // Require membership in every configured channel before showing the menu.
    if (!(await requireJoin(msg, false))) return;
    const currentUser = db.getUser(id);
    const loadingMessage = await showLoading(bot, msg.chat.id, msg.from, menuText(currentUser));
    const oldMenuMessage = loadingMessage ? { message: { chat: { id: msg.chat.id }, message_id: loadingMessage.message_id } } : null;
    await sendMenu(msg.chat.id, currentUser, oldMenuMessage);
});

// ═══ /menu ═══
bot.onText(/^\/menu$/, async (msg) => {
    const id = msg.from.id;
    clearState(id);
    if (db.isBanned(id)) {
        return bot.sendMessage(msg.chat.id,
            `<b>MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!</b>`,
            { parse_mode: "HTML" });
    }
    // /menu is public as well; membership checks belong only in explicitly gated features.
    await sendMenu(msg.chat.id, db.getUser(id));
});

// ═══ /cancel ═══
bot.onText(/^\/cancel$/, async (msg) => {
    const id = msg.from.id;
    clearState(id);

    // Clear login flow
    if (ownerModule && ownerModule.loginStates) {
        const st = ownerModule.loginStates.get(String(id));
        if (st) {
            if (st.resolvePhone) { try { st.resolvePhone.reject(new Error("CANCELLED")); } catch {} st.resolvePhone = null; }
            if (st.resolveOtp) { try { st.resolveOtp.reject(new Error("CANCELLED")); } catch {} st.resolveOtp = null; }
            if (st.resolvePassword) { try { st.resolvePassword.reject(new Error("CANCELLED")); } catch {} st.resolvePassword = null; }
            if (st.client) try { await st.client.disconnect(); } catch {}
        }
        ownerModule.loginStates.delete(String(id));
    }

    await bot.sendMessage(msg.chat.id,
        `<b>✕ Dibatalkan</b>\n\n<i>Semua proses dibatalkan. Ketik /menu buat kembali.</i>`,
        { parse_mode: "HTML" });
});

// ═══ /queue ═══
bot.onText(/^\/queue$/, async (msg) => {
    try {
        const id = msg.from.id;
        const buildQueueMod = require(path.join(ROOT, "libs", "build-queue.js"));
        const buildServers = require(path.join(ROOT, "libs", "build-servers.js"));

        const position = buildQueueMod.getQueuePosition(id);
        const queueList = buildQueueMod.getQueue();
        const servers = buildServers.getAllServers();
        const accessible = buildServers.getUserAccessibleServers(id, buildPanelCtx());
        const available = accessible.filter(sid => !servers[sid].busy);

        let text =
            `<b>📊 STATUS ANTRIAN & SERVER</b>\n\n` +
            `━━━━━━━━━━━━━━━━━━━━\n`;

        if (position) {
            text += `📍 <b>Posisi kamu</b>: <code>#${position}</code> dari <code>${queueList.length}</code>\n`;
        } else {
            text += `📍 <b>Posisi kamu</b>: <i>Tidak di antrian</i>\n`;
        }

        text += `\n<b>SERVER STATUS</b>\n`;
        for (const sid of accessible) {
            const srv = servers[sid];
            if (!srv) continue;
            const status = srv.busy ? `🔴 Penuh (${srv.userName || "—"})` : `🟢 Available`;
            text += `▸ ${srv.name}: ${status}\n`;
        }

        text += `\n<b>ANTRIAN TOTAL</b>: <code>${queueList.length}</code>\n`;
        text += `━━━━━━━━━━━━━━━━━━━━\n\n`;

        if (available.length > 0) {
            text += `<i>✅ Ada ${available.length} server available. Klik /menu → Build.</i>`;
        } else if (position) {
            text += `<i>⏳ Semua server penuh. Kamu di antrian #${position}.</i>`;
        } else {
            text += `<i>⏳ Semua server penuh. Coba lagi nanti.</i>`;
        }

        await bot.sendMessage(msg.chat.id, text, {
            parse_mode: "HTML",
            reply_markup: { inline_keyboard: [[{ text: "🔄 Refresh", callback_data: "queue_refresh", style: "primary" }]] }
        });
    } catch (e) {
        console.log("[QUEUE CMD ERR]", e.message);
    }
});

// ═══ NATIVE CHANNEL MEMBER NOTIFICATIONS + BAN/UNBAN ═══
function channelMemberButtons(chatId, userId, action = "ban") {
    return { inline_keyboard: [[{
        text: action === "ban" ? "⛔ Ban dari channel" : "♻️ Unban / izinkan masuk",
        callback_data: `channel_member_${action}:${chatId}:${userId}`,
        style: action === "ban" ? "danger" : "success"
    }]] };
}

function memberDisplay(member) {
    const u = member?.user || {};
    const name = [u.first_name, u.last_name].filter(Boolean).join(" ") || "Pengguna";
    const username = u.username ? `@${esc(u.username)}` : "—";
    return { u, name: esc(name), username };
}

bot.on("chat_member", async (update) => {
    try {
        const chat = update.chat;
        if (!chat || chat.type !== "channel") return;
        const channelSettings = readDB("settings");
        if (!channelSettings.channel_notifications?.[String(chat.id)]?.enabled) return;
        const oldStatus = update.old_chat_member?.status;
        const newStatus = update.new_chat_member?.status;
        const joined = ["left", "kicked", "restricted"].includes(oldStatus) && ["member", "administrator", "creator"].includes(newStatus);
        const left = ["member", "administrator", "creator", "restricted"].includes(oldStatus) && ["left", "kicked"].includes(newStatus);
        if (!joined && !left) return;
        const { u, name, username } = memberDisplay(update.new_chat_member || update.old_chat_member);
        if (!u.id || String(u.id) === String(cfg.OWNER_ID)) return;
        const label = joined ? "MEMBER BARU JOIN CHANNEL" : "MEMBER KELUAR DARI CHANNEL";
        const status = joined ? "🟢 BERGABUNG" : "🔴 KELUAR";
        const html = `<b>${joined ? "🟢" : "🔴"} ${label}</b>\n` +
            `<blockquote>📡 <b>Channel</b>: ${esc(chat.title || chat.username || chat.id)}\n` +
            `👤 <b>Pengguna</b>: ${username}\n` +
            `🆔 <b>User ID</b>: <code>${u.id}</code>\n` +
            `📍 <b>Status</b>: ${status}</blockquote>\n` +
            `<i>MULTI FUNGSI · Channel Monitor</i>`;
        await bot.sendMessage(chat.id, html, { parse_mode: "HTML", reply_markup: channelMemberButtons(chat.id, u.id, "ban") });
    } catch (e) {
        console.log("[CHANNEL MEMBER NOTIF ERR]", e.message);
    }
});

bot.on("callback_query", async (q) => {
    const data = String(q?.data || "");
    const match = data.match(/^channel_member_(ban|unban):(-?\d+):(\d+)$/);
    if (!match) return;
    const [, action, chatId, targetId] = match;
    try {
        let actorIsAdmin = String(q.from.id) === String(cfg.OWNER_ID);
        if (!actorIsAdmin) {
            try {
                const member = await bot.getChatMember(chatId, q.from.id);
                actorIsAdmin = ["creator", "administrator"].includes(member.status);
            } catch { actorIsAdmin = false; }
        }
        if (!actorIsAdmin) {
            await bot.answerCallbackQuery(q.id, { text: "Hanya admin channel ini yang bisa memakai tombol.", show_alert: true }).catch(() => {});
            return;
        }
        if (action === "ban") {
            await bot.banChatMember(chatId, Number(targetId));
            await bot.answerCallbackQuery(q.id, { text: "User diblokir dari channel." }).catch(() => {});
            const original = String(q.message?.text || q.message?.caption || "");
            const updated = original.replace(/MEMBER BARU JOIN CHANNEL|MEMBER KELUAR DARI CHANNEL/, "USER DIBAN DARI CHANNEL");
            await bot.editMessageText(`${updated}\n\n<p>⛔ Pengguna ini sudah diblokir dan tidak bisa bergabung kembali sampai di-unban.</p>`, {
                chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: "HTML",
                reply_markup: channelMemberButtons(chatId, targetId, "unban")
            }).catch(async () => {
                await bot.sendMessage(q.message.chat.id, `<p>⛔ User <code>${targetId}</code> berhasil diban dari channel <code>${chatId}</code>.</p>`, { reply_markup: channelMemberButtons(chatId, targetId, "unban") });
            });
        } else {
            await bot.unbanChatMember(chatId, Number(targetId), { only_if_banned: true });
            await bot.answerCallbackQuery(q.id, { text: "Ban dicabut; user bisa bergabung lagi." }).catch(() => {});
            await bot.editMessageText(`<h2>♻️ UNBAN BERHASIL</h2><p>User <code>${targetId}</code> diizinkan bergabung kembali ke channel <code>${chatId}</code>.</p>`, {
                chat_id: q.message.chat.id, message_id: q.message.message_id, parse_mode: "HTML",
                reply_markup: channelMemberButtons(chatId, targetId, "ban")
            }).catch(() => {});
        }
    } catch (e) {
        await bot.answerCallbackQuery(q.id, { text: `Gagal: ${String(e.message || "Telegram API error").slice(0, 150)}`, show_alert: true }).catch(() => {});
        console.log(`[CHANNEL ${action.toUpperCase()} ERR]`, e.message);
    }
});

// ═══ CHANNEL NOTIFICATION REGISTRATION + REPORT ASSISTANT ═══
const channelRegistrationWait = new Map();

bot.on("callback_query", async (q) => {
    const data = String(q?.data || "");
    if (data === "channel_notify_add") {
        if (q.message?.chat?.type !== "private") {
            await bot.answerCallbackQuery(q.id, { text: "Buka chat pribadi bot untuk mendaftarkan channel.", show_alert: true }).catch(() => {});
            return;
        }
        channelRegistrationWait.set(String(q.from.id), true);
        await bot.answerCallbackQuery(q.id).catch(() => {});
        await bot.sendMessage(q.message.chat.id,
            `<b>📡 DAFTARKAN CHANNEL NOTIFICATION</b>\n\n` +
            `<blockquote>1. Tambahkan bot sebagai admin channel.\n2. Pastikan bot dapat melihat perubahan anggota.\n3. Kirim @username channel atau ID channel -100...</blockquote>\n` +
            `<i>Notifikasi hanya aktif untuk channel yang didaftarkan. Tombol ban/unban membutuhkan izin membatasi anggota.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "✕ Batal", callback_data: "channel_notify_cancel" }]] } }
        ).catch(e => console.log("[CHANNEL REGISTER UI]", e.message));
        return;
    }
    if (data === "channel_notify_cancel") {
        channelRegistrationWait.delete(String(q.from.id));
        await bot.answerCallbackQuery(q.id, { text: "Pendaftaran dibatalkan." }).catch(() => {});
        await bot.sendMessage(q.message.chat.id, "<b>Pendaftaran channel dibatalkan.</b>", { parse_mode: "HTML" }).catch(() => {});
        return;
    }
    if (data === "menu_rep_account") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        await bot.sendMessage(q.message.chat.id,
            `<b>🛡️ BANTUAN LAPORAN AKUN TELEGRAM</b>\n\n` +
            `<blockquote>Gunakan panduan ini untuk menyiapkan laporan yang akurat dan ditinjau manual. Sertakan tautan akun/pesan serta bukti relevan.\n\nBot tidak meminta password Gmail/App Password, tidak mengirim laporan massal, dan tidak mengulang laporan otomatis. Laporan palsu atau massal bisa merugikan pengguna lain.</blockquote>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [
                [{ text: "📄 Panduan resmi Telegram", url: "https://telegram.org/support" }],
                [{ text: "↩ Kembali ke menu", callback_data: "menu_back" }]
            ] } }
        ).catch(e => console.log("[REPORT ACCOUNT MENU]", e.message));
    }
});

bot.on("message", async (msg) => {
    if (!msg.chat || msg.chat.type !== "private" || !msg.from || typeof msg.text !== "string") return;
    if (!channelRegistrationWait.has(String(msg.from.id)) || msg.text.startsWith("/")) return;
    const raw = msg.text.trim();
    let chat;
    try {
        const target = /^-100\d+$/.test(raw)
            ? raw
            : raw.replace(/^https?:\/\/t\.me\//i, "").replace(/^@/, "").replace(/\/.*$/, "");
        chat = await bot.getChat(target.startsWith("-100") ? target : "@" + target);
    } catch {
        await bot.sendMessage(msg.chat.id, "❌ Channel tidak ditemukan. Pastikan username/ID benar dan bot sudah menjadi admin, lalu coba lagi.");
        return;
    }
    if (!chat || chat.type !== "channel") {
        await bot.sendMessage(msg.chat.id, "❌ Yang dikirim bukan channel Telegram. Kirim @username atau ID channel -100...");
        return;
    }
    try {
        const actor = await bot.getChatMember(chat.id, msg.from.id);
        if (!["creator", "administrator"].includes(actor.status)) {
            await bot.sendMessage(msg.chat.id, "❌ Hanya admin channel tersebut yang bisa mendaftarkannya.");
            return;
        }
        const me = await bot.getMe();
        const botMember = await bot.getChatMember(chat.id, me.id);
        if (!["creator", "administrator"].includes(botMember.status)) {
            await bot.sendMessage(msg.chat.id, "❌ Bot belum menjadi admin channel. Tambahkan bot sebagai admin, lalu kirim ulang username channel.");
            return;
        }
        const settings = readDB("settings");
        settings.channel_notifications = settings.channel_notifications || {};
        settings.channel_notifications[String(chat.id)] = {
            chatId: String(chat.id),
            title: chat.title || chat.username || String(chat.id),
            username: chat.username ? "@" + chat.username : null,
            addedBy: String(msg.from.id),
            addedAt: new Date().toISOString(),
            enabled: true
        };
        writeDB("settings", settings);
        channelRegistrationWait.delete(String(msg.from.id));
        await bot.sendMessage(msg.chat.id,
            `<b>✅ CHANNEL BERHASIL DIDAFTARKAN</b>\n\n` +
            `<blockquote>📡 <b>Nama</b>: ${esc(chat.title || "Channel")}\n🆔 <b>ID</b>: <code>${chat.id}</code>\n🔔 Notifikasi join/keluar: <b>Aktif</b></blockquote>\n` +
            `<i>Bot harus tetap admin. Ketersediaan event anggota bergantung pada update Telegram yang diterima bot.</i>`,
            { parse_mode: "HTML", reply_markup: { inline_keyboard: [
                [{ text: "📡 Tambah channel lain", callback_data: "channel_notify_add" }],
                [{ text: "↩ Menu utama", callback_data: "menu_back" }]
            ] } }
        );
    } catch (e) {
        await bot.sendMessage(msg.chat.id, `❌ Gagal mendaftarkan channel: ${esc(e.message || "error")}`, { parse_mode: "HTML" }).catch(() => {});
    }
});

// ═══ WELCOME / LEAVE ═══
bot.on("new_chat_members", async (msg) => {
    try { await guard.handleNewMembers(bot, msg, { db, gate }); }
    catch (e) { console.log("[NEW MEMBERS ERR]", e.message); }
});

bot.on("left_chat_member", async (msg) => {
    try { await guard.handleLeftMembers(bot, msg, { db, gate }); }
    catch (e) { console.log("[LEFT MEMBER ERR]", e.message); }
});

try {
    const grouptools = require(path.join(ROOT, "modules", "grouptools.js"));
    grouptools.register(bot, { db, gate });
} catch (e) {
    console.log("[GROUPTOOLS REGISTER ERR]", e.message);
}

// ═══ /reset ═══
bot.onText(/^\/reset$/, async (msg) => {
    const id = msg.from.id;
    try {
        const ai = require(path.join(ROOT, "modules", "ai-engine.js"));
        ai.clearMemory(id);
        await bot.sendMessage(msg.chat.id,
            `<b>🧹 Memory di-reset!</b>\n\n<i>Sakura lupa chat sebelumnya. Mulai fresh lagi~ UwU</i>`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[RESET ERR]", e.message); }
});

// ═══ /accubot ═══
bot.onText(/^\/accubot(?:\s+(.+))?$/, async (msg) => {
    if (String(msg.from.id) !== String(cfg.OWNER_ID)) {
        return bot.sendMessage(msg.chat.id, `<b>✕ Owner only.</b>`, { parse_mode: "HTML" });
    }
    const args = (msg.text || "").split(/\s+/).slice(1);
    const targetId = args[0];
    const role = args[1];
    if (!targetId || !role) {
        return bot.sendMessage(msg.chat.id,
            `<b>Format:</b> <code>/accubot [user_id] [role]</code>\n\n` +
            `<b>Role:</b> permanent, reseller, admin, owner`,
            { parse_mode: "HTML" });
    }
    try {
        const store = require(path.join(ROOT, "handlers", "userbot", "session-store.js"));
        store.setUserRole(targetId, role, 0);
        await bot.sendMessage(msg.chat.id,
            `<b>✓ ROLE USERBOT DI-ACC</b>\n\n` +
            `▸ User: <code>${esc(targetId)}</code>\n` +
            `▸ Role: <b>${esc(role.toUpperCase())}</b>\n` +
            `▸ Status: Permanen`,
            { parse_mode: "HTML" });
        await bot.sendMessage(targetId,
            `<b>𖡛 ROLE USERBOT DI-ACC</b>\n\n` +
            `▸ Role: <b>${esc(role.toUpperCase())}</b>\n` +
            `▸ Status: Permanen\n\n` +
            `<i>Ketik /menu → Userbot Telegram → Login</i>`,
            { parse_mode: "HTML" }).catch(() => {});
        // Channel success notification only after Owner explicitly approves the transfer.
        try {
            const storeData = require(path.join(ROOT, "handlers", "userbot", "session-store.js"));
            const notifGen = require(path.join(ROOT, "handlers", "userbot", "modules", "notif-generator.js"));
            const userInfo = await bot.getChat(targetId).catch(() => ({}));
            await notifGen.sendBuyRoleNotif(bot, cfg, {
                roleName: String(role).toUpperCase(),
                price: "Terverifikasi admin",
                status: "success",
                username: userInfo.username ? `@${userInfo.username}` : "-",
                fullName: [userInfo.first_name, userInfo.last_name].filter(Boolean).join(" ") || "User",
                userId: targetId,
                timestamp: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
            });
        } catch (notifyErr) {
            console.log("[USERBOT APPROVAL NOTIF]", notifyErr.message);
        }
    } catch (e) {
        await bot.sendMessage(msg.chat.id, `<b>✕ Error:</b> ${esc(e.message.slice(0, 150))}`, { parse_mode: "HTML" });
    }
});

// ═══ COMMANDS PANEL ═══
bot.onText(/^\/add(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAdd(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADD ERR]", e.message); }
});
bot.onText(/^\/addgroup(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddGroup(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDGROUP ERR]", e.message); }
});
bot.onText(/^\/addall(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddAll(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDALL ERR]", e.message); }
});
bot.onText(/^\/addrole(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleAddRole(bot, msg, buildPanelCtx()); } catch (e) { console.log("[ADDROLE ERR]", e.message); }
});
bot.onText(/^\/cadp(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleCadp(bot, msg, buildPanelCtx(), 1); } catch (e) { console.log("[CADP ERR]", e.message); }
});
bot.onText(/^\/cadp2(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleCadp(bot, msg, buildPanelCtx(), 2); } catch (e) { console.log("[CADP2 ERR]", e.message); }
});
bot.onText(/^\/info(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try { await panel.handleInfoGroup(bot, msg, buildPanelCtx()); } catch (e) { console.log("[INFO ERR]", e.message); }
});
bot.onText(/^\/create(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        if (typeof panel.handleCreate === "function") {
            await panel.handleCreate(bot, msg, buildPanelCtx());
        }
    } catch (e) { console.log("[CREATE ERR]", e.message); }
});
bot.onText(/^\/setconfig(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        if (typeof panel.handleSetConfig === "function") {
            await panel.handleSetConfig(bot, msg, buildPanelCtx());
        }
    } catch (e) { console.log("[SETCONFIG ERR]", e.message); }
});
bot.onText(/^\/order(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        const orderMod = require(path.join(ROOT, "modules", "order.js"));
        if (typeof orderMod.handleOrder === "function") {
            await orderMod.handleOrder(bot, msg, buildPanelCtx());
        }
    } catch (e) { console.log("[ORDER ERR]", e.message); }
});
bot.onText(/^\/orderstats(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        const orderMod = require(path.join(ROOT, "modules", "order.js"));
        if (typeof orderMod.statsHandler === "function") {
            await orderMod.statsHandler(bot, msg, buildPanelCtx());
        }
    } catch (e) { console.log("[ORDERSTATS ERR]", e.message); }
});
bot.onText(/^\/unmuteall(?:@\w+)?(?:\s+(.+))?$/, async (msg) => {
    try {
        const gg = require(path.join(ROOT, "modules", "groupgate.js"));
        if (typeof gg.unmuteAll !== "function") return;
        const result = await gg.unmuteAll(bot, msg.chat.id);
        await bot.sendMessage(msg.chat.id,
            `<b>✓ UNMUTE ALL</b>\n\n▸ Total: ${result.total}\n▸ Berhasil: ${result.success}`,
            { parse_mode: "HTML" });
    } catch (e) { console.log("[UNMUTEALL ERR]", e.message); }
});

// ═══════════════════════════════════════════
// CALLBACK QUERY
// ═══════════════════════════════════════════
bot.on("callback_query", async (q) => {
    if (!q || !q.from || !q.message || !q.data) {
        console.log("[CB] invalid query");
        return bot.answerCallbackQuery(q?.id || "").catch(() => {});
    }

    const id = q.from.id;
    const data = q.data;
    if (String(data).startsWith("channel_member_")) return; // handled by owner-only channel moderation listener below
    const user = db.getUser(id);

    console.log("[CB] user:", id, "data:", data);

    // START MENU: expand the existing full menu without changing its callback_data.
    if (data === "menu_show_all") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        return sendMenu(q.message.chat.id, user, q, null, true);
    }

    // Legacy callback kept for old menu messages; new button opens the channel URL directly.
    if (data === "menu_testi_channel") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        return bot.sendMessage(q.message.chat.id, '<b>Channel Testi</b>', { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "Buka @testilyd", url: "https://t.me/testilyd" }]] } });
    }

    if (data === "menu_test_function") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        const up = Math.floor(process.uptime());
        const html = `<h1>🧪 TEST FUNCTION</h1><p>Hasil pemeriksaan dasar MULTI FUNGSI.</p><table bordered compact><tr><th>Komponen</th><th>Status</th></tr><tr><td>Node.js</td><td>✅ Aktif</td></tr><tr><td>Bot API</td><td>✅ Polling berjalan</td></tr><tr><td>Rich Message</td><td>${typeof bot.sendRichMessage === "function" ? "✅ Adapter terpasang" : "⚠️ Adapter tidak tersedia"}</td></tr><tr><td>Uptime</td><td>${Math.floor(up/3600)}j ${Math.floor((up%3600)/60)}m ${up%60}d</td></tr></table>`;
        const kb = [[{ text: "🔄 Tes Ulang", callback_data: "menu_test_function", style: "success" }],[{ text: "‹ Kembali", callback_data: "menu_back", style: "danger" }]];
        if (typeof bot.sendRichMessage === "function") return bot.sendRichMessage(q.message.chat.id, html, { reply_markup: { inline_keyboard: kb } });
        return bot.sendMessage(q.message.chat.id, html, { parse_mode: "HTML", reply_markup: { inline_keyboard: kb } });
    }

    // QUICK: menu_close
    if (data === "menu_close") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        try { await bot.deleteMessage(q.message.chat.id, q.message.message_id); } catch {}
        return;
    }

    // QUICK: menu_back
    if (data === "menu_back") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        return sendMenu(q.message.chat.id, user, q, null, true);
    }

    // QUICK: check_join
    if (data === "check_join") {
        await bot.answerCallbackQuery(q.id).catch(() => {});
        const join = await gate.checkJoin(bot, id);
        if (!join.ok) {
            const missing = join.missing || cfg.CHANNELS;
            const keyboard = missing.map(c => [{ text: `Join ${c.name}`, url: c.url }]);
            keyboard.push([{ text: "✓ Saya Sudah Join", callback_data: "check_join", style: "success" }]);
            return bot.sendMessage(q.message.chat.id,
                `<b>Belum lengkap.</b> Kamu belum join:\n${missing.map(c => `• ${c.name}`).join("\n")}`,
                { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } });
        }
        return sendMenu(q.message.chat.id, user, q, null, false);
    }

    // BANNED CHECK
    if (db.isBanned(id) &&
        !data.startsWith("dev_") &&
        !data.startsWith("redeem_claim") &&
        !data.startsWith("guard_")) {
        return bot.answerCallbackQuery(q.id, {
            text: "MAAF LU LAGI DI BANNED OWNER BOT JIKA MAU DI UNBANNED CHAT DEVELOPER SEKARANG JUGA!!!!",
            show_alert: true
        }).catch(() => {});
    }

    // No global join gate: public menus and tools should not repeatedly prompt users to join.

    // QUICK: queue_refresh
    if (data === "queue_refresh") {
        try {
            await bot.answerCallbackQuery(q.id, { text: "🔄 Refreshing..." }).catch(() => {});
            const buildQueueMod = require(path.join(ROOT, "libs", "build-queue.js"));
            const buildServers = require(path.join(ROOT, "libs", "build-servers.js"));

            const position = buildQueueMod.getQueuePosition(id);
            const queueList = buildQueueMod.getQueue();
            const servers = buildServers.getAllServers();
            const accessible = buildServers.getUserAccessibleServers(id, buildPanelCtx());

            let text =
                `<b>📊 STATUS ANTRIAN & SERVER</b>\n\n` +
                `━━━━━━━━━━━━━━━━━━━━\n`;

            if (position) {
                text += `📍 <b>Posisi kamu</b>: <code>#${position}</code> dari <code>${queueList.length}</code>\n`;
            } else {
                text += `📍 <b>Posisi kamu</b>: <i>Tidak di antrian</i>\n`;
            }

            text += `\n<b>SERVER STATUS</b>\n`;
            for (const sid of accessible) {
                const srv = servers[sid];
                if (!srv) continue;
                const status = srv.busy ? `🔴 Penuh` : `🟢 Available`;
                text += `▸ ${srv.name}: ${status}\n`;
            }
            text += `\n<b>ANTRIAN TOTAL</b>: <code>${queueList.length}</code>\n`;
            text += `━━━━━━━━━━━━━━━━━━━━`;

            try {
                await bot.editMessageText(text, {
                    chat_id: q.message.chat.id,
                    message_id: q.message.message_id,
                    parse_mode: "HTML",
                    reply_markup: { inline_keyboard: [[{ text: "🔄 Refresh", callback_data: "queue_refresh", style: "primary" }]] }
                });
            } catch (e) {
                const m = e.message || "";
                if (!m.includes("message is not modified")) {
                    console.log("[QUEUE REFRESH] err:", m.slice(0, 100));
                }
            }
        } catch (e) {
            console.log("[QUEUE REFRESH ERR]", e.message);
        }
        return;
    }

    // QUICK: queue_cancel
    if (data === "queue_cancel") {
        try {
            await bot.answerCallbackQuery(q.id, { text: "❌ Dibatalkan" }).catch(() => {});
            const buildQueueMod = require(path.join(ROOT, "libs", "build-queue.js"));
            const buildNotif = require(path.join(ROOT, "libs", "build-notif.js"));

            const removed = buildQueueMod.removeFromQueue(id);
            if (removed) {
                await buildNotif.notifyQueueCancelled(bot, q.message.chat.id, q.message.message_id);
            } else {
                await bot.sendMessage(q.message.chat.id, `<b>✕ Kamu tidak di antrian.</b>`, { parse_mode: "HTML" });
            }
        } catch (e) {
            console.log("[QUEUE CANCEL ERR]", e.message);
        }
        return;
    }

    // ROUTER
    try {
        return await router(bot, q, data, user, buildPanelCtx());
    } catch (e) {
        console.log("[ROUTER CALL ERR]", e.message);
        try {
            await bot.answerCallbackQuery(q.id, {
                text: "Error: " + e.message.slice(0, 100),
                show_alert: true
            }).catch(() => {});
        } catch {}
    }
});

// ═══════════════════════════════════════════
// MESSAGE HANDLER — URUTAN FINAL
// ═══════════════════════════════════════════
bot.on("message", async (msg) => {
    if (!msg.text && !msg.photo && !msg.video && !msg.document && !msg.audio && !msg.voice) return;

    const id = msg.from.id;

    // ═══════════════════════════════════════════
    // ⚡ PRIORITAS 1: LOGIN USER SESSION FLOW (PALING ATAS)
    // ═══════════════════════════════════════════
    try {
        if (ownerModule && typeof ownerModule.isInLoginFlow === "function" && ownerModule.isInLoginFlow(id)) {
            console.log("[INTERCEPT] Login flow user:", id, "text:", (msg.text || "").slice(0, 30));
            await ownerModule.handleLoginMessage(bot, msg, buildPanelCtx());
            return;
        }
    } catch (e) {
        console.log("[LOGIN INTERCEPT ERR]", e.message);
    }

    // ═══ PRIORITAS 2: GROUP HANDLER ═══
    if (msg.chat.type === "group" || msg.chat.type === "supergroup") {
        try { await groupgate.handleMessage(bot, msg, { db, gate }); }
        catch (e) { console.log("[GROUPGATE ERR]", e.message); }

        try { await guard.handleMessage(bot, msg, { db, gate }); }
        catch (e) { console.log("[GUARD ERR]", e.message); }
    }

    // ═══ PRIORITAS 3: SKIP COMMAND ═══
    if (msg.text && msg.text.startsWith("/")) {
        return;
    }

    // ═══ PRIORITAS 4: CEK STATE BIASA ═══
    const state = getState(id);
    if (!state) return;

    // ═══ PRIORITAS 5: GATE CHECK ═══
    if (String(id) !== String(cfg.OWNER_ID)) {
        try {
            const join = await gate.checkJoin(bot, id);
            if (!join.ok) return;
        } catch {}
    }

    // ═══ PRIORITAS 6: ROUTER MESSAGE ═══
    try {
        return await router.message(bot, msg, state, buildPanelCtx());
    } catch (e) {
        console.log("[ROUTER MSG ERR]", e.message);
        return bot.sendMessage(msg.chat.id, "Error: " + e.message.slice(0, 200), { parse_mode: "HTML" }).catch(() => {});
    }
});

bot.on("polling_error", (e) => {
    if (!e.message.includes("EFATAL")) console.log("[POLLING]", e.message);
});

// ═══ SHUTDOWN ═══
process.on("SIGINT", () => {
    console.log("[SHUTDOWN] SIGINT received");
    if (autoBackup) try { autoBackup.stopAutoBackup(); } catch {}
    process.exit(0);
});

process.on("SIGTERM", () => {
    console.log("[SHUTDOWN] SIGTERM received");
    if (autoBackup) try { autoBackup.stopAutoBackup(); } catch {}
    process.exit(0);
});

console.log("𖡛 𝗕𝗢𝗧 𝗠𝗨𝗟𝗧𝗜 𝗙𝗨𝗡𝗚𝗦𝗜 aktif...");
console.log("[DB]", DB_DIR);
console.log("[CH]", cfg.CHANNELS.length);
console.log("[OWNER]", cfg.OWNER_ID);