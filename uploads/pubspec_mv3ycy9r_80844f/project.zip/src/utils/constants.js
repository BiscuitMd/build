module.exports = {
  PORT: process.env.PORT || 2005,
  WS_PORT: process.env.WS_PORT || 2005,
  // WhatsApp bug types
  BUGS: [
    { bug_id: "click", bug_name: "FC 1 MSG" },
    { bug_id: "call", bug_name: "FC CALL" },
    { bug_id: "invisible", bug_name: "DELAY HARD X INVISIBLE" },
    { bug_id: "hard", bug_name: "BLANK ANDRO" },  
    { bug_id: "ios_invis", bug_name: "CRASH IOS" },
    { bug_id: "spam_call", bug_name: "Call Spam" },
  ],
    
  payload: [
    { bug_id: "click", bug_name: "1 MSG Crash" },
    { bug_id: "invisible", bug_name: "Freeze Click" },
    { bug_id: "ios_invis", bug_name: "Loca IOS" },
    { bug_id: "invisible", bug_name: "Delay Invisible ( 75 MSG )" },
    { bug_id: "hard", bug_name: "Crash Perma Click" },
    { bug_id: "invisible", bug_name: "Crash Call" },
    { bug_id: "permenCall", bug_name: "Call" },    
  ],
    
  DDOS: [
    { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
    { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
    { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
    { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
    { ddos_id: "icmp", ddos_name: "ICMP Flood" },
    { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }

  ],
  // News data
  NEWS: [
    {
      image: "https://files.catbox.moe/v2pe42.jpg",
      title: "Remastered",
      desc: "Powered By @Ravionshare"
    }
  ],
  // Role cooldowns (in seconds)
  ROLE_COOLDOWNS: {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    vip: 60,
  },
  // Max quantities by role
  MAX_QUANTITIES: {
    member: 5,
    reseller: 5,
    reseller1: 5,
    owner: 10,
    vip: 10,
  }
};