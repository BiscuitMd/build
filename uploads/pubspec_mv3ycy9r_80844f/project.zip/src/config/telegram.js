module.exports = {
  TOKEN: process.env.TELEGRAM_TOKEN || "BOT_TOKEN_LU",
  OWNER_ID: process.env.OWNER_ID || ID_LU,
  ID_GROUP: [
    -1003211137137 // GNTI JDI ID GROUP LU
  ],
  ID_GROUP_UTAMA: [
    -1003211137137 // GNTI JDI ID GROUP LU
  ]
};